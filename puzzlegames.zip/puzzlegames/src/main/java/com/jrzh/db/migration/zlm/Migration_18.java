package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建导师用户关联表zlm_member_users
 * @author Xanthin
 *
 */
public class Migration_18 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_member_users";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_18##########Begin");
		table(TABLE_NAME, "客服类别表", true, 
				pk(),
				jrVarchar("_user_id", "管理员用户ID", 64),
				jrVarchar("_member_id", "平台用户ID", 64));
		log.info("##########执行涨了么项目 Migration_18##########End");
	}

}
