package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建广场广告图zlm_plaza_ad
 * @author Luominqi
 *
 */
public class Migration_20 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_plaza_ad";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_20##########Begin");
		table(TABLE_NAME, "广场广告图", true, 
				pk(),
				jrVarchar("_img_name", "图片名称", 128),
				jrVarchar("_img_url", "图片路径", 512),
				jrVarchar("_img_link", "图片链接", 512),
				jrVarchar("_img_type", "图片类型", 64));
		log.info("##########执行涨了么项目 Migration_20##########End");
	}

}
