package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建常见问题表zlm_server_question和意见反馈表zlm_server_feedback
 * @author Xanthin
 *
 */
public class Migration_10 extends BaseMigration{
	
	private static final String TABLE_NAME_ONE = "zlm_server_question";
	private static final String TABLE_NAME_TWO = "zlm_server_feedback";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME_ONE);
		MigrationHelper.dropTable(TABLE_NAME_TWO);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_10##########Begin");
		table(TABLE_NAME_ONE, "常见问题表", true, 
				pk(),
				jrVarchar("_question", "问题", 64),
				jrVarchar("_answer", "答案", 1024),
				jrVarchar("_user_name", "创建人", 64));
		table(TABLE_NAME_TWO, "意见反馈表", true, 
				pk(),
				jrVarchar("_opinion", "反馈意见", 1024),
				jrVarchar("_mobile", "联系方式", 64),
				jrVarchar("_user_id", "用户ID", 64),
				jrVarchar("_user_name", "用户名称", 64),
				jrInt("_status", "反馈状态"));
		log.info("##########执行涨了么项目 Migration_10##########End");
	}

}
