package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建用户收藏表zlm_collect
 * @author LuoMingQi
 *
 */
public class Migration_33 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_collect";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_33##########Begin");
		table(TABLE_NAME, "用户收藏表", true, 
				pk(),
				jrVarchar("_user_id", "用户ID", 64),
				jrVarchar("_circle_id", "话题ID", 64),
				jrTimestamp("_datetime", "收藏时间"));
		log.info("##########执行涨了么项目 Migration_33##########End");
	}

}
