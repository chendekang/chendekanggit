package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建圈子分类菜单表zlm_bbs_menu
 * @author Xanthin
 *
 */
public class Migration_4 extends BaseMigration {
	
	private static final String TABLE_NAME = "zlm_bbs_menu";

	@Override
	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_4##########Begin");
		table(TABLE_NAME, "圈子分类菜单表", true, 
				pk(),
				jrVarchar("_code", "编号", 64),
				jrVarchar("_pid", "级别", 36),
				jrVarchar("_name", "名称", 256),
				jrVarchar("_description", "描述", 512),
				jrVarchar("_img_url", "圈子图片", 512),
				jrVarchar("_img_type", "图片格式", 64),
				jrVarchar("_img_size", "图片大小", 64));
		log.info("##########执行涨了么项目 Migration_4##########End");
	}

}
