package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * zlm_gold_historys删除_type字段
 * @author zlm_gold_historys
 *
 */
public class Migration_41 extends BaseMigration {
	
	private static final String TABLE_NAME = "zlm_gold_historys";

	@Override
	public void down() {
		addColumn(TABLE_NAME, "_type", "类型", DataTypes.INTEGER,1);
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_41##########Begin");
		MigrationHelper.dropColumn("_type", TABLE_NAME);
		log.info("##########执行涨了么项目 Migration_41##########End");
	}

}
