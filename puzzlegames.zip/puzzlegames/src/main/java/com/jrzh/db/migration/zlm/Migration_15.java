package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建用户自选表zlm_member_optional
 * @author Xanthin
 *
 */
public class Migration_15 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_member_optional";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_15##########Begin");
		table(TABLE_NAME, "用户自选表", true, 
				pk(),
				jrVarchar("_user_id", "用户ID", 64),
				jrVarchar("_product_code", "产品代码", 512));
		log.info("##########执行涨了么项目 Migration_15##########End");
	}

}
