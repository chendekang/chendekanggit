package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * TabBar文字图片表zlm_tabbars增加_default_img_url_two，_default_img_url_three，_pressed_img_url_two，
 * _pressed_img_url_three，_defaul_img_type_two，_defaul_img_type_three，_pressed_img_type_two，_pressed_img_type_three
 * @author Administrator
 *
 */
public class Migration_31 extends BaseMigration{
	
	private static final String TABLE_NAME="zlm_tabbars";
	
	@Override
	public void down() {
		MigrationHelper.dropColumn("_default_img_url_two", TABLE_NAME);
		MigrationHelper.dropColumn("_default_img_url_three", TABLE_NAME);
		MigrationHelper.dropColumn("_pressed_img_url_two", TABLE_NAME);
		MigrationHelper.dropColumn("_pressed_img_url_three", TABLE_NAME);
		MigrationHelper.dropColumn("_defaul_img_type_two", TABLE_NAME);
		MigrationHelper.dropColumn("_defaul_img_type_three", TABLE_NAME);
		MigrationHelper.dropColumn("_pressed_img_type_two", TABLE_NAME);
		MigrationHelper.dropColumn("_pressed_img_type_three", TABLE_NAME);
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_31##########Begin");
		addColumn(TABLE_NAME, "_default_img_url_two", "点击前二档", DataTypes.VARCHAR, 512);
		addColumn(TABLE_NAME, "_defaul_img_type_two", "点击前二档图片类型", DataTypes.VARCHAR, 128);
		addColumn(TABLE_NAME, "_default_img_url_three", "点击前三档", DataTypes.VARCHAR, 512);
		addColumn(TABLE_NAME, "_defaul_img_type_three", "点击前三档图片类型", DataTypes.VARCHAR, 128);
		addColumn(TABLE_NAME, "_pressed_img_url_two", "点击后二档", DataTypes.VARCHAR, 512);
		addColumn(TABLE_NAME, "_pressed_img_type_two", "点击后二档图片类型", DataTypes.VARCHAR, 128);
		addColumn(TABLE_NAME, "_pressed_img_url_three", "点击后三档", DataTypes.VARCHAR, 512);
		addColumn(TABLE_NAME, "_pressed_img_type_three", "点击后三档图片类型", DataTypes.VARCHAR, 128);
		log.info("##########执行涨了么项目 Migration_31##########End");
	}

}
