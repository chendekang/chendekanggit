package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define;
import com.eroi.migrate.Define.DataTypes;
import com.eroi.migrate.Execute;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 话题表zlm_bbs_topic和zlm_bbs_topic_audit_log增加_issue_time和_audit_time字段
 * @author Xanthin
 *
 */
public class Migration_22 extends BaseMigration{
	
	private static final String TABLE_NAME_ONE = "zlm_bbs_topic";
	private static final String TABLE_NAME_TWO = "zlm_bbs_topic_audit_log";

	public void down() {
		MigrationHelper.dropColumn("_audit_time", TABLE_NAME_ONE);
		MigrationHelper.dropColumn("_issue_time", TABLE_NAME_TWO);
		MigrationHelper.dropColumn("_audit_time", TABLE_NAME_TWO);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_22##########Begin");
		Execute.addColumn(Define.column("_audit_time", DataTypes.TIMESTAMP, Define.defaultValue(null)), TABLE_NAME_ONE);
		Execute.addColumn(Define.column("_issue_time", DataTypes.TIMESTAMP, Define.defaultValue(null)), TABLE_NAME_TWO);
		Execute.addColumn(Define.column("_audit_time", DataTypes.TIMESTAMP, Define.defaultValue(null)), TABLE_NAME_TWO);
		log.info("##########执行涨了么项目 Migration_22##########End");
	}

}
