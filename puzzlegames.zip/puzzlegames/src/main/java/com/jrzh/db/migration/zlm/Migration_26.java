package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建话题回复消息表zlm_bbs_reply和话题点赞表zlm_bbs_praise
 * 话题表zlm_bbs_topic增加平均值字段，话题粉丝表增加字段
 * @author Xanthin
 *
 */
public class Migration_26 extends BaseMigration{
	
	private static final String TABLE_NAME_ONE = "zlm_bbs_reply";
	private static final String TABLE_NAME_TWO = "zlm_bbs_praise";
	private static final String TABLE_NAME_THREE = "zlm_bbs_topic";
	private static final String TABLE_NAME_FOUR = "zlm_bbs_fans";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME_ONE);
		MigrationHelper.dropTable(TABLE_NAME_TWO);
		MigrationHelper.dropColumn("_average", TABLE_NAME_THREE);
		MigrationHelper.dropColumn("_topic_num", TABLE_NAME_FOUR);
		MigrationHelper.dropColumn("_praise_num", TABLE_NAME_FOUR);
		MigrationHelper.dropColumn("_reply_num", TABLE_NAME_FOUR);
		MigrationHelper.dropColumn("_average", TABLE_NAME_FOUR);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_26##########Begin");
		table(TABLE_NAME_ONE, "话题回复消息表", true, 
				pk(),
				jrVarchar("_topic_id", "话题ID", 64),
				jrVarchar("_content", "回复内容", 64),
				jrVarchar("_user_id", "用户ID", 64));
		
		table(TABLE_NAME_TWO, "话题点赞表", true, 
				pk(),
				jrVarchar("_topic_id", "话题ID", 64),
				jrVarchar("_user_id", "用户ID", 64));
		
		MigrationHelper.addDecimalColumn("_average", TABLE_NAME_THREE, 15, 4, "_praise");
		MigrationHelper.addColumnCommnent(TABLE_NAME_THREE, "_average", "DECIMAL", 0, "评论数和点赞数平均值");
		addColumn(TABLE_NAME_FOUR, "_topic_num", "话题数", DataTypes.BIGINT,512);
		addColumn(TABLE_NAME_FOUR, "_praise_num", "点赞数", DataTypes.BIGINT,512);
		addColumn(TABLE_NAME_FOUR, "_reply_num", "评论数", DataTypes.BIGINT,512);
		MigrationHelper.addDecimalColumn("_average", TABLE_NAME_FOUR, 15, 4, "_reply_num");
		MigrationHelper.addColumnCommnent(TABLE_NAME_FOUR, "_average", "DECIMAL", 0, "发帖数、评论数和点赞数平均值");
		log.info("##########执行涨了么项目 Migration_26##########End");
	}

}
