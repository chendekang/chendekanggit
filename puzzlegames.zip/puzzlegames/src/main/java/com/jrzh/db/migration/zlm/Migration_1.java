package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Configure;
import com.eroi.migrate.Engine;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建APP广告图表zlm_banners
 * @author Xanthin
 *
 */
public class Migration_1 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_banners";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_1##########Begin");
		table(TABLE_NAME, "APP广告图表", true, 
				pk(),
				jrVarchar("_img_name", "图片名称", 128),
				jrVarchar("_img_url", "图片路径", 512),
				jrVarchar("_img_link", "图片链接", 512),
				jrVarchar("_img_type", "图片格式", 64),
				jrVarchar("_img_size", "图片大小", 64));
		log.info("##########执行涨了么项目 Migration_1##########End");
	}
	
	public static void main(String[] args) {
		Configure.configure("jdbc:mysql://localhost:3306/zhanglm?useUnicode=true&characterEncoding=utf-8", 
				"com.mysql.jdbc.Driver", 
				"root", 
				"123456", 
				"", "com.jrzh.db.migration.zlm", 
				Configure.DEFAULT_CLASSNAME_PREFIX,
				Configure.DEFAULT_SEPARATOR, 
				Configure.DEFAULT_START_INDEX, 
				"version_zlm");
		Engine.migrate();
	}
}
