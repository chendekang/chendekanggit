package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建消息模板表zlm_message_templates
 * @author Xanthin
 *
 */
public class Migration_3 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_message_templates";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_3##########Begin");
		table(TABLE_NAME, "消息模板表", true, 
				pk(),
				jrVarchar("_code", "模板编号", 128),
				jrVarchar("_name", "模板名称", 256),
				jrVarchar("_mobile_content", "短信内容", 512),
				jrVarchar("_platform_content", "平台消息", 512),
				jrTinyint("_is_send_mobile", "是否发送短信"),
				jrTinyint("_is_send_platform", "是否发送平台消息"));
		log.info("##########执行涨了么项目 Migration_3##########End");
	}

}
