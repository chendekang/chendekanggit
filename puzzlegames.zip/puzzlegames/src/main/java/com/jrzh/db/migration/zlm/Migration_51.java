package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 首页活动图片管理zlm_activity_picture
 * @author LuoMingQi
 *
 */
public class Migration_51 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_activity_picture";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_51##########Begin");
		table(TABLE_NAME, "首页活动图片管理", true, 
				pk(),
				jrVarchar("_img_name", "图片名称", 128),
				jrVarchar("_img_url", "图片路径", 512),
				jrVarchar("_img_type", "图片类型", 64));
		log.info("##########执行涨了么项目 Migration_51##########End");
	}

}
