package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 分享页面管理zlm_share_page
 * @author LuoMingQi
 *
 */
public class Migration_48 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_share_page";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_48##########Begin");
		table(TABLE_NAME, "分享页面管理", true, 
				pk(),
				jrVarchar("_img_url", "图片路径", 512),
				jrVarchar("_name", "标题名称", 128),
				jrVarchar("_content", "内容", 64));
		log.info("##########执行涨了么项目 Migration_48##########End");
	}

}
