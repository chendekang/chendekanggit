package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 用户信息表zlm_members增加_real_name、_id_card、_bank_acco字段
 * @author Xanthin
 *
 */
public class Migration_19 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_members";

	public void down() {
		MigrationHelper.dropColumn("_real_name", TABLE_NAME);
		MigrationHelper.dropColumn("_id_card", TABLE_NAME);
		MigrationHelper.dropColumn("_bank_acco", TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_19##########Begin");
		addColumn(TABLE_NAME, "_real_name", "真实姓名", DataTypes.VARCHAR, 64);
		addColumn(TABLE_NAME, "_id_card", "身份证号", DataTypes.VARCHAR, 128);
		addColumn(TABLE_NAME, "_bank_acco", "银行卡号", DataTypes.VARCHAR, 128);
		log.info("##########执行涨了么项目 Migration_19##########End");
	}

}
