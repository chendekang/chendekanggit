package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建话题评论回复表zlm_comment_reply
 * @author LuoMingQi
 *
 */
public class Migration_39 extends BaseMigration {
	
	private static final String TABLE_NAME = "zlm_comment_reply";

	@Override
	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_39##########Begin");
		table(TABLE_NAME, "专栏分类管理表", true, 
				pk(),
				jrVarchar("_user_id", "用户Id", 64),
				jrVarchar("_comment", "评论回复内容", 256),
				jrVarchar("_comment_id", "评论Id", 64),
				jrVarchar("_reply_id", "话题Id", 64));
		log.info("##########执行涨了么项目 Migration_39##########End");
	}

}
