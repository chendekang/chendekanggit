package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建圈子粉丝表zlm_bbs_fans
 * @author Xanthin
 *
 */
public class Migration_25 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_bbs_fans";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_25##########Begin");
		table(TABLE_NAME, "圈子粉丝表", true, 
				pk(),
				jrVarchar("_menu_id", "圈子ID", 64),
				jrVarchar("_user_id", "用户ID", 64));
		log.info("##########执行涨了么项目 Migration_25##########End");
	}

}
