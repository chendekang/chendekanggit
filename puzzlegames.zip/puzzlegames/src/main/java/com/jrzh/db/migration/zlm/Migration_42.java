package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 重建客服人员管理zlm_server_person
 * @author LuoMingQi
 *
 */
public class Migration_42 extends BaseMigration {
	
	private static final String TABLE_ONE = "zlm_server_person";
	private static final String TABLE_TWO = "zlm_service_person";

	@Override
	public void down() {
		MigrationHelper.dropTable(TABLE_ONE);
		table(TABLE_TWO, "客服人员管理", true, 
				pk(),
				jrVarchar("_user_name", "客服人员名称", 64),
				jrVarchar("_number", "客服人员编号", 256),
				jrVarchar("_categoryId", "客服类别Id", 64));
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_42##########Begin");
		MigrationHelper.dropTable(TABLE_TWO);
		table(TABLE_ONE, "客服人员管理", true, 
				pk(),
				jrVarchar("_user_name", "客服人员名称", 64),
				jrVarchar("_number", "客服人员编号", 256),
				jrVarchar("_categoryId", "客服类别Id", 64));
		log.info("##########执行涨了么项目 Migration_42##########End");
	}

}
