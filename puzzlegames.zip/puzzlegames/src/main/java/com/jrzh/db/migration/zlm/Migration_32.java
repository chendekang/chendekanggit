package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 直播室数据表zlm_zhibo_lives重建_zhibo_url字段
 * @author LuoMingQi
 *
 */
public class Migration_32 extends BaseMigration{
	
	private static final String TABLE_NAME_ONE = "zlm_zhibo_lives";

	public void down() {
		MigrationHelper.dropColumn("_zhibo_url", TABLE_NAME_ONE);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_32##########Begin");
		MigrationHelper.dropColumn("_zhibo_url", TABLE_NAME_ONE);
		addColumn(TABLE_NAME_ONE, "_zhibo_url", "拉取视频地址", DataTypes.VARCHAR,512);
		log.info("##########执行涨了么项目 Migration_32##########End");
	}

}
