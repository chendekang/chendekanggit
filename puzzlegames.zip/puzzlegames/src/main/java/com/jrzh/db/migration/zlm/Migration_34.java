package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建tabbar类型表zlm_tabbar_type
 * @author Administrator
 *
 */
public class Migration_34 extends BaseMigration{
	private static final String TABLIE_NAME="zlm_tabbar_type";
	@Override
	public void down() {
		MigrationHelper.dropTable(TABLIE_NAME);
	}

	@Override
	public void up() {
		table(TABLIE_NAME, "tabbar类型表", true, 
				pk(),
				jrVarchar("_name", "类别名称",128),
				jrVarchar("_description", "类别描述", 256)
				);
	}

}
