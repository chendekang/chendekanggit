package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 直播室数据表zlm_zhibo_lives增加_port端口号字段
 * @author LuoMingQi
 *
 */
public class Migration_38 extends BaseMigration{
	
	private static final String TABLE_NAME_ONE = "zlm_snapshot_log";

	public void down() {
		MigrationHelper.dropColumn("_type", TABLE_NAME_ONE);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_38##########Begin");
		addColumn(TABLE_NAME_ONE, "_type", "类型（0:1分钟|1：5分钟|2：15分钟|3：30分钟|4：60分钟）", DataTypes.INTEGER,1);
		log.info("##########执行涨了么项目 Migration_38##########End");
	}
}
