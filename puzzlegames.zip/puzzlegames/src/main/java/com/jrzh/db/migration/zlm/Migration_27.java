package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建广场数据表zlm_plaza_datas
 * @author Xanthin
 *
 */
public class Migration_27 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_plaza_datas";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_27##########Begin");
		table(TABLE_NAME, "广场数据表", true, 
				pk(),
				jrVarchar("_user_id", "用户ID", 64),
				jrVarchar("_data_id", "关联数据ID", 64),
				jrInt("_data_category", "数据类别 0--话题  1--直播  2--活动"));
		log.info("##########执行涨了么项目 Migration_27##########End");
	}

}
