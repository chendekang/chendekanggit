package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建预约开户登记表zlm_open_acco_log
 * @author Xanthin
 *
 */
public class Migration_7 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_open_acco_log";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_7##########Begin");
		table(TABLE_NAME, "预约开户登记表", true, 
				pk(),
				jrVarchar("_user_id", "用户ID", 64),
				jrVarchar("_mobile", "手机号码", 64),
				jrInt("_status", "状态"));
		log.info("##########执行涨了么项目 Migration_7##########End");
	}

}
