package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建客服类别表zlm_server_categorys
 * @author Xanthin
 *
 */
public class Migration_16 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_server_categorys";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_16##########Begin");
		table(TABLE_NAME, "客服类别表", true, 
				pk(),
				jrVarchar("_name", "类别名称", 128),
				jrVarchar("_img_url", "图片路径", 512),
				jrVarchar("_img_link", "图片链接", 512),
				jrVarchar("_img_type", "图片格式", 64),
				jrVarchar("_img_size", "图片大小", 64));
		log.info("##########执行涨了么项目 Migration_16##########End");
	}

}
