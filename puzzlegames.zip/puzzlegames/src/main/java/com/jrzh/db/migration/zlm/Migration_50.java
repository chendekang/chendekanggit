package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 圈子话题表zlm_bbs_topic增加_img_url字段
 * @author LuoMingQi
 *
 */
public class Migration_50 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_bbs_topic";

	public void down() {
		MigrationHelper.dropColumn("_img_url", TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_50##########Begin");
		addColumn(TABLE_NAME, "_img_url", "图片路径", DataTypes.VARCHAR,512);
		log.info("##########执行涨了么项目 Migration_50##########End");
	}

}
