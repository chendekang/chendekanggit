package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 给TabBar文字图片表zlm_tabbars增加_pid
 * @author Administrator
 *
 */
public class Migration_36 extends BaseMigration {

	private static final String TABLE_NAME="zlm_tabbars";
	@Override
	public void down() {
		MigrationHelper.dropColumn("_pid", TABLE_NAME);
	}

	@Override
	public void up() {
		addColumn(TABLE_NAME, "_pid", "节点",DataTypes.CHAR, 36);
	}

}
