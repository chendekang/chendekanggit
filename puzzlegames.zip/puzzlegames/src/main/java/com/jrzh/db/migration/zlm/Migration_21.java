package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建用户关注表zlm_member_attentions
 * @author Xanthin
 *
 */
public class Migration_21 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_member_attentions";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_21##########Begin");
		table(TABLE_NAME, "用户关注表", true, 
				pk(),
				jrVarchar("_member_id", "用户ID", 64),
				jrVarchar("_fans_id", "粉丝ID", 64));
		log.info("##########执行涨了么项目 Migration_21##########End");
	}
}
