package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 直播室数据表zlm_zhibo_lives增加_column_code字段
 * @author LuoMingQi
 *
 */
public class Migration_29 extends BaseMigration{
	
	private static final String TABLE_NAME_ONE = "zlm_zhibo_lives";

	public void down() {
		MigrationHelper.dropColumn("_column_code", TABLE_NAME_ONE);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_29##########Begin");
		addColumn(TABLE_NAME_ONE, "_column_code", "栏目编号", DataTypes.VARCHAR,512);
		log.info("##########执行涨了么项目 Migration_29##########End");
	}

}
