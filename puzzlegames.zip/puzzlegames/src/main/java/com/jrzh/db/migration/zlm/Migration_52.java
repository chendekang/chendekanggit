package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 圈子话题表zlm_bbs_topic重建_content字段
 * @author LuoMingQi
 *
 */
public class Migration_52 extends BaseMigration{
	
	private static final String TABLE_NAME_ONE = "zlm_bbs_topic";

	public void down() {
		MigrationHelper.dropColumn("_content", TABLE_NAME_ONE);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_52##########Begin");
		MigrationHelper.alterColumn(TABLE_NAME_ONE, "_content", "text");
		log.info("##########执行涨了么项目 Migration_52##########End");
	}

}
