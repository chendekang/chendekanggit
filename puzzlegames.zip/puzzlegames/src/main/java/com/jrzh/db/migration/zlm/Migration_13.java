package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 意见反馈表zlm_server_feedback增加_reply和_reply_user字段
 * @author Xanthin
 *
 */
public class Migration_13 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_server_feedback";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_13##########Begin");
		addColumn(TABLE_NAME, "_reply", "回复信息", DataTypes.VARCHAR, 512);
		addColumn(TABLE_NAME, "_reply_user", "回复人", DataTypes.VARCHAR, 128);
		log.info("##########执行涨了么项目 Migration_13##########End");
	}

}
