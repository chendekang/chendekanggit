package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建app版本管理zlm_app_version
 * @author Luominqi
 *
 */
public class Migration_23 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_app_version";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_23##########Begin");
		table(TABLE_NAME, "app版本管理", true, 
				pk(),
				jrVarchar("_app_name", "版本名称", 256),
				jrInt("_app_number", "版本号"),
				jrVarchar("_app_url", "文件地址", 512),
		        jrInt("_app_status", "状态"),
		        jrVarchar("_app_qr_code", "二维码", 512));
		log.info("##########执行涨了么项目 Migration_23##########End");
	}

}
