package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建黄金每秒记录表:zlm_snapshot_second_log
 * @author Administrator
 *
 */
public class Migration_44  extends BaseMigration{

	private static final String TABLE_NAME="zlm_snapshot_second_log";
	@Override
	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_44##########Begin");
		table(TABLE_NAME, "黄金每秒记录表",  true, 
				pk(),
				jrInt("_snapshot_id", "对应黄金表id字段"),
				jrVarchar("_old_symbol", "历史产品代码", 255),
				jrVarchar("_old_name", "历史产品名称", 255),
				jrTimestamp("_old_datetime", "历史存入时间"),
				jrDouble("_old_close", "历史最新价"),
				jrDouble("_old_tvolume", "历史成交量"),
				jrDouble("_old_tvalue", "历史持仓量"));
		log.info("##########执行涨了么项目 Migration_44##########End");
	}
	

}
