package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建黄金历史数据表zlm_gold_historys
 * @author Xanthin
 *
 */
public class Migration_5 extends BaseMigration {
	
	private static final String TABLE_NAME = "zlm_gold_historys";

	@Override
	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_5##########Begin");
		table(TABLE_NAME, "黄金历史数据表", true, 
				pk(),
				jrVarchar("_symbol", "代码", 64),
				jrVarchar("_name", "产品名称", 36),
				jrTimestamp("_date_time", "日期时间"));
		MigrationHelper.addDecimalColumn("_open", TABLE_NAME, 15, 4, "_date_time");
		MigrationHelper.addColumnCommnent(TABLE_NAME, "_open", "DECIMAL", 0, "开盘价");
		MigrationHelper.addDecimalColumn("_high", TABLE_NAME, 15, 4, "_open");
		MigrationHelper.addColumnCommnent(TABLE_NAME, "_high", "DECIMAL", 0, "最高价");
		MigrationHelper.addDecimalColumn("_low", TABLE_NAME, 15, 4, "_high");
		MigrationHelper.addColumnCommnent(TABLE_NAME, "_low", "DECIMAL", 0, "最低价");
		MigrationHelper.addDecimalColumn("_close", TABLE_NAME, 15, 4, "_low");
		MigrationHelper.addColumnCommnent(TABLE_NAME, "_close", "DECIMAL", 0, "收盘价");
		MigrationHelper.addDecimalColumn("_tvolume", TABLE_NAME, 15, 4, "_close");
		MigrationHelper.addColumnCommnent(TABLE_NAME, "_tvolume", "DECIMAL", 0, "成交量");
		log.info("##########执行涨了么项目 Migration_5##########End");
	}

}
