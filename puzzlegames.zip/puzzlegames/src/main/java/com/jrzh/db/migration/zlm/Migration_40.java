package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建客服人员管理zlm_service_person
 * @author LuoMingQi
 *
 */
public class Migration_40 extends BaseMigration {
	
	private static final String TABLE_NAME = "zlm_service_person";

	@Override
	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_40##########Begin");
		table(TABLE_NAME, "客服人员管理", true, 
				pk(),
				jrVarchar("_user_name", "客服人员名称", 64),
				jrVarchar("_number", "客服人员编号", 256),
				jrVarchar("_categoryId", "客服类别Id", 64));
		log.info("##########执行涨了么项目 Migration_40##########End");
	}

}
