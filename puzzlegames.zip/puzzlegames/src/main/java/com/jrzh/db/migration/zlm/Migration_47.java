package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 下载路径管理zlm_download
 * @author LuoMingQi
 *
 */
public class Migration_47 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_download";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_47##########Begin");
		table(TABLE_NAME, "下载路径管理", true, 
				pk(),
				jrVarchar("_name", "路径名称", 128),
				jrVarchar("_url", "下载路径", 512),
				jrVarchar("_type", "下载类型", 64));
		log.info("##########执行涨了么项目 Migration_47##########End");
	}

}
