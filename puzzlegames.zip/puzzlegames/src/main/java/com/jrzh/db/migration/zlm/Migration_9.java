package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建圈子话题审核记录表zlm_bbs_topic_audit_log
 * @author Xanthin
 *
 */
public class Migration_9 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_bbs_topic_audit_log";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_9##########Begin");
		table(TABLE_NAME, "圈子话题审核记录表", true, 
				pk(),
				jrVarchar("_topic_id", "关联话题ID", 64),
				jrVarchar("_topic_title", "话题标题", 64),
				jrVarchar("_user_name", "用户名称", 64),
				jrVarchar("_auditer", "审核人", 64),
				jrVarchar("_opinion", "审核说明", 512),
				jrInt("_status", "审核状态"));
		log.info("##########执行涨了么项目 Migration_9##########End");
	}

}
