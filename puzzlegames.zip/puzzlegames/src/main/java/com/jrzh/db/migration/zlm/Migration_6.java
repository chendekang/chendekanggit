package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 用户信息表zlm_members增加_qq_no、_weibo_no、_wechat_no和_login_channel字段
 * @author Xanthin
 *
 */
public class Migration_6 extends BaseMigration {
	
	private static final String TABLE_NAME = "zlm_members";

	@Override
	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_6##########Begin");
		addColumn(TABLE_NAME, "_photo", "头像图片路径", DataTypes.VARCHAR, 512);
		addColumn(TABLE_NAME, "_qq_no", "绑定QQ账号", DataTypes.VARCHAR, 128);
		addColumn(TABLE_NAME, "_weibo_no", "绑定微博账号", DataTypes.VARCHAR, 128);
		addColumn(TABLE_NAME, "_wechat_no", "绑定微信账号", DataTypes.VARCHAR, 128);
		addColumn(TABLE_NAME, "_login_channel", "登陆渠道", DataTypes.INTEGER, 64);
		log.info("##########执行涨了么项目 Migration_6##########End");
	}

}
