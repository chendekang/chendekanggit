package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建圈子话题表zlm_bbs_topic
 * @author Xanthin
 *
 */
public class Migration_8 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_bbs_topic";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_8##########Begin");
		table(TABLE_NAME, "圈子话题表", true, 
				pk(),
				jrVarchar("_title", "标题", 64),
				jrVarchar("_content", "内容", 512),
				jrVarchar("_user_id", "发布用户ID", 64),
				jrVarchar("_user_name", "发布用户昵称", 64),
				jrInt("_discuss", "评论数"),
				jrInt("_praise", "点赞数"),
				jrVarchar("_menu_code", "所属类别", 64),
				jrInt("_status", "状态"),
				jrVarchar("_auditer", "审核人", 64),
				jrVarchar("_opinion", "审核说明", 512));
		log.info("##########执行涨了么项目 Migration_8##########End");
	}

}
