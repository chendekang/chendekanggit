package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define;
import com.eroi.migrate.Define.DataTypes;
import com.eroi.migrate.Execute;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建直播室数据表zlm_zhibo_lives
 * @author Xanthin
 *
 */
public class Migration_24 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_zhibo_lives";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_24##########Begin");
		table(TABLE_NAME, "直播室数据表", true, 
				pk(),
				jrVarchar("_user_id", "用户ID", 64),
				jrVarchar("_title", "标题", 64),
				jrVarchar("_intro", "简介", 64),
				jrVarchar("_img_name", "图片名称", 128),
				jrVarchar("_img_url", "图片路径", 512),
				jrVarchar("_img_type", "图片类型", 64),
				jrBigint("_collect_num", "收藏量"),
				jrBigint("_click_num", "点击量"),
				jrVarchar("_zhibo_url", "拉取视频地址", 64));
		Execute.addColumn(Define.column("_start_time", DataTypes.TIMESTAMP, Define.defaultValue(null)), TABLE_NAME);//开始时间
		Execute.addColumn(Define.column("_end_time", DataTypes.TIMESTAMP, Define.defaultValue(null)), TABLE_NAME);//结束时间
		log.info("##########执行涨了么项目 Migration_24##########End");
	}
}
