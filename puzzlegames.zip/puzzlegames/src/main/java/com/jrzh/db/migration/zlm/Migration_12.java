package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 提现审核记录表zlm_withdraw_audit_log
 * @author LuoMingQi
 *
 */
public class Migration_12 extends BaseMigration{
	
	private static final String TABLE_NAME_ONE = "zlm_withdraw_audit_log";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME_ONE);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_12##########Begin");
		table(TABLE_NAME_ONE, "提现审核记录表", true, 
				pk(),
				jrVarchar("_user_name", "用户名称", 30),
				jrVarchar("_auditor", "审核人", 30),
		        jrVarchar("_status", "审核状态", 20),
		        jrVarchar("_audit_result", "审核结果", 20));
		MigrationHelper.addDecimalColumn("_draw_money", TABLE_NAME_ONE, 15, 4, "_user_name");
		MigrationHelper.addColumnCommnent(TABLE_NAME_ONE, "_draw_money", "DECIMAL", 0, "提现金额");
		log.info("##########执行涨了么项目 Migration_12##########End");
	}

}
