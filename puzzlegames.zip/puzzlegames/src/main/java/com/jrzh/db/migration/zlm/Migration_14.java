package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建用户消息表zlm_member_msgs
 * @author Xanthin
 *
 */
public class Migration_14 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_member_msgs";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_14##########Begin");
		table(TABLE_NAME, "创建用户消息表", true, 
				pk(),
				jrVarchar("_title", "消息标题", 64),
				jrVarchar("_content", "消息内容", 512),
				jrVarchar("_user_id", "收信人ID", 64),
				jrInt("_status", "消息状态"),
				jrVarchar("_sender_id", "发件人ID", 64));
		log.info("##########执行涨了么项目 Migration_14##########End");
	}

}
