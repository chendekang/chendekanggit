package com.jrzh.db.migration.zlm;

import com.eroi.migrate.Define.DataTypes;
import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 直播室数据表zlm_zhibo_lives增加_share_num字段
 * 圈子话题表zlm_bbs_topic增加_click_num字段
 * 黄金历史数据表zlm_gold_historys增加_tvalue字段
 * @author LuoMingQi
 *
 */
public class Migration_43 extends BaseMigration{
	
	private static final String TABLE_NAME_ONE = "zlm_zhibo_lives";
	private static final String TABLE_NAME_TWO = "zlm_bbs_topic";
	private static final String TABLE_NAME_THREE = "zlm_gold_historys";

	public void down() {
		MigrationHelper.dropColumn("_share_num", TABLE_NAME_ONE);
		MigrationHelper.dropColumn("_click_num", TABLE_NAME_TWO);
		MigrationHelper.dropColumn("_tvalue", TABLE_NAME_THREE);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_43##########Begin");
		addColumn(TABLE_NAME_ONE, "_share_num", "分享量", DataTypes.BIGINT,20);
		addColumn(TABLE_NAME_TWO, "_click_num", "点击量", DataTypes.BIGINT,20);
		addColumn(TABLE_NAME_THREE, "_tvalue", "持仓量", DataTypes.DOUBLE,15,4);
		log.info("##########执行涨了么项目 Migration_43##########End");
	}

}
