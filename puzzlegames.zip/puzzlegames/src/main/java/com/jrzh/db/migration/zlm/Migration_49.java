package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 黄金推荐表zlm_gold_recommend
 * @author LuoMingQi
 *
 */
public class Migration_49 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_gold_recommend";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_49##########Begin");
		table(TABLE_NAME, "黄金推荐表", true, 
				pk(),
				jrInt("_snapshot_id", "关联黄金ID"));
		      MigrationHelper.addCommonColumns(TABLE_NAME);
		log.info("##########执行涨了么项目 Migration_49##########End");
	}

}
