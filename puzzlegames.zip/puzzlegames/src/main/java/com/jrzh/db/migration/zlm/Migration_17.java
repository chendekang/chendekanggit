package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 重建zlm_withdraw_audit_log表
 * @author LuoMingQi
 *
 */
public class Migration_17 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_withdraw_audit_log";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		//删表
		MigrationHelper.dropTable(TABLE_NAME);
		//重新建表
		log.info("##########执行涨了么项目 Migration_17##########Begin");
		table(TABLE_NAME, "提现审核记录表", true, 
				pk(),
				jrVarchar("_user_id", "用户ID", 32),
				jrVarchar("_user_name", "用户名称", 32),
				jrVarchar("_auditor", "审核人", 32),
		        jrVarchar("_status", "审核说明", 640),
		        jrInt("_audit_state", "审核状态"));
		MigrationHelper.addDecimalColumn("_draw_money", TABLE_NAME, 15, 4, "_user_name");
		MigrationHelper.addColumnCommnent(TABLE_NAME, "_draw_money", "DECIMAL", 0, "提现金额");
		log.info("##########执行涨了么项目 Migration_17##########End");
	}

}
