package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建专栏分类管理表zlm_special_column
 * @author LuoMingQi
 *
 */
public class Migration_28 extends BaseMigration {
	
	private static final String TABLE_NAME = "zlm_special_column";

	@Override
	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	@Override
	public void up() {
		log.info("##########执行涨了么项目 Migration_28##########Begin");
		table(TABLE_NAME, "专栏分类管理表", true, 
				pk(),
				jrVarchar("_code", "编号", 64),
				jrVarchar("_name", "名称", 256));
		log.info("##########执行涨了么项目 Migration_28##########End");
	}

}
