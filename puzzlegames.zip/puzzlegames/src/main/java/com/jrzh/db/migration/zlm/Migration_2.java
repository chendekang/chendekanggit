package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建用户信息表zlm_members
 * @author Xanthin
 *
 */
public class Migration_2 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_members";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_1##########Begin");
		table(TABLE_NAME, "APP广告图表", true, 
				pk(),
				jrVarchar("_nick_name", "用户昵称", 64),
				jrVarchar("_mobile", "手机号码", 64),
				jrVarchar("_signature", "个性签名", 512),
				jrVarchar("_intro", "简介", 512),
				jrBigint("_m_coin", "么币"),
				jrVarchar("_login_pass", "登陆密码", 64));
		MigrationHelper.addDecimalColumn("_capital", TABLE_NAME, 15, 4, "_intro");
		MigrationHelper.addColumnCommnent(TABLE_NAME, "_capital", "DECIMAL", 0, "个人资产");
		MigrationHelper.addDecimalColumn("_balance", TABLE_NAME, 15, 4, "_capital");
		MigrationHelper.addColumnCommnent(TABLE_NAME, "_balance", "DECIMAL", 0, "可用余额");
		log.info("##########执行涨了么项目 Migration_1##########End");
	}

}
