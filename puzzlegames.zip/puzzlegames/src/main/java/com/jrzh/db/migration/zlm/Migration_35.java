package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建tabbar资源表zlm_tabbar_resource
 * @author Administrator
 *
 */
public class Migration_35 extends BaseMigration {
	private static final String TABLIE_NAME="zlm_tabbar_resource";

	@Override
	public void down() {
		MigrationHelper.dropTable(TABLIE_NAME);
	}

	@Override
	public void up() {
		table(TABLIE_NAME, "tabbar资源表", true, 
				pk(),
				jrChar("_type_id", "所属类别",36),
				jrChar("_tabbar_version_id", "所属版本",36),
				jrInt("_resource_type", "0---点击前  1----点击后"),
				jrVarchar("_tabbar_img", "文件路径",512),
				jrVarchar("_tabbar_img_type", "图片类型", 128),
				jrVarchar("_tabbar_img_name", "图片名称", 512)
			);
	}
}
