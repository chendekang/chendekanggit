package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 创建TabBar文字图片表zlm_tabbars
 * @author Xanthin
 *
 */
public class Migration_11 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_tabbars";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_11##########Begin");
		table(TABLE_NAME, "TabBar文字图片表", true, 
				pk(),
				jrVarchar("_tab_name", "Tab文字", 64),
				jrVarchar("_default_img_url", "点击前图片路径", 512),
				jrVarchar("_pressed_img_url", "点击后图片路径", 512),
				jrVarchar("_defaul_img_type", "点击前图片格式", 64),
				jrVarchar("_pressed_img_type", "点击后图片格式", 64),
				jrVarchar("_mobile_category", "移动操作系统", 64),
				jrVarchar("_tab_intro", "Tab版本描述", 64),
				jrInt("_tab_version", "Tab版本号"));
		log.info("##########执行涨了么项目 Migration_11##########End");
	}

}
