package com.jrzh.db.migration.zlm;

import com.jrzh.framework.migration.BaseMigration;
import com.jrzh.framework.migration.MigrationHelper;
/**
 * 用户默认头像zlm_default
 * @author LuoMingQi
 *
 */
public class Migration_46 extends BaseMigration{
	
	private static final String TABLE_NAME = "zlm_default";

	public void down() {
		MigrationHelper.dropTable(TABLE_NAME);
	}

	public void up() {
		log.info("##########执行涨了么项目 Migration_46##########Begin");
		table(TABLE_NAME, "用户默认头像", true, 
				pk(),
				jrVarchar("_img_name", "图片名称", 128),
				jrVarchar("_img_url", "图片路径", 512),
				jrVarchar("_img_type", "图片类型", 64));
		log.info("##########执行涨了么项目 Migration_46##########End");
	}

}
