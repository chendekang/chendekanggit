package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.MemberOptionalModel;
import com.jrzh.mvc.view.zhanglm.MemberOptionalView;

public class MemberOptionalConvert implements BaseConvertI<MemberOptionalModel, MemberOptionalView> {

	@Override
	public MemberOptionalModel addConvert(MemberOptionalView view) throws ProjectException {
		MemberOptionalModel model = new MemberOptionalModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public MemberOptionalModel editConvert(MemberOptionalView view, MemberOptionalModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public MemberOptionalView convertToView(MemberOptionalModel model) throws ProjectException {
		MemberOptionalView view = new MemberOptionalView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
