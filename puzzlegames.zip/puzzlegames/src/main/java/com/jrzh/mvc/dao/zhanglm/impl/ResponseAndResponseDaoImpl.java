package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.ResponseAndResponseDaoI;
import com.jrzh.mvc.model.zhanglm.ResponseAndResponseModel;

@Repository("ResponseAndResponseDaoI")
public class ResponseAndResponseDaoImpl extends BaseDaoImpl<ResponseAndResponseModel> implements ResponseAndResponseDaoI{

}