package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class ZhiboCourseSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String equalzbId;
	
	private String likeName;
	
	private Boolean equalIsLock;
	
	private String equalColumnCode;
	
	
	
	public String getEqualColumnCode() {
		return equalColumnCode;
	}

	public void setEqualColumnCode(String equalColumnCode) {
		this.equalColumnCode = equalColumnCode;
	}

	public Boolean getEqualIsLock() {
		return equalIsLock;
	}

	public void setEqualIsLock(Boolean equalIsLock) {
		this.equalIsLock = equalIsLock;
	}

	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}
	public String getEqualzbId() {
		return equalzbId;
	}

	public void setEqualzbId(String equalzbId) {
		this.equalzbId = equalzbId;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalzbId)){
			dc.add(Restrictions.eq("zbId", equalzbId));
		}
	}
}