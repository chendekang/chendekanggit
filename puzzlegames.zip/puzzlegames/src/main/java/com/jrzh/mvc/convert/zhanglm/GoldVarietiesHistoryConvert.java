package com.jrzh.mvc.convert.zhanglm;

import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.GoldVarietiesHistoryModel;
import com.jrzh.mvc.view.zhanglm.GoldHistoryView;
import com.jrzh.mvc.view.zhanglm.GoldVarietiesHistoryView;

public class GoldVarietiesHistoryConvert implements BaseConvertI<GoldVarietiesHistoryModel, GoldVarietiesHistoryView> {

	@Override
	public GoldVarietiesHistoryModel addConvert(GoldVarietiesHistoryView view) throws ProjectException {
		GoldVarietiesHistoryModel model = new GoldVarietiesHistoryModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}
	
	public GoldVarietiesHistoryModel addConvertByStr(GoldHistoryView view) throws ProjectException {
		GoldVarietiesHistoryModel model = new GoldVarietiesHistoryModel();
		model.setSymbol(view.getSymbol());
		model.setName(view.getName());
		model.setDateTime(view.getDateTime());
		if(StringUtils.equals(view.getOpenStr(), "-")){
			model.setOpen(0.0);
		}else{
			model.setOpen(Double.parseDouble(view.getOpenStr()));
		}
		if(StringUtils.equals(view.getHighStr(), "-")){
			model.setHigh(0.0);
		}else{
			model.setHigh(Double.parseDouble(view.getHighStr()));
		}
		if(StringUtils.equals(view.getLowStr(), "-")){
			model.setLow(0.0);
		}else{
			model.setLow(Double.parseDouble(view.getLowStr()));
		}
		if(StringUtils.equals(view.getCloseStr(), "-")){
			model.setClose(0.0);
		}else{
			model.setClose(Double.parseDouble(view.getCloseStr()));
		}
		if(StringUtils.equals(view.getTvolumeStr(), "-")){
			model.setTvolume(0.0);
		}else{
			model.setTvolume(Double.parseDouble(view.getTvolumeStr()));
		}
		if(StringUtils.equals(view.getTvalueStr(),"-")){
			model.setTvalue(0.0);
		}
		return model;
	}

	@Override
	public GoldVarietiesHistoryModel editConvert(GoldVarietiesHistoryView view, GoldVarietiesHistoryModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public GoldVarietiesHistoryView convertToView(GoldVarietiesHistoryModel model) throws ProjectException {
		GoldVarietiesHistoryView view = new GoldVarietiesHistoryView();
		ReflectUtils.copySameFieldToTarget(model, view);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		view.setDateTimeStr(sdf.format(view.getDateTime()));
		view.setCeratedateTimeStr(sdf.format(view.getCreateTime()));
		return view;
	}

}
