package com.jrzh.mvc.controller.zhanglm.ajax;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAjaxController;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.search.zhanglm.BbsMenuSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;

@Controller(BbsTopicController.LOCATION +"/BbsTopicController")
@RequestMapping(BbsTopicController.LOCATION)
public class BbsTopicController extends BaseAjaxController{
	public static final String LOCATION = "zhanglm/ajax/bbs";

	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;

	@RequestMapping(method = RequestMethod.POST, value = "broadMenu")
	@UserEvent(desc = "版块菜单")
	@ResponseBody
	public List<BbsMenuView> broadMenu(BbsMenuSearch search) {
		List<BbsMenuView> viewList = new ArrayList<BbsMenuView>();
	    try{
	    	String pCode = request.getParameter("pCode");
	    	if(StringUtils.isNotBlank(pCode)){
	    		BbsMenuModel pModel = zhanglmServiceManage.bbsMenuService.findByField("code", pCode);
		    	search.setEqualPid(pModel.getId());
		    	viewList = zhanglmServiceManage.bbsMenuService.viewList(search);
	    	}
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return viewList;
	}
	
	@Override
	protected void setData() {
		// TODO Auto-generated method stub
		
	}
	
	
}
