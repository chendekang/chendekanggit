package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.CollectConvert;
import com.jrzh.mvc.model.zhanglm.CollectModel;
import com.jrzh.mvc.search.zhanglm.CollectSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.CollectView;

@Controller(CollectController.LOCATION +"/CollectController")
@RequestMapping(CollectController.LOCATION)
public class CollectController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/collect";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_collect";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "Collect列表查询")
	@ResponseBody
	public EasyuiDataGrid<CollectView> datagrid(CollectSearch search) {
		EasyuiDataGrid<CollectView> dg = new EasyuiDataGrid<CollectView>();
	    try{
	    	search.setSort("datetime");
	    	search.setOrder(BaseSearch.Order_Type_Desc);
	    	List<CollectView> viewList= zhanglmServiceManage.collectService.collectList(search);
	    	dg.setRows(viewList);
	    	dg.setTotal((long)viewList.size());
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new CollectView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "Collect增加")
	@ResponseBody
	public ResultBean add(CollectView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			CollectModel model =new CollectConvert().addConvert(view);
			zhanglmServiceManage.collectService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.collectService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "Collect修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, CollectView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			CollectModel model = zhanglmServiceManage.collectService.findById(id);
			model = new CollectConvert().editConvert(view, model);
			zhanglmServiceManage.collectService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "Collect删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			CollectModel model = zhanglmServiceManage.collectService.findById(id);
			zhanglmServiceManage.collectService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "Collect禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			CollectModel model = zhanglmServiceManage.collectService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.collectService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
