package com.jrzh.mvc.dao.zhanglm.impl;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.AnswerDaoI;
import com.jrzh.mvc.model.zhanglm.AnswerModel;
import com.jrzh.mvc.search.zhanglm.AnswerSearch;
import com.jrzh.mvc.view.zhanglm.AnswerView;
@Repository("AnswerDaoI")
public class AnswerDaoImpl extends BaseDaoImpl<AnswerModel> implements AnswerDaoI{
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	private Class<AnswerModel> getClazz(){
		return  (Class< AnswerModel >)((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<AnswerModel> selectByField(String fieldName, Object value) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		dc.add(Restrictions.eq(fieldName, value));
		return dc.getExecutableCriteria(sessionFactory.getCurrentSession()).list();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AnswerModel> findList(AnswerSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
	    if (search != null) {
	      search.setAutoDc(dc);

	      return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
	        .setFirstResult((search.getPage() - 1) * search.getRows())
	        .setMaxResults(search.getRows())
	        .list();
	    }
	    return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).list();
	}

	@Override
	public AnswerModel getmodel(String id) {
		 return (AnswerModel) this.sessionFactory.getCurrentSession().get(getClazz(), id);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AnswerView> findBylistField(String string, String equalPid) {
		  DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		    dc.add(Restrictions.eq(string, equalPid));
		    return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).list();
	}

}
	
	/*
	 public List<AnswerView> findList(AnswerSearch search)
	  {
	    DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
	    if (search != null) {
	      search.setAutoDc(dc);

	      return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
	        .setFirstResult((search.getPage() - 1) * search.getRows())
	        .setMaxResults(search.getRows())
	        .list();
	    }
	    return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).list();
	  }
}*/