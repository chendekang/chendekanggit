package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.AppVersionModel;
import com.jrzh.mvc.view.zhanglm.AppVersionView;

public class AppVersionConvert implements BaseConvertI<AppVersionModel, AppVersionView> {

	@Override
	public AppVersionModel addConvert(AppVersionView view) throws ProjectException {
		AppVersionModel model = new AppVersionModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public AppVersionModel editConvert(AppVersionView view, AppVersionModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public AppVersionView convertToView(AppVersionModel model) throws ProjectException {
		AppVersionView view = new AppVersionView();
		ReflectUtils.copySameFieldToTarget(model, view);
		if(!model.getIsDisable()){
			view.setStatus("是");
		}else{
			view.setStatus("否");
		}
		return view;
	}

}
