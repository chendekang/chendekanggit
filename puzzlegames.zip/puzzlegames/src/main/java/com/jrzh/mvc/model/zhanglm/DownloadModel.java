package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_download")
public class DownloadModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 路径名称
     */
    @Column(name = "_name")
    private String name;
    /**
     * 下载路径
     */
    @Column(name = "_url")
    private String url;
    /**
     * 下载类型
     */
    @Column(name = "_type")
    private String type;

    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    
    public String getUrl() {
        return this.url;
    }
    public void setType(String type) {
        this.type = type;
    }
    
    public String getType() {
        return this.type;
    }

}