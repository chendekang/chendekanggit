package com.jrzh.mvc.service.zhanglm.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.convert.zhanglm.AppointmentaccountConvert;
import com.jrzh.mvc.dao.zhanglm.AppointmentaccountDaoI;
import com.jrzh.mvc.model.zhanglm.AppointmentaccountModel;
import com.jrzh.mvc.search.zhanglm.AppointmentaccountSearch;
import com.jrzh.mvc.service.zhanglm.AppointmentaccountService;
import com.jrzh.mvc.view.zhanglm.AppointmentaccountView;
@Service("appointmentaccountservice")
public class AppointmentaccountServiceImpl implements AppointmentaccountService{

	
	@Resource(name = "appointmentaccountdaoi")
	private AppointmentaccountDaoI appointmentaccountdaoi;
	
	@Override
	public void addall(AppointmentaccountModel model) {
		appointmentaccountdaoi.addll(model);
		
	}

	@Override
	public AppointmentaccountModel findByField(String string, String mobile) {
		return appointmentaccountdaoi.findByField(string,mobile);
	}

	@Override
	public EasyuiDataGrid<AppointmentaccountView> datagrid(AppointmentaccountSearch search) {
		EasyuiDataGrid<AppointmentaccountView> dg = new EasyuiDataGrid<AppointmentaccountView>();
		List<AppointmentaccountView> view_list = new ArrayList<AppointmentaccountView>();
		Long count = appointmentaccountdaoi.countBySearch(search);
		if (count.longValue() > 0L) {
			try {
				view_list = viewList(search);
			} catch (ProjectException e) {
				e.printStackTrace();
			}
		}
		dg.setRows(view_list);
		dg.setTotal(count);
		return dg;
	}

	
	public List<AppointmentaccountView> viewList(AppointmentaccountSearch search) throws ProjectException{
		List<AppointmentaccountModel> list = this.list(search);
		return this.convertByModelList(list);
	}
	
	public List<AppointmentaccountModel> list(AppointmentaccountSearch search){
		return  appointmentaccountdaoi.findListBySearch(search);
	}

	public List<AppointmentaccountView> convertByModelList(List<AppointmentaccountModel> modelList) throws ProjectException{
		List<AppointmentaccountView> viewList = new ArrayList<AppointmentaccountView>();
		if(null != modelList && modelList.size() > 0){
			for(AppointmentaccountModel t : modelList){
				viewList.add(getConvert().convertToView(t));
			}
		}
		return viewList;
	}
	public AppointmentaccountConvert getConvert() {
		return new AppointmentaccountConvert();
	}

	@Override
	public void deleteopenaccolog(AppointmentaccountModel model, SessionUser sessionUser) {
		appointmentaccountdaoi.deleteopenaccolog(model);
		
	}


}
