package com.jrzh.mvc.service.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.ZhiboLiveModel;
import com.jrzh.mvc.search.zhanglm.ZhiboLiveSearch;
import com.jrzh.mvc.view.zhanglm.ZhiboLiveView;

public interface ZhiboLiveServiceI  extends BaseServiceI<ZhiboLiveModel, ZhiboLiveSearch, ZhiboLiveView>{
	
	void addAndFile(ZhiboLiveModel model,FileModel file,SessionUser user)throws ProjectException;
	void editAndFile(ZhiboLiveModel model,FileModel file,SessionUser user)throws ProjectException;
	void deleteAndFile(ZhiboLiveModel model,FileModel file,SessionUser user)throws ProjectException;
}