package com.jrzh.mvc.dao.zhanglm;

import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.MemberAttentionModel;

public interface MemberAttentionDaoI extends BaseDaoI<MemberAttentionModel>{

}
