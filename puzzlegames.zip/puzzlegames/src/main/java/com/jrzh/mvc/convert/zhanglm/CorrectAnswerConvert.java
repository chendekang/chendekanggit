package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.mvc.model.zhanglm.CorrectAnswerModel;
import com.jrzh.mvc.view.zhanglm.CorrectAnswerView;

public class CorrectAnswerConvert {

	public CorrectAnswerModel addConvert(CorrectAnswerView view) throws ProjectException {
		CorrectAnswerModel model = new CorrectAnswerModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	public CorrectAnswerModel editConvert(CorrectAnswerView view, CorrectAnswerModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	public static CorrectAnswerView convertToView(CorrectAnswerModel model) throws ProjectException {
		CorrectAnswerView view = new CorrectAnswerView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
