package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.common.utils.DateUtil;
import com.jrzh.framework.base.search.BaseSearch;

public class SnapshotLogSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String eqSymbol;
	
	private Integer eqType;
	
	private String geStartTime;
	
	private String leEndTime;
	
	private String id;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getGeStartTime() {
		return geStartTime;
	}
	public void setGeStartTime(String geStartTime) {
		this.geStartTime = geStartTime;
	}
	public String getLeEndTime() {
		return leEndTime;
	}
	public void setLeEndTime(String leEndTime) {
		this.leEndTime = leEndTime;
	}
	public String getEqSymbol() {
		return eqSymbol;
	}
	public void setEqSymbol(String eqSymbol) {
		this.eqSymbol = eqSymbol;
	}
	public Integer getEqType() {
		return eqType;
	}
	public void setEqType(Integer eqType) {
		this.eqType = eqType;
	}
	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(id)){
			dc.add(Restrictions.eq("id", id));
		}
		if(StringUtils.isNotBlank(eqSymbol)){
			dc.add(Restrictions.eq("oldSymbol", eqSymbol));
		}
		if(null != eqType){
			dc.add(Restrictions.eq("type", eqType));
		}
		if(StringUtils.isNotBlank(geStartTime)){
			dc.add(Restrictions.ge("oldDatetime", DateUtil.format(geStartTime,"yyyy-MM-dd HH:mm:ss")));
		}
		if(StringUtils.isNotBlank(leEndTime)){
			dc.add(Restrictions.le("oldDatetime", DateUtil.format(leEndTime,"yyyy-MM-dd HH:mm:ss")));
		}
	}
}