package com.jrzh.mvc.controller.zhanglm.mobile;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MaBean;
import com.jrzh.bean.MobileResultBean;
import com.jrzh.common.utils.DateUtil;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.convert.zhanglm.SnapshotConvert;
import com.jrzh.mvc.model.zhanglm.GoldRecommendModel;
import com.jrzh.mvc.model.zhanglm.MemberOptionalModel;
import com.jrzh.mvc.model.zhanglm.OpenAccoLogModel;
import com.jrzh.mvc.search.zhanglm.GoldHistorySearch;
import com.jrzh.mvc.search.zhanglm.GoldRecommendSearch;
import com.jrzh.mvc.search.zhanglm.MemberOptionalSearch;
import com.jrzh.mvc.search.zhanglm.SnapshotLogSearch;
import com.jrzh.mvc.search.zhanglm.SnapshotSearch;
import com.jrzh.mvc.view.zhanglm.GoldHistoryView;
import com.jrzh.mvc.view.zhanglm.SnapshotLogView;
import com.jrzh.mvc.view.zhanglm.SnapshotView;

@Controller(GoldController.LOCATION + "GoldController")
@RequestMapping(GoldController.LOCATION)
public class GoldController extends BaseMobileController{
	public static final String LOCATION = "/mobile/gold/";
	
	
	@RequestMapping(method = RequestMethod.POST, value = "recommend")
	@MemberEvent(desc = "安卓/IOS 推荐黄金产品")
	@ResponseBody
	public MobileResultBean recommend(){
		MobileResultBean result = new MobileResultBean();
		String message = "";
		Map<String,Object> map = new HashMap<String, Object>();
		List<GoldRecommendModel> recommendList = new ArrayList<GoldRecommendModel>();
		List<SnapshotView> goldList = new ArrayList<SnapshotView>();
		map.put("method", "recommend");
		try {
			GoldRecommendSearch search = new GoldRecommendSearch();
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Desc);
			search.setRows(3);
			recommendList = zhanglmServiceManage.goldRecommendService.list(search);
			for(GoldRecommendModel model : recommendList){
				goldList.add(new SnapshotConvert().convertToView(model.getSnapshot()));
			}
			map.put("goldList", goldList);
			message = "获取推荐成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "openAccoOrder")
	@MemberEvent(desc = "安卓/IOS黄金预约开户")
	@ResponseBody
	public MobileResultBean openAccoOrder(){
		MobileResultBean result = new MobileResultBean();
		String message = "";
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "openAccoOrder");
		try {
			String mobile = request.getParameter("mobile");
			if(!isLogin()){
				message = "登陆失效";
			}else{
				if(StringUtils.isBlank(mobile)){
					result.setMessage("手机号不能为空");
					return result;
				}
				OpenAccoLogModel model = zhanglmServiceManage.openAccoLogService.findByField("mobile", mobile);
				if(model != null){
					result.setMessage("您已预约过，请不要重复提交");
					return result;
				}else{
					model = new OpenAccoLogModel();
					model.setUserId(getSessionUser().getId());
					model.setMobile(mobile);
					model.setStatus(BusinessConstants.OPEN_ACCO_STATUS.NOT_SOLVE);
					zhanglmServiceManage.openAccoLogService.add(model, getSessionUser());
					message = "预约成功，请等待工作人员联系";
					result.setObject(map);
					result.setStatus(MobileResultBean.SUCCESS);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "goldHistory")
	@MemberEvent(desc = "安卓/IOS单个黄金历史数据")
	@ResponseBody
	public MobileResultBean goldHistory(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<GoldHistoryView> goldHistoryList = new ArrayList<GoldHistoryView>();
		List<Double> volumeList = new ArrayList<Double>();//成交量数据
		List<String> xVals = new ArrayList<String>();
		List<MaBean> ma5 = new ArrayList<MaBean>();
		List<MaBean> ma10 = new ArrayList<MaBean>();
		List<MaBean> ma20 = new ArrayList<MaBean>();
		List<MaBean> ma60 = new ArrayList<MaBean>();
		String message = "";
		map.put("method", "goldHistory");
		try {
			String symbol = request.getParameter("symbol");
			GoldHistorySearch search = new GoldHistorySearch();
			search.setSort("dateTime");
			search.setEqualSymbol(symbol);
			goldHistoryList = zhanglmServiceManage.goldHistoryService.viewList(search);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			for(GoldHistoryView view : goldHistoryList){
				volumeList.add(view.getTvolume());
				xVals.add(sdf.format(view.getDateTime()));
			}
			//计算MA5
			caculateHistoryMA(5,goldHistoryList, ma5);
			//计算MA10
			caculateHistoryMA(10, goldHistoryList, ma10);
			//计算MA20
			caculateHistoryMA(20, goldHistoryList, ma20);
			//计算MA60
			caculateHistoryMA(60, goldHistoryList, ma60);
			map.put("ma5", ma5);
			map.put("ma10", ma10);
			map.put("ma20", ma20);
			map.put("ma60", ma60);
			map.put("xVals", xVals);
			map.put("volumeList", volumeList);
			map.put("goldHistoryList", goldHistoryList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "goldList")
	@MemberEvent(desc = "安卓/IOS黄金行情列表")
	@ResponseBody
	public MobileResultBean goldList(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<SnapshotView> goldList = new ArrayList<SnapshotView>();
		String message = "";
		map.put("method", "goldList");
		try {
			SnapshotSearch search = new SnapshotSearch();
			search.setSort("id");
			goldList = zhanglmServiceManage.snapshotService.viewList(search);
			map.put("goldList", goldList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "goldInfo")
	@MemberEvent(desc = "安卓/IOS单个黄金行情")
	@ResponseBody
	public MobileResultBean goldInfo(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "goldInfo");
		try {
			String symbol = request.getParameter("symbol");
			if(StringUtils.isBlank(symbol)){
				result.setMessage("编号不能为空");
				return result;
			}
			String[] resymbol = symbol.split(" ");
			symbol = "";
			for (int i = 0; i < resymbol.length; i++) {
				if(i == 0){
					symbol = resymbol[i];
				}else{
					symbol += "+"+resymbol[i];
				}
			}
			SnapshotView goldView = zhanglmServiceManage.snapshotService.findViewByField("symbol", symbol);
			if(null == goldView){
				result.setMessage("产品不存在");
				return result;
			}
			if(!isLogin()){
				goldView.setType(0);
			}else{
				MemberOptionalSearch search = new MemberOptionalSearch();
				search.setEqualUserId(getSessionUser().getId());
				search.setEqualProductCode(symbol);
				MemberOptionalModel model = zhanglmServiceManage.memberOptionalService.findBySearch(search);
				if(model != null){
					//已添加自选
					goldView.setType(1);
				}else{
					goldView.setType(0);
				}
			}
			map.put("goldView", goldView);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "addOptional")
	@MemberEvent(desc = "安卓/IOS黄金添加自选")
	@ResponseBody
	public MobileResultBean addOptional(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addOptional");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String code = request.getParameter("code");
				String[] resymbol = code.split(" ");
				for (int i = 0; i < resymbol.length; i++) {
					if(i == 0){
						code = resymbol[i];
					}else{
						code += "+"+resymbol[i];
					}
				}
				String userId = getSessionUser().getId();
				MemberOptionalSearch search = new MemberOptionalSearch();
				search.setEqualUserId(userId);
				search.setEqualProductCode(code);
				MemberOptionalModel model = zhanglmServiceManage.memberOptionalService.findBySearch(search);
				if(model != null){
					result.setMessage("请不要重复添加");
					return result;
				}
				model = new MemberOptionalModel();
				model.setUserId(userId);
				model.setProductCode(code);
				zhanglmServiceManage.memberOptionalService.add(model, getSessionUser());
				message = "添加自选成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "deleteOptional")
	@MemberEvent(desc = "安卓/IOS黄金删除自选")
	@ResponseBody
	public MobileResultBean deleteOptional(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "deleteOptional");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String code = request.getParameter("code");
				String[] resymbol = code.split(" ");
				for (int i = 0; i < resymbol.length; i++) {
					if(i == 0){
						code = resymbol[i];
					}else{
						code += "+"+resymbol[i];
					}
				}
				MemberOptionalSearch search = new MemberOptionalSearch();
				search.setEqualUserId(getSessionUser().getId());
				search.setEqualProductCode(code);
				MemberOptionalModel model = zhanglmServiceManage.memberOptionalService.findBySearch(search);
				zhanglmServiceManage.memberOptionalService.delete(model, getSessionUser());
				message = "删除自选成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "getOptional")
	@MemberEvent(desc = "安卓/IOS黄金获取自选产品列表")
	@ResponseBody
	public MobileResultBean getOptional(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<SnapshotView> goldList = new ArrayList<SnapshotView>();
		String message = "";
		map.put("method", "addOptional");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				MemberOptionalSearch search = new MemberOptionalSearch();
				search.setEqualUserId(userId);
				List<MemberOptionalModel> list = zhanglmServiceManage.memberOptionalService.list(search);
				if(list.size() > 0){
					for(MemberOptionalModel optional : list){
						SnapshotView view = zhanglmServiceManage.snapshotService.findViewByField("symbol", optional.getProductCode());
						if(view != null){
							goldList.add(view);
						}
					}
				}else{
					SnapshotView view = zhanglmServiceManage.snapshotService.findViewByField("symbol", "SGAUT+D");
					goldList.add(view);
				}
				message = "获取成功";
				map.put("optionalList", goldList);
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "HMLine")
	@UserEvent(desc = "时分线数据")
	@ResponseBody
	public MobileResultBean HMLine(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "HMLine");
		String symbol = request.getParameter("symbol");
		try {
			List<SnapshotLogView> list = new ArrayList<SnapshotLogView>();//时分线数据
			List<Double> volumeList = new ArrayList<Double>();//成交量数据
			List<Double> valueList = new ArrayList<Double>();//持仓量数据
			List<String> xVals = new ArrayList<String>();
			List<MaBean> ma = new ArrayList<MaBean>();
			SnapshotLogSearch search = new SnapshotLogSearch();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			search.setEqSymbol(symbol);
			search.setSort("oldDatetime");
			search.setOrder("asc");
			search.setEqType(BusinessConstants.SNAPSHOT_TYPE.FIVE);
			Calendar calendar = Calendar.getInstance();
			Date nowDate = calendar.getTime();
			int day = calendar.get(Calendar.DAY_OF_WEEK);
			int hour = calendar.get(Calendar.HOUR_OF_DAY);
			if(day == 7){
				//周六的时候查询周五-今日2点半的数据
				Date friday = DateUtil.addDay(nowDate, -1);//周五
				search.setGeStartTime(sdf.format(friday) + " 20:00:00");
				search.setLeEndTime(sdf.format(new Date()) + " 2:30:30");
				System.out.println(search);
				List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
				for(SnapshotLogView oneView : oneList){
					list.add(oneView);
					volumeList.add(oneView.getOldTvolume());
					valueList.add(oneView.getOldTvalue());
				}
			}else if(day == 0){
				//周日的时候查询数据为周五-周六的数据
				Date friday = DateUtil.addDay(nowDate, -2);//周五
				Date saturday = DateUtil.addDay(nowDate, -1);//周六
				search.setGeStartTime(sdf.format(friday) + " 20:00:00");
				search.setLeEndTime(sdf.format(saturday) + " 23:59:59");
				System.out.println(search);
				List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
				for(SnapshotLogView oneView : oneList){
					list.add(oneView);
					volumeList.add(oneView.getOldTvolume());
					valueList.add(oneView.getOldTvalue());
				}
			}else if(day == 2){
				if(hour >= 20){
					//过了20:00为周二开盘时间
					search.setGeStartTime(sdf.format(new Date()) + " 20:00:00");
					search.setLeEndTime(sdf.format(new Date()) + " 23:59:59");
					System.out.println(search);
					List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView oneView : oneList){
						list.add(oneView);
						volumeList.add(oneView.getOldTvolume());
						valueList.add(oneView.getOldTvalue());
					}
				}else{
					//周一的数据为上周五20:00-周六3:00 加上今日9:00-11:30和13:30-15:30
					Date friday = DateUtil.addDay(nowDate, -3);//周五
					Date saturday = DateUtil.addDay(nowDate, -2);//周六
					search.setGeStartTime(sdf.format(friday) + " 20:00:00");
					search.setLeEndTime(sdf.format(saturday) + " 23:59:59");
					System.out.println(search);
					List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView oneView : oneList){
						list.add(oneView);
						volumeList.add(oneView.getOldTvolume());
						valueList.add(oneView.getOldTvalue());
					}
					//今日9:00到11:30
					search.setGeStartTime(sdf.format(new Date())+" 9:00:00");
					search.setLeEndTime(sdf.format(new Date())+" 11:30:00");
					List<SnapshotLogView> twoList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView twoView : twoList){
						list.add(twoView);
						volumeList.add(twoView.getOldTvolume());
						valueList.add(twoView.getOldTvalue());
					}
					//今日13:30到15:30
					search.setGeStartTime(sdf.format(new Date())+" 13:30:00");
					search.setLeEndTime(sdf.format(new Date())+" 15:30:00");
					List<SnapshotLogView> threeList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView threeView : threeList){
						list.add(threeView);
						volumeList.add(threeView.getOldTvolume());
						valueList.add(threeView.getOldTvalue());
					}
				}
			}else{
				if(hour >= 20){
					//今晚20点到最新的时间
					search.setGeStartTime(sdf.format(new Date()) + " 20:00:00");
					search.setLeEndTime(sdf.format(new Date()) + " 23:59:59");
					System.out.println(search);
					List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView oneView : oneList){
						list.add(oneView);
						volumeList.add(oneView.getOldTvolume());
						valueList.add(oneView.getOldTvalue());
					}
				}else{
					//前一天晚上20:00到今日凌晨2:30
					search.setGeStartTime(sdf.format(DateUtil.addDay(DateUtil.getBegin(new Date()), -1))+" 20:30:00");
					search.setLeEndTime(sdf.format(new Date())+" 2:30:00");
					List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView oneView : oneList){
						list.add(oneView);
						volumeList.add(oneView.getOldTvolume());
						valueList.add(oneView.getOldTvalue());
					}
					//今日9:00到11:30
					search.setGeStartTime(sdf.format(new Date())+" 9:00:00");
					search.setLeEndTime(sdf.format(new Date())+" 11:30:00");
					List<SnapshotLogView> twoList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView twoView : twoList){
						list.add(twoView);
						volumeList.add(twoView.getOldTvolume());
						valueList.add(twoView.getOldTvalue());
					}
					//今日13:30到15:30
					search.setGeStartTime(sdf.format(new Date())+" 13:30:00");
					search.setLeEndTime(sdf.format(new Date())+" 15:30:00");
					List<SnapshotLogView> threeList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView threeView : threeList){
						list.add(threeView);
						volumeList.add(threeView.getOldTvolume());
						valueList.add(threeView.getOldTvalue());
					}
				}
			}
			//计算均线
			Double sum = 0.0;
			for(int i=0;i<list.size();i++){
				sum = sum + list.get(i).getOldClose();
				Double val = sum / (i+1);
				MaBean bean = new MaBean();
				bean.setIndex(i+"");
				bean.setSum(val.toString());
				ma.add(bean);
			}
			//X轴数据
			String[] hours = new String[]{"20","21","22","23","00","01","02","09","10","11","13","14","15"};
			for(String i : hours){
				if(StringUtils.equals(i, "13")){
					for(int m=30;m<=55;m+=5){
						xVals.add("13:"+m);
					}
				}else{
					xVals.add(i+":00");
					xVals.add(i+":05");
					if(StringUtils.equals(i, "02") || StringUtils.equals(i, "11") || StringUtils.equals(i, "15")){
						for(int m=10;m<=30;m+=5){
							xVals.add(i+":"+m);
						}
					}else{
						for(int m=10;m<=55;m+=5){
							xVals.add(i+":"+m);
						}
					}
				}
			}
			map.put("HMList", list);
			map.put("xVals", xVals);
			map.put("valueList", valueList);
			map.put("volumeList", volumeList);
			map.put("ma", ma);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			result.setMessage(e.getMessage());
		}
		result.setObject(map);
		return result;
	}
		
	
	@RequestMapping(method = RequestMethod.POST, value = "kLine")
	@UserEvent(desc = "k线图数据")
	@ResponseBody
	public MobileResultBean kLine(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "kLine");
		try {
			String symbol = request.getParameter("symbol");
			String[] resymbol = symbol.split(" ");
			symbol = "";
			for (int i = 0; i < resymbol.length; i++) {
				if(i == 0){
					symbol = resymbol[i];
				}else{
					symbol += "+"+resymbol[i];
				}
			}
			String type = request.getParameter("type");
			if("".equals(type) || null == type){
				GoldHistorySearch search = new GoldHistorySearch();
				search.setEqualSymbol(symbol);
				search.setSort("dateTime");
				search.setOrder("asc");
				List<GoldHistoryView> list = zhanglmServiceManage.goldHistoryService.viewList(search);
				map.put("kLineList", list);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				List<SnapshotLogView> list = new ArrayList<SnapshotLogView>();//K线图数据
				List<Double> volumeList = new ArrayList<Double>();//成交量数据
				List<Double> valueList = new ArrayList<Double>();//持仓量数据
				List<String> xVals = new ArrayList<String>();
				List<MaBean> ma5 = new ArrayList<MaBean>();
				List<MaBean> ma10 = new ArrayList<MaBean>();
				List<MaBean> ma20 = new ArrayList<MaBean>();
				List<MaBean> ma60 = new ArrayList<MaBean>();
				SimpleDateFormat xSdf =new SimpleDateFormat("dd/HH:mm");
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+type);
				SnapshotLogSearch search = new SnapshotLogSearch();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				search.setEqSymbol(symbol);
				search.setSort("oldDatetime");
				search.setOrder("asc");
				search.setEqType(Integer.valueOf(type));
				//如果今天已经过了20点
				Calendar calendar = Calendar.getInstance();
				Date nowDate = calendar.getTime();
				int day = calendar.get(Calendar.DAY_OF_WEEK);
				int hour = calendar.get(Calendar.HOUR_OF_DAY);
				if(day == 7){
					//周六的时候查询周一20:00-今日2:30的数据
					Date monday = DateUtil.addDay(nowDate, -5);//周一
					search.setGeStartTime(sdf.format(monday) + " 20:00:00");
					search.setLeEndTime(sdf.format(new Date()) + " 2:30:00");
					System.out.println(search);
					List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView oneView : oneList){
						list.add(oneView);
						volumeList.add(oneView.getOldTvolume());
						valueList.add(oneView.getOldTvalue());
						xVals.add(xSdf.format(oneView.getOldDatetime()));
					}
				}else if(day == 0){
					//周日的时候查询数据为周二20:00-周六2:30的数据
					Date tuesDay = DateUtil.addDay(nowDate, -5);//周二
					Date saturday = DateUtil.addDay(nowDate, -1);//周六
					search.setGeStartTime(sdf.format(tuesDay) + " 20:00:00");
					search.setLeEndTime(sdf.format(saturday) + " 2:30:00");
					System.out.println(search);
					List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
					for(SnapshotLogView oneView : oneList){
						list.add(oneView);
						volumeList.add(oneView.getOldTvolume());
						valueList.add(oneView.getOldTvalue());
						xVals.add(xSdf.format(oneView.getOldDatetime()));
					}
				}else if(day == 2){
					//周一的数据
					if(hour >= 20){
						//过了20:00为周二开盘时间，查询时间为上周三的20:00-当前时间
						search.setGeStartTime(sdf.format(DateUtil.addDay(new Date(), -5)) + " 20:00:00");
						search.setLeEndTime(sdf.format(new Date()) + " 23:59:59");
						System.out.println(search);
						List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
						for(SnapshotLogView oneView : oneList){
							list.add(oneView);
							volumeList.add(oneView.getOldTvolume());
							valueList.add(oneView.getOldTvalue());
							xVals.add(xSdf.format(oneView.getOldDatetime()));
						}
					}else{
						//周一的数据为上周二20:00-周六2:30 加上今日9:00-11:30和13:30-15:30
						Date tuesDay = DateUtil.addDay(nowDate, -6);//周二
						Date saturday = DateUtil.addDay(nowDate, -2);//周六
						search.setGeStartTime(sdf.format(tuesDay) + " 20:00:00");
						search.setLeEndTime(sdf.format(saturday) + " 2:30:00");
						System.out.println(search);
						List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
						for(SnapshotLogView oneView : oneList){
							list.add(oneView);
							volumeList.add(oneView.getOldTvolume());
							valueList.add(oneView.getOldTvalue());
							xVals.add(xSdf.format(oneView.getOldDatetime()));
						}
						//今日9:00到11:30
						search.setGeStartTime(sdf.format(new Date())+" 9:00:00");
						search.setLeEndTime(sdf.format(new Date())+" 11:30:00");
						List<SnapshotLogView> twoList = zhanglmServiceManage.snapshotLogService.viewList(search);
						for(SnapshotLogView twoView : twoList){
							list.add(twoView);
							volumeList.add(twoView.getOldTvolume());
							valueList.add(twoView.getOldTvalue());
							xVals.add(xSdf.format(twoView.getOldDatetime()));
						}
						//今日13:30到15:30
						search.setGeStartTime(sdf.format(new Date())+" 13:30:00");
						search.setLeEndTime(sdf.format(new Date())+" 15:30:00");
						List<SnapshotLogView> threeList = zhanglmServiceManage.snapshotLogService.viewList(search);
						for(SnapshotLogView threeView : threeList){
							list.add(threeView);
							volumeList.add(threeView.getOldTvolume());
							valueList.add(threeView.getOldTvalue());
							xVals.add(xSdf.format(threeView.getOldDatetime()));
						}
					}
				}else{
					if(hour >= 20){
						//查找最近五天的数据，20点到最新的时间
						search.setGeStartTime(sdf.format(DateUtil.addDay(new Date(), -5)) + " 20:00:00");
						search.setLeEndTime(sdf.format(new Date()) + " 23:59:59");
						System.out.println(search);
						List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
						for(SnapshotLogView oneView : oneList){
							list.add(oneView);
							volumeList.add(oneView.getOldTvolume());
							valueList.add(oneView.getOldTvalue());
							xVals.add(xSdf.format(oneView.getOldDatetime()));
						}
					}else{
						//查找最近五天的数据,前一天晚上20:00到今日凌晨2:30
						search.setGeStartTime(sdf.format(DateUtil.addDay(DateUtil.getBegin(new Date()), -6))+" 20:30:00");
						search.setLeEndTime(sdf.format(new Date())+" 2:30:00");
						List<SnapshotLogView> oneList = zhanglmServiceManage.snapshotLogService.viewList(search);
						for(SnapshotLogView oneView : oneList){
							list.add(oneView);
							volumeList.add(oneView.getOldTvolume());
							valueList.add(oneView.getOldTvalue());
							xVals.add(xSdf.format(oneView.getOldDatetime()));
						}
						//今日9:00到11:30
						search.setGeStartTime(sdf.format(new Date())+" 9:00:00");
						search.setLeEndTime(sdf.format(new Date())+" 11:30:00");
						List<SnapshotLogView> twoList = zhanglmServiceManage.snapshotLogService.viewList(search);
						for(SnapshotLogView twoView : twoList){
							list.add(twoView);
							volumeList.add(twoView.getOldTvolume());
							valueList.add(twoView.getOldTvalue());
							xVals.add(xSdf.format(twoView.getOldDatetime()));
						}
						//今日13:30到15:30
						search.setGeStartTime(sdf.format(new Date())+" 13:30:00");
						search.setLeEndTime(sdf.format(new Date())+" 15:30:00");
						List<SnapshotLogView> threeList = zhanglmServiceManage.snapshotLogService.viewList(search);
						for(SnapshotLogView threeView : threeList){
							list.add(threeView);
							volumeList.add(threeView.getOldTvolume());
							valueList.add(threeView.getOldTvalue());
							xVals.add(xSdf.format(threeView.getOldDatetime()));
						}
					}
				}
				//计算MA5
				caculateMA(5,list, ma5);
				//计算MA10
				caculateMA(10, list, ma10);
				//计算MA20
				caculateMA(20, list, ma20);
				//计算MA60
				caculateMA(60, list, ma60);
				map.put("kLineList", list);
				map.put("xVals", xVals);
				map.put("valueList", valueList);
				map.put("volumeList", volumeList);
				map.put("ma5", ma5);
				map.put("ma10", ma10);
				map.put("ma20", ma20);
				map.put("ma60", ma60);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		result.setObject(map);
		return result;
	}

	private void caculateMA(int ma,List<SnapshotLogView> list, List<MaBean> maList) {
		for (int index = ma - 1; index < list.size(); index++) {
			Double sum = 0.0;
		    for (int m = 0; m < ma; m++) {
		    	Double val = list.get(index - m).getOldClose();
		        sum += val;
		    }
		    sum /= ma;
		    MaBean bean = new MaBean();
		    bean.setSum(sum.toString());
		    bean.setIndex(index+"");
		    maList.add(bean);
		}
	}
	
	private void caculateHistoryMA(int ma,List<GoldHistoryView> list, List<MaBean> maList) {
		for (int index = ma - 1; index < list.size(); index++) {
			Double sum = 0.0;
		    for (int m = 0; m < ma; m++) {
		    	Double val = list.get(index - m).getClose();
		        sum += val;
		    }
		    sum /= ma;
		    MaBean bean = new MaBean();
		    bean.setSum(sum.toString());
		    bean.setIndex(index+"");
		    maList.add(bean);
		}
	}

}
