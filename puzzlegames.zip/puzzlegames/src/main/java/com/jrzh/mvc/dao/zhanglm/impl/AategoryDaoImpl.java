package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.AategoryDaoI;
import com.jrzh.mvc.model.zhanglm.AategoryModel;

@Repository("AategoryDaoI")
public class AategoryDaoImpl extends BaseDaoImpl<AategoryModel> implements AategoryDaoI{

}