package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class TitleReleaseSearch extends BaseSearch {
	private static final long serialVersionUID = 1L;
	private String eqcategoryid;


	private String eqtitlename;
	
	private Integer eqsorting;
	
	private String eqtitleqtype;
	
	private Integer eqtitleqtag;
	private String eqid;
	
	public String getEqid() {
		return eqid;
	}
	public void setEqid(String eqid) {
		this.eqid = eqid;
	}
	public Integer getEqtitleqtag() {
		return eqtitleqtag;
	}
	public void setEqtitleqtag(Integer eqtitleqtag) {
		this.eqtitleqtag = eqtitleqtag;
	}
	public String getEqtitleqtype() {
		return eqtitleqtype;
	}
	public void setEqtitleqtype(String eqtitleqtype) {
		this.eqtitleqtype = eqtitleqtype;
	}
	public Integer getEqsorting() {
		return eqsorting;
	}
	public void setEqsorting(Integer eqsorting) {
		this.eqsorting = eqsorting;
	}
	public String getEqtitlename() {
		return eqtitlename;
	}
	public void setEqtitlename(String eqtitlename) {
		this.eqtitlename = eqtitlename;
	}
	public String getEqcategoryid() {
		return eqcategoryid;
	}
	public void setEqcategoryid(String eqcategoryid) {
		this.eqcategoryid = eqcategoryid;
	}
	@Override
	public void setDc(DetachedCriteria dc) {


		if (StringUtils.isNotBlank(eqcategoryid)) {
			dc.add(Restrictions.eq("categoryid", eqcategoryid));
		}
		
		if (StringUtils.isNotBlank(eqtitlename)) {
			dc.add(Restrictions.like("title", "%"+eqtitlename+"%"));
		}
		
		if (eqsorting != null) {
			//大于序号查询
			dc.add(Restrictions.gt("sorting", eqsorting));
		}
		
		if (StringUtils.isNotBlank(eqtitleqtype)) {
			dc.add(Restrictions.eq("qtype", eqtitleqtype));
		}
		

		if (eqtitleqtag != null) {
			dc.add(Restrictions.eq("tag", eqtitleqtag));
		}
		
		if (StringUtils.isNotBlank(eqid)) {
			dc.add(Restrictions.eq("id", eqid));
		}


	}

}