package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.mvc.model.zhanglm.MemberLogStatisticsModel;
import com.jrzh.mvc.view.zhanglm.MemberLogStatisticsView;
import com.jrzh.mvc.view.zhanglm.SnapshotView;

public class GoidCustomerConvert {
	public MemberLogStatisticsModel addConvert(SnapshotView view) throws ProjectException {
		MemberLogStatisticsModel model = new MemberLogStatisticsModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	public MemberLogStatisticsModel editConvert(MemberLogStatisticsView view, MemberLogStatisticsModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	public MemberLogStatisticsView convertToView(MemberLogStatisticsModel model) throws ProjectException {
		MemberLogStatisticsView view = new MemberLogStatisticsView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}
}
