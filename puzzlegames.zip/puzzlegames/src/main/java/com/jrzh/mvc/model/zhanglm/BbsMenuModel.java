package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.jrzh.framework.annotation.UniqueValue;
import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_bbs_menu")
public class BbsMenuModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 编号
     */
    @Column(name = "_code")
    @UniqueValue(name = "类别编号")
    @NotNull(message = "类别编号不能为空")
    private String code;
    /**
     * 级别
     */
    @Column(name = "_pid")
    private String pid;
    /**
     * 名称
     */
    @Column(name = "_name")
    @NotNull(message = "类别名称不能为空")
    private String name;
    /**
     * 描述
     */
    @Column(name = "_description")
    private String description;
    /**
     * 圈子图片
     */
    @Column(name = "_img_url")
    @NotNull(message = "圈子图片不能为空")
    private String imgUrl;
    /**
     * 图片格式
     */
    @Column(name = "_img_type")
    private String imgType;
    /**
     * 图片大小
     */
    @Column(name = "_img_size")
    private String imgSize;

    public void setCode(String code) {
        this.code = code;
    }
    
    public String getCode() {
        return this.code;
    }
    public void setPid(String pid) {
        this.pid = pid;
    }
    
    public String getPid() {
        return this.pid;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return this.description;
    }
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
    
    public String getImgUrl() {
        return this.imgUrl;
    }
    public void setImgType(String imgType) {
        this.imgType = imgType;
    }
    
    public String getImgType() {
        return this.imgType;
    }
    public void setImgSize(String imgSize) {
        this.imgSize = imgSize;
    }
    
    public String getImgSize() {
        return this.imgSize;
    }

}