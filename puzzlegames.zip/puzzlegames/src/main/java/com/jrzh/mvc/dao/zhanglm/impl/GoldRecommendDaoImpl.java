package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.GoldRecommendDaoI;
import com.jrzh.mvc.model.zhanglm.GoldRecommendModel;

@Repository("goldRecommendDao")
public class GoldRecommendDaoImpl extends BaseDaoImpl<GoldRecommendModel> implements GoldRecommendDaoI{

}