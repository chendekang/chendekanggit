package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.WithdrawAuditLogModel;
import com.jrzh.mvc.search.zhanglm.WithdrawAuditLogSearch;
import com.jrzh.mvc.view.zhanglm.WithdrawAuditLogView;

public interface WithdrawAuditLogServiceI  extends BaseServiceI<WithdrawAuditLogModel, WithdrawAuditLogSearch, WithdrawAuditLogView>{

}