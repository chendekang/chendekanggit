package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.convert.zhanglm.BannerConvert;
import com.jrzh.mvc.dao.zhanglm.BannerDaoI;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.BannerModel;
import com.jrzh.mvc.search.zhanglm.BannerSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.BannerServiceI;
import com.jrzh.mvc.view.zhanglm.BannerView;

@Service("bannerService")
public class BannerServiceImpl extends
		BaseServiceImpl<BannerModel, BannerSearch, BannerView> implements
		BannerServiceI {

	@Resource(name = "bannerDao")
	private BannerDaoI bannerDao;

	@Autowired
	private SysServiceManage sysServiceManage;
	
	@Override
	public BaseDaoI<BannerModel> getDao() {
		return bannerDao;
	}

	@Override
	public BaseConvertI<BannerModel, BannerView> getConvert() {
		return new BannerConvert();
	}

	@Override
	public void addAndFile(BannerModel model, FileModel file, SessionUser user)throws Exception {
		this.add(model, user);
		if(file != null){
			file.setFormId(model.getId());
			sysServiceManage.fileService.add(file, user);
		}
	}

	@Override
	public void editAndFile(BannerModel model, FileModel file, SessionUser user)throws Exception {
		this.edit(model, user);
		if(file != null){
			sysServiceManage.fileService.edit(file, user);
		}
	}

	@Override
	public void deleteAndFile(BannerModel model, FileModel file,SessionUser user)throws Exception {
		this.delete(model, user);
		if(file != null){
			sysServiceManage.fileService.delete(file, user);
		}
	}

}
