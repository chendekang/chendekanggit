package com.jrzh.mvc.service.zhanglm;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.mvc.model.zhanglm.TodayDealModel;
import com.jrzh.mvc.search.zhanglm.TodayDealSearch;
import com.jrzh.mvc.view.zhanglm.TodayDealView;

public interface TodayDealServiceI {
	String add(TodayDealModel model)throws ProjectException;

	EasyuiDataGrid<TodayDealView> datagrid(TodayDealSearch search);

	void exporttodaydeal(TodayDealSearch search, HttpServletResponse response) throws ProjectException, IOException;
}
