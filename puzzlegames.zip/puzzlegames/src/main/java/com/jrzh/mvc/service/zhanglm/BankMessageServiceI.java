package com.jrzh.mvc.service.zhanglm;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.mvc.model.zhanglm.BankMessageModel;
import com.jrzh.mvc.search.zhanglm.BankMessageSearch;
import com.jrzh.mvc.view.zhanglm.BankMessageView;

public interface BankMessageServiceI{
	String add(BankMessageModel model)throws ProjectException;

	EasyuiDataGrid<BankMessageView> datagrid(BankMessageSearch search);

	void exportbankmessage(BankMessageSearch search, HttpServletResponse response) throws ProjectException, IOException;

}
