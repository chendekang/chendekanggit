package com.jrzh.mvc.controller.zhanglm.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.PlazaDataSearch;
import com.jrzh.mvc.view.zhanglm.PlazaDataView;

@Controller(PlazaController.LOCATION + "PlazaController")
@RequestMapping(PlazaController.LOCATION)
public class PlazaController extends BaseMobileController {
	public static final String LOCATION = "/mobile/plaza/";
	@RequestMapping(method = RequestMethod.POST, value = "getData")
	@MemberEvent(desc = "安卓/IOS 获取广场数据")
	@ResponseBody
	public MobileResultBean getData(PlazaDataSearch search) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "getData");
		String message = "";
		try {
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Desc);
			List<PlazaDataView> dataList = zhanglmServiceManage.plazaDataService
					.dataListMobile(search, getSessionUser());
			DefaultSearch defaultsearch = new DefaultSearch();
			for (PlazaDataView data : dataList) {
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService
						.first(defaultsearch);
				if (null == data.getUserPhoto()) {
					data.setUserPhoto(defaultModel.getImgUrl());
				}
			}
			map.put("dataList", dataList);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "getDatanew")
	@MemberEvent(desc ="安卓/IOS 获取广场数据")
	@ResponseBody
	public MobileResultBean getDatanew(PlazaDataSearch search) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "getData");
		String currPage = request.getParameter("currPage");
		String pageSize = request.getParameter("pageSize");
		Long number = 0L;
		String message = "";
		try {
		    search.setPage(Integer.parseInt(currPage));
		    search.setRows(Integer
		    		.parseInt(pageSize));
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Desc);
			//直播
			search.setEqualCategory(1);
			List<PlazaDataView> dataList = zhanglmServiceManage.plazaDataService.dataListMobile(search,getSessionUser());
			DefaultSearch defaultsearch = new DefaultSearch();
			for(PlazaDataView data : dataList){
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if(null == data.getUserPhoto()){
					data.setUserPhoto(defaultModel.getImgUrl());
				}
				}
				
			//话题
			search.setEqualCategory(0);
			List<PlazaDataView> datatopic = zhanglmServiceManage.plazaDataService.dataListMobile(search,getSessionUser());
			for(PlazaDataView data : datatopic){
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
			if(null == data.getUserPhoto()){
				data.setUserPhoto(defaultModel.getImgUrl());
			}
			}
			List<PlazaDataView> filterlive = new ArrayList<PlazaDataView>();
			for (PlazaDataView plazadataview : dataList) {
					filterlive.add(plazadataview);
			}
			for (PlazaDataView plazadataview : datatopic) {
					filterlive.add(plazadataview);
			}
			number = zhanglmServiceManage.plazaDataService.count(search);
			map.put("number", number);
			map.put("currPage", currPage);
			map.put("dataList", filterlive);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
}
