package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.CommentReplyModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.view.zhanglm.CommentReplyView;

public class CommentReplyConvert implements BaseConvertI<CommentReplyModel, CommentReplyView> {

	@Override
	public CommentReplyModel addConvert(CommentReplyView view) throws ProjectException {
		CommentReplyModel model = new CommentReplyModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public CommentReplyModel editConvert(CommentReplyView view, CommentReplyModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public CommentReplyView convertToView(CommentReplyModel model) throws ProjectException {
		CommentReplyView view = new CommentReplyView();
		ReflectUtils.copySameFieldToTarget(model, view);
		MemberModel member = model.getMember();
		if(member != null){
			view.setUserName(member.getNickName());
			view.setUserPhoto(member.getPhoto());
		}
		return view;
	}

}
