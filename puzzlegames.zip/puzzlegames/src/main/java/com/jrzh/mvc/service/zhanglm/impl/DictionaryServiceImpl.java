package com.jrzh.mvc.service.zhanglm.impl;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.DictionaryConvert;
import com.jrzh.mvc.dao.zhanglm.DictionaryDaoI;
import com.jrzh.mvc.model.zhanglm.DictionaryModel;
import com.jrzh.mvc.search.zhanglm.DictionarySearch;
import com.jrzh.mvc.service.zhanglm.DictionaryServiceI;
import com.jrzh.mvc.view.zhanglm.DictionaryView;
@Service("DictionaryServiceI")
public class DictionaryServiceImpl extends BaseServiceImpl<DictionaryModel, DictionarySearch, DictionaryView> 
implements DictionaryServiceI {

	@Resource(name = "DictionaryDaoI")
	private DictionaryDaoI dictionarydaoi;

	@Override
	public BaseDaoI<DictionaryModel> getDao() {
		return dictionarydaoi;
	}

	@Override
	public BaseConvertI<DictionaryModel, DictionaryView> getConvert() {
		return new DictionaryConvert();
	}
	




}
