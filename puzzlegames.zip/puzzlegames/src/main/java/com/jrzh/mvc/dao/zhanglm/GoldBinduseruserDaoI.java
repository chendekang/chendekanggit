package com.jrzh.mvc.dao.zhanglm;

import com.jrzh.mvc.model.zhanglm.GoldbinduseruserModel;

public interface GoldBinduseruserDaoI {
	String savebinduser(GoldbinduseruserModel binduseruser);

	GoldbinduseruserModel findByField(String string, String id);

	Integer executeSql(String sql, String value);
}
