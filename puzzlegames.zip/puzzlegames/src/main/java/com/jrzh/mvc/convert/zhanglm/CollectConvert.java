package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.CollectModel;
import com.jrzh.mvc.view.zhanglm.CollectView;

public class CollectConvert implements BaseConvertI<CollectModel, CollectView> {

	@Override
	public CollectModel addConvert(CollectView view) throws ProjectException {
		CollectModel model = new CollectModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public CollectModel editConvert(CollectView view, CollectModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public CollectView convertToView(CollectModel model) throws ProjectException {
		CollectView view = new CollectView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
