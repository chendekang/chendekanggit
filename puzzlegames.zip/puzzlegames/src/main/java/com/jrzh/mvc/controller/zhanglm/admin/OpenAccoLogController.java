package com.jrzh.mvc.controller.zhanglm.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.convert.zhanglm.OpenAccoLogConvert;
import com.jrzh.mvc.model.zhanglm.AppointmentaccountModel;
import com.jrzh.mvc.model.zhanglm.OpenAccoLogModel;
import com.jrzh.mvc.search.zhanglm.AppointmentaccountSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.AppointmentaccountView;
import com.jrzh.mvc.view.zhanglm.OpenAccoLogView;

@Controller(OpenAccoLogController.LOCATION +"/OpenAccoLogController")
@RequestMapping(OpenAccoLogController.LOCATION)
public class OpenAccoLogController extends BaseAdminController{
	public static final String LOCATION = "memberManage/admin/openAccoLog";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_openAccoLog";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}

/*	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "OpenAccoLog列表查询")
	@ResponseBody
	public EasyuiDataGrid<OpenAccoLogView> datagrid(OpenAccoLogSearch search) {
		EasyuiDataGrid<OpenAccoLogView> dg = new EasyuiDataGrid<OpenAccoLogView>();
	    try{
	    	dg = zhanglmServiceManage.openAccoLogService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}*/
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "OpenAccoLog列表查询")
	@ResponseBody
	public EasyuiDataGrid<AppointmentaccountView> datagrid(AppointmentaccountSearch search) {
		EasyuiDataGrid<AppointmentaccountView> dg = new EasyuiDataGrid<AppointmentaccountView>();
	    try{
	    	dg = zhanglmServiceManage.appointmentaccountservice.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new OpenAccoLogView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "OpenAccoLog增加")
	@ResponseBody
	public ResultBean add(OpenAccoLogView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			OpenAccoLogModel model =new OpenAccoLogConvert().addConvert(view);
			zhanglmServiceManage.openAccoLogService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.openAccoLogService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "OpenAccoLog修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, OpenAccoLogView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			OpenAccoLogModel model = zhanglmServiceManage.openAccoLogService.findById(id);
			model = new OpenAccoLogConvert().editConvert(view, model);
			zhanglmServiceManage.openAccoLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "OpenAccoLog删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			AppointmentaccountModel model = zhanglmServiceManage.appointmentaccountservice.findByField("id", id);
			//OpenAccoLogModel model = zhanglmServiceManage.openAccoLogService.findById(id);
			zhanglmServiceManage.appointmentaccountservice.deleteopenaccolog(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "OpenAccoLog禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			OpenAccoLogModel model = zhanglmServiceManage.openAccoLogService.findById(id);
			model.setStatus(BusinessConstants.OPEN_ACCO_STATUS.SOLVE);
			zhanglmServiceManage.openAccoLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
