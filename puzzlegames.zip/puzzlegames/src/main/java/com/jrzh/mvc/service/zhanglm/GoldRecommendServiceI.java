package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.GoldRecommendModel;
import com.jrzh.mvc.search.zhanglm.GoldRecommendSearch;
import com.jrzh.mvc.view.zhanglm.GoldRecommendView;

public interface GoldRecommendServiceI  extends BaseServiceI<GoldRecommendModel, GoldRecommendSearch, GoldRecommendView>{

}