package com.jrzh.mvc.dao.zhanglm;

import java.util.List;

import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.CorrectAnswerModel;
import com.jrzh.mvc.search.zhanglm.CorrectAnswerSearch;

public interface CorrectAnswerViewDaoI extends BaseDaoI<CorrectAnswerModel>{
	 public List<CorrectAnswerModel> selectByField(String paramString, Object paramObject);

	public List<CorrectAnswerModel> findList(CorrectAnswerSearch search);

	public CorrectAnswerModel getmodel(String id);

}
