package com.jrzh.mvc.controller.zhanglm.admin;

import java.io.File;
import java.util.List;

import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.jrzh.common.bean.excel.ExcelBean;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.model.zhanglm.GoldRecommendModel;
import com.jrzh.mvc.search.zhanglm.SnapshotSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.GoldHistoryView;
import com.jrzh.mvc.view.zhanglm.SnapshotView;
import com.jrzh.tools.ExcelTools;

@Controller(SnapshotController.LOCATION +"/SnapshotController")
@RequestMapping(SnapshotController.LOCATION)
public class SnapshotController extends BaseAdminController{
	public static final String LOCATION = "productManage/admin/snapshot";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String VIEW_PAGE = LOCATION + "/view";
	
	public static final String MODULE = "zhanglm_snapshot";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "Snapshot列表查询")
	@ResponseBody
	public EasyuiDataGrid<SnapshotView> datagrid(SnapshotSearch search) {
		EasyuiDataGrid<SnapshotView> dg = new EasyuiDataGrid<SnapshotView>();
	    try{
	    	search.setSort("id");
	    	dg = zhanglmServiceManage.snapshotService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "importHistory")
	public String importHistory(){
		return FORM_PAGE;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.POST,value = "importHistory")
	@UserEvent(desc = "导入黄金历史数据")
	@ResponseBody
	public ResultBean importFundRatio(@RequestParam("filename") MultipartFile mFile){
		ResultBean result = new ResultBean();
		String message = "";
		try {
			String url = this.getClass().getClassLoader().getResource("goldHistory.properties").getFile();
			File file = new File(url);
			ExcelTools excel = new ExcelTools(file);
			CommonsMultipartFile cf = (CommonsMultipartFile) mFile;
			DiskFileItem fi = (DiskFileItem)cf.getFileItem();
			File importFile = fi.getStoreLocation();
			ExcelBean excelBean = excel.importExcel(importFile);
			List<GoldHistoryView> list = (List<GoldHistoryView>) excelBean.getSourceList().get(0);
			zhanglmServiceManage.goldHistoryService.addAndReset(list, getSessionUser());
			message = "导入成功";
			result.setStatus(ResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
			if(StringUtils.isBlank(message)){
				message = "系统异常";
			}
		}
		result.setMsg(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "viewHistory/{id}")
	public String viewHistory(){
		return VIEW_PAGE;
	}

	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "Snapshot设为推荐/删除推荐")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") Integer id){
		ResultBean result = new ResultBean();
		try {
			GoldRecommendModel model = zhanglmServiceManage.goldRecommendService.findByField("snapshotId", id);
			if(model != null){
				zhanglmServiceManage.goldRecommendService.delete(model, getSessionUser());
			}else{
				model = new GoldRecommendModel();
				model.setSnapshotId(id);
				zhanglmServiceManage.goldRecommendService.add(model, getSessionUser());
			}
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
