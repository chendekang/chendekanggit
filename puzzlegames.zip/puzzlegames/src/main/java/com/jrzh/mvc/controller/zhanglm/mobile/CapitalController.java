package com.jrzh.mvc.controller.zhanglm.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.WithdrawAuditLogModel;
import com.jrzh.mvc.search.zhanglm.WithdrawAuditLogSearch;
import com.jrzh.mvc.view.zhanglm.WithdrawAuditLogView;

@Controller(CapitalController.LOCATION + "CapitalController")
@RequestMapping(CapitalController.LOCATION)
public class CapitalController extends BaseMobileController {
	public static final String LOCATION = "/mobile/capital/";
	
	@RequestMapping(method = RequestMethod.POST, value = "withdraw")
	@MemberEvent(desc = "安卓/IOS 发起提现申请")
	@ResponseBody
	public MobileResultBean writeUserIntro(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "withdraw");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String moneyStr = request.getParameter("money");
				Double money = Double.parseDouble(moneyStr);
				WithdrawAuditLogModel model = new WithdrawAuditLogModel();
				model.setUserId(getSessionUser().getId());
				model.setDrawMoney(money);
				model.setAuditState(BusinessConstants.WITHDROW_AUDIT_STATUS.NOT_AUDIT);
				zhanglmServiceManage.withdrawAuditLogService.add(model, getSessionUser());
				message = "申请成功，等待工作人员审核";
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setObject(map);
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "withdrawLog")
	@MemberEvent(desc = "安卓/IOS 提现申请记录")
	@ResponseBody
	public MobileResultBean withdrawLog(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<WithdrawAuditLogView> viewList = new ArrayList<WithdrawAuditLogView>();
		map.put("method", "withdrawLog");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				WithdrawAuditLogSearch search = new WithdrawAuditLogSearch();
				search.setEqualUserId(getSessionUser().getId());
				viewList = zhanglmServiceManage.withdrawAuditLogService.viewList(search);
				map.put("withdrawLogList", viewList);
				message = "获取成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setObject(map);
		result.setMessage(message);
		return result;
	}
}
