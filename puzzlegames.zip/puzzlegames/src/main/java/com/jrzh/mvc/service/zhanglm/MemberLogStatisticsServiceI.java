package com.jrzh.mvc.service.zhanglm;
import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.mvc.model.zhanglm.GoldbinduseruserModel;
import com.jrzh.mvc.model.zhanglm.MemberLogStatisticsModel;
import com.jrzh.mvc.search.zhanglm.GoidCustomerSearch;
import com.jrzh.mvc.search.zhanglm.MemberLogStatisticsSearch;
import com.jrzh.mvc.view.zhanglm.MemberLogStatisticsView;

public interface MemberLogStatisticsServiceI {
	String add(MemberLogStatisticsModel model) throws ProjectException;

	EasyuiDataGrid<MemberLogStatisticsView> datagrid(GoidCustomerSearch search);

	MemberLogStatisticsModel findBySearch(MemberLogStatisticsSearch search);

	void update(MemberLogStatisticsModel model);

	void exportlogstatistics(GoidCustomerSearch search, HttpServletResponse response) throws ProjectException, IOException;
	//添加绑定用户
	String addbinduser(GoldbinduseruserModel binduseruser);
	//查询绑定用户
	GoldbinduseruserModel findByField(String string, String id);
	//删除绑定用户
	Integer delete(String sql, String id);
}
