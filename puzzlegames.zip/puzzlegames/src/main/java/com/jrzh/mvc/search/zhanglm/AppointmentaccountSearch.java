package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class AppointmentaccountSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String equalname;
	
	private String equalMobilel;
	
	private Integer equalStatus;
	
	
	public Integer getEqualStatus() {
		return equalStatus;
	}

	public void setEqualStatus(Integer equalStatus) {
		this.equalStatus = equalStatus;
	}
	public String getEqualname() {
		return equalname;
	}

	public void setEqualname(String equalname) {
		this.equalname = equalname;
	}

	public String getEqualMobilel() {
		return equalMobilel;
	}

	public void setEqualMobilel(String equalMobilel) {
		this.equalMobilel = equalMobilel;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		//dc.createAlias("user", "user");
		if(StringUtils.isNotBlank(equalMobilel)){
			dc.add(Restrictions.eq("mobile", equalMobilel));
		}
		if(StringUtils.isNotBlank(equalname)){
			dc.add(Restrictions.eq("name", equalname));
		}
	/*	if(StringUtils.isNotBlank(likeName)){
			dc.add(Restrictions.like("user.nickName", "%"+likeName+"%"));
		}*/
		if(null != equalStatus){
			dc.add(Restrictions.eq("status", equalStatus));
		}
	}

}