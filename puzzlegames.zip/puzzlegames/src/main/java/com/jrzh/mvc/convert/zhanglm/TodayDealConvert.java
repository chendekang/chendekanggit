package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.mvc.model.zhanglm.TodayDealModel;
import com.jrzh.mvc.view.zhanglm.SnapshotView;
import com.jrzh.mvc.view.zhanglm.TodayDealView;
public class TodayDealConvert {
	public TodayDealModel addConvert(SnapshotView view) throws ProjectException {
		TodayDealModel model = new TodayDealModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	public TodayDealModel editConvert(TodayDealView view, TodayDealModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	public TodayDealView convertToView(TodayDealModel model) throws ProjectException {
		TodayDealView view = new TodayDealView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}
}
