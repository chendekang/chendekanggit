package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class MemberAttentionSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String equalMemberId;
	private String equalFansId;
	
	public String getEqualMemberId() {
		return equalMemberId;
	}

	public void setEqualMemberId(String equalMemberId) {
		this.equalMemberId = equalMemberId;
	}

	public String getEqualFansId() {
		return equalFansId;
	}

	public void setEqualFansId(String equalFansId) {
		this.equalFansId = equalFansId;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalMemberId)){
			dc.add(Restrictions.eq("memberId", equalMemberId));
		}
		if(StringUtils.isNotBlank(equalFansId)){
			dc.add(Restrictions.eq("fansId", equalFansId));
		}
	}

}