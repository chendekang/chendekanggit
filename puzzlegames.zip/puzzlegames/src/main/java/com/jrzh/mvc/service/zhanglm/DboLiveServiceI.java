package com.jrzh.mvc.service.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.DboLiveModel;
import com.jrzh.mvc.search.zhanglm.DboLiveSearch;
import com.jrzh.mvc.view.zhanglm.DboLiveView;

public interface DboLiveServiceI  extends BaseServiceI<DboLiveModel, DboLiveSearch, DboLiveView>{
	
	void addAndFile(DboLiveModel model,FileModel file,SessionUser user)throws ProjectException;
	void editAndFile(DboLiveModel model,FileModel file,SessionUser user)throws ProjectException;
	void deleteAndFile(DboLiveModel model,FileModel file,SessionUser user)throws ProjectException;
}