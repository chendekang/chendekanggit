package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.MemberMsgModel;
import com.jrzh.mvc.view.zhanglm.MemberMsgView;

public class MemberMsgConvert implements BaseConvertI<MemberMsgModel, MemberMsgView> {

	@Override
	public MemberMsgModel addConvert(MemberMsgView view) throws ProjectException {
		MemberMsgModel model = new MemberMsgModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public MemberMsgModel editConvert(MemberMsgView view, MemberMsgModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public MemberMsgView convertToView(MemberMsgModel model) throws ProjectException {
		MemberMsgView view = new MemberMsgView();
		ReflectUtils.copySameFieldToTarget(model, view);
		view.setMemberMsgId(model.getId());
		return view;
	}

}
