package com.jrzh.mvc.convert.zhanglm;

import org.apache.commons.lang.StringUtils;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.OpenAccoLogModel;
import com.jrzh.mvc.view.zhanglm.OpenAccoLogView;

public class OpenAccoLogConvert implements BaseConvertI<OpenAccoLogModel, OpenAccoLogView> {

	@Override
	public OpenAccoLogModel addConvert(OpenAccoLogView view) throws ProjectException {
		OpenAccoLogModel model = new OpenAccoLogModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public OpenAccoLogModel editConvert(OpenAccoLogView view, OpenAccoLogModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public OpenAccoLogView convertToView(OpenAccoLogModel model) throws ProjectException {
		OpenAccoLogView view = new OpenAccoLogView();
		ReflectUtils.copySameFieldToTarget(model, view);
		view.setStatusStr(BusinessConstants.OPEN_ACCO_STATUS.valueMap.get(view.getStatus()));
		MemberModel member = model.getUser();
		if(null != member){
			String nickName = member.getNickName();
			if(StringUtils.isNotBlank(nickName)){
				view.setUserName(nickName);
			}else{
				view.setUserName("该用户未设置昵称");
			}
		}
		return view;
	}

}
