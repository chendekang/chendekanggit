package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.mvc.model.zhanglm.ZhiboCourseModel;
import com.jrzh.mvc.search.zhanglm.ZhiboCourseSearch;
import com.jrzh.mvc.view.zhanglm.ZhiboCourseView;

public interface ZhiboCourseServiceI{
	void add(ZhiboCourseModel views)throws ProjectException;
	List<ZhiboCourseModel> viewListall(ZhiboCourseSearch search)throws ProjectException;
	List<ZhiboCourseView> viewListallzb(ZhiboCourseSearch zhibocoursesearch);
	void deletecourse(List<ZhiboCourseModel> viewList) throws ProjectException;
	void edit(ZhiboCourseModel model) throws ProjectException;
	
}
