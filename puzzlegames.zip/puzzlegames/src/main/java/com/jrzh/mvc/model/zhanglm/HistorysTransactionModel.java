package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.jrzh.framework.base.BaseObject;

@Entity
@Table(name = "zlm_quo_sfd_historys_transaction")
public class HistorysTransactionModel extends BaseObject{
	private static final long serialVersionUID = 1L;
	/**
	* 
	*/
	@Id
	@Column(name = "_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String id;
	@Column(name = "_instID")
	private String instid;

	@Column(name = "_name")
	private String name;

	@Column(name = "_lastSettle")
	private Double lastsettle;

	@Column(name = "_lastClose")
	private Double lastclose;

	@Column(name = "_open")
	private Double open;

	@Column(name = "_high")
	private Double high;

	@Column(name = "_low")
	private Double low;

	@Column(name = "_last")
	private Double last;

	@Column(name = "_close")
	private Double close;

	@Column(name = "_settle")
	private Double settle;

	@Column(name = "_bid1")
	private Double bid1;

	@Column(name = "_bidLot1")
	private Integer bidlot1;

	@Column(name = "_bid2")
	private Double bid2;

	@Column(name = "_bidLot2")
	private Integer bidlot2;

	@Column(name = "_bid3")
	private Double bid3;

	@Column(name = "_bidLot3")
	private Integer bidlot3;

	@Column(name = "_bid4")
	private Double bid4;

	@Column(name = "_bidLot4")
	private Integer bidlot4;

	@Column(name = "_bid5")
	private Double bid5;

	@Column(name = "_bidLot5")
	private Integer bidlot5;

	@Column(name = "_ask1")
	private Double ask1;

	@Column(name = "_askLot1")
	private Integer asklot1;

	@Column(name = "_ask2")
	private Double ask2;

	@Column(name = "_askLot2")
	private Integer asklot2;

	@Column(name = "_ask3")
	private Double ask3;

	@Column(name = "_askLot3")
	private Integer asklot3;

	@Column(name = "_ask4")
	private Double ask4;

	@Column(name = "_askLot4")
	private Integer asklot4;

	@Column(name = "_ask5")
	private Double ask5;

	@Column(name = "_askLot5")
	private Integer asklot5;

	@Column(name = "_volume")
	private Double volume;

	@Column(name = "_weight")
	private Double weight;

	@Column(name = "_highLimit")
	private Double highlimit;

	@Column(name = "_lowLimit")
	private Double lowlimit;

	@Column(name = "_posi")
	private Double posi;

	@Column(name = "_upDown")
	private Double updown;

	@Column(name = "_upDownRate")
	private Double updownrate;

	@Column(name = "_turnOver")
	private Double turnover;

	@Column(name = "_average")
	private Double average;

	@Column(name = "_sequenceNo")
	private Double sequenceno;

	@Column(name = "_datetime")
	private Date datetime;

	@Column(name = "_create_time")
	private Date createTime;
	
	@Column(name = "_datatype")
	private String DataType;


	public String getDataType() {
		return DataType;
	}

	public void setDataType(String dataType) {
		DataType = dataType;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Double getLastsettle() {
		return lastsettle;
	}

	public void setLastsettle(Double lastsettle) {
		this.lastsettle = lastsettle;
	}

	public Double getSettle() {
		return settle;
	}

	public void setSettle(Double settle) {
		this.settle = settle;
	}

	public Double getPosi() {
		return posi;
	}

	public void setPosi(Double posi) {
		this.posi = posi;
	}

	public HistorysTransactionModel() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getInstid() {
		return instid;
	}

	public void setInstid(String instid) {
		this.instid = instid == null ? null : instid.trim();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public Double getLastclose() {
		return lastclose;
	}

	public void setLastclose(Double lastclose) {
		this.lastclose = lastclose;
	}

	public Double getOpen() {
		return open;
	}

	public void setOpen(Double open) {
		this.open = open;
	}

	public Double getHigh() {
		return high;
	}

	public void setHigh(Double high) {
		this.high = high;
	}

	public Double getLow() {
		return low;
	}

	public void setLow(Double low) {
		this.low = low;
	}

	public Double getLast() {
		return last;
	}

	public void setLast(Double last) {
		this.last = last;
	}

	public Double getClose() {
		return close;
	}

	public void setClose(Double close) {
		this.close = close;
	}

	public Double getBid1() {
		return bid1;
	}

	public void setBid1(Double bid1) {
		this.bid1 = bid1;
	}

	public Integer getBidlot1() {
		return bidlot1;
	}

	public void setBidlot1(Integer bidlot1) {
		this.bidlot1 = bidlot1;
	}

	public Double getBid2() {
		return bid2;
	}

	public void setBid2(Double bid2) {
		this.bid2 = bid2;
	}

	public Integer getBidlot2() {
		return bidlot2;
	}

	public void setBidlot2(Integer bidlot2) {
		this.bidlot2 = bidlot2;
	}

	public Double getBid3() {
		return bid3;
	}

	public void setBid3(Double bid3) {
		this.bid3 = bid3;
	}

	public Integer getBidlot3() {
		return bidlot3;
	}

	public void setBidlot3(Integer bidlot3) {
		this.bidlot3 = bidlot3;
	}

	public Double getBid4() {
		return bid4;
	}

	public void setBid4(Double bid4) {
		this.bid4 = bid4;
	}

	public Integer getBidlot4() {
		return bidlot4;
	}

	public void setBidlot4(Integer bidlot4) {
		this.bidlot4 = bidlot4;
	}

	public Double getBid5() {
		return bid5;
	}

	public void setBid5(Double bid5) {
		this.bid5 = bid5;
	}

	public Integer getBidlot5() {
		return bidlot5;
	}

	public void setBidlot5(Integer bidlot5) {
		this.bidlot5 = bidlot5;
	}

	public Double getAsk1() {
		return ask1;
	}

	public void setAsk1(Double ask1) {
		this.ask1 = ask1;
	}

	public Integer getAsklot1() {
		return asklot1;
	}

	public void setAsklot1(Integer asklot1) {
		this.asklot1 = asklot1;
	}

	public Double getAsk2() {
		return ask2;
	}

	public void setAsk2(Double ask2) {
		this.ask2 = ask2;
	}

	public Integer getAsklot2() {
		return asklot2;
	}

	public void setAsklot2(Integer asklot2) {
		this.asklot2 = asklot2;
	}

	public Double getAsk3() {
		return ask3;
	}

	public void setAsk3(Double ask3) {
		this.ask3 = ask3;
	}

	public Integer getAsklot3() {
		return asklot3;
	}

	public void setAsklot3(Integer asklot3) {
		this.asklot3 = asklot3;
	}

	public Double getAsk4() {
		return ask4;
	}

	public void setAsk4(Double ask4) {
		this.ask4 = ask4;
	}

	public Integer getAsklot4() {
		return asklot4;
	}

	public void setAsklot4(Integer asklot4) {
		this.asklot4 = asklot4;
	}

	public Double getAsk5() {
		return ask5;
	}

	public void setAsk5(Double ask5) {
		this.ask5 = ask5;
	}

	public Integer getAsklot5() {
		return asklot5;
	}

	public void setAsklot5(Integer asklot5) {
		this.asklot5 = asklot5;
	}

	public Double getVolume() {
		return volume;
	}

	public void setVolume(Double volume) {
		this.volume = volume;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Double getHighlimit() {
		return highlimit;
	}

	public void setHighlimit(Double highlimit) {
		this.highlimit = highlimit;
	}

	public Double getLowlimit() {
		return lowlimit;
	}

	public void setLowlimit(Double lowlimit) {
		this.lowlimit = lowlimit;
	}

	public Double getUpdown() {
		return updown;
	}

	public void setUpdown(Double updown) {
		this.updown = updown;
	}

	public Double getUpdownrate() {
		return updownrate;
	}

	public void setUpdownrate(Double updownrate) {
		this.updownrate = updownrate;
	}

	public Double getTurnover() {
		return turnover;
	}

	public void setTurnover(Double turnover) {
		this.turnover = turnover;
	}

	public Double getAverage() {
		return average;
	}

	public void setAverage(Double average) {
		this.average = average;
	}

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}

	public Double getSequenceno() {
		return sequenceno;
	}

	public void setSequenceno(Double sequenceno) {
		this.sequenceno = sequenceno;
	}

}
