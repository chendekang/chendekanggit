package com.jrzh.mvc.controller.zhanglm.admin;
import javax.persistence.Column;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.AategoryConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.AategoryModel;
import com.jrzh.mvc.search.sys.FileSearch;
import com.jrzh.mvc.search.zhanglm.AategorySearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.AategoryView;
@Controller(AategoryController.LOCATION +"/AategoryController")
@RequestMapping(AategoryController.LOCATION)
public class AategoryController extends BaseAdminController{
public static final String LOCATION = "zhanglm/admin/title/titleMenu";
	public static final String INDEX_PAGE = LOCATION + "/index";
	public static final String FORM_PAGE = LOCATION + "/form";

	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "topicDatagrid")
	@UserEvent(desc = "题库分类列表查询")
	@ResponseBody
	public EasyuiDataGrid<AategoryView> topicDatagrid(AategorySearch search) {
		EasyuiDataGrid<AategoryView> dg = new EasyuiDataGrid<AategoryView>();
	    try{
	    	dg = zhanglmServiceManage.aategoryservicei.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	

	
	
	
	
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd(AategorySearch search) {
		try {
		
			request.setAttribute("view", new AategoryView());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}

	
	

	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "分类增加")
	@ResponseBody
	public ResultBean add(AategoryView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			AategoryModel model =new AategoryConvert().addConvert(view);
			String[] url = request.getParameterValues("fileUrl");
			String[] type = request.getParameterValues("fileType");
			FileModel[] fileModels = new FileModel[2];
			if(url != null && url.length > 0){
				for(int i =0;i<url.length;i++){
					FileModel file = new FileModel();
					file.setModel("type");
					file.setName(view.getTypeName());
					file.setType(type[i]);
					file.setUrl(url[i]);
					//file.setFormId(view.getId());
					fileModels[i] = file;
				}
			}
			
			zhanglmServiceManage.aategoryservicei.addAndFiles(model,fileModels, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}
	
	
	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {

			AategoryView view = zhanglmServiceManage.aategoryservicei.findViewById(id);
			//题库图片
			request.setAttribute("file", sysServiceManage.fileService.findViewByField("formId", id));
			//首页图片
			request.setAttribute("pressedFile1", sysServiceManage.fileService.findViewByField("formId", id+"-t1"));
			request.setAttribute("view", view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "分类修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, AategoryView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
/*			String imgUrl = request.getParameter("fileUrl");
			AategoryModel model = zhanglmServiceManage.aategoryservicei.findById(id);
			if(null != model){
				model.setTypeName(view.getTypeName());
				model.setDescribe(view.getDescribe());
				if(StringUtils.isNotBlank(imgUrl)){
					model.setTypeImgUrl(imgUrl);	
				}
			}*/
			AategoryModel model =new AategoryConvert().addConvert(view);
			AategoryModel aateag = zhanglmServiceManage.aategoryservicei.findById(id);
			if(aateag != null){
				
				aateag.setTypeName(model.getTypeName());
				aateag.setTypeImgUrl(model.getTypeImgUrl());
				aateag.setIndeximgType(model.getIndeximgType());
				aateag.setImgType(model.getImgType());
				aateag.setDescribe(model.getDescribe());
			}
			String[] url = request.getParameterValues("fileUrl");
			if(url != null && url.length > 1){
				aateag.setTypeImgUrl(url[0]);
				aateag.setIndeximgType(url[1]);
			}
			zhanglmServiceManage.aategoryservicei.edit(aateag, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "分类删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			AategoryModel model = zhanglmServiceManage.aategoryservicei.findById(id);
			zhanglmServiceManage.aategoryservicei.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	
	@Override
	protected void setData() {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
