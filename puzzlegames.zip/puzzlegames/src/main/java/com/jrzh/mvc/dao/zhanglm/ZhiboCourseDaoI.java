package com.jrzh.mvc.dao.zhanglm;
import java.util.List;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.ZhiboCourseModel;
public interface ZhiboCourseDaoI extends BaseDaoI<ZhiboCourseModel>{
	 public List<ZhiboCourseModel> selectByField(String paramString, Object paramObject);

}
