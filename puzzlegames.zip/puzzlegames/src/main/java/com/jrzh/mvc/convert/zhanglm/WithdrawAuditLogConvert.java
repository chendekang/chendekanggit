package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.WithdrawAuditLogModel;
import com.jrzh.mvc.view.zhanglm.WithdrawAuditLogView;

public class WithdrawAuditLogConvert implements BaseConvertI<WithdrawAuditLogModel, WithdrawAuditLogView> {

	@Override
	public WithdrawAuditLogModel addConvert(WithdrawAuditLogView view) throws ProjectException {
		WithdrawAuditLogModel model = new WithdrawAuditLogModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public WithdrawAuditLogModel editConvert(WithdrawAuditLogView view, WithdrawAuditLogModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public WithdrawAuditLogView convertToView(WithdrawAuditLogModel model) throws ProjectException {
		WithdrawAuditLogView view = new WithdrawAuditLogView();
		ReflectUtils.copySameFieldToTarget(model, view);
		view.setAuditStateStr(BusinessConstants.WITHDROW_AUDIT_STATUS.valueMap.get(view.getAuditState()));
		return view;
	}

}
