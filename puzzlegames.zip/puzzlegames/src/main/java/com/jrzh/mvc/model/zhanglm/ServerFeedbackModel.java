package com.jrzh.mvc.model.zhanglm;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_server_feedback")
public class ServerFeedbackModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 反馈意见
     */
    @Column(name = "_opinion")
    private String opinion;
    /**
     * 联系方式
     */
    @Column(name = "_mobile")
    private String mobile;
    /**
     * 用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 关联用户表
     */
    @ManyToOne(fetch = FetchType.EAGER,optional = true,cascade = CascadeType.PERSIST, targetEntity = MemberModel.class )
	@JoinColumn(name = "_user_id",referencedColumnName = "_id",insertable=false,updatable=false)
	private MemberModel user;
    /**
     * 用户名称无效
     */
    @Column(name = "_user_name")
    private String userName;
    /**
     * 反馈状态
     */
    @Column(name = "_status")
    private Integer status;
    /**
     * 回复信息
     */
    @Column(name = "_reply")
    private String reply;
    /**
     * 回复人
     */
    @Column(name = "_reply_user")
    private String replyUser;

    public MemberModel getUser() {
		return user;
	}

	public void setUser(MemberModel user) {
		this.user = user;
	}

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}

	public String getReplyUser() {
		return replyUser;
	}

	public void setReplyUser(String replyUser) {
		this.replyUser = replyUser;
	}

	public void setOpinion(String opinion) {
        this.opinion = opinion;
    }
    
    public String getOpinion() {
        return this.opinion;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
    public String getMobile() {
        return this.mobile;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String getUserName() {
        return this.userName;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    
    public Integer getStatus() {
        return this.status;
    }

}