package com.jrzh.mvc.service.zhanglm.impl;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.DotitleConvert;
import com.jrzh.mvc.dao.zhanglm.DotitleDaoI;
import com.jrzh.mvc.model.zhanglm.DotitleModel;
import com.jrzh.mvc.search.zhanglm.DotitleSearch;
import com.jrzh.mvc.service.zhanglm.DotitleServiceI;
import com.jrzh.mvc.view.zhanglm.DotitleView;
@Service("DotitleServiceI")
public class DotitleServiceImpl extends
		BaseServiceImpl<DotitleModel, DotitleSearch, DotitleView> implements
		DotitleServiceI {

	@Resource(name = "DotitleDaoI")
	private DotitleDaoI dotitledaoi;

	@Override
	public BaseDaoI<DotitleModel> getDao() {
		return dotitledaoi;
	}

	@Override
	public BaseConvertI<DotitleModel, DotitleView> getConvert() {
		return new DotitleConvert();
	}

}
