package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.convert.zhanglm.DiǎnboLiveConvert;
import com.jrzh.mvc.dao.zhanglm.DboLiveDaoI;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.DboLiveModel;
import com.jrzh.mvc.search.zhanglm.DboLiveSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.DboLiveServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.DboLiveView;

@Service("dboLiveServiceI")
public class DboLiveServiceImpl extends
		BaseServiceImpl<DboLiveModel, DboLiveSearch, DboLiveView> implements
		DboLiveServiceI {

	@SuppressWarnings("unused")
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@Resource(name = "dboLiveDaoI")
	private DboLiveDaoI dboLiveDaoI;
	
	@Autowired
	private SysServiceManage sysServiceManage;

	@Override
	public BaseDaoI<DboLiveModel> getDao() {
		return dboLiveDaoI;
	}

	@Override
	public BaseConvertI<DboLiveModel, DboLiveView> getConvert() {
		return new DiǎnboLiveConvert();
	}
/*
	@Override
	public void addAndFile(ZhiboLiveModel model, FileModel file,SessionUser user) throws ProjectException {
		this.add(model, user);
		if(null != file){
			file.setFormId(model.getId());
			sysServiceManage.fileService.add(file, user);
		}
		//直播发布到广场
		PlazaDataModel plazaData = new PlazaDataModel();
		plazaData.setDataId(model.getId());
		plazaData.setUserId(model.getUserId());
		plazaData.setDataCategory(BusinessConstants.PLAZA_DATA_CATEGORY.ZHIBO);
		zhanglmServiceManage.plazaDataService.add(plazaData, user);
	}

	@Override
	public void editAndFile(ZhiboLiveModel model, FileModel file,SessionUser user) throws ProjectException {
		this.edit(model, user);
		if(null != file){
			sysServiceManage.fileService.edit(file, user);
		}
	}

	@Override
	public void deleteAndFile(ZhiboLiveModel model, FileModel file,SessionUser user) throws ProjectException {
		this.delete(model, user);
		if(null != file){
			sysServiceManage.fileService.delete(file, user);
		}
	}*/

	@Override
	public void addAndFile(DboLiveModel model, FileModel file, SessionUser user) throws ProjectException {
		this.add(model, user);
		if(null != file){
			file.setFormId(model.getId());
			sysServiceManage.fileService.add(file, user);
		}
		//点播发布到广场
/*		PlazaDataModel plazaData = new PlazaDataModel();
		plazaData.setDataId(model.getId());
		plazaData.setUserId(model.getUserId());
		plazaData.setDataCategory(BusinessConstants.PLAZA_DATA_CATEGORY.ZHIBO);
		zhanglmServiceManage.plazaDataService.add(plazaData, user);*/
		
	}

	@Override
	public void editAndFile(DboLiveModel model, FileModel file, SessionUser user) throws ProjectException {
		this.edit(model, user);
		if(null != file){
			sysServiceManage.fileService.edit(file, user);
		}
	}

	@Override
	public void deleteAndFile(DboLiveModel model, FileModel file, SessionUser user) throws ProjectException {
		this.delete(model, user);
		if(null != file){
			sysServiceManage.fileService.delete(file, user);
		}
		
	}
}
