package com.jrzh.mvc.service.zhanglm;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.BbsCommentsModel;
import com.jrzh.mvc.search.zhanglm.BbsCommentsSearch;
import com.jrzh.mvc.view.zhanglm.BbsCommentsView;
public interface BbsCommentsServiceI  extends BaseServiceI<BbsCommentsModel, BbsCommentsSearch, BbsCommentsView>{

}