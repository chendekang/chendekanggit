package com.jrzh.mvc.service.zhanglm.impl;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.mvc.convert.zhanglm.BankMessageConvert;
import com.jrzh.mvc.dao.zhanglm.BankMessageDaoI;
import com.jrzh.mvc.model.zhanglm.BankMessageModel;
import com.jrzh.mvc.search.zhanglm.BankMessageSearch;
import com.jrzh.mvc.service.zhanglm.BankMessageServiceI;
import com.jrzh.mvc.view.zhanglm.BankMessageView;
import com.jrzh.tools.ExceptionConstant;
import com.jrzh.tools.ExportsWorkBookException;
import com.jrzh.tools.PoiUtils;

@Service("bankmessageservicei")
public class BankMessageServiceImpl implements BankMessageServiceI{
	@Resource(name = "bankmessagedaoi")
	private BankMessageDaoI bankmessagedaoi;
	private Logger log = LoggerFactory.getLogger(BankMessageServiceImpl.class);
	//添加
	@Override
	public String add(BankMessageModel model) throws ProjectException {
	    Date _time = new Date();
	    model.setCreatetime(_time);
	    return bankmessagedaoi.save(model);
	
	}

	//查询列表
	@Override
	public EasyuiDataGrid<BankMessageView> datagrid(BankMessageSearch search) {
		EasyuiDataGrid<BankMessageView> dg = new EasyuiDataGrid<BankMessageView>();
		List<BankMessageView> view_list = new ArrayList<BankMessageView>();
		Long count = bankmessagedaoi.countBySearch(search);
		if (count.longValue() > 0L) {
			try {
				view_list = viewList(search);
			} catch (ProjectException e) {
				e.printStackTrace();
			}
		}
		dg.setRows(view_list);
		dg.setTotal(count);
		return dg;
	}
	
	public List<BankMessageView> viewList(BankMessageSearch search) throws ProjectException{
		List<BankMessageModel> list = this.list(search);
		return this.convertByModelList(list);
	}
	
	public List<BankMessageModel> list(BankMessageSearch search){
		return  bankmessagedaoi.findListBySearch(search);
	}

	public List<BankMessageView> convertByModelList(List<BankMessageModel> modelList) throws ProjectException{
		List<BankMessageView> viewList = new ArrayList<BankMessageView>();
		if(null != modelList && modelList.size() > 0){
			for(BankMessageModel t : modelList){
				viewList.add(getConvert().convertToView(t));
			}
		}
		return viewList;
	}
	public BankMessageConvert getConvert() {
		return new BankMessageConvert();
	}

	
	/**
	 * 导出
	 * @throws ProjectException 
	 * @throws IOException 
	 */
	@Override
	public void exportbankmessage(BankMessageSearch search, HttpServletResponse response) throws ProjectException, IOException {
		List<BankMessageModel> list = this.list(search);
		List<BankMessageView> view =  this.convertByModelList(list);
		List<Map<String, Object>> sheetData = new ArrayList<Map<String, Object>>();
		Map<String, Object> map = null;
	    SimpleDateFormat sim =  new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
		for (BankMessageView bm : view) {
			map = new HashMap<String, Object>();
			map.put("客户号", bm.getAccNo());
			map.put("入金金额", bm.getTransferFund());
			map.put("银行账号", bm.getBankCard());
			map.put("入金时间", bm.getTransfertime());
			map.put("创建时间", sim.format(bm.getCreatetime()));
			sheetData.add(map);

		}
		List<String[]> titleDatas = new ArrayList<String[]>();
		titleDatas.add(new String[] { "客户号", "入金金额", "银行账号", "入金时间","创建时间"});
		Map<String, List<Map<String, Object>>> wbData = new HashMap<String, List<Map<String, Object>>>();
		wbData.put("银行转账信息", sheetData);
		Workbook workbook = PoiUtils.createSxssWorkBook(wbData, titleDatas);
		String filename = "银行转账列表.xlsx";// 设置下载时客户端Excel的名称
		filename = URLEncoder.encode(filename, "utf-8");
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("Content-disposition", "attachment;filename="
				+ filename);
		OutputStream ouputStream = null;
		try {
			ouputStream = response.getOutputStream();
			workbook.write(ouputStream);
			ouputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
			log.error(ExceptionConstant.EXPORT_LOGS_FAIL, e);
			throw new ExportsWorkBookException(
					ExceptionConstant.EXPORT_LOGS_FAIL);
		} finally {
			try {
				if (ouputStream != null)
					ouputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
				throw new ExportsWorkBookException("关闭导出excel文件流失败");
			}
		}
	}
}
