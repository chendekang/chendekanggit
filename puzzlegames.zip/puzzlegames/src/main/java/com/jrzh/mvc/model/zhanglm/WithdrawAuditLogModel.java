package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_withdraw_audit_log")
public class WithdrawAuditLogModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 用户名称
     */
    @Column(name = "_user_name")
    private String userName;
    /**
     * 提现金额
     */
    @Column(name = "_draw_money")
    private Double drawMoney;
    /**
     * 审核人
     */
    @Column(name = "_auditor")
    private String auditor;
    /**
     * 审核说明
     */
    @Column(name = "_status")
    private String status;
    /**
     * 审核状态
     */
    @Column(name = "_audit_state")
    private Integer auditState;

    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String getUserName() {
        return this.userName;
    }
    
    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }
    
    public Double getDrawMoney() {
		return drawMoney;
	}

	public void setDrawMoney(Double drawMoney) {
		this.drawMoney = drawMoney;
	}

	public String getAuditor() {
        return this.auditor;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getStatus() {
        return this.status;
    }
    public void setAuditState(Integer auditState) {
        this.auditState = auditState;
    }
    
    public Integer getAuditState() {
        return this.auditState;
    }

}