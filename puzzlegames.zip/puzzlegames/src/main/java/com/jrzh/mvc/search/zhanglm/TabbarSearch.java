package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class TabbarSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private Integer equalTabBarVersion;
		
	private String likeTabName;
	
	
	public String getLikeTabName() {
		return likeTabName;
	}

	public void setLikeTabName(String likeTabName) {
		this.likeTabName = likeTabName;
	}

	public Integer getEqualTabBarVersion() {
		return equalTabBarVersion;
	}

	public void setEqualTabBarVersion(Integer equalTabBarVersion) {
		this.equalTabBarVersion = equalTabBarVersion;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(null != equalTabBarVersion){
			dc.add(Restrictions.eq("tabVersion", equalTabBarVersion));
			
		}
		if(StringUtils.isNotBlank(likeTabName)){
			dc.add(Restrictions.like("tabName", "%"+likeTabName+"%"));
		}
	}

}