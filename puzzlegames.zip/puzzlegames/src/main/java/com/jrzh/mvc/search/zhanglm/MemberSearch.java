package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.common.utils.DateUtil;
import com.jrzh.framework.base.search.BaseSearch;

public class MemberSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private Integer equalLoginChannel;
	
	private String equalStartDate;
	
	private String equalEndDate;
	
	private String equalMobile;
	
	private String likeNickName;
	
	private Integer equalState;
	
	
	public Integer getEqualState() {
		return equalState;
	}

	public void setEqualState(Integer equalState) {
		this.equalState = equalState;
	}

	public String getLikeNickName() {
		return likeNickName;
	}

	public void setLikeNickName(String likeNickName) {
		this.likeNickName = likeNickName;
	}

	public String getEqualMobile() {
		return equalMobile;
	}

	public void setEqualMobile(String equalMobile) {
		this.equalMobile = equalMobile;
	}

	public String getEqualStartDate() {
		return equalStartDate;
	}

	public void setEqualStartDate(String equalStartDate) {
		this.equalStartDate = equalStartDate;
	}

	public String getEqualEndDate() {
		return equalEndDate;
	}

	public void setEqualEndDate(String equalEndDate) {
		this.equalEndDate = equalEndDate;
	}
    

	public Integer getEqualLoginChannel() {
		return equalLoginChannel;
	}

	public void setEqualLoginChannel(Integer equalLoginChannel) {
		this.equalLoginChannel = equalLoginChannel;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(null != equalState){
			dc.add(Restrictions.eq("isTeacher", equalState));
		}
		
		if(null != equalLoginChannel){
			dc.add(Restrictions.eq("loginChannel", equalLoginChannel));
		}
		if(StringUtils.isNotBlank(equalStartDate)){
			dc.add(Restrictions.ge("createTime", DateUtil.format(equalStartDate + " 00:00:00","yyyy-MM-dd HH:mm:ss")));
		}
		if(StringUtils.isNotBlank(equalEndDate)){
			dc.add(Restrictions.le("createTime",DateUtil.format(equalEndDate + " 23:59:59","yyyy-MM-dd HH:mm:ss")));
		}
		if(StringUtils.isNotBlank(equalMobile)){
			dc.add(Restrictions.eq("mobile", equalMobile));
		}
		if(StringUtils.isNotBlank(likeNickName)){
			dc.add(Restrictions.like("nickName", "%"+likeNickName+"%"));
		}
	}

}