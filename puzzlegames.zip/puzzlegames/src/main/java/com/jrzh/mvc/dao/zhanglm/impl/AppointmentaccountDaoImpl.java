package com.jrzh.mvc.dao.zhanglm.impl;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.AppointmentaccountDaoI;
import com.jrzh.mvc.model.zhanglm.AppointmentaccountModel;
import com.jrzh.mvc.search.zhanglm.AppointmentaccountSearch;
@Repository("appointmentaccountdaoi")
public class AppointmentaccountDaoImpl extends BaseDaoImpl<AppointmentaccountModel> implements  AppointmentaccountDaoI{
	@Autowired
	private SessionFactory sessionFactory;
	@SuppressWarnings("unchecked")
	private Class<AppointmentaccountModel> getClazz(){
		return  (Class< AppointmentaccountModel >)((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}

	@Override
	public String addll(AppointmentaccountModel model) {
		return ((String) this.sessionFactory.getCurrentSession().save(model));
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AppointmentaccountModel> selectByField(String fieldName, Object value) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		dc.add(Restrictions.eq(fieldName, value));
		return dc.getExecutableCriteria(sessionFactory.getCurrentSession()).list();
	}

	@Override
	public AppointmentaccountModel findByField(String fieldName, String value) {
		List<AppointmentaccountModel> list = selectByField(fieldName, value);
		    if ((list != null) && (list.size() > 0)) {
		      return list.get(0);
		    }
		    return null;
	}


	@Override
	public Long countBySearch(AppointmentaccountSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		search.setAutoDc(dc);
		Long count = (Long) dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
				.setProjection(Projections.rowCount()).uniqueResult();
		return Long.valueOf((count == null) ? 0L : count.longValue());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AppointmentaccountModel> findListBySearch(AppointmentaccountSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		if (search != null) {
			search.setAutoDc(dc);
			return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
					.setFirstResult((search.getPage() - 1) * search.getRows()).setMaxResults(search.getRows()).list();
		}
		return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).list();
	}

	@Override
	public void deleteopenaccolog(AppointmentaccountModel model) {
		this.sessionFactory.getCurrentSession().delete(model);
		
	}


}
