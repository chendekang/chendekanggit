package com.jrzh.mvc.model.zhanglm;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "question_bank")
public class TitleReleaseModel extends BaseModel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * 题目标题
     */
    @Column(name = "_title")
    private String title;
    /**
     * 题目内容
     */
    @Column(name = "_content")
    private String content;
    /**一个题目对应多个答案,一对多
     * 答案ID\n
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = CorrectAnswerModel.class)
 	@JoinColumn(name = "_id", referencedColumnName = "_questionid",insertable=false,updatable=false)
 	@NotFound(action=NotFoundAction.IGNORE)
    private CorrectAnswerModel answermodel;

    
    /**
     *题目解析
     */
    @Column(name = "_analysis")
    private String analysis;
    
    /**
     * 题目类型(排行题/闯关题/活动题)
     */
    @Column(name = "_q_type")
    private String qtype;
    /**
     * 一个分类对应多个题目
     * 关联分类id
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = AategoryModel.class)
	@JoinColumn(name = "_categoryid", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private AategoryModel aategoryMenu;
  
    
    @Column(name = "_categoryid")
    private String categoryid;
    
    /**
     * 难度
     */
    @Column(name = "_difficulty")
    private Integer difficulty;
    /**
     *分值
     */
    @Column(name = "_score")
    private Integer score;

    /**
     *开放状态(对哪一类会员开放)
     */
    @Column(name = "_isopen")
    private Integer isopen;

    
    /**
     * 回复数量
     */
    @Column(name = "_comment_count")
    private Integer commentcount;
    /**
     *正确数量
     */
    @Column(name = "_correct_count")
    private Double correctcount;

    /**
     *错误数量
     */
    @Column(name = "_wrong_count")
    private Integer wrongcount;
    
    /**
     *题目配图
     */
    @Column(name = "_question_imgurl")
    private String questionimgurl;
    /**
     * 解析配图
     */
    @Column(name = "_analysis_imgurl")
    private String analysisimgurl;
    
    /**
     * 正确答案
     */
    @Column(name = "_correct")
    private String correct;
    
    
    /**
     * 评论数
     */
    @Column(name = "_discuss")
    private Integer discuss;
    
    /**
     * 题目图片url
     */
    @Column(name = "_imgUrl")
    private String imgurl;
   
    /**
     * 收藏数
     */
    @Column(name = "_collection")
    private Integer collection;
    
    /**
     * 排序字段
     */
    @Column(name = "_sorting")
    private Integer sorting;
    
    
    /**
     * 标识是否重做
     */
    @Column(name = "_tag")
    private Integer tag;
    
    
    
	public Integer getTag() {
		return tag;
	}
	public void setTag(Integer tag) {
		this.tag = tag;
	}
	public Integer getSorting() {
		return sorting;
	}
	public void setSorting(Integer sorting) {
		this.sorting = sorting;
	}
	public Integer getCollection() {
		return collection;
	}
	public void setCollection(Integer collection) {
		this.collection = collection;
	}
	public String getImgurl() {
		return imgurl;
	}
	public void setImgurl(String imgurl) {
		this.imgurl = imgurl;
	}
	public Integer getDiscuss() {
		return discuss;
	}
	public void setDiscuss(Integer discuss) {
		this.discuss = discuss;
	}
	public String getCorrect() {
		return correct;
	}
	public void setCorrect(String correct) {
		this.correct = correct;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAnalysis() {
		return analysis;
	}
	public void setAnalysis(String analysis) {
		this.analysis = analysis;
	}

	public String getQtype() {
		return qtype;
	}
	public void setQtype(String qtype) {
		this.qtype = qtype;
	}
	public AategoryModel getAategoryMenu() {
		return aategoryMenu;
	}
	public void setAategoryMenu(AategoryModel aategoryMenu) {
		this.aategoryMenu = aategoryMenu;
	}
	public String getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(String categoryid) {
		this.categoryid = categoryid;
	}
	public Integer getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(Integer difficulty) {
		this.difficulty = difficulty;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public Integer getIsopen() {
		return isopen;
	}
	public void setIsopen(Integer isopen) {
		this.isopen = isopen;
	}
	public Integer getCommentcount() {
		return commentcount;
	}
	public void setCommentcount(Integer commentcount) {
		this.commentcount = commentcount;
	}

	public Double getCorrectcount() {
		return correctcount;
	}
	public void setCorrectcount(Double correctcount) {
		this.correctcount = correctcount;
	}
	public Integer getWrongcount() {
		return wrongcount;
	}
	public void setWrongcount(Integer wrongcount) {
		this.wrongcount = wrongcount;
	}
	public String getQuestionimgurl() {
		return questionimgurl;
	}
	public void setQuestionimgurl(String questionimgurl) {
		this.questionimgurl = questionimgurl;
	}
	public String getAnalysisimgurl() {
		return analysisimgurl;
	}
	public void setAnalysisimgurl(String analysisimgurl) {
		this.analysisimgurl = analysisimgurl;
	}
	public CorrectAnswerModel getAnswermodel() {
		return answermodel;
	}
	public void setAnswermodel(CorrectAnswerModel answermodel) {
		this.answermodel = answermodel;
	}

}


