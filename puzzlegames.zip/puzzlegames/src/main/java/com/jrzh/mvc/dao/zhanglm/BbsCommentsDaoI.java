package com.jrzh.mvc.dao.zhanglm;

import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.BbsCommentsModel;

public interface BbsCommentsDaoI extends BaseDaoI<BbsCommentsModel>{

}
