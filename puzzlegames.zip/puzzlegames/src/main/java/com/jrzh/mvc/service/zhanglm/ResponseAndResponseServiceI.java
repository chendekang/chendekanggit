package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.ResponseAndResponseModel;
import com.jrzh.mvc.search.zhanglm.ResponseAndResponseSearch;
import com.jrzh.mvc.view.zhanglm.ResponseAndResponseView;

public interface ResponseAndResponseServiceI  extends BaseServiceI<ResponseAndResponseModel, ResponseAndResponseSearch, ResponseAndResponseView>{



}