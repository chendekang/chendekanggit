package com.jrzh.mvc.dao.zhanglm;

import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.MemberOptionalModel;

public interface MemberOptionalDaoI extends BaseDaoI<MemberOptionalModel>{

}
