package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.mvc.model.zhanglm.AnswerModel;
import com.jrzh.mvc.view.zhanglm.AnswerView;

public class AnswerConvert {

	public AnswerModel addConvert(AnswerView view) throws ProjectException {
		AnswerModel model = new AnswerModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	public AnswerModel editConvert(AnswerView view, AnswerModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	public static AnswerView convertToView(AnswerModel model) throws ProjectException {
		AnswerView view = new AnswerView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
