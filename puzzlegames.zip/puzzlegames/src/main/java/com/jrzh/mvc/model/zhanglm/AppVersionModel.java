package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_app_version")
public class AppVersionModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 版本名称
     */
    @Column(name = "_app_name")
    private String appName;
    /**
     * 版本号
     */
    @Column(name = "_app_number")
    private Integer appNumber;
    /**
     * 文件地址
     */
    @Column(name = "_app_url")
    private String appUrl;
    /**
     * 状态
     */
    @Column(name = "_app_status")
    private Integer appStatus;
    /**
     * 二维码
     */
    @Column(name = "_app_qr_code")
    private String appQrCode;

    public void setAppName(String appName) {
        this.appName = appName;
    }
    
    public String getAppName() {
        return this.appName;
    }
    public void setAppNumber(Integer appNumber) {
        this.appNumber = appNumber;
    }
    
    public Integer getAppNumber() {
        return this.appNumber;
    }
    public void setAppUrl(String appUrl) {
        this.appUrl = appUrl;
    }
    
    public String getAppUrl() {
        return this.appUrl;
    }
    public void setAppStatus(Integer appStatus) {
        this.appStatus = appStatus;
    }
    
    public Integer getAppStatus() {
        return this.appStatus;
    }
    public void setAppQrCode(String appQrCode) {
        this.appQrCode = appQrCode;
    }
    
    public String getAppQrCode() {
        return this.appQrCode;
    }

}