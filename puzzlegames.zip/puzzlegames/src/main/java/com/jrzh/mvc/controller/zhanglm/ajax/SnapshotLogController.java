package com.jrzh.mvc.controller.zhanglm.ajax;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.utils.DateUtil;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAjaxController;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.search.zhanglm.GoldHistorySearch;
import com.jrzh.mvc.search.zhanglm.SnapshotLogSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.GoldHistoryView;
import com.jrzh.mvc.view.zhanglm.SnapshotLogView;

@Controller(SnapshotLogController.LOCATION +"/SnapshotLogController")
@RequestMapping(SnapshotLogController.LOCATION)
public class SnapshotLogController extends BaseAjaxController{
	public static final String LOCATION = "zhanglm/ajax/snapshotLog";

	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET, value = "kLine")
	@UserEvent(desc = "k线图数据")
	@ResponseBody
	public ResultBean kLine(){
		ResultBean result = new ResultBean();
		try {
			String symbol = request.getParameter("symbol");
			String[] resymbol = symbol.split(" ");
			symbol = "";
			for (int i = 0; i < resymbol.length; i++) {
				if(i == 0){
					symbol = resymbol[i];
				}else{
					symbol += "+"+resymbol[i];
				}
			}
			String type = request.getParameter("type");
			if("".equals(type) || null == type){
				GoldHistorySearch search = new GoldHistorySearch();
				search.setEqualSymbol(symbol);
				search.setSort("dateTime");
				search.setOrder("asc");
				List<GoldHistoryView> list = zhanglmServiceManage.goldHistoryService.viewList(search);
				Object [] objs = new Object[list.size()];
				if(CollectionUtils.isNotEmpty(list)){
					for (int i=0;i<list.size();i++) {
						Object [] data = new Object[6];
						data[0] = DateUtil.format(list.get(i).getDateTime(),"yyyy/MM/dd");
						data[1] = list.get(i).getOpen();
						data[2] = list.get(i).getClose();
						data[3] = list.get(i).getLow();
						data[4] = list.get(i).getHigh();
						data[5] = list.get(i).getTvolume();
						objs[i] = data;
					}
					result.setObjs(objs);
					result.setStatus(ResultBean.SUCCESS);
				}
			}else{
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+type);
				SnapshotLogSearch search = new SnapshotLogSearch();
				search.setEqSymbol(symbol);
				search.setSort("oldDatetime");
				search.setOrder("asc");
				search.setEqType(Integer.valueOf(type));
				List<SnapshotLogView> list = zhanglmServiceManage.snapshotLogService.viewList(search);
				Object [] objs = new Object[list.size()];
				if(CollectionUtils.isNotEmpty(list)){
					for (int i=0;i<list.size();i++) {
						Object [] data = new Object[6];
						data[0] = DateUtil.format(list.get(i).getOldDatetime(),"MM/dd HH:mm:ss");
						data[1] = list.get(i).getOldOpen();
						data[2] = list.get(i).getOldClose();
						data[3] = list.get(i).getOldLow();
						data[4] = list.get(i).getOldHigh();
						data[5] = list.get(i).getOldTvolume();
						objs[i] = data;
					}
					result.setObjs(objs);
					result.setStatus(ResultBean.SUCCESS);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	@Override
	protected void setData() {
		
	}
	

}
