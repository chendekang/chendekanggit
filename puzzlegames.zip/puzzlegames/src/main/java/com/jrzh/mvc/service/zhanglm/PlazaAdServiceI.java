package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.PlazaAdModel;
import com.jrzh.mvc.search.zhanglm.PlazaAdSearch;
import com.jrzh.mvc.view.zhanglm.PlazaAdView;

public interface PlazaAdServiceI  extends BaseServiceI<PlazaAdModel, PlazaAdSearch, PlazaAdView>{

	void addAndFile(PlazaAdModel model,FileModel file,SessionUser user) throws Exception;
	void editAndFile(PlazaAdModel model,FileModel file,SessionUser user) throws Exception;
	void deleteAndFile(PlazaAdModel model, FileModel file, SessionUser user)throws Exception;
}