package com.jrzh.mvc.dao.zhanglm;

import java.util.List;

import com.jrzh.mvc.model.zhanglm.AppointmentaccountModel;
import com.jrzh.mvc.search.zhanglm.AppointmentaccountSearch;

public interface AppointmentaccountDaoI {

	String addll(AppointmentaccountModel model);

	AppointmentaccountModel findByField(String string, String mobile);

	Long countBySearch(AppointmentaccountSearch search);

	List<AppointmentaccountModel> findListBySearch(AppointmentaccountSearch search);

	void deleteopenaccolog(AppointmentaccountModel model);

}
