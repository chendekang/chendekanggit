package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.AategoryModel;
import com.jrzh.mvc.model.zhanglm.ResponseAndResponseModel;
import com.jrzh.mvc.view.zhanglm.AategoryView;
import com.jrzh.mvc.view.zhanglm.ResponseAndResponseView;
public class ResponseAndResponseConvert implements BaseConvertI<ResponseAndResponseModel, ResponseAndResponseView> {

	@Override
	public ResponseAndResponseModel addConvert(ResponseAndResponseView view) throws ProjectException {
		ResponseAndResponseModel model = new ResponseAndResponseModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public ResponseAndResponseModel editConvert(ResponseAndResponseView view, ResponseAndResponseModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public ResponseAndResponseView convertToView(ResponseAndResponseModel model) throws ProjectException {
		ResponseAndResponseView view = new ResponseAndResponseView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
