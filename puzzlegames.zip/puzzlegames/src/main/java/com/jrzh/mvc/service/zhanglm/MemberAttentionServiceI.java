package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.MemberAttentionModel;
import com.jrzh.mvc.search.zhanglm.MemberAttentionSearch;
import com.jrzh.mvc.view.zhanglm.MemberAttentionView;

public interface MemberAttentionServiceI  extends BaseServiceI<MemberAttentionModel, MemberAttentionSearch, MemberAttentionView>{

}