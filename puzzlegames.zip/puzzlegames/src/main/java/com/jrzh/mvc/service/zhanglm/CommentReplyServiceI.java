package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.CommentReplyModel;
import com.jrzh.mvc.search.zhanglm.CommentReplySearch;
import com.jrzh.mvc.view.zhanglm.CommentReplyView;

public interface CommentReplyServiceI  extends BaseServiceI<CommentReplyModel, CommentReplySearch, CommentReplyView>{

	List<CommentReplyView> viewListCommentReply(CommentReplySearch commentreplysearch, String userId) throws ProjectException;

}