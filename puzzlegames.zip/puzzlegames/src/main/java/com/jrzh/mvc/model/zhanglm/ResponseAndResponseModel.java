package com.jrzh.mvc.model.zhanglm;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;
@Entity
@Table(name = "zlm_response_and_response")
public class ResponseAndResponseModel extends BaseModel {

	private static final long serialVersionUID = 1L;
	/**
     * 回复表ID
     */
    @Column(name = "_reply_id")
    private String replyid;
    /**
     * 内容
     */
    @Column(name = "content")
    private String content;
    /**
     * 用户id
     */
    @Column(name = "_userId")
    private String userid;
    
    
	public String getReplyid() {
		return replyid;
	}
	public void setReplyid(String replyid) {
		this.replyid = replyid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}


}


