package com.jrzh.mvc.search.zhanglm;



import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class AppVersionSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private Boolean equalDisable;
	
	
	public Boolean getEqualDisable() {
		return equalDisable;
	}

	public void setEqualDisable(Boolean equalDisable) {
		this.equalDisable = equalDisable;
	}


	@Override
	public void setDc(DetachedCriteria dc) {
	if(null!=equalDisable){	
		dc.add(Restrictions.eq("isDisable", equalDisable));
	}
	}

}