package com.jrzh.mvc.controller.zhanglm.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.ServerQuestionConvert;
import com.jrzh.mvc.model.zhanglm.ServerQuestionModel;
import com.jrzh.mvc.search.zhanglm.ServerQuestionSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.ServerQuestionView;

@Controller(ServerQuestionController.LOCATION +"/ServerQuestionController")
@RequestMapping(ServerQuestionController.LOCATION)
public class ServerQuestionController extends BaseAdminController{
	public static final String LOCATION = "serverManage/admin/serverQuestion";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_serverQuestion";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "ServerQuestion列表查询")
	@ResponseBody
	public EasyuiDataGrid<ServerQuestionView> datagrid(ServerQuestionSearch search) {
		EasyuiDataGrid<ServerQuestionView> dg = new EasyuiDataGrid<ServerQuestionView>();
	    try{
	    	dg = zhanglmServiceManage.serverQuestionService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new ServerQuestionView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "ServerQuestion增加")
	@ResponseBody
	public ResultBean add(ServerQuestionView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			ServerQuestionModel model =new ServerQuestionConvert().addConvert(view);
			model.setUserName(getSessionUser().getName());
			zhanglmServiceManage.serverQuestionService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.serverQuestionService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "ServerQuestion修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, ServerQuestionView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			ServerQuestionModel model = zhanglmServiceManage.serverQuestionService.findById(id);
			view.setUserName(model.getUserName());
			model = new ServerQuestionConvert().editConvert(view, model);
			zhanglmServiceManage.serverQuestionService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "ServerQuestion删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			ServerQuestionModel model = zhanglmServiceManage.serverQuestionService.findById(id);
			zhanglmServiceManage.serverQuestionService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "ServerQuestion禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			ServerQuestionModel model = zhanglmServiceManage.serverQuestionService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.serverQuestionService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
