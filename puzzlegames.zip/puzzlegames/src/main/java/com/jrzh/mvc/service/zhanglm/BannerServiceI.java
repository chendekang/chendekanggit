package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.BannerModel;
import com.jrzh.mvc.search.zhanglm.BannerSearch;
import com.jrzh.mvc.view.zhanglm.BannerView;

public interface BannerServiceI  extends BaseServiceI<BannerModel, BannerSearch, BannerView>{
	
	void addAndFile(BannerModel model,FileModel file,SessionUser user) throws Exception;
	void editAndFile(BannerModel model,FileModel file,SessionUser user) throws Exception;
	void deleteAndFile(BannerModel model, FileModel file, SessionUser user)throws Exception;
}