package com.jrzh.mvc.model.zhanglm;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name = "answer_bank")
public class AnswerModel{
	@Id
	@Column(name = "_id")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@GeneratedValue(generator = "system-uuid")
	private String id;

	/**
     * 题目ID
     */
    @Column(name = "_questionid")
    private String questionid;
    /**
     * 答案内容
     */
    @Column(name = "_answer_content")
    private String answercontent;
    /**
     * 答案排序(1/2/3/4, 对应A/B/C/D) 
     */
    @Column(name = "_answer_sort")
    private String answersort;
    
    /**
     * 正确答案
     */
    @Column(name = "_answer")
    private String answer;

    /**
     * 创建时间
     */
    @Column(name = "_ceratedate")
    private Date ceratedate;
    
    
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Date getCeratedate() {
		return ceratedate;
	}
	public void setCeratedate(Date ceratedate) {
		this.ceratedate = ceratedate;
	}
	public String getQuestionid() {
		return questionid;
	}
	public void setQuestionid(String questionid) {
		this.questionid = questionid;
	}
	public String getAnswercontent() {
		return answercontent;
	}
	public void setAnswercontent(String answercontent) {
		this.answercontent = answercontent;
	}
	public String getAnswersort() {
		return answersort;
	}
	public void setAnswersort(String answersort) {
		this.answersort = answersort;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
    
    
    
   
    

}


