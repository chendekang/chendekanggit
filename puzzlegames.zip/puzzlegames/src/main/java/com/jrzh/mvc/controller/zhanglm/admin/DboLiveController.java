package com.jrzh.mvc.controller.zhanglm.admin;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.DiǎnboLiveConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.DboLiveModel;
import com.jrzh.mvc.model.zhanglm.MemberUserModel;
import com.jrzh.mvc.search.zhanglm.DboLiveSearch;
import com.jrzh.mvc.search.zhanglm.SpecialColumnSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.DboLiveView;
import com.jrzh.mvc.view.zhanglm.SpecialColumnView;
import com.jrzh.mvc.view.zhanglm.ZhiboLiveView;
import com.jrzh.tools.TestMain;
import com.jrzh.tools.entity.DemandVo;
@Controller(DboLiveController.LOCATION +"/DboLiveController")
@RequestMapping(DboLiveController.LOCATION)
public class DboLiveController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/dbo/dboLive";	
	public static final String INDEX_PAGE = LOCATION + "/index";	
	public static final String INDEX_ALL_PAGE = LOCATION + "/indexAll";	
	public static final String FORM_PAGE = LOCATION + "/form";
	public static final String EDITOR_PAGE = LOCATION + "/editor";
	public static final String MODULE = "zhanglm_zhiboLive";	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		try {
			List<SpecialColumnView> columnModel = zhanglmServiceManage.specialColumnService.findAllView();
			request.setAttribute("columnModel", columnModel);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "indexAll")
	public String indexAll() {
		try {
			List<SpecialColumnView> columnModel = zhanglmServiceManage.specialColumnService.findAllView();
			request.setAttribute("columnModel", columnModel);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return INDEX_ALL_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "ZhiboLive列表查询")
	@ResponseBody
	public EasyuiDataGrid<DboLiveView> datagrid(DboLiveSearch search) {
		EasyuiDataGrid<DboLiveView> dg = new EasyuiDataGrid<DboLiveView>();
	    try{
	    	MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
	    	if(memberUser != null){
	    		search.setEqualUserId(memberUser.getMemberId());
	    	}
	    	dg = zhanglmServiceManage.dboLiveServiceI.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "allDatagrid")
	@UserEvent(desc = "ZhiboLive列表查询")
	@ResponseBody
	public EasyuiDataGrid<DboLiveView> allDatagrid(DboLiveSearch search) {
		EasyuiDataGrid<DboLiveView> dg = new EasyuiDataGrid<DboLiveView>();
	    try{
	    	dg = zhanglmServiceManage.dboLiveServiceI.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd(SpecialColumnSearch search) {
		//获取专栏分类类别
		try {
			List<SpecialColumnView> viewList = zhanglmServiceManage.specialColumnService.viewList(search);
			List<DemandVo> dbvo = TestMain.dboGet();
			request.setAttribute("dbvoList",dbvo);
			request.setAttribute("viewList",viewList);
			request.setAttribute("view", new ZhiboLiveView());
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "ZhiboLive增加")
	@ResponseBody
	public ResultBean add(DboLiveView dbview){
		ResultBean result = new ResultBean();
		try{
			String imgName = request.getParameter("fileName");
			String imgUrl = request.getParameter("fileUrl");
			String imgType = request.getParameter("fileType");

			//String code = request.getParameter("code");//直播串流码
			String zburl = request.getParameter("zburl");//点播url
			String codes=request.getParameter("codes");
			DboLiveModel diǎnbomodel =new DiǎnboLiveConvert().addConvert(dbview);
			//点播
			if("0002".equals(codes)){
				if(StringUtils.isBlank(imgUrl)){
					result.setMsg("图片不能为空");
					return result;
				}
				if(StringUtils.isBlank(codes)){
					result.setMsg("专栏不能为空");
					return result;
				}
				if(StringUtils.isBlank(imgName)){
					result.setMsg("标题不能为空");
					return result;
				}

				if (StringUtils.isBlank(zburl)) {
					result.setMsg("视频url不能为空");
					return result;
				}
			}else{
				result.setMsg("请选择点播");
				return result;
			}

			//List<ZhiboLiveModel> zhiboModel=zhanglmServiceManage.zhiboLiveService.findAll();
			//生成随机整数1024~65535
			/*String ports=String.valueOf((int)(1024+Math.random()*64511));
			for(ZhiboLiveModel portModel : zhiboModel ){
				String port=portModel.getPort();
				if(port.equals(ports)){
					ports=String.valueOf((int)(1024+Math.random()*64511));
				}
			}*/
//		    //初始化数据
//		    model.setPort(ports);
			//发布人
			MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
			if(memberUser != null){
				String memberId  = memberUser.getMemberId();
				diǎnbomodel.setUserId(memberId);
			}else{
				result.setMsg("管理员未绑定平台用户");
				return result;
			}
			//保存图片
			FileModel file = new FileModel();
			file.setName(imgName);
			file.setType(imgType);
			file.setUrl(imgUrl);
			diǎnbomodel.setImgName(imgName);
			diǎnbomodel.setImgUrl(imgUrl);
			diǎnbomodel.setImgType(imgType);
			diǎnbomodel.setClickNum(0L);
			diǎnbomodel.setColumnCode(codes);
			file.setModel("diǎnboLive");
			diǎnbomodel.setZhiboUrl(zburl);
			zhanglmServiceManage.dboLiveServiceI.addAndFile(diǎnbomodel, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}

	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id,SpecialColumnSearch search) {
		try {
			List<SpecialColumnView> viewList = zhanglmServiceManage.specialColumnService.viewList(search);
			request.setAttribute("viewList",viewList);
			DboLiveView view = zhanglmServiceManage.dboLiveServiceI.findViewById(id);
			//String url = view.getZhiboUrl();
			//String urls[] = url.split(BusinessConstants.RTMP_LIVE);
			//view.setZhiboUrl(urls[1]);
			List<DemandVo> dbvo = TestMain.dboGet();
			request.setAttribute("dbvoList",dbvo);
			request.setAttribute("view", view);
			request.setAttribute("file", sysServiceManage.fileService.findViewByField("formId", id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return EDITOR_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "DiǎnboLive修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, DboLiveView view) {
		ResultBean result = new ResultBean();
		try {
			String imgName = request.getParameter("fileName");
			String imgUrl = request.getParameter("fileUrl");
			String imgType = request.getParameter("fileType");
			//String code = request.getParameter("code");//串流码
			String codes = request.getParameter("codes");//专栏编号
//			String startTime=request.getParameter("startTime");
//			String endTime=request.getParameter("endTime");
			if(StringUtils.isBlank(imgUrl)){
				result.setMsg("图片不能为空");
				return result;
			}
			DboLiveModel model = zhanglmServiceManage.dboLiveServiceI.findById(id);
			view.setClickNum(model.getClickNum());
			model = new DiǎnboLiveConvert().editConvert(view, model);
			//初始化数据
			model.setImgName(imgName);
			model.setImgUrl(imgUrl);
			model.setImgType(imgType);
			//model.setZhiboUrl(BusinessConstants.RTMP_LIVE + code);
			model.setColumnCode(codes);
			//发布人
			MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
			if(memberUser != null){
				String memberId  = memberUser.getMemberId();
				model.setUserId(memberId);
			}else{
				result.setMsg("管理员未绑定平台用户");
				return result;
			}
			//保存图片
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			file.setName(imgName);
			file.setType(imgType);
			file.setUrl(imgUrl);
			zhanglmServiceManage.dboLiveServiceI.editAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "ZhiboLive删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			DboLiveModel model = zhanglmServiceManage.dboLiveServiceI.findById(id);
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			zhanglmServiceManage.dboLiveServiceI.deleteAndFile(model, file, getSessionUser());
			//广场对应直播数据删除
	/*		PlazaDataModel plazaData = zhanglmServiceManage.plazaDataService.findByField("dataId",id);
			if(plazaData != null){
				zhanglmServiceManage.plazaDataService.delete(plazaData, getSessionUser());
			}*/
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "ZhiboLive禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			DboLiveModel model = zhanglmServiceManage.dboLiveServiceI.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.dboLiveServiceI.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "setRecommend/{id}")
	@UserEvent(desc = "菜单设置/取消推荐")
	@ResponseBody
	public ResultBean setRecommend(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			DboLiveModel model = zhanglmServiceManage.dboLiveServiceI.findById(id);
			if(null != model.getIsLock()){
				model.setIsLock(!model.getIsLock());//取消推荐
			}else{
				model.setIsLock(true);//推荐
			}
			zhanglmServiceManage.dboLiveServiceI.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
