package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.MobileSmsSendingModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.notify.sms.bean.MessageBean;

public interface NotifyServiceI {

	void saveSend(String templateCode, MessageBean message, MemberModel member,SessionUser sessionUser);
	void saveSend(MobileSmsSendingModel sending, SessionUser user) throws Exception;
}
