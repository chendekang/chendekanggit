package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class OpenAccoLogSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String likeName;
	
	private String equalMobilel;
	
	private Integer equalStatus;
	
	
	public Integer getEqualStatus() {
		return equalStatus;
	}

	public void setEqualStatus(Integer equalStatus) {
		this.equalStatus = equalStatus;
	}

	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}

	public String getEqualMobilel() {
		return equalMobilel;
	}

	public void setEqualMobilel(String equalMobilel) {
		this.equalMobilel = equalMobilel;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		dc.createAlias("user", "user");
		if(StringUtils.isNotBlank(equalMobilel)){
			dc.add(Restrictions.eq("mobile", equalMobilel));
		}
		if(StringUtils.isNotBlank(likeName)){
			dc.add(Restrictions.like("user.nickName", "%"+likeName+"%"));
		}
		if(null != equalStatus){
			dc.add(Restrictions.eq("status", equalStatus));
		}
	}

}