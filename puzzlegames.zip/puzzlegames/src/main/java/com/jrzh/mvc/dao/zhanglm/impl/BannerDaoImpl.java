package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.BannerDaoI;
import com.jrzh.mvc.model.zhanglm.BannerModel;

@Repository("bannerDao")
public class BannerDaoImpl extends BaseDaoImpl<BannerModel> implements BannerDaoI{

}