package com.jrzh.mvc.controller.zhanglm.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.common.cache.Cache;
import com.jrzh.common.cache.CacheManager;
import com.jrzh.common.utils.HttpClientHelper;
import com.jrzh.config.zhanglm.ZhanglmConfigration;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.constants.ConfigConstants;
import com.jrzh.mvc.model.zhanglm.ServerFeedbackModel;
import com.jrzh.mvc.search.zhanglm.ServerCategorySearch;
import com.jrzh.mvc.search.zhanglm.ServerQuestionSearch;
import com.jrzh.mvc.view.zhanglm.ServerCategoryView;
import com.jrzh.mvc.view.zhanglm.ServerQuestionView;


@Controller(ServerController.LOCATION + "ServerController")
@RequestMapping(ServerController.LOCATION)
public class ServerController extends BaseMobileController {
	public static final String LOCATION = "/mobile/server/";
	
	@Autowired
	ZhanglmConfigration zhanglmConfigration;
	
	@RequestMapping(method = RequestMethod.POST, value = "feedback")
	@MemberEvent(desc = "安卓/IOS意见反馈")
	@ResponseBody
	public MobileResultBean feedback(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "feedback");
		try {
			String opinion = request.getParameter("opinion");
			String mobile = request.getParameter("mobile");
			if(!isLogin()){
				message = "登陆失效";
			}else{
				ServerFeedbackModel model = new ServerFeedbackModel();
				model.setUserId(getSessionUser().getId());
				model.setMobile(mobile);
				model.setOpinion(opinion);
				model.setStatus(BusinessConstants.FEED_BACK_STATUS.NOT_SOLVE);
				zhanglmServiceManage.serverFeedbackService.add(model, getSessionUser());
				message = "感谢您的反馈，请等待工作人员联系";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "questionList")
	@MemberEvent(desc = "安卓/IOS常见问题列表")
	@ResponseBody
	public MobileResultBean questionList(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "questionList");
		try {
			String likeQuestion = request.getParameter("likeQuestion");
			//常见问题列表
			ServerQuestionSearch search = new ServerQuestionSearch();
			search.setEqualIsDisable(false);
			if(StringUtils.isNotBlank(likeQuestion)){
				search.setLikeQuestion(likeQuestion);
			}
			List<ServerQuestionView> viewList = zhanglmServiceManage.serverQuestionService.viewList(search);
			map.put("viewList", viewList);
			//客服电话
			String mobile = sysServiceManage.configService.getValue(ConfigConstants.PLATFORM_TELEPHONE);
			if(StringUtils.isBlank(mobile)){
				mobile = "未设置客服电话";
			}
			map.put("mobile", mobile);
			//客服类别
			List<ServerCategoryView> categoryList = new ArrayList<ServerCategoryView>();
			ServerCategorySearch categorySearch = new ServerCategorySearch();
			search.setEqualIsDisable(false);
			categoryList = zhanglmServiceManage.serverCategoryService.viewList(categorySearch);
			map.put("categoryList", categoryList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "serverPhone")
	@MemberEvent(desc = "安卓/IOS获取客服电话")
	@ResponseBody
	public MobileResultBean serverPhone(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "serverPhone");
		try {
			String mobile = sysServiceManage.configService.getValue(ConfigConstants.PLATFORM_TELEPHONE);
			if(StringUtils.isBlank(mobile)){
				mobile = "未设置客服电话";
			}
			map.put("mobile", mobile);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "serverCategory")
	@MemberEvent(desc = "安卓/IOS获取客服类别")
	@ResponseBody
	public MobileResultBean serverCategory(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<ServerCategoryView> viewList = new ArrayList<ServerCategoryView>();
		String message = "";
		map.put("method", "serverCategory");
		try {
			ServerCategorySearch search = new ServerCategorySearch();
			search.setRows(4);
			search.setSort("sortNum");
			search.setOrder(BaseSearch.Order_Type_Desc);
			search.setEqualIsDisable(false);
			viewList = zhanglmServiceManage.serverCategoryService.viewList(search);
			map.put("viewList", viewList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "serviceAllot")
	@MemberEvent(desc = "安卓/IOS 客服分配")
	@ResponseBody
	public MobileResultBean serviceAllot(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		//获取页面点击类别名称
		String name = request.getParameter("name");
		map.put("method", "serviceAllot");
		try {
			ServerCategorySearch search = new ServerCategorySearch();
			search.setEqualIsDisable(false);
			search.setEqualName(name);
			ServerCategoryView allotView = zhanglmServiceManage.serverCategoryService.findViewBySearch(search);
			map.put("allotView", allotView);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "tourist")
	@MemberEvent(desc = "安卓/IOS游客ID")
	@ResponseBody
	public MobileResultBean tourist(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "tourist");
		try {
			    int num = (int)(Math.random()* 1000000);
			    Cache cacheRecord = CacheManager.getCacheInfo("userCache"+num);
			    Cache cache = new Cache();
			    if(null != cacheRecord){
			    	while(cacheRecord != null){
			    		num = (int)(Math.random()* 1000000);
			    		cacheRecord = CacheManager.getCacheInfo("userCache"+num);
			    	}
			    }
			    cache.setKey("tour");
		    	cache.setValue(num);
				CacheManager.putCache("userCache"+num, cache);
				//同步缓存
				String url = zhanglmConfigration.projectTouristUrl;
				System.out.println(url);
				Map<String, String> params = new HashMap<String, String>();
				params.put("tourId", String.valueOf(num));
				String cahaeResult = HttpClientHelper.doPost(url, params);
	    		System.out.println(cahaeResult);
	    		message = "获取成功";
	    		map.put("tourId", String.valueOf(num));
	    		result.setStatus(MobileResultBean.SUCCESS);
	    		result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "deleteTourist")
	@MemberEvent(desc = "安卓/IOS删除游客ID")
	@ResponseBody
	public MobileResultBean deleteTourist(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "deleteTourist");
		try {
			String tourId = request.getParameter("tourId");
			if(StringUtils.isBlank(tourId)){
				message="游客为空";
			}else{
				CacheManager.clearOnly("userCache" + tourId);
				//同步清除缓存
				String url = zhanglmConfigration.projectDelCacheUrl;
				Map<String, String> params = new HashMap<String, String>();
				params.put("cacheKey", "userCache"+tourId);
				String cacheResult = HttpClientHelper.doPost(url, params);
				System.out.println(cacheResult);
				message = "删除成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
}
