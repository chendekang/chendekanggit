package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.jrzh.framework.base.BaseObject;

@Entity
@Table(name = "zlm_bank_message")
public class BankMessageModel extends BaseObject{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	  @Column(name="_id")
	  @GenericGenerator(name="system-uuid", strategy="uuid")
	  @GeneratedValue(generator="system-uuid")
	  private String id;
	/**
     * 客户号
     */
    @Column(name = "_accno")
    private String accNo;
    /**
     *入金金额
     */
    @Column(name = "_transferfund")
    private String transferFund;
    /**
     * 入金时间
     */
    @Column(name = "_transfertime")
    private String transfertime;
    /**
     *银行账号
     */
    @Column(name = "_bankcard")
    private String bankCard;
    
    /**
     *创建时间
     */
    @Column(name = "_create_time")
    private Date createtime;
 

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getTransferFund() {
		return transferFund;
	}
	public void setTransferFund(String transferFund) {
		this.transferFund = transferFund;
	}
	public String getTransfertime() {
		return transfertime;
	}
	public void setTransfertime(String transfertime) {
		this.transfertime = transfertime;
	}
	public String getBankCard() {
		return bankCard;
	}
	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}


}