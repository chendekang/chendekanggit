package com.jrzh.mvc.dao.zhanglm.impl;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.BankMessageDaoI;
import com.jrzh.mvc.model.zhanglm.BankMessageModel;
import com.jrzh.mvc.search.zhanglm.BankMessageSearch;
@Repository("bankmessagedaoi")
public class BankMessageDaoImpl extends BaseDaoImpl<BankMessageModel> implements BankMessageDaoI {

	@Autowired
	private SessionFactory sessionFactory;


	@SuppressWarnings("unchecked")
	private Class<BankMessageModel> getClazz(){
		return  (Class< BankMessageModel >)((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}
	@Override
	public String save(BankMessageModel model) {
		return ((String) this.sessionFactory.getCurrentSession().save(model));
	}

	@Override
	public Long countBySearch(BankMessageSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		search.setAutoDc(dc);
		Long count = (Long) dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
				.setProjection(Projections.rowCount()).uniqueResult();
		return Long.valueOf((count == null) ? 0L : count.longValue());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BankMessageModel> findListBySearch(BankMessageSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		if (search != null) {
			search.setAutoDc(dc);
			return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
					.setFirstResult((search.getPage() - 1) * search.getRows()).setMaxResults(search.getRows()).list();
		}
		return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).list();
	}

}
