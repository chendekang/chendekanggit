package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.zhanglm.PlazaDataModel;
import com.jrzh.mvc.search.zhanglm.PlazaDataSearch;
import com.jrzh.mvc.view.zhanglm.PlazaDataView;

public interface PlazaDataServiceI  extends BaseServiceI<PlazaDataModel, PlazaDataSearch, PlazaDataView>{

	List<PlazaDataView> dataList(PlazaDataSearch search)throws ProjectException;

	List<PlazaDataView> dataListMobile(PlazaDataSearch search,SessionUser user)throws ProjectException;

	List<PlazaDataView> ViewdataMobile(PlazaDataSearch search, SessionUser sessionUser) throws ProjectException;

}