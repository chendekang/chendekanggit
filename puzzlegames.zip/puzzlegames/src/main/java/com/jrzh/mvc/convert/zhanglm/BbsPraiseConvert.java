package com.jrzh.mvc.convert.zhanglm;

import org.apache.commons.lang.StringUtils;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.BbsPraiseModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.view.zhanglm.BbsPraiseView;

public class BbsPraiseConvert implements BaseConvertI<BbsPraiseModel, BbsPraiseView> {

	@Override
	public BbsPraiseModel addConvert(BbsPraiseView view) throws ProjectException {
		BbsPraiseModel model = new BbsPraiseModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public BbsPraiseModel editConvert(BbsPraiseView view, BbsPraiseModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public BbsPraiseView convertToView(BbsPraiseModel model) throws ProjectException {
		BbsPraiseView view = new BbsPraiseView();
		ReflectUtils.copySameFieldToTarget(model, view);
		MemberModel member = model.getMember();
		if(null != member){
			String userName = member.getNickName();
			String userPhoto = member.getPhoto();
			if(StringUtils.isNotBlank(userPhoto)){
				view.setUserPhoto(userPhoto);
			}
			if(StringUtils.isNotBlank(userName)){
				view.setUserName(userName);
			}else{
				view.setUserName("未设置用户名");
			}
		}
		return view;
	}

}
