package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.MessageTemplateModel;
import com.jrzh.mvc.search.zhanglm.MessageTemplateSearch;
import com.jrzh.mvc.view.zhanglm.MessageTemplateView;

public interface MessageTemplateServiceI  extends BaseServiceI<MessageTemplateModel, MessageTemplateSearch, MessageTemplateView>{

}