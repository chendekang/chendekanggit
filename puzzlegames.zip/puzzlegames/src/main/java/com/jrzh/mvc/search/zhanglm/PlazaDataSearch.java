package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class PlazaDataSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String likeName;
	private Integer equalCategory;
		
	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}

	public Integer getEqualCategory() {
		return equalCategory;
	}

	public void setEqualCategory(Integer equalCategory) {
		this.equalCategory = equalCategory;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		dc.createAlias("member", "member");
		if(StringUtils.isNotBlank(likeName)){
			dc.add(Restrictions.like("member.nickName", "%"+likeName+"%"));
		}
		if(null != equalCategory){
			dc.add(Restrictions.eq("dataCategory", equalCategory));
		}
	}
}