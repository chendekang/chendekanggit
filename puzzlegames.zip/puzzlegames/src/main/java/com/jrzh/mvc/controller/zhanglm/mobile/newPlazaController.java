package com.jrzh.mvc.controller.zhanglm.mobile;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.model.zhanglm.ZhiboCourseModel;
import com.jrzh.mvc.search.zhanglm.DboLiveSearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.PlazaDataSearch;
import com.jrzh.mvc.search.zhanglm.ZhiboCourseSearch;
import com.jrzh.mvc.search.zhanglm.ZhiboLiveSearch;
import com.jrzh.mvc.view.zhanglm.DboLiveView;
import com.jrzh.mvc.view.zhanglm.PlazaDataView;
import com.jrzh.mvc.view.zhanglm.ZhiboLiveView;
@Controller(newPlazaController.LOCATION + "newPlazaController")
@RequestMapping(newPlazaController.LOCATION)
public class newPlazaController extends BaseMobileController {
	public Logger logger = Logger.getLogger(newPlazaController.class);
	public static final String LOCATION = "/plaza/";	
	/*
	 * 获取推荐直播
	 * 
	 * */
	@RequestMapping(method = RequestMethod.POST, value = "getliveData")
	@MemberEvent(desc ="安卓/IOS 获取推荐直播")
	@ResponseBody
	public MobileResultBean getliveData(ZhiboLiveSearch search,DboLiveSearch dbsearch) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		ZhiboCourseSearch zhibocoursesearch = new ZhiboCourseSearch();
		List<ZhiboCourseModel> zhibocourseview = new ArrayList<ZhiboCourseModel>();
		map.put("method", "recommend");
		String message = "";
		try {
			//直播
			search.setEqualIsLock(true);
			search.setRows(2);
			List<ZhiboLiveView> recommendList = zhanglmServiceManage.zhiboLiveService.viewList(search);
			//点播
			dbsearch.setEqualIsLock(true);
			List<DboLiveView> dbList = zhanglmServiceManage.dboLiveServiceI.viewList(dbsearch);
			DefaultSearch defaultsearch = new DefaultSearch();
			ZhiboLiveView zb = new ZhiboLiveView();
			//直播set值
			for (ZhiboLiveView zhibo : recommendList) {
				zhibo.setIntro("直播讲师:" + zhibo.getUserName());
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if (null == zhibo.getPhoto()) {
					zhibo.setPhoto(defaultModel.getImgUrl());
				}
				// 直播	
				if ("0001".equals(zhibo.getColumnCode())) {
					zhibocoursesearch.setEqualzbId(zhibo.getId());
					zhibocourseview = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(zhibocoursesearch);
					if (zhibocourseview != null && zhibocourseview.size() > 0) {
						zb.setStartTime1(zhibocourseview.get(0).getStartTime());
						zb.setEndTime1(zhibocourseview.get(0).getEndTime());
						zb.setTitle1(zhibocourseview.get(0).getTitle());
						zb.setLecturer1(zhibocourseview.get(0).getLecturer());
						zb.setStartTime2(zhibocourseview.get(1).getStartTime());
						zb.setEndTime2(zhibocourseview.get(1).getEndTime());
						zb.setTitle2(zhibocourseview.get(1).getTitle());
						zb.setLecturer2(zhibocourseview.get(1).getLecturer());
						zb.setStartTime3(zhibocourseview.get(2).getStartTime());
						zb.setEndTime3(zhibocourseview.get(2).getEndTime());
						zb.setTitle3(zhibocourseview.get(2).getTitle());
						zb.setLecturer3(zhibocourseview.get(2).getLecturer());
					}
					// 判断是否在直播中 false为未直播 true为正在直播
					Boolean flag = false;
					Long starts1 = zb.getStartTime1().getTime();
					Long Ends1 = zb.getEndTime1().getTime();
					Long starts2 = zb.getStartTime2().getTime();
					Long Ends2 = zb.getEndTime2().getTime();
					Long starts3 = zb.getStartTime3().getTime();
					Long Ends3 = zb.getEndTime3().getTime();
					Long date = new Date().getTime();
					if (starts1 <= date && Ends1 >= date) {
						flag = true;
					}
					if (starts2 <= date && Ends2 >= date) {
						flag = true;
					}
					if (starts3 <= date && Ends3 >= date) {
						flag = true;
					}
					zhibo.setJudgeZhibo(flag);
					// 判断是否在直播中 false为点播播 true为1是直播
					zhibo.setJudgeDianbo(true);	
				} 
			}
/*			//点播set值
			List<DiǎnboLiveView> dbview = new ArrayList<DiǎnboLiveView>();
			for (DiǎnboLiveView dbo : dbList) {
				dbo.setIntro("直播讲师:" + dbo.getUserName());
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if (null == dbo.getPhoto()) {
					dbo.setPhoto(defaultModel.getImgUrl());
				}
				// 点播
				if ("0002".equals(dbo.getColumnCode())) {
					// 判断是否在直播中 false为未直播 true为正在直播
					Boolean flag = false;
					Long starts1 = dbo.getStartTime().getTime();
					Long Ends1 = dbo.getEndTime().getTime();
					Long date = new Date().getTime();
					if (starts1 <= date && Ends1 >= date) {
						flag = true;
					}
					dbo.setJudgeZhibo(flag);
					// 判断是否在直播中 false为点播播 true为1是直播
					dbo.setJudgeDianbo(false);
				} 
				//添加集合
				dbview.add(dbo);
			}*/
			if (recommendList != null && recommendList.size() > 0) {
				map.put("zbList", recommendList);
				//map.put("dbList", dbview);
				result.setObject(map);
				message = "获取推荐直播成功";
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				map.put("zbList", recommendList);
				//map.put("dbList", dbview);
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods index"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}
		
/*	@RequestMapping(method = RequestMethod.POST, value = "getliveData")
	@MemberEvent(desc ="安卓/IOS 获取推荐直播")
	@ResponseBody
	public MobileResultBean getliveData(ZhiboLiveSearch search) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		ZhiboCourseSearch zhibocoursesearch = new ZhiboCourseSearch();
		List<ZhiboCourseModel> zhibocourseview = new ArrayList<ZhiboCourseModel>();
		map.put("method", "getliveData");
		String message = "";
		try {
			search.setEqualIsLock(true);
			search.setRows(2);
			List<ZhiboLiveView> recommendList = zhanglmServiceManage.zhiboLiveService.viewList(search);
				DefaultSearch defaultsearch = new DefaultSearch();
			for (ZhiboLiveView zhibo : recommendList) {
				zhibocoursesearch.setEqualzbId(zhibo.getId());
				zhibocourseview = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(zhibocoursesearch);
				if(zhibocourseview !=null && zhibocourseview.size() > 0){
					zhibo.setStartTime1(zhibocourseview.get(0).getStartTime());
					zhibo.setEndTime1(zhibocourseview.get(0).getEndTime());
					zhibo.setTitle1(zhibocourseview.get(0).getTitle());
					zhibo.setLecturer1(zhibocourseview.get(0).getLecturer());
					zhibo.setStartTime2(zhibocourseview.get(1).getStartTime());
					zhibo.setEndTime2(zhibocourseview.get(1).getEndTime());
					zhibo.setTitle2(zhibocourseview.get(1).getTitle());
					zhibo.setLecturer2(zhibocourseview.get(1).getLecturer());
					zhibo.setStartTime3(zhibocourseview.get(2).getStartTime());
					zhibo.setEndTime3(zhibocourseview.get(2).getEndTime());
					zhibo.setTitle3(zhibocourseview.get(2).getTitle());
					zhibo.setLecturer3(zhibocourseview.get(2).getLecturer());			
				}
				zhibo.setIntro("直播讲师:" + zhibo.getUserName());
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if (null == zhibo.getPhoto()) {
					zhibo.setPhoto(defaultModel.getImgUrl());
				}
			}
			
			if (recommendList != null && recommendList.size() > 0) {
				map.put("recommendList", recommendList);
				result.setObject(map);
				message = "获取推荐直播成功";
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				map.put("recommendList", recommendList);
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getliveData---"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}*/
	
	/*
	 * 
	 * 获取观点数据列表
	 * 
	 * */
	@RequestMapping(method = RequestMethod.POST, value = "getViewdata")
	@MemberEvent(desc ="安卓/IOS 获取广场观点数据")
	@ResponseBody
	public MobileResultBean getViewdata(PlazaDataSearch search,String currPage,String pageSize) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "getViewdata");
		//String currPage = request.getParameter("currPage");
		//String pageSize = request.getParameter("pageSize");
		Long number = 0L;
		String message = "";
		try {
			if(StringUtils.isBlank(currPage)){
				result.setMessage("请求页不能为空");
				return result;
			}
		    search.setPage(Integer.parseInt(currPage));
		    search.setRows(Integer
		    		.parseInt(pageSize));
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Desc);
			DefaultSearch defaultsearch = new DefaultSearch();
			//话题
			search.setEqualCategory(0);
			List<PlazaDataView> datatopic = zhanglmServiceManage.plazaDataService.ViewdataMobile(search,getSessionUser());
			for (PlazaDataView data : datatopic) {
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if (null == data.getUserPhoto()) {
					data.setUserPhoto(defaultModel.getImgUrl());
				}
			}
			number = zhanglmServiceManage.plazaDataService.count(search);
			if (datatopic != null && datatopic.size() > 0) {
				map.put("number", number);
				map.put("currPage", currPage);
				map.put("dataList", datatopic);
				result.setObject(map);
				message = "获取成功";
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				map.put("number", number);
				map.put("currPage", currPage);
				map.put("dataList", datatopic);
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getViewdata---"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}
}
