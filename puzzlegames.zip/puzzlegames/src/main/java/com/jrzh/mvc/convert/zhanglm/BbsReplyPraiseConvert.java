package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.BbsReplyPraiseModel;
import com.jrzh.mvc.view.zhanglm.BbsReplyPraiseView;

public class BbsReplyPraiseConvert implements BaseConvertI<BbsReplyPraiseModel, BbsReplyPraiseView> {

	@Override
	public BbsReplyPraiseModel addConvert(BbsReplyPraiseView view) throws ProjectException {
		BbsReplyPraiseModel model = new BbsReplyPraiseModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public BbsReplyPraiseModel editConvert(BbsReplyPraiseView view, BbsReplyPraiseModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public BbsReplyPraiseView convertToView(BbsReplyPraiseModel model) throws ProjectException {
		BbsReplyPraiseView view = new BbsReplyPraiseView();
		ReflectUtils.copySameFieldToTarget(model, view);
	/*	MemberModel member = model.getMember();
		if(null != member){
			String userName = member.getNickName();
			String userPhoto = member.getPhoto();
			if(StringUtils.isNotBlank(userPhoto)){
				view.setUserPhoto(userPhoto);
			}
			if(StringUtils.isNotBlank(userName)){
				view.setUserName(userName);
			}else{
				view.setUserName("未设置用户名");
			}
		}*/
		return view;
	}

}
