package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.convert.zhanglm.PlazaDataConvert;
import com.jrzh.mvc.model.zhanglm.PlazaDataModel;
import com.jrzh.mvc.search.zhanglm.PlazaDataSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.PlazaDataView;

@Controller(PlazaDataController.LOCATION +"/PlazaDataController")
@RequestMapping(PlazaDataController.LOCATION)
public class PlazaDataController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/plaza/plazaData";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_plazaData";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		Map<Integer, String> categoryMap = BusinessConstants.PLAZA_DATA_CATEGORY.valueMap;
		request.setAttribute("categoryMap", categoryMap);
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "PlazaData列表查询")
	@ResponseBody
	public EasyuiDataGrid<PlazaDataView> datagrid(PlazaDataSearch search) {
		EasyuiDataGrid<PlazaDataView> dg = new EasyuiDataGrid<PlazaDataView>();
	    try{
	    	search.setSort("createTime");
	    	search.setOrder(BaseSearch.Order_Type_Desc);
	    	List<PlazaDataView> viewList = zhanglmServiceManage.plazaDataService.dataList(search);
	    	dg.setRows(viewList);
	    	dg.setTotal((long) viewList.size());
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new PlazaDataView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "PlazaData新增")
	@ResponseBody
	public ResultBean add(PlazaDataView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			PlazaDataModel model =new PlazaDataConvert().addConvert(view);
			zhanglmServiceManage.plazaDataService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.plazaDataService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "PlazaData编辑")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, PlazaDataView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			PlazaDataModel model = zhanglmServiceManage.plazaDataService.findById(id);
			model = new PlazaDataConvert().editConvert(view, model);
			zhanglmServiceManage.plazaDataService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "PlazaData删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			PlazaDataModel model = zhanglmServiceManage.plazaDataService.findById(id);
			zhanglmServiceManage.plazaDataService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "PlazaData启用/禁用状态更改")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			PlazaDataModel model = zhanglmServiceManage.plazaDataService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.plazaDataService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
