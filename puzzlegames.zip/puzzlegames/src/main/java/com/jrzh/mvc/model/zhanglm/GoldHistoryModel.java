package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_gold_historys")
public class GoldHistoryModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 代码
     */
    @Column(name = "_symbol")
    private String symbol;
    /**
     * 产品名称
     */
    @Column(name = "_name")
    private String name;
    /**
     * 日期时间
     */
    @Column(name = "_date_time")
    private Date dateTime;
    /**
     * 开盘价
     */
    @Column(name = "_open")
    private Double open;
    /**
     * 最高价
     */
    @Column(name = "_high")
    private Double high;
    /**
     * 最低价
     */
    @Column(name = "_low")
    private Double low;
    /**
     * 收盘价
     */
    @Column(name = "_close")
    private Double close;
    /**
     * 成交量
     */
    @Column(name = "_tvolume")
    private Double tvolume;
    /**
     * 持仓量
     */
    @Column(name = "_tvalue")
    private Double tvalue;
    
    
	public Double getTvalue() {
		return tvalue;
	}

	public void setTvalue(Double tvalue) {
		this.tvalue = tvalue;
	}

	public void setSymbol(String symbol) {
        this.symbol = symbol;
    }
    
    public String getSymbol() {
        return this.symbol;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }
    
    public Date getDateTime() {
        return this.dateTime;
    }
    public Double getOpen() {
		return open;
	}

	public void setOpen(Double open) {
		this.open = open;
	}

	public Double getHigh() {
		return high;
	}

	public void setHigh(Double high) {
		this.high = high;
	}

	public Double getLow() {
		return low;
	}

	public void setLow(Double low) {
		this.low = low;
	}

	public Double getClose() {
		return close;
	}

	public void setClose(Double close) {
		this.close = close;
	}

	public Double getTvolume() {
		return tvolume;
	}

	public void setTvolume(Double tvolume) {
		this.tvolume = tvolume;
	}

}