package com.jrzh.mvc.model.zhanglm;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;
@Entity
@Table(name = "category")
public class AategoryModel extends BaseModel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * 分类名称
     */
    @Column(name = "_typeName")
    private String typeName;
    /**
     * 类型图片
     */
    @Column(name = "_typeImgUrl")
    private String typeImgUrl;
    /**
     * 首页推荐图片
     */
    @Column(name = "_index_imgType")
    private String indeximgType;
    
    /**
     * 图片格式
     */
    @Column(name = "_imgType")
    private String imgType;
    /**
     * 分类描述
     */
    @Column(name = "_describe")
    private String describe;

	public String getIndeximgType() {
		return indeximgType;
	}
	public void setIndeximgType(String indeximgType) {
		this.indeximgType = indeximgType;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getTypeImgUrl() {
		return typeImgUrl;
	}
	public void setTypeImgUrl(String typeImgUrl) {
		this.typeImgUrl = typeImgUrl;
	}

	public String getImgType() {
		return imgType;
	}
	public void setImgType(String imgType) {
		this.imgType = imgType;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}


