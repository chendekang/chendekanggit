package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.UseranswersModel;
import com.jrzh.mvc.view.zhanglm.UseranswersView;
public class UseranswersConvert implements BaseConvertI<UseranswersModel, UseranswersView> {

	@Override
	public UseranswersModel addConvert(UseranswersView view) throws ProjectException {
		UseranswersModel model = new UseranswersModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public UseranswersModel editConvert(UseranswersView view, UseranswersModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public UseranswersView convertToView(UseranswersModel model) throws ProjectException {
		UseranswersView view = new UseranswersView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
