package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_members")
public class MemberModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 用户昵称
     */
    @Column(name = "_nick_name")
    private String nickName;
    /**
     * 手机号码
     */
    @Column(name = "_mobile")
    private String mobile;
    /**
     * 个性签名
     */
    @Column(name = "_signature")
    private String signature;
    /**
     * 简介	
     */
    @Column(name = "_intro")
    private String intro;
    /**
     * 个人资产
     */
    @Column(name = "_capital")
    private Double capital;
    /**
     * 可用余额
     */
    @Column(name = "_balance")
    private Double balance;
    /**
     * 么币
     */
    @Column(name = "_m_coin")
    private Double mcoin;
    /**
     * 登陆密码
     */
    @Column(name = "_login_pass")
    private String loginPass;
    /**
     * 绑定QQ账号
     */
    @Column(name = "_qq_no")
    private String qqNo;
    /**
     * 绑定微博账号
     */
    @Column(name = "_weibo_no")
    private String weiboNo;
    /**
     * 绑定微信账号
     */
    @Column(name = "_wechat_no")
    private String wechatNo;
    /**
     * 登陆渠道
     */
    @Column(name = "_login_channel")
    private Integer loginChannel;
    /**
     * 头像图片路径
     */
    @Column(name = "_photo")
    private String photo;
    /**
     * 真实姓名
     */
    @Column(name = "_real_name")
    private String realName;
    /**
     * 身份证号
     */
    @Column(name = "_id_card")
    private String idCard;
    /**
     * 银行卡号
     */
    @Column(name = "_bank_acco")
    private String bankAcco;
    public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getBankAcco() {
		return bankAcco;
	}

	public void setBankAcco(String bankAcco) {
		this.bankAcco = bankAcco;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getQqNo() {
		return qqNo;
	}

	public void setQqNo(String qqNo) {
		this.qqNo = qqNo;
	}

	public String getWeiboNo() {
		return weiboNo;
	}

	public void setWeiboNo(String weiboNo) {
		this.weiboNo = weiboNo;
	}

	public String getWechatNo() {
		return wechatNo;
	}

	public void setWechatNo(String wechatNo) {
		this.wechatNo = wechatNo;
	}

	public Integer getLoginChannel() {
		return loginChannel;
	}

	public void setLoginChannel(Integer loginChannel) {
		this.loginChannel = loginChannel;
	}

	public void setNickName(String nickName) {
        this.nickName = nickName;
    }
    
    public String getNickName() {
        return this.nickName;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
    public String getMobile() {
        return this.mobile;
    }
    public void setSignature(String signature) {
        this.signature = signature;
    }
    
    public String getSignature() {
        return this.signature;
    }
    public Double getCapital() {
		return capital;
	}

	public void setCapital(Double capital) {
		this.capital = capital;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Double getMcoin() {
		return mcoin;
	}

	public void setMcoin(Double mcoin) {
		this.mcoin = mcoin;
	}

	public void setIntro(String intro) {
        this.intro = intro;
    }
    
    public String getIntro() {
        return this.intro;
    }
    public void setLoginPass(String loginPass) {
        this.loginPass = loginPass;
    }
    
    public String getLoginPass() {
        return this.loginPass;
    }

}