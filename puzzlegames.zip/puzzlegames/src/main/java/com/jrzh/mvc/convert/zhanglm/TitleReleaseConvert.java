package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.TitleReleaseModel;
import com.jrzh.mvc.view.zhanglm.TitleReleaseView;
public class TitleReleaseConvert implements BaseConvertI<TitleReleaseModel, TitleReleaseView> {

	@Override
	public TitleReleaseModel addConvert(TitleReleaseView view) throws ProjectException {
		TitleReleaseModel model = new TitleReleaseModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public TitleReleaseModel editConvert(TitleReleaseView view, TitleReleaseModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public TitleReleaseView convertToView(TitleReleaseModel model) throws ProjectException {
		TitleReleaseView view = new TitleReleaseView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
