package com.jrzh.mvc.dao.zhanglm;

import java.util.List;

import com.jrzh.mvc.model.zhanglm.GoldbinduseruserModel;
import com.jrzh.mvc.model.zhanglm.MemberLogStatisticsModel;
import com.jrzh.mvc.search.zhanglm.GoidCustomerSearch;
import com.jrzh.mvc.search.zhanglm.MemberLogStatisticsSearch;

public interface MemberLogStatisticsDaoI{
	String save(MemberLogStatisticsModel model);

	Long countBySearch(GoidCustomerSearch search);

	List<MemberLogStatisticsModel> findListBySearch(GoidCustomerSearch search);

	MemberLogStatisticsModel findModelBySearch(MemberLogStatisticsSearch search);

	void update(MemberLogStatisticsModel model);

	String savebinduser(GoldbinduseruserModel binduseruser);
}
