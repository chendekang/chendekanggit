package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.convert.zhanglm.MessageTemplateConvert;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.MemberMsgModel;
import com.jrzh.mvc.model.zhanglm.MessageTemplateModel;
import com.jrzh.mvc.search.zhanglm.MemberSearch;
import com.jrzh.mvc.search.zhanglm.MessageTemplateSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.MessageTemplateView;

@Controller(MessageTemplateController.LOCATION +"/MessageTemplateController")
@RequestMapping(MessageTemplateController.LOCATION)
public class MessageTemplateController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/messageTemplate";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String SEND_FORM_PAGE = LOCATION + "/sendForm";
	
	public static final String MODULE = "zhanglm_messageTemplate";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "MessageTemplate列表查询")
	@ResponseBody
	public EasyuiDataGrid<MessageTemplateView> datagrid(MessageTemplateSearch search) {
		EasyuiDataGrid<MessageTemplateView> dg = new EasyuiDataGrid<MessageTemplateView>();
	    try{
	    	dg = zhanglmServiceManage.messageTemplateService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new MessageTemplateView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "MessageTemplate增加")
	@ResponseBody
	public ResultBean add(MessageTemplateView view,BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		if(errors.hasErrors()){
			for(ObjectError objectError : errors.getAllErrors()){
				message = this.getMessage(objectError.getCode(),objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if(this.log.isDebugEnabled()){
			this.log.debug("doAdd() View:"+ view.toString());
		}
		try{
			MessageTemplateModel model =new MessageTemplateConvert().addConvert(view);
			message = zhanglmServiceManage.messageTemplateService.validate(model);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.messageTemplateService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.messageTemplateService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "MessageTemplate修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, MessageTemplateView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(), objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if (this.log.isDebugEnabled()) {
			this.log.debug("doEdit() View:" + view.toString());
		}
		try {
			MessageTemplateModel model = zhanglmServiceManage.messageTemplateService.findById(id);
			model = new MessageTemplateConvert().editConvert(view, model);
			message = zhanglmServiceManage.messageTemplateService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.messageTemplateService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "MessageTemplate删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id, MessageTemplateView view,
	BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(),
						objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if (this.log.isDebugEnabled()) {
			this.log.debug("doDelete() View:" + view.toString());
		}
		try {
			MessageTemplateModel model = zhanglmServiceManage.messageTemplateService.findById(id);
			zhanglmServiceManage.messageTemplateService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeIsPlatform/{id}")
	@ResponseBody
	public ResultBean changeIsPlatform(@PathVariable("id") String id,MessageTemplateView view, BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(), objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		try {
			MessageTemplateModel model = zhanglmServiceManage.messageTemplateService.findById(id);
			model.setIsSendPlatform(!model.getIsSendPlatform());
			message = zhanglmServiceManage.messageTemplateService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.messageTemplateService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeIsMobile/{id}")
	@ResponseBody
	public ResultBean changeIsMobile(@PathVariable("id") String id,MessageTemplateView view, BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(), objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		try {
			MessageTemplateModel model = zhanglmServiceManage.messageTemplateService.findById(id);
			model.setIsSendMobile(!model.getIsSendMobile());
			message = zhanglmServiceManage.messageTemplateService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.messageTemplateService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id,MessageTemplateView view, BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(), objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		try {
			MessageTemplateModel model = zhanglmServiceManage.messageTemplateService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			message = zhanglmServiceManage.messageTemplateService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.messageTemplateService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "send")
	public String preSend(MessageTemplateSearch search) {
		try {
			search.setEqualIsDisable(false);
			search.setEqualIsSendPlatform(true);
			List<MessageTemplateView> viewList = zhanglmServiceManage.messageTemplateService.viewList(search);
			request.setAttribute("viewList", viewList);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return SEND_FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "send")
	@ResponseBody
	public ResultBean send() {
		ResultBean result = new ResultBean();
		String message = "";
		try {
			String code = request.getParameter("code");
			if(StringUtils.isBlank(code)){
				result.setMsg("请选择一个模板");
				return result;
			}
			MessageTemplateModel model = zhanglmServiceManage.messageTemplateService.findByField("code", code);
			String title = model.getName();
			String content = model.getPlatformContent();
			String senderId = getSessionUser().getId();
			MemberSearch search = new MemberSearch();
			List<MemberModel> memberList = zhanglmServiceManage.memberService.list(search);
			for(MemberModel member : memberList){
				MemberMsgModel msg = new MemberMsgModel();
				msg.setContent(content);
				msg.setSenderId(senderId);
				msg.setUserId(member.getId());
				msg.setTitle(title);
				msg.setStatus(BusinessConstants.MEMBER_MSG_STATUS.NOT_READ);
				zhanglmServiceManage.memberMsgService.add(msg, getSessionUser());
			}
			message = "发送成功";
			result.setStatus(ResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMsg(message);
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
