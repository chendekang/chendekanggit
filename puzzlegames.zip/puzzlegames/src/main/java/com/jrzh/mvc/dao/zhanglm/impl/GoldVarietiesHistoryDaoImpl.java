package com.jrzh.mvc.dao.zhanglm.impl;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.GoldVarietiesHistoryDaoI;
import com.jrzh.mvc.model.zhanglm.GoldVarietiesHistoryModel;

@Repository("goldvarietieshistorydaoi")
public class GoldVarietiesHistoryDaoImpl extends BaseDaoImpl<GoldVarietiesHistoryModel> implements GoldVarietiesHistoryDaoI{

	@Autowired
	private SessionFactory sessionFactory;
	@SuppressWarnings("unchecked")
	private Class<GoldVarietiesHistoryModel> getClazz(){
		return  (Class< GoldVarietiesHistoryModel >)((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}
	@Override
	public GoldVarietiesHistoryModel findByField(String fieldName, Object value) {
		 List list = selectByField(fieldName, value);
		    if ((list != null) && (list.size() > 0)) {
		      return (GoldVarietiesHistoryModel) list.get(0);
		    }
		    return null;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<GoldVarietiesHistoryModel> selectByField(String fieldName, Object value)
	  {
	    DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
	    dc.add(Restrictions.eq(fieldName, value));
	    dc.addOrder(Order.desc("dateTime"));
	    return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).list();
	  }


}