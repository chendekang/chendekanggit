package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class ServerQuestionSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String likeQuestion;
		
	public String getLikeQuestion() {
		return likeQuestion;
	}

	public void setLikeQuestion(String likeQuestion) {
		this.likeQuestion = likeQuestion;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(likeQuestion)){
			dc.add(Restrictions.like("question", "%"+likeQuestion+"%"));
		}
	}

}