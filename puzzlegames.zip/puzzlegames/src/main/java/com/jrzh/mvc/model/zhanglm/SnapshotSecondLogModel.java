package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_snapshot_second_log")
public class SnapshotSecondLogModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 对应黄金表id字段
     */
    @Column(name = "_snapshot_id")
    private Integer snapshotId;
    /**
     * 历史产品代码
     */
    @Column(name = "_old_symbol")
    private String oldSymbol;
    /**
     * 历史产品名称
     */
    @Column(name = "_old_name")
    private String oldName;
    /**
     * 历史存入时间
     */
    @Column(name = "_old_datetime")
    private Date oldDatetime;
    /**
     * 历史最新价
     */
    @Column(name = "_old_close")
    private Double oldClose;
    /**
     * 历史成交量
     */
    @Column(name = "_old_tvolume")
    private Double oldTvolume;
    /**
     * 历史持仓量
     */
    @Column(name = "_old_tvalue")
    private Double oldTvalue;

    public void setSnapshotId(Integer snapshotId) {
        this.snapshotId = snapshotId;
    }
    
    public Integer getSnapshotId() {
        return this.snapshotId;
    }
    public void setOldSymbol(String oldSymbol) {
        this.oldSymbol = oldSymbol;
    }
    
    public String getOldSymbol() {
        return this.oldSymbol;
    }
    public void setOldName(String oldName) {
        this.oldName = oldName;
    }
    
    public String getOldName() {
        return this.oldName;
    }
    public void setOldDatetime(Date oldDatetime) {
        this.oldDatetime = oldDatetime;
    }
    
    public Date getOldDatetime() {
        return this.oldDatetime;
    }
    public void setOldClose(Double oldClose) {
        this.oldClose = oldClose;
    }
    
    public Double getOldClose() {
        return this.oldClose;
    }
    public void setOldTvolume(Double oldTvolume) {
        this.oldTvolume = oldTvolume;
    }
    
    public Double getOldTvolume() {
        return this.oldTvolume;
    }
    public void setOldTvalue(Double oldTvalue) {
        this.oldTvalue = oldTvalue;
    }
    
    public Double getOldTvalue() {
        return this.oldTvalue;
    }

}