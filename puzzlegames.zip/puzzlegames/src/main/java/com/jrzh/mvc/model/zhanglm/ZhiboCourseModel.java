package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "zlm_zhibo_course")
public class ZhiboCourseModel{
	@Id
	@Column(name = "_id")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@GeneratedValue(generator = "system-uuid")
	private String id;

    /**
     * 用户ID
     */
    @Column(name = "_zb_id")
    private String zbId;
    
    /**
     * 标题
     */
    @Column(name = "_title")
    private String title;
    /**
     * 直播开始时间
     */
    @Column(name = "_start_time")
    private Date startTime;
    /**
     * 直播结束时间
     */
    @Column(name = "_end_time")
    private Date endTime;

    /**
     * 讲师
     */
    @Column(name = "_lecturer")
    private String lecturer;

    /**
     * 创建时间
     */
    @Column(name = "_ceratedate")
    private Date ceratedate;

	public String getZbId() {
		return zbId;
	}

	public void setZbId(String zbId) {
		this.zbId = zbId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getStartTime() {
		return startTime;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getLecturer() {
		return lecturer;
	}

	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}

	public Date getCeratedate() {
		return ceratedate;
	}

	public void setCeratedate(Date ceratedate) {
		this.ceratedate = ceratedate;
	}
    

}
