package com.jrzh.mvc.convert.zhanglm;

import org.apache.commons.lang.StringUtils;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.ServerFeedbackModel;
import com.jrzh.mvc.view.zhanglm.ServerFeedbackView;

public class ServerFeedbackConvert implements BaseConvertI<ServerFeedbackModel, ServerFeedbackView> {

	@Override
	public ServerFeedbackModel addConvert(ServerFeedbackView view) throws ProjectException {
		ServerFeedbackModel model = new ServerFeedbackModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public ServerFeedbackModel editConvert(ServerFeedbackView view, ServerFeedbackModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public ServerFeedbackView convertToView(ServerFeedbackModel model) throws ProjectException {
		ServerFeedbackView view = new ServerFeedbackView();
		ReflectUtils.copySameFieldToTarget(model, view);
		view.setStatusStr(BusinessConstants.FEED_BACK_STATUS.valueMap.get(view.getStatus()));
		if(StringUtils.isBlank(model.getUser().getNickName())){
			view.setUserName("用户未设置昵称");
		}else{
			view.setUserName(model.getUser().getNickName());
		}
		if(StringUtils.isBlank(view.getReply())){
			view.setReply("------");
			view.setReplyUser("------");
		}
		return view;
	}

}
