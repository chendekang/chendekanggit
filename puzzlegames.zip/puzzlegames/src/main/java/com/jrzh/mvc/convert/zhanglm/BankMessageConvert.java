package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.mvc.model.zhanglm.BankMessageModel;
import com.jrzh.mvc.view.zhanglm.BankMessageView;
import com.jrzh.mvc.view.zhanglm.SnapshotView;
import com.jrzh.mvc.view.zhanglm.VarietiesTransactionView;

public class BankMessageConvert {
	public BankMessageModel addConvert(SnapshotView view) throws ProjectException {
		BankMessageModel model = new BankMessageModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	public BankMessageModel editConvert(VarietiesTransactionView view, BankMessageModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	public BankMessageView convertToView(BankMessageModel model) throws ProjectException {
		BankMessageView view = new BankMessageView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}
}
