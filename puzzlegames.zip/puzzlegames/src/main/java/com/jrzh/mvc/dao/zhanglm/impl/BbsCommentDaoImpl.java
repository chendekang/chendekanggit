package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.BbsCommentsDaoI;
import com.jrzh.mvc.model.zhanglm.BbsCommentsModel;

@Repository("bbsCommentsDaoi")
public class BbsCommentDaoImpl extends BaseDaoImpl<BbsCommentsModel> implements BbsCommentsDaoI{

}