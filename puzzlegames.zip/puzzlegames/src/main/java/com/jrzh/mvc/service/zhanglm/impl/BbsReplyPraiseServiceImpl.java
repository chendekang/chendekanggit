package com.jrzh.mvc.service.zhanglm.impl;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.BbsReplyPraiseConvert;
import com.jrzh.mvc.dao.zhanglm.BbsReplyPraiseDaoI;
import com.jrzh.mvc.model.zhanglm.BbsReplyPraiseModel;
import com.jrzh.mvc.search.zhanglm.BbsReplyPraiseSearch;
import com.jrzh.mvc.service.zhanglm.BbsReplyPraiseServiceI;
import com.jrzh.mvc.view.zhanglm.BbsReplyPraiseView;
@Service("BbsReplyPraiseServiceI")
public class BbsReplyPraiseServiceImpl extends
		BaseServiceImpl<BbsReplyPraiseModel, BbsReplyPraiseSearch, BbsReplyPraiseView> implements
		BbsReplyPraiseServiceI {

	@Resource(name = "bbsReplyPraiseDaoI")
	private BbsReplyPraiseDaoI bbsReplyPraiseDaoI;

	@Override
	public BaseDaoI<BbsReplyPraiseModel> getDao() {
		return bbsReplyPraiseDaoI;
	}

	@Override
	public BaseConvertI<BbsReplyPraiseModel, BbsReplyPraiseView> getConvert() {
		return new BbsReplyPraiseConvert();
	}

}
