package com.jrzh.mvc.dao.zhanglm.impl;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.SnapshotDaoI;
import com.jrzh.mvc.model.zhanglm.SnapshotModel;

@Repository("snapshotDao")
public class SnapshotDaoImpl extends BaseDaoImpl<SnapshotModel> implements SnapshotDaoI{
	
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	private Class<SnapshotModel> getClazz(){
		return  (Class< SnapshotModel >)((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}
	
	public SnapshotModel findByField(String fieldName, Object value) {
		List<SnapshotModel> list = selectByField(fieldName, value);
		if(null != list && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<SnapshotModel> selectByField(String fieldName, Object value) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		dc.add(Restrictions.eq(fieldName, value));
		return dc.getExecutableCriteria(sessionFactory.getCurrentSession()).list();
	}
	
}