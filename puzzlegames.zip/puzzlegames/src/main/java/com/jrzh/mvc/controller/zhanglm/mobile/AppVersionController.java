package com.jrzh.mvc.controller.zhanglm.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.mvc.search.zhanglm.AppVersionSearch;
import com.jrzh.mvc.view.zhanglm.AppVersionView;

@Controller(AppVersionController.LOCATION + "AppVersionController")
@RequestMapping(AppVersionController.LOCATION)
public class AppVersionController extends BaseMobileController {
	public static final String LOCATION = "/mobile/AppVersion/";
	
	@RequestMapping(method = RequestMethod.POST, value = "appVersions")
	@MemberEvent(desc = "安卓/IOS app版本管理")
	@ResponseBody
	public MobileResultBean appVersion(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "appVersions");
		try {
			AppVersionSearch appVersionSearch=new AppVersionSearch();
			//取出状态为禁用的
			appVersionSearch.setEqualDisable(false);
			List<AppVersionView> appVersionViews=new ArrayList<AppVersionView>();
			appVersionViews=zhanglmServiceManage.appVersionService.viewList(appVersionSearch);
			map.put("appVersionViews", appVersionViews);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setObject(map);
		result.setMessage(message);
		return result;
	}
	
	
}
