package com.jrzh.mvc.controller.zhanglm.mobile.front;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.mvc.controller.zhanglm.mobile.BaseMobileController;
import com.jrzh.mvc.model.zhanglm.AategoryModel;
import com.jrzh.mvc.search.zhanglm.AnswerSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.AategoryView;
import com.jrzh.mvc.view.zhanglm.AnswerView;
import com.jrzh.mvc.view.zhanglm.TitleReleaseView;
@Controller(Bbsh5topicController.LOCATION + "Bbsh5topicController")
@RequestMapping(Bbsh5topicController.LOCATION)
public class Bbsh5topicController extends BaseMobileController {
	public static final String LOCATION = "zhanglm/mobile/famous/";
	public Logger logger = Logger.getLogger(Bbsh5topicController.class);
	public static final String TOPICSHARE_PAGE = LOCATION + "share";
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	/*圈子话题详情页*/
	@RequestMapping(method = RequestMethod.GET,value = "titleshare")
	public String titleshare(String topicId,String userId) {
		try {

			TitleReleaseView titlerelease = new TitleReleaseView();
			AnswerSearch search = new AnswerSearch();
			
			@SuppressWarnings("unused")
			List<AnswerView> answerview = new ArrayList<AnswerView>();
			if(StringUtils.isNotBlank(topicId)){
				titlerelease = zhanglmServiceManage.titlereleaseservicei.findViewById(topicId);
				AategoryView aategoryview = zhanglmServiceManage.aategoryservicei.findViewById(titlerelease.getCategoryid());
				if(null != aategoryview){
					titlerelease.setTypeName(aategoryview.getTypeName());
				}
				search.setEqualPid(titlerelease.getId());
				if(null != titlerelease){
					answerview  =zhanglmServiceManage.answerservicei.viewListallzb(search);
				}
	
				
				
				
				request.setAttribute("titlerelease", titlerelease);
				
				request.setAttribute("answerview", answerview);
			}
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return TOPICSHARE_PAGE;
	}
}
