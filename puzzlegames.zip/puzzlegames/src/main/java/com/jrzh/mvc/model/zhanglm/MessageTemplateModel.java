package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_message_templates")
public class MessageTemplateModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 模板编号
     */
    @Column(name = "_code")
    private String code;
    /**
     * 模板名称
     */
    @Column(name = "_name")
    private String name;
    /**
     * 短信内容
     */
    @Column(name = "_mobile_content")
    private String mobileContent;
    /**
     * 平台消息
     */
    @Column(name = "_platform_content")
    private String platformContent;
    
    @Column(name="_is_send_mobile")
    private Boolean isSendMobile;
 	
 	@Column(name="_is_send_platform")
 	private Boolean isSendPlatform;
 	
    public Boolean getIsSendMobile() {
		return isSendMobile;
	}

	public void setIsSendMobile(Boolean isSendMobile) {
		this.isSendMobile = isSendMobile;
	}

	public Boolean getIsSendPlatform() {
		return isSendPlatform;
	}

	public void setIsSendPlatform(Boolean isSendPlatform) {
		this.isSendPlatform = isSendPlatform;
	}

	public void setCode(String code) {
        this.code = code;
    }
    
    public String getCode() {
        return this.code;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    public void setMobileContent(String mobileContent) {
        this.mobileContent = mobileContent;
    }
    
    public String getMobileContent() {
        return this.mobileContent;
    }
    public void setPlatformContent(String platformContent) {
        this.platformContent = platformContent;
    }
    
    public String getPlatformContent() {
        return this.platformContent;
    }

}