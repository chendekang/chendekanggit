package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_tabbars")
public class TabbarModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * Tab文字
     */
    @Column(name = "_tab_name")
    private String tabName;
    /**
     * 点击前图片路径
     */
    @Column(name = "_default_img_url")
    private String defaultImgUrl;
    /**
     * 点击后图片路径
     */
    @Column(name = "_pressed_img_url")
    private String pressedImgUrl;
    /**
     * 点击前图片格式
     */
    @Column(name = "_defaul_img_type")
    private String defaulImgType;
    /**
     * 点击后图片格式
     */
    @Column(name = "_pressed_img_type")
    private String pressedImgType;
    /**
     * 移动操作系统
     */
    @Column(name = "_mobile_category")
    private String mobileCategory;
    /**
     * Tab版本描述
     */
    @Column(name = "_tab_intro")
    private String tabIntro;
    /**
     * Tab版本号
     */
    @Column(name = "_tab_version")
    private Integer tabVersion;

    public void setTabName(String tabName) {
        this.tabName = tabName;
    }
    
    public String getTabName() {
        return this.tabName;
    }
    public void setDefaultImgUrl(String defaultImgUrl) {
        this.defaultImgUrl = defaultImgUrl;
    }
    
    public String getDefaultImgUrl() {
        return this.defaultImgUrl;
    }
    public void setPressedImgUrl(String pressedImgUrl) {
        this.pressedImgUrl = pressedImgUrl;
    }
    
    public String getPressedImgUrl() {
        return this.pressedImgUrl;
    }
    public void setDefaulImgType(String defaulImgType) {
        this.defaulImgType = defaulImgType;
    }
    
    public String getDefaulImgType() {
        return this.defaulImgType;
    }
    public void setPressedImgType(String pressedImgType) {
        this.pressedImgType = pressedImgType;
    }
    
    public String getPressedImgType() {
        return this.pressedImgType;
    }
    public void setMobileCategory(String mobileCategory) {
        this.mobileCategory = mobileCategory;
    }
    
    public String getMobileCategory() {
        return this.mobileCategory;
    }
    public void setTabIntro(String tabIntro) {
        this.tabIntro = tabIntro;
    }
    
    public String getTabIntro() {
        return this.tabIntro;
    }
    public void setTabVersion(Integer tabVersion) {
        this.tabVersion = tabVersion;
    }
    
    public Integer getTabVersion() {
        return this.tabVersion;
    }

}