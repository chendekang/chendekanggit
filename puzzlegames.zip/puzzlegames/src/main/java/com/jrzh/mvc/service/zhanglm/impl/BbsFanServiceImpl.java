package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.BbsFanConvert;
import com.jrzh.mvc.dao.zhanglm.BbsFanDaoI;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;
import com.jrzh.mvc.search.zhanglm.BbsFanSearch;
import com.jrzh.mvc.service.zhanglm.BbsFanServiceI;
import com.jrzh.mvc.view.zhanglm.BbsFanView;

@Service("bbsFanService")
public class BbsFanServiceImpl extends
		BaseServiceImpl<BbsFanModel, BbsFanSearch, BbsFanView> implements
		BbsFanServiceI {

	@Resource(name = "bbsFanDao")
	private BbsFanDaoI bbsFanDao;

	@Override
	public BaseDaoI<BbsFanModel> getDao() {
		return bbsFanDao;
	}

	@Override
	public BaseConvertI<BbsFanModel, BbsFanView> getConvert() {
		return new BbsFanConvert();
	}

}
