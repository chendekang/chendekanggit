package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.ServerQuestionModel;
import com.jrzh.mvc.view.zhanglm.ServerQuestionView;

public class ServerQuestionConvert implements BaseConvertI<ServerQuestionModel, ServerQuestionView> {

	@Override
	public ServerQuestionModel addConvert(ServerQuestionView view) throws ProjectException {
		ServerQuestionModel model = new ServerQuestionModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public ServerQuestionModel editConvert(ServerQuestionView view, ServerQuestionModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public ServerQuestionView convertToView(ServerQuestionModel model) throws ProjectException {
		ServerQuestionView view = new ServerQuestionView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
