package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.BbsPraiseConvert;
import com.jrzh.mvc.dao.zhanglm.BbsPraiseDaoI;
import com.jrzh.mvc.model.zhanglm.BbsPraiseModel;
import com.jrzh.mvc.search.zhanglm.BbsPraiseSearch;
import com.jrzh.mvc.service.zhanglm.BbsPraiseServiceI;
import com.jrzh.mvc.view.zhanglm.BbsPraiseView;

@Service("bbsPraiseService")
public class BbsPraiseServiceImpl extends
		BaseServiceImpl<BbsPraiseModel, BbsPraiseSearch, BbsPraiseView> implements
		BbsPraiseServiceI {

	@Resource(name = "bbsPraiseDao")
	private BbsPraiseDaoI bbsPraiseDao;

	@Override
	public BaseDaoI<BbsPraiseModel> getDao() {
		return bbsPraiseDao;
	}

	@Override
	public BaseConvertI<BbsPraiseModel, BbsPraiseView> getConvert() {
		return new BbsPraiseConvert();
	}

}
