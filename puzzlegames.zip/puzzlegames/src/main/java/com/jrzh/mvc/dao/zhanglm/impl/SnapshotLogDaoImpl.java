package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.SnapshotLogDaoI;
import com.jrzh.mvc.model.zhanglm.SnapshotLogModel;

@Repository("snapshotLogDao")
public class SnapshotLogDaoImpl extends BaseDaoImpl<SnapshotLogModel> implements SnapshotLogDaoI{

}