package com.jrzh.mvc.convert.zhanglm;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.SnapshotLogModel;
import com.jrzh.mvc.model.zhanglm.SnapshotModel;
import com.jrzh.mvc.model.zhanglm.SnapshotSecondLogModel;
import com.jrzh.mvc.view.zhanglm.SnapshotLogView;

public class SnapshotLogConvert implements BaseConvertI<SnapshotLogModel, SnapshotLogView> {

	@Override
	public SnapshotLogModel addConvert(SnapshotLogView view) throws ProjectException {
		SnapshotLogModel model = new SnapshotLogModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public SnapshotLogModel editConvert(SnapshotLogView view, SnapshotLogModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public SnapshotLogView convertToView(SnapshotLogModel model) throws ProjectException {
		SnapshotLogView view = new SnapshotLogView();
		ReflectUtils.copySameFieldToTarget(model, view);
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		view.setOldDatetimeStr(sdf.format(view.getOldDatetime()));
		return view;
	}
	
	public SnapshotLogModel convertSnapshotToSnapshotLog(SnapshotModel model, Date time, Integer type) throws ProjectException{
		SnapshotLogModel saveModel = new SnapshotLogModel();
		saveModel.setSnapshotId(model.getId());
		saveModel.setOldSymbol(model.getSymbol());
		saveModel.setOldName(model.getName());
		saveModel.setDatetime(time);
		saveModel.setOldOpen(model.getOpen());
		saveModel.setOldHigh(model.getHigh());
		saveModel.setOldLow(model.getLow());
		saveModel.setOldClose(model.getClose());
		saveModel.setOldBid1price(model.getBid1price());
		saveModel.setOldBid1volume(model.getBid1volume());
		saveModel.setOldAsk1price(model.getAsk1price());
		saveModel.setOldAsk1volume(model.getAsk1volume());
		saveModel.setOldPclose(model.getPclose());
		saveModel.setOldTvolume(model.getTvolume());
		saveModel.setOldTvalue(model.getTvalue());
		saveModel.setType(type);
		return saveModel;
	}
	
	public SnapshotLogModel convertSnapshotToLog(SnapshotSecondLogModel model, Integer type) throws ProjectException{
		SnapshotLogModel saveModel = new SnapshotLogModel();
		saveModel.setSnapshotId(model.getSnapshotId());
		saveModel.setOldSymbol(model.getOldSymbol());
		saveModel.setOldName(model.getOldName());
		saveModel.setDatetime(new Date());
		saveModel.setOldClose(model.getOldClose());
		saveModel.setOldTvolume(model.getOldTvolume());
		saveModel.setOldTvalue(model.getOldTvalue());
		saveModel.setType(type);
		return saveModel;
	}
	
}
