package com.jrzh.mvc.controller.zhanglm.mobile.front;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.controller.zhanglm.mobile.BaseMobileController;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.search.zhanglm.BbsTopicSearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.MemberAttentionSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;
import com.jrzh.mvc.view.zhanglm.MemberAttentionView;
import com.jrzh.mvc.view.zhanglm.MemberView;

@Controller(MemberController.LOCATION + "MemberController")
@RequestMapping(MemberController.LOCATION)
public class MemberController extends BaseMobileController {
	public static final String LOCATION = "zhanglm/mobile/member/";
	
	public static final String FAMOUS_PAGE = LOCATION + "famous";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "famous")
	private String famous() {
		try {
			//移动端区分页面参数
			String type = request.getParameter("type");
			if(StringUtils.isNotBlank(type)){
				request.setAttribute("type", type);
			}
			//获取当前操作用户
			SessionUser user = getMobileUser();
			if(null != user){
				request.setAttribute("userId", user.getId());
			}
			//获取牛人ID
			String talentId=request.getParameter("talentId");
			if(StringUtils.isBlank(talentId)){
				String topicId = request.getParameter("topicId");
				BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(topicId);
				talentId = topic.getUserId();
			}
			MemberView talent=zhanglmServiceManage.memberService.ViewDataById(talentId, user.getId());
			if(StringUtils.isBlank(talent.getPhoto())){
				DefaultSearch defaultsearch = new DefaultSearch();
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if(defaultModel != null){
					talent.setPhoto(defaultModel.getImgUrl());
				}
			}
			//传牛人用户的信息到页面
			request.setAttribute("talent", talent);
			//牛人关注
			MemberAttentionSearch attentionSearch = new MemberAttentionSearch();
			attentionSearch.setEqualFansId(talentId);
			attentionSearch.setRows(5);
			List<MemberAttentionView> attentionList = zhanglmServiceManage.memberAttentionService.viewList(attentionSearch);
			//用户默认头像
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			for(MemberAttentionView view : attentionList){
				if(StringUtils.isBlank(view.getPhoto())){
					if(defaultImg != null){
						view.setPhoto(defaultImg.getImgUrl());
					}
				}
			}
			request.setAttribute("attentionList", attentionList);
			//牛人观点
			BbsTopicSearch topicSearch=new BbsTopicSearch();
			topicSearch.setEqualUserId(talentId);
			List<BbsTopicView> topicList=zhanglmServiceManage.bbsTopicService.viewListTopic(topicSearch, user);
			request.setAttribute("topicList", topicList);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return FAMOUS_PAGE;
	}
}
