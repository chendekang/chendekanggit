package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.DotitleModel;
import com.jrzh.mvc.search.zhanglm.DotitleSearch;
import com.jrzh.mvc.view.zhanglm.DotitleView;

public interface DotitleServiceI  extends BaseServiceI<DotitleModel, DotitleSearch, DotitleView>{



}