package com.jrzh.mvc.dao.zhanglm.impl;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.TodayDealDaoI;
import com.jrzh.mvc.model.zhanglm.TodayDealModel;
import com.jrzh.mvc.search.zhanglm.TodayDealSearch;
@Repository("todaydealdaoi")
public class TodayDealDaoImpl extends BaseDaoImpl<TodayDealModel> implements TodayDealDaoI {

	@Autowired
	private SessionFactory sessionFactory;
	

	@SuppressWarnings("unchecked")
	private Class<TodayDealModel> getClazz(){
		return  (Class< TodayDealModel >)((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}
	@Override
	public String save(TodayDealModel model) {
		return ((String)this.sessionFactory.getCurrentSession().save(model));
		
	}
	@Override
	public Long countBySearch(TodayDealSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		search.setAutoDc(dc);
		Long count = (Long) dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
				.setProjection(Projections.rowCount()).uniqueResult();
		return Long.valueOf((count == null) ? 0L : count.longValue());
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<TodayDealModel> findListBySearch(TodayDealSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		if (search != null) {
			search.setAutoDc(dc);
			return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
					.setFirstResult((search.getPage() - 1) * search.getRows()).setMaxResults(search.getRows()).list();
		}
		return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).list();
	}
}
