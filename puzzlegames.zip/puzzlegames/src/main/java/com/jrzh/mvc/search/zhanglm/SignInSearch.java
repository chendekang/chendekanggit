package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.common.utils.DateUtil;
import com.jrzh.framework.base.search.BaseSearch;

public class SignInSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String equalUserId;
	
	private String equalDate;
	
	
	
	public String getEqualDate() {
		return equalDate;
	}

	public void setEqualDate(String equalDate) {
		this.equalDate = equalDate;
	}

	public String getEqualUserId() {
		return equalUserId;
	}

	public void setEqualUserId(String equalUserId) {
		this.equalUserId = equalUserId;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalUserId)){
			dc.add(Restrictions.eq("userId", equalUserId));
		}
		if(StringUtils.isNotBlank(equalDate)){
			dc.add(Restrictions.ge("date", DateUtil.format(equalDate+" 00:00:00")));
			dc.add(Restrictions.le("date", DateUtil.format(equalDate+" 23:59:59")));
		}
	}

}