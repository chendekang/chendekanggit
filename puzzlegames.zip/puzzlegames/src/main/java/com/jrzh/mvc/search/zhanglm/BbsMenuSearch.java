package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class BbsMenuSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	
	
	private String equalPid;
	
	private String[] inId;

	private String equalCode;

	
	public String getEqualCode() {
		return equalCode;
	}

	public void setEqualCode(String equalCode) {
		this.equalCode = equalCode;
	}

	public String[] getInId() {
		return inId;
	}

	public void setInId(String[] inId) {
		this.inId = inId;
	}

	public String getEqualPid() {
		return equalPid;
	}

	public void setEqualPid(String equalPid) {
		this.equalPid = equalPid;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalPid)){
			dc.add(Restrictions.eq("pid", equalPid));
		}
		if(null != inId && inId.length > 0){
			dc.add(Restrictions.in("id", inId));
		}
		if(StringUtils.isNotBlank(equalCode)){
			dc.add(Restrictions.eq("code", equalCode));
		}
	}

}