package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class ServerCategorySearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private Boolean equalIsDisable;
	
	private String equalName;
	
	private String likeName;
	
	
	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}

	public String getEqualName() {
		return equalName;
	}

	public void setEqualName(String equalName) {
		this.equalName = equalName;
	}

	public Boolean getEqualIsDisable() {
		return equalIsDisable;
	}

	public void setEqualIsDisable(Boolean equalIsDisable) {
		this.equalIsDisable = equalIsDisable;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
	if(null != equalIsDisable){
		dc.add(Restrictions.eq("isDisable", equalIsDisable));
	}
	if(StringUtils.isNotBlank(equalName)){
		dc.add(Restrictions.eq("name", equalName));
	}
	if(StringUtils.isNotBlank(likeName)){
		dc.add(Restrictions.like("name", "%"+likeName+"%"));
	}
	}

}