package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.convert.zhanglm.BbsTopicConvert;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.model.zhanglm.CollectModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.MemberUserModel;
import com.jrzh.mvc.model.zhanglm.PlazaDataModel;
import com.jrzh.mvc.search.zhanglm.BbsFanSearch;
import com.jrzh.mvc.search.zhanglm.BbsMenuSearch;
import com.jrzh.mvc.search.zhanglm.BbsTopicSearch;
import com.jrzh.mvc.search.zhanglm.CollectSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;

@Controller(BbsTopicController.LOCATION +"/BbsTopicController")
@RequestMapping(BbsTopicController.LOCATION)
public class BbsTopicController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/bbs/bbsTopic";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String TOPIC_INDEX_PAGE = LOCATION + "/topicIndex";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String AUDIT_PAGE = LOCATION + "/audit";
	
	public static final String AUDIT_FORM_PAGE = LOCATION + "/auditForm";
	
	public static final String AUDIT_VIEW_PAGE = LOCATION + "/auditView";
	
	public static final String MODULE = "zhanglm_bbsTopic";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "topicIndex")
	public String topicIndex() {
		return TOPIC_INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "topicDatagrid")
	@UserEvent(desc = "BbsTopic列表查询")
	@ResponseBody
	public EasyuiDataGrid<BbsTopicView> topicDatagrid(BbsTopicSearch search) {
		EasyuiDataGrid<BbsTopicView> dg = new EasyuiDataGrid<BbsTopicView>();
	    try{
	    	search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
	    	dg = zhanglmServiceManage.bbsTopicService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "audit")
	public String audit() {
		return AUDIT_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "pass/{id}")
	public String auditForm(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.bbsTopicService.findViewById(id));
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return AUDIT_FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "noPass/{id}")
	public String noPass(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.bbsTopicService.findViewById(id));
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return AUDIT_FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "pass/{id}")
	@UserEvent(desc = "BbsTopic审核通过")
	@ResponseBody
	public ResultBean pass(@PathVariable("id") String id, BbsTopicView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			BbsTopicModel model = zhanglmServiceManage.bbsTopicService.findById(id);
			model.setStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			model.setOpinion(view.getOpinion());
			model.setAuditer(getSessionUser().getName());
			model.setAuditTime(new Date());
			zhanglmServiceManage.bbsTopicService.editAndLog(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("审核完成");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "noPass/{id}")
	@UserEvent(desc = "BbsTopic审核不通过")
	@ResponseBody
	public ResultBean noPass(@PathVariable("id") String id, BbsTopicView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			BbsTopicModel model = zhanglmServiceManage.bbsTopicService.findById(id);
			model.setStatus(BusinessConstants.BBS_TOPIC_STATUS.NOT_AUDIT);
			model.setOpinion(view.getOpinion());
			model.setAuditer(getSessionUser().getName());
			model.setAuditTime(new Date());
			zhanglmServiceManage.bbsTopicService.editAndLog(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("审核完成");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "auditView/{id}")
	public String auditView(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.bbsTopicService.findViewById(id));
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return AUDIT_VIEW_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "auditDatagrid")
	@UserEvent(desc = "BbsTopic审核列表查询")
	@ResponseBody
	public EasyuiDataGrid<BbsTopicView> auditDatagrid(BbsTopicSearch search) {
		EasyuiDataGrid<BbsTopicView> dg = new EasyuiDataGrid<BbsTopicView>();
	    try{
	    	search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDING);
	    	dg = zhanglmServiceManage.bbsTopicService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "BbsTopic列表查询")
	@ResponseBody
	public EasyuiDataGrid<BbsTopicView> datagrid(BbsTopicSearch search) {
		EasyuiDataGrid<BbsTopicView> dg = new EasyuiDataGrid<BbsTopicView>();
	    try{
	    	MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
	    	if(memberUser != null){
	    		search.setEqualUserId(memberUser.getMemberId());
	    	}
	    	dg = zhanglmServiceManage.bbsTopicService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd(BbsMenuSearch search) {
		try {
			//获取分类主菜单列表
			List<BbsMenuView> menuList = new ArrayList<BbsMenuView>();
			List<BbsMenuView> viewList = zhanglmServiceManage.bbsMenuService.viewList(search);
			for(BbsMenuView menu : viewList){
				if(StringUtils.isBlank(menu.getPid())){
					menuList.add(menu);
				}
			}
			request.setAttribute("menuList", menuList);
			request.setAttribute("view", new BbsTopicView());
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	/*
	 * 旧话题添加功能
	 * 
	 * */ 
/*	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "BbsTopic增加")
	@ResponseBody
	public ResultBean add(BbsTopicView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			String imgUrl = request.getParameter("fileUrl");
			BbsTopicModel model =new BbsTopicConvert().addConvert(view);
			//添加时初始化评论数和点赞数
			model.setDiscuss(0);
			model.setPraise(0);
			//发布人
			MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
			if(memberUser != null){
				String memberId  = memberUser.getMemberId();
				MemberModel member = zhanglmServiceManage.memberService.findById(memberId);
				model.setUserId(memberId);
				model.setUserName(member.getNickName());
				if(StringUtils.isNotBlank(imgUrl)){
					model.setImgUrl(imgUrl);
				}
				//发布人是否加入该圈子
				//旧功能
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", view.getMenuCode());
				String menuId = menu.getId();
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualUserId(memberId);
				fanSearch.setEqualMenuId(menuId);
				BbsFanModel fans = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(null == fans){
					//默认发布用户关注圈子
					fans = new BbsFanModel();
					fans.setUserId(memberId);
					fans.setMenuId(menuId);
					fans.setTopicNum(0L);
					fans.setPraiseNum(0L);
					fans.setReplyNum(0L);
					fans.setAverage(0.0);
					zhanglmServiceManage.bbsFanService.add(fans, getSessionUser());
				}
			}else{
				result.setMsg("管理员未绑定平台用户");
				return result;
			}
			//状态为审核中
			model.setStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDING);
			model.setAuditTime(null);
			zhanglmServiceManage.bbsTopicService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}*/
	
	
	/*
	 * 新后台添加话题功能
	 * 
	 * */
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "BbsTopic增加")
	@ResponseBody
	public ResultBean add(BbsTopicView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			String imgUrl = request.getParameter("fileUrl");
			BbsTopicModel model =new BbsTopicConvert().addConvert(view);
			//添加时初始化评论数和点赞数
			model.setDiscuss(0);
			model.setPraise(0);
			//发布人
			MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
			if(memberUser != null){
				String memberId  = memberUser.getMemberId();
				MemberModel member = zhanglmServiceManage.memberService.findById(memberId);
				model.setUserId(memberId);
				model.setUserName(member.getNickName());
				if(StringUtils.isNotBlank(imgUrl)){
					model.setImgUrl(imgUrl);
				}
				//发布人是否加入该圈子
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("id", view.getMenuid());
				String menuId = menu.getId();
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualUserId(memberId);
				fanSearch.setEqualMenuId(menuId);
				BbsFanModel fans = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(null == fans){
					//默认发布用户关注圈子
					fans = new BbsFanModel();
					fans.setUserId(memberId);
					fans.setMenuId(menuId);
					fans.setTopicNum(0L);
					fans.setPraiseNum(0L);
					fans.setReplyNum(0L);
					fans.setAverage(0.0);
					zhanglmServiceManage.bbsFanService.add(fans, getSessionUser());
				}
			}else{
				result.setMsg("管理员未绑定平台用户");
				return result;
			}
			//状态为审核中
			model.setStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDING);
			model.setAuditTime(null);
			zhanglmServiceManage.bbsTopicService.addTopic(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			//获取分类菜单列表
			List<BbsMenuView> menuList = new ArrayList<BbsMenuView>();
			BbsMenuSearch search = new BbsMenuSearch();
			List<BbsMenuView> viewList = zhanglmServiceManage.bbsMenuService.viewList(search);
			for(BbsMenuView menu : viewList){
				if(StringUtils.isBlank(menu.getPid())){
					menuList.add(menu);
				}
			}
			request.setAttribute("menuList", menuList);
			BbsTopicView view = zhanglmServiceManage.bbsTopicService.findViewById(id);
			BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("id", view.getMenuid());
			BbsMenuModel pMenu = zhanglmServiceManage.bbsMenuService.findById(menu.getPid());
			request.setAttribute("pidCode", pMenu.getCode());
			request.setAttribute("view", view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "BbsTopic修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, BbsTopicView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			String imgUrl = request.getParameter("fileUrl");
			//发布人
			MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
			if(memberUser == null){
				result.setMsg("管理员未绑定平台用户");
				return result;
			}
			BbsTopicModel model = zhanglmServiceManage.bbsTopicService.findById(id);
			model.setTitle(view.getTitle());
			model.setMenuCode(view.getMenuCode());
			model.setContent(view.getContent());
			if(StringUtils.isNotBlank(imgUrl)){
				model.setImgUrl(imgUrl);
			}
			//状态为审核中
			model.setStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDING);
			zhanglmServiceManage.bbsTopicService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "BbsTopic删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			BbsTopicModel model = zhanglmServiceManage.bbsTopicService.findById(id);
			zhanglmServiceManage.bbsTopicService.delete(model, getSessionUser());
			//删除对应广场数据
			PlazaDataModel data = zhanglmServiceManage.plazaDataService.findByField("dataId", id);
			if(null != data){
				zhanglmServiceManage.plazaDataService.delete(data, getSessionUser());
			}
			CollectSearch search = new CollectSearch();
			search.setEqualCircleId(id);
			CollectModel collect = zhanglmServiceManage.collectService.findBySearch(search);
			if(null != collect){
				zhanglmServiceManage.collectService.delete(collect, getSessionUser());
			}
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "BbsTopic禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			BbsTopicModel model = zhanglmServiceManage.bbsTopicService.findById(id);
			if(null != model.getIsDisable()){
				model.setIsDisable(!model.getIsDisable());
			}else {
				model.setIsDisable(true);
			}
			zhanglmServiceManage.bbsTopicService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
