package com.jrzh.mvc.dao.zhanglm.impl;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.ZhiboCourseDaoI;
import com.jrzh.mvc.model.zhanglm.ZhiboCourseModel;
@Repository("zhibocoursedaoi")
public class ZhiboCourseDaoImpl extends BaseDaoImpl<ZhiboCourseModel> implements ZhiboCourseDaoI{
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	private Class<ZhiboCourseModel> getClazz(){
		return  (Class< ZhiboCourseModel >)((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<ZhiboCourseModel> selectByField(String fieldName, Object value) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		dc.add(Restrictions.eq(fieldName, value));
		return dc.getExecutableCriteria(sessionFactory.getCurrentSession()).list();

	}
}
