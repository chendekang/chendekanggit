package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.mvc.model.zhanglm.ZhiboCourseModel;
import com.jrzh.mvc.view.zhanglm.SnapshotView;
import com.jrzh.mvc.view.zhanglm.ZhiboCourseView;

public class ZhiboCourseConvert {

	public ZhiboCourseModel addConvert(SnapshotView view) throws ProjectException {
		ZhiboCourseModel model = new ZhiboCourseModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	public ZhiboCourseModel editConvert(ZhiboCourseView view, ZhiboCourseModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	public ZhiboCourseView convertToView(ZhiboCourseModel model) throws ProjectException {
		ZhiboCourseView view = new ZhiboCourseView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
