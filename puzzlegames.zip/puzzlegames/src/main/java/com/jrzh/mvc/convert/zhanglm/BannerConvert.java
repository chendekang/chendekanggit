package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.BannerModel;
import com.jrzh.mvc.view.zhanglm.BannerView;

public class BannerConvert implements BaseConvertI<BannerModel, BannerView> {

	@Override
	public BannerModel addConvert(BannerView view) throws ProjectException {
		BannerModel model = new BannerModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public BannerModel editConvert(BannerView view, BannerModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public BannerView convertToView(BannerModel model) throws ProjectException {
		BannerView view = new BannerView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
