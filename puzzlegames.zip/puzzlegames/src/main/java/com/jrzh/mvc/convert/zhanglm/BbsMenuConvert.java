package com.jrzh.mvc.convert.zhanglm;

import java.util.HashMap;
import java.util.Map;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.bean.EasyuiTree;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;

public class BbsMenuConvert implements BaseConvertI<BbsMenuModel, BbsMenuView> {

	@Override
	public BbsMenuModel addConvert(BbsMenuView view) throws ProjectException {
		BbsMenuModel model = new BbsMenuModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public BbsMenuModel editConvert(BbsMenuView view, BbsMenuModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public BbsMenuView convertToView(BbsMenuModel model) throws ProjectException {
		BbsMenuView view = new BbsMenuView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

	public EasyuiTree converToEasyuiTree(BbsMenuModel model) {
		EasyuiTree tree = new EasyuiTree();
		tree.setId(model.getId());
		tree.setPid(model.getPid());
		tree.setText(model.getName());
		Map<String, Object> attributes = new HashMap<String, Object>();
		tree.setAttributes(attributes);
		return tree;
	}

}
