package com.jrzh.mvc.controller.zhanglm.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.SnapshotSecondLogConvert;
import com.jrzh.mvc.model.zhanglm.SnapshotSecondLogModel;
import com.jrzh.mvc.search.zhanglm.SnapshotSecondLogSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.SnapshotSecondLogView;

@Controller(SnapshotSecondLogController.LOCATION +"/SnapshotSecondLogController")
@RequestMapping(SnapshotSecondLogController.LOCATION)
public class SnapshotSecondLogController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/snapshotSecondLog";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_snapshotSecondLog";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "SnapshotSecondLog鍒楄〃鏌ヨ")
	@ResponseBody
	public EasyuiDataGrid<SnapshotSecondLogView> datagrid(SnapshotSecondLogSearch search) {
		EasyuiDataGrid<SnapshotSecondLogView> dg = new EasyuiDataGrid<SnapshotSecondLogView>();
	    try{
	    	dg = zhanglmServiceManage.snapshotSecondLogService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new SnapshotSecondLogView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "SnapshotSecondLog澧炲姞")
	@ResponseBody
	public ResultBean add(SnapshotSecondLogView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			SnapshotSecondLogModel model =new SnapshotSecondLogConvert().addConvert(view);
			zhanglmServiceManage.snapshotSecondLogService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("娣诲姞鎴愬姛");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.snapshotSecondLogService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "SnapshotSecondLog淇敼")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, SnapshotSecondLogView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			SnapshotSecondLogModel model = zhanglmServiceManage.snapshotSecondLogService.findById(id);
			model = new SnapshotSecondLogConvert().editConvert(view, model);
			zhanglmServiceManage.snapshotSecondLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("淇敼鎴愬姛");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "SnapshotSecondLog鍒犻櫎")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			SnapshotSecondLogModel model = zhanglmServiceManage.snapshotSecondLogService.findById(id);
			zhanglmServiceManage.snapshotSecondLogService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("鍒犻櫎鎴愬姛");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "SnapshotSecondLog绂佺敤/鍚敤鐘舵�")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			SnapshotSecondLogModel model = zhanglmServiceManage.snapshotSecondLogService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.snapshotSecondLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("鎿嶄綔鎴愬姛");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
