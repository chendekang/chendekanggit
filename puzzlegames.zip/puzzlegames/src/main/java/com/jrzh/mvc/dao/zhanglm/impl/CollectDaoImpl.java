package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.CollectDaoI;
import com.jrzh.mvc.model.zhanglm.CollectModel;

@Repository("collectDao")
public class CollectDaoImpl extends BaseDaoImpl<CollectModel> implements CollectDaoI{

}