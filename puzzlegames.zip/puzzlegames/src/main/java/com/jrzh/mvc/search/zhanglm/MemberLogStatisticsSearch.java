package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class MemberLogStatisticsSearch extends BaseSearch{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ids;
	private String equalmobilephone;
	
	private String likeName;
	
	private Boolean equalIsLock;
	
	private String equalColumnCode;
	
	private String acctno;

	public String getAcctno() {
		return acctno;
	}

	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public String getEqualColumnCode() {
		return equalColumnCode;
	}

	public void setEqualColumnCode(String equalColumnCode) {
		this.equalColumnCode = equalColumnCode;
	}

	public Boolean getEqualIsLock() {
		return equalIsLock;
	}

	public void setEqualIsLock(Boolean equalIsLock) {
		this.equalIsLock = equalIsLock;
	}

	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}



	public String getEqualmobilephone() {
		return equalmobilephone;
	}

	public void setEqualmobilephone(String equalmobilephone) {
		this.equalmobilephone = equalmobilephone;
	}

	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalmobilephone)){
			dc.add(Restrictions.eq("mobile_phone", equalmobilephone));
		}
		
		if(StringUtils.isNotBlank(ids)){
			dc.add(Restrictions.eq("id", ids));
		}
		
		if(StringUtils.isNotBlank(acctno)){
			dc.add(Restrictions.eq("acct_no", acctno));
		}
	}
}