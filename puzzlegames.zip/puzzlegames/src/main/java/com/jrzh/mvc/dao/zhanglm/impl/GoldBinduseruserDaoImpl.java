package com.jrzh.mvc.dao.zhanglm.impl;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.GoldBinduseruserDaoI;
import com.jrzh.mvc.model.zhanglm.GoldbinduseruserModel;

@Repository("goldbinduseruserdaoi")
public class GoldBinduseruserDaoImpl extends BaseDaoImpl<GoldbinduseruserModel> implements GoldBinduseruserDaoI {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	private Class<GoldbinduseruserModel> getClazz(){
		return  (Class< GoldbinduseruserModel >)((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}
	
	/**
	 * 添加绑定用户关联信息
	 * */
	@Override
	public String savebinduser(GoldbinduseruserModel binduseruser) {
		return ((String) this.sessionFactory.getCurrentSession().save(binduseruser));
	}

	
	/**
	 * 根据id查询绑定用户关联信息
	 * */
	@Override
	public GoldbinduseruserModel findByField(String fieldName, String value) {
		List<GoldbinduseruserModel> list = selectByField(fieldName, value);
	    if ((list != null) && (list.size() > 0)) {
	      return list.get(0);
	    }
	    return null;
	}
	 @SuppressWarnings("unchecked")
	public List<GoldbinduseruserModel> selectByField(String fieldName, Object value)
	  {
	    DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
	    dc.add(Restrictions.eq(fieldName, value));
	    return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).list();
	  }

	/**
	 * 删除绑定用户关联信息
	 */
	@Override
	public Integer executeSql(String sql, String value) {

/*		if (StringUtils.isNotBlank(sql)) {
		      sql = StringFormat.format(sql, value);
		    }*/
		sql+=" where _binduseruserid="+"'"+value+"'";
		    return Integer.valueOf(this.sessionFactory.getCurrentSession().createSQLQuery(sql).executeUpdate());
	}

}
