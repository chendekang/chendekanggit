package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.MemberUserModel;
import com.jrzh.mvc.view.zhanglm.MemberUserView;

public class MemberUserConvert implements BaseConvertI<MemberUserModel, MemberUserView> {

	@Override
	public MemberUserModel addConvert(MemberUserView view) throws ProjectException {
		MemberUserModel model = new MemberUserModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public MemberUserModel editConvert(MemberUserView view, MemberUserModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public MemberUserView convertToView(MemberUserModel model) throws ProjectException {
		MemberUserView view = new MemberUserView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
