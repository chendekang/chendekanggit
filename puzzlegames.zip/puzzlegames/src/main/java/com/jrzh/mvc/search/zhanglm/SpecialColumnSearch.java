package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class SpecialColumnSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String likeName;
	
	private String equalCode;
	
	
	public String getEqualCode() {
		return equalCode;
	}

	public void setEqualCode(String equalCode) {
		this.equalCode = equalCode;
	}

	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
	   if(StringUtils.isNotBlank(likeName)){
		  dc.add(Restrictions.like("name", "%"+likeName+"%"));
	   }
	   if(StringUtils.isNotBlank(equalCode)){
		   dc.add(Restrictions.eq("code", equalCode));
	   }
	}

}