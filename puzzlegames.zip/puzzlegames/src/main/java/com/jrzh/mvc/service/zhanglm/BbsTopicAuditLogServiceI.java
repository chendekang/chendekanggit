package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.BbsTopicAuditLogModel;
import com.jrzh.mvc.search.zhanglm.BbsTopicAuditLogSearch;
import com.jrzh.mvc.view.zhanglm.BbsTopicAuditLogView;

public interface BbsTopicAuditLogServiceI  extends BaseServiceI<BbsTopicAuditLogModel, BbsTopicAuditLogSearch, BbsTopicAuditLogView>{

}