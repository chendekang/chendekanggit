package com.jrzh.mvc.model.zhanglm;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_plaza_datas")
public class PlazaDataModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 关联用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_user_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel member;
    /**
     * 关联数据ID
     */
    @Column(name = "_data_id")
    private String dataId;
    /**
     * 数据类别 0--话题  1--直播  2--活动
     */
    @Column(name = "_data_category")
    private Integer dataCategory;

    public MemberModel getMember() {
		return member;
	}

	public void setMember(MemberModel member) {
		this.member = member;
	}

	public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }
    public void setDataId(String dataId) {
        this.dataId = dataId;
    }
    
    public String getDataId() {
        return this.dataId;
    }
    public void setDataCategory(Integer dataCategory) {
        this.dataCategory = dataCategory;
    }
    
    public Integer getDataCategory() {
        return this.dataCategory;
    }

}