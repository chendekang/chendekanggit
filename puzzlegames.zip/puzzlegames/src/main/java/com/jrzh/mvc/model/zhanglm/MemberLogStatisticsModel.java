package com.jrzh.mvc.model.zhanglm;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name = "zlm_gold_customer")
public class MemberLogStatisticsModel {
	@Id
	@Column(name = "_id")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@GeneratedValue(generator = "system-uuid")
	private String id;

	/**
	 * 用户id
	 */
	@Column(name = "UserID")
	private String UserID; 
	/**
	 * 客户号
	 */
	@Column(name = "acct_no")
	private String acct_no;    
	/**
	 * 
	 */
	@Column(name = "b_sys_stat")
	private String b_sys_stat;  
	/**
	 * 
	 */
	@Column(name = "branch_id")
	private String branch_id;    
	/**
	 * id号
	 */
	@Column(name = "cust_id")
	private String cust_id;   
	/**
	 * 姓名
	 */
	@Column(name = "cust_name")
	private String cust_name;  
	/**
	 *退出开始时间
	 */
	@Column(name = "exch_date")      
	private String exch_date;   
	/**
	 * 退出时间
	 */
	@Column(name = "last_exch_date")
	private String last_exch_date; 
	/**
	 * 登录时间
	 */
	@Column(name = "last_login_date")
	private String last_login_date; 
	/**
	 * 结束时间
	 */
	@Column(name = "last_login_time")
	private String last_login_time; 
	/**
	 * 
	 */
	@Column(name = "m_sys_stat")
	private String m_sys_stat;   
	/**
	 * 会员id
	 */
	@Column(name = "member_id")
	private String member_id;   
	/**
	 * 手机号
	 */
	@Column(name = "mobile_phone")
	private String mobile_phone;
	
	/**
	 * 创建时间
	 */
	@Column(name = "creation_time")
	private Date creation_time;
	/**
	 * 是否绑定
	 */
	@Column(name="_is_disable")
	private Boolean isDisable;
	
	public Boolean getIsDisable() {
		return isDisable;
	}
	public void setIsDisable(Boolean isDisable) {
		this.isDisable = isDisable;
	}
	public Date getCreation_time() {
		return creation_time;
	}
	public void setCreation_time(Date creation_time) {
		this.creation_time = creation_time;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getAcct_no() {
		return acct_no;
	}
	public void setAcct_no(String acct_no) {
		this.acct_no = acct_no;
	}
	public String getB_sys_stat() {
		return b_sys_stat;
	}
	public void setB_sys_stat(String b_sys_stat) {
		this.b_sys_stat = b_sys_stat;
	}
	public String getBranch_id() {
		return branch_id;
	}
	public void setBranch_id(String branch_id) {
		this.branch_id = branch_id;
	}
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getExch_date() {
		return exch_date;
	}
	public void setExch_date(String exch_date) {
		this.exch_date = exch_date;
	}
	public String getLast_exch_date() {
		return last_exch_date;
	}
	public void setLast_exch_date(String last_exch_date) {
		this.last_exch_date = last_exch_date;
	}
	public String getLast_login_date() {
		return last_login_date;
	}
	public void setLast_login_date(String last_login_date) {
		this.last_login_date = last_login_date;
	}
	public String getLast_login_time() {
		return last_login_time;
	}
	public void setLast_login_time(String last_login_time) {
		this.last_login_time = last_login_time;
	}
	public String getM_sys_stat() {
		return m_sys_stat;
	}
	public void setM_sys_stat(String m_sys_stat) {
		this.m_sys_stat = m_sys_stat;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getMobile_phone() {
		return mobile_phone;
	}
	public void setMobile_phone(String mobile_phone) {
		this.mobile_phone = mobile_phone;
	}       
}