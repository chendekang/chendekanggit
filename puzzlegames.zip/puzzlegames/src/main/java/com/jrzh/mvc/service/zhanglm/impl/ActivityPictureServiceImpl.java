package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.convert.zhanglm.ActivityPictureConvert;
import com.jrzh.mvc.dao.zhanglm.ActivityPictureDaoI;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.ActivityPictureModel;
import com.jrzh.mvc.search.zhanglm.ActivityPictureSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.ActivityPictureServiceI;
import com.jrzh.mvc.view.zhanglm.ActivityPictureView;

@Service("activityPictureService")
public class ActivityPictureServiceImpl extends
		BaseServiceImpl<ActivityPictureModel, ActivityPictureSearch, ActivityPictureView> implements
		ActivityPictureServiceI {

	@Autowired
	public SysServiceManage sysServiceManage;
	
	@Resource(name = "activityPictureDao")
	private ActivityPictureDaoI activityPictureDao;

	@Override
	public BaseDaoI<ActivityPictureModel> getDao() {
		return activityPictureDao;
	}

	@Override
	public BaseConvertI<ActivityPictureModel, ActivityPictureView> getConvert() {
		return new ActivityPictureConvert();
	}

	@Override
	public void addAndFile(ActivityPictureModel model, FileModel file, SessionUser user)throws Exception {
		this.add(model, user);
		if(file != null){
			file.setFormId(model.getId());
			sysServiceManage.fileService.add(file, user);
		}
		
	}

	public void editAndFile(ActivityPictureModel model, FileModel file, SessionUser user)throws Exception {
		this.edit(model, user);
		if(file != null){
			sysServiceManage.fileService.edit(file, user);
		}
		
	}

	public void deleteAndFile(ActivityPictureModel model, FileModel file,SessionUser user) throws Exception {
		this.delete(model, user);
		if(file != null){
			sysServiceManage.fileService.delete(file, user);
		}
		
	}
}
