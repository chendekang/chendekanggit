package com.jrzh.mvc.search.zhanglm;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class DictionarySearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String likeName;


	public Boolean getEqualIsDisable() {
		return equalIsDisable;
	}

	public void setEqualIsDisable(Boolean equalIsDisable) {
		this.equalIsDisable = equalIsDisable;
	}

	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}


	@Override
	public void setDc(DetachedCriteria dc) {
		if(null != equalIsDisable){
			dc.add(Restrictions.eq("isDisable", equalIsDisable));
		}
	}

}