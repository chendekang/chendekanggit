package com.jrzh.mvc.service.zhanglm.impl;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.convert.zhanglm.AategoryConvert;
import com.jrzh.mvc.dao.zhanglm.AategoryDaoI;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.AategoryModel;
import com.jrzh.mvc.search.sys.FileSearch;
import com.jrzh.mvc.search.zhanglm.AategorySearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.AategoryServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.AategoryView;
@Service("AategoryServiceI")
public class AategoryServiceImpl extends
		BaseServiceImpl<AategoryModel, AategorySearch, AategoryView> implements
		AategoryServiceI {

	@Resource(name = "AategoryDaoI")
	private AategoryDaoI aategorydaoi;

	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	@Autowired
	private SysServiceManage sysServiceManage;
	@Override
	public BaseDaoI<AategoryModel> getDao() {
		return aategorydaoi;
	}

	@Override
	public BaseConvertI<AategoryModel, AategoryView> getConvert() {
		return new AategoryConvert();
	}

	@Override
	public void addAndFiles(AategoryModel model, FileModel[] fileModels, SessionUser sessionUser) throws ProjectException {
		this.add(model, sessionUser);
		FileSearch filesearch = new FileSearch();
		FileSearch indexsearch = new FileSearch();
		filesearch.setEqualFormId(model.getId());
		indexsearch.setEqualFormId(model.getId()+"-t1");
		if(null != fileModels[0]){
			fileModels[0].setFormId(model.getId());
			sysServiceManage.fileService.add(fileModels[0], sessionUser);
		}
		if(null != fileModels[1]){
			fileModels[1].setFormId(model.getId()+"-t1");
			sysServiceManage.fileService.add(fileModels[1], sessionUser);
		}
		//获取题库推荐图片
		FileModel titlefile = sysServiceManage.fileService.findBySearch(filesearch);
		FileModel indextitlefile = sysServiceManage.fileService.findBySearch(indexsearch);
		AategoryModel md = zhanglmServiceManage.aategoryservicei.findById(model.getId());
		if(null != titlefile){
			md.setTypeImgUrl(titlefile.getUrl());//推荐图片
		}
		if(null != indextitlefile){
			md.setIndeximgType(indextitlefile.getUrl());//首页图片
		}
		this.edit(model, sessionUser);
	}

}
