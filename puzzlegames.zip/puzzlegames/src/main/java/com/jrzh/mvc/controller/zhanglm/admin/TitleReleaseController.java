package com.jrzh.mvc.controller.zhanglm.admin;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.TitleReleaseConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.AnswerModel;
import com.jrzh.mvc.model.zhanglm.CorrectAnswerModel;
import com.jrzh.mvc.model.zhanglm.TitleReleaseModel;
import com.jrzh.mvc.search.zhanglm.AategorySearch;
import com.jrzh.mvc.search.zhanglm.AnswerSearch;
import com.jrzh.mvc.search.zhanglm.CorrectAnswerSearch;
import com.jrzh.mvc.search.zhanglm.DictionarySearch;
import com.jrzh.mvc.search.zhanglm.TitleReleaseSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.AategoryView;
import com.jrzh.mvc.view.zhanglm.AnswerView;
import com.jrzh.mvc.view.zhanglm.DictionaryView;
import com.jrzh.mvc.view.zhanglm.TitleReleaseView;
@Controller(TitleReleaseController.LOCATION +"/TitleReleaseController")
@RequestMapping(TitleReleaseController.LOCATION)
public class TitleReleaseController extends BaseAdminController{	
public static final String LOCATION = "zhanglm/admin/title/titleRelease";
	public static final String INDEX_PAGE = LOCATION + "/index";
	public static final String FORM_PAGE = LOCATION + "/form";
	public static final String TOPIC_INDEX_PAGE = LOCATION + "/topicIndex";
	//答案
	public static final String ANSWER_INDEX = LOCATION + "/answer";
	//选 择答案跳转
	public static final String rightanswer_index = LOCATION + "/rightanswer";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index(AategorySearch aatsearch) throws ProjectException {
		DictionarySearch dictionarysearch = new DictionarySearch();
		List<AategoryView> viewList = zhanglmServiceManage.aategoryservicei.viewList(aatsearch);
		List<DictionaryView> dictionarylist = zhanglmServiceManage.dictionaryservicei.viewList(dictionarysearch);
    	//类型
		request.setAttribute("dictionarylist", dictionarylist);
		//分类
		request.setAttribute("menumainList", viewList);
		return INDEX_PAGE;
	}
	@RequestMapping(method = RequestMethod.GET,value = "topicIndex")
	public String topicIndex(AategorySearch aatsearch) throws ProjectException {
		DictionarySearch dictionarysearch = new DictionarySearch();
		List<AategoryView> viewList = zhanglmServiceManage.aategoryservicei.viewList(aatsearch);
		List<DictionaryView> dictionarylist = zhanglmServiceManage.dictionaryservicei.viewList(dictionarysearch);
    	//类型
		request.setAttribute("dictionarylist", dictionarylist);
		//分类
		request.setAttribute("menumainList", viewList);
		return TOPIC_INDEX_PAGE;
	}
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "题目列表查询")
	@ResponseBody	
	public EasyuiDataGrid<TitleReleaseView> datagrid(TitleReleaseSearch search) {
		EasyuiDataGrid<TitleReleaseView> dg = new EasyuiDataGrid<TitleReleaseView>();
	    try{
	    	dg = zhanglmServiceManage.titlereleaseservicei.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}

	
	@RequestMapping(method = RequestMethod.POST, value = "topicDatagrid")
	@UserEvent(desc = "BbsTopic列表查询")
	@ResponseBody
	public EasyuiDataGrid<TitleReleaseView> topicDatagrid(TitleReleaseSearch search) {
		EasyuiDataGrid<TitleReleaseView> dg = new EasyuiDataGrid<TitleReleaseView>();
	    try{
	    	dg = zhanglmServiceManage.titlereleaseservicei.topicdatagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "BbsTopic禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			TitleReleaseModel model = zhanglmServiceManage.titlereleaseservicei.findById(id);
			if(null != model.getIsDisable()){
				model.setIsDisable(!model.getIsDisable());
			}else {
				model.setIsDisable(true);
			}
			zhanglmServiceManage.titlereleaseservicei.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd(AategorySearch search) {
		try {
			DictionarySearch dictionarysearch = new DictionarySearch();
			List<AategoryView> viewList = zhanglmServiceManage.aategoryservicei.viewList(search);
			List<DictionaryView> dictionarylist = zhanglmServiceManage.dictionaryservicei.viewList(dictionarysearch);
			//类型
			request.setAttribute("dictionarylist", dictionarylist);
			//分类
			request.setAttribute("menumainList", viewList);
			request.setAttribute("view", new TitleReleaseView());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}

	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "题目增加")
	@ResponseBody
	public ResultBean add(TitleReleaseView view,BindingResult errors){
		ResultBean result = new ResultBean();
		TitleReleaseSearch titlereleasesearch = new TitleReleaseSearch();
		try{
			TitleReleaseModel model =new TitleReleaseConvert().addConvert(view);
			titlereleasesearch.setEqcategoryid(model.getCategoryid());
			TitleReleaseModel latesttitle = zhanglmServiceManage.titlereleaseservicei.viewlatestValue(titlereleasesearch);
			if(null != latesttitle){
				Integer sorting = latesttitle.getSorting();
				if(null != sorting){
					sorting++;
					model.setSorting(sorting);
				}else{
					model.setSorting(1);
				}
			
			}else{
				model.setSorting(1);
			}
			if(StringUtils.isBlank(view.getCategoryid())){
				result.setMsg("分类名称不能为空");
				return result;
			}
	/*		if(StringUtils.isBlank(view.getQtype())){
				result.setMsg("题目类型不能为空");
				return result;
			}*/
			//String symbol = request.getParameter("imgurl");
			String imgurl = request.getParameter("imgurl");//题目标识1
			String analysisimgurl = request.getParameter("analysisimgurl");//解析图标识2
			String[] url = request.getParameterValues("fileUrl");	
			String[] type = request.getParameterValues("fileType");
			String[] fileName = request.getParameterValues("fileName");
			FileModel[] fileModels = new FileModel[2];
			
	/*		if(!StringUtils.isNotBlank(model.getContent()) && StringUtils.isNotBlank(model.getAnalysis())){
				
				
			}else{
				
			}*/
			
			if(url != null){
				if(url != null && url.length > 1){
					for(int i =0;i<fileModels.length;i++){
						FileModel file = new FileModel();
						file.setModel("topic");
						file.setName(view.getTitle());
						file.setType(type[i]);
						file.setUrl(url[i]);
						file.setRemark(fileName[i]);
						fileModels[i] = file;
					}
					
					if(fileName != null){
						if(fileName[0].equals(fileName[1])){
							model.setImgurl(url[0]);
						}else{
							model.setImgurl(url[0]);
							model.setAnalysisimgurl(url[1]);
						}
					}
				}else{
					result.setMsg("请上传题目图片一样");
					return result;
				}
				
			}
/*			if(url != null && url.length > 0){
				for(int i =0;i<url.length;i++){
					FileModel file = new FileModel();
					file.setModel("topic");
					file.setName(view.getTitle());
					file.setType(type[i]);
					file.setUrl(url[i]);
					fileModels[i] = file;
				}
				if(imgurl.equals("1") && analysisimgurl.equals("2")){
					for (int i = 0; i < url.length; i++) {
						//题目图片
						if(0 == i){
							model.setImgurl(url[i]);
						}else{
							//解析配图 
							model.setAnalysisimgurl(url[i]);
						}
					}
				}else{
					if(imgurl.equals("1")){
						model.setImgurl(url[0]);
					}
					
					if(analysisimgurl.equals("2")){
						model.setAnalysisimgurl(url[0]);
					}
					
				}
			}else{	
				result.setMsg("请上传图片");
				return result;
			}*/
			
			zhanglmServiceManage.titlereleaseservicei.addAndFiles(model, fileModels, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}
	
	
	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id,AategorySearch search) {
		try {
			DictionarySearch dictionarysearch = new DictionarySearch();
			AnswerSearch answwer = new AnswerSearch();
			answwer.setEqualPid(id);
			TitleReleaseView view = zhanglmServiceManage.titlereleaseservicei.findViewById(id);
			//AategoryView viewList = zhanglmServiceManage.aategoryservicei.findViewById(view.getCategoryid());
			List<AategoryView> viewList = zhanglmServiceManage.aategoryservicei.viewList(search);
			List<DictionaryView> dictionarylist = zhanglmServiceManage.dictionaryservicei.viewList(dictionarysearch);
	
			List<AnswerView> answerlist = zhanglmServiceManage.answerservicei.viewList(answwer);
			//选择正确答案
			request.setAttribute("answerlist", answerlist);
			
			//类型
			request.setAttribute("dictionarylist", dictionarylist);
			request.setAttribute("menumainList", viewList);
			
			
			request.setAttribute("file", sysServiceManage.fileService.findViewByField("formId", id));
			request.setAttribute("pressedFile1", sysServiceManage.fileService.findViewByField("formId", id+"-p1"));
			//request.setAttribute("pressedFile2", sysServiceManage.fileService.findViewByField("formId", id+"-p2"));
			request.setAttribute("view", view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "题修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, TitleReleaseView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			//TitleReleaseModel model =new TitleReleaseConvert().addConvert(view);
	/*		TitleReleaseModel model = zhanglmServiceManage.titlereleaseservicei.findById(id);
			String[] url = request.getParameterValues("fileUrl");
			if(url != null && url.length > 1){
				//题目配图
				model.setQuestionimgurl(url[0]);
				//解析配图
				model.setAnalysisimgurl(url[1]);
			}
			*/
			String[] url = request.getParameterValues("fileUrl");
			String[] type = request.getParameterValues("fileType");
			FileModel[] fileModels = new FileModel[2];
			fileModels[0] = sysServiceManage.fileService.findByField("formId", id);
			fileModels[1] = sysServiceManage.fileService.findByField("formId", id+"-p1");
			TitleReleaseModel model = zhanglmServiceManage.titlereleaseservicei.findById(id);
			model = new TitleReleaseConvert().editConvert(view, model);
			//String[] fileName = request.getParameterValues("fileName");
			if(url != null){
				if(url != null && url.length > 1){
					for(int i =0;i<fileModels.length;i++){
						FileModel file = new FileModel();
						file.setModel("topic");
						file.setName(view.getTitle());
						file.setType(type[i]);
						file.setUrl(url[i]);
						fileModels[i] = file;
					}
					String f1 =url[0].substring(42);
					String[] splits1 = f1.split("-");
					String f2 =url[1].substring(42);
					String[] splits2 = f2.split("-");
					if(splits1[0].equals(splits2[0])){
						model.setImgurl(url[0]);
					}else{
						model.setImgurl(url[0]);
						model.setAnalysisimgurl(url[1]);
					}
				}else{
					result.setMsg("请上传题目图片一样");
					return result;
				}
			}
			zhanglmServiceManage.titlereleaseservicei.editAndFiles(model,fileModels,getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "题目删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		AnswerSearch search = new AnswerSearch();
		try {
			TitleReleaseModel model = zhanglmServiceManage.titlereleaseservicei.findById(id);
			zhanglmServiceManage.titlereleaseservicei.delete(model, getSessionUser());
			//关联删除答案
			search.setEqualPid(id);//题目id
			List<AnswerModel> viewList = zhanglmServiceManage.answerservicei.viewListall(search);
			zhanglmServiceManage.answerservicei.deletecourse(viewList);
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	// 选择正确答案添加
	@RequestMapping(method = RequestMethod.POST, value = "queryright")
	public Map<String,Object> queryright(HttpServletRequest req) {
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		try {
			String[] array = req.getParameterValues("array[]");
			CorrectAnswerSearch search = new CorrectAnswerSearch();
			
	    	
			
		    for (String id : array) {
		    
		    	CorrectAnswerModel correctanswer = new CorrectAnswerModel();
		    	AnswerModel answid = zhanglmServiceManage.answerservicei.findById(id);
		    	correctanswer.setQuestionid(answid.getQuestionid());//题目id
		    	correctanswer.setAnswerid(id);
		    	correctanswer.setAnswersort(answid.getAnswersort());
		    	correctanswer.setAnswercontent(answid.getAnswercontent());
		    	//search.setEqualPid(id);
		    	search.setEqualPid(answid.getQuestionid());
		    	List<CorrectAnswerModel> correctanwer = zhanglmServiceManage.correctanswerservicei.viewListall(search);
		    	if(correctanwer != null && correctanwer.size() > 0){
		    		
		    		map.put("code", 2);//重复添加
	
					return map;
		    	}else{
		    	 	zhanglmServiceManage.correctanswerservicei.add(correctanswer);
			    	//viewList.add(answid);
		    	 	map.put("code", 1);
		    	}
		   
		    }			
			
			//request.setAttribute("view", view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}
	
	
	// 答案添加页面跳转
	@RequestMapping(method = RequestMethod.GET, value = "addtitleRelease/{id}")
	public String addLivedirectory(@PathVariable("id") String id) {
		AnswerSearch search = new AnswerSearch();
		AnswerView view = new AnswerView();
		// 获取专栏分类类别
		try {
		
			DictionarySearch dictionarysearch = new DictionarySearch();
			List<DictionaryView> dictionarylist = zhanglmServiceManage.dictionaryservicei.viewList(dictionarysearch);
			//类型
			request.setAttribute("dictionarylist", dictionarylist);
			
			request.setAttribute("view", view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ANSWER_INDEX;
	}

	// 添加题目答案
	@RequestMapping(method = RequestMethod.POST, value = "addtitleRelease/{id}")
	@UserEvent(desc = "添加题目答案")
	@ResponseBody
	public ResultBean addLivedirectory(@PathVariable("id") String questionid, AnswerView view) {
		ResultBean result = new ResultBean();
		try {    
			
			List<AnswerModel> zhibocoursemodelall = new ArrayList<AnswerModel>();
			AnswerModel model1 = new AnswerModel();
			model1.setQuestionid(questionid);
			//答案内容
			model1.setAnswercontent(view.getAnswercontent1());
			//正确答案
			model1.setAnswer(view.getAnswer1());
			
			AnswerModel model2 = new AnswerModel();
			model2.setQuestionid(questionid);
			//答案内容
			model2.setAnswercontent(view.getAnswercontent2());
			//正确答案
			model2.setAnswer(view.getAnswer2());
			
			
			AnswerModel model3 = new AnswerModel();
			model3.setQuestionid(questionid);
			//答案内容
			model3.setAnswercontent(view.getAnswercontent3());
			//正确答案
			model3.setAnswer(view.getAnswer3());
			
			
			AnswerModel model4 = new AnswerModel();
			model4.setQuestionid(questionid);
			//答案内容
			model4.setAnswercontent(view.getAnswercontent4());
			//正确答案
			model4.setAnswer(view.getAnswer4());
			
			
			AnswerModel model5 = new AnswerModel();
			model5.setQuestionid(questionid);
			//答案内容
			model5.setAnswercontent(view.getAnswercontent5());
			//正确答案
			model5.setAnswer(view.getAnswer5());
			zhibocoursemodelall.add(model1);
			zhibocoursemodelall.add(model2);
			zhibocoursemodelall.add(model3);
			zhibocoursemodelall.add(model4);
			zhibocoursemodelall.add(model5);
			if(zhibocoursemodelall !=null && zhibocoursemodelall.size() > 0){
				
				for (AnswerModel model : zhibocoursemodelall) {
					if(StringUtils.isNotBlank(model.getAnswercontent())){
						zhanglmServiceManage.answerservicei.add(model);
					}
					
				}

			}
			
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}

	// 题目答案跳转编辑
	@RequestMapping(method = RequestMethod.GET, value = "edittitleRelease/{id}")
	public String editLivedirectory(@PathVariable("id") String id) {
		AnswerSearch search = new AnswerSearch();
		AnswerView view = new AnswerView();
		// 获取专栏分类类别
		try {
			search.setEqualPid(id);
			List<AnswerModel> viewList = zhanglmServiceManage.answerservicei.viewListall(search);
			if (viewList != null && viewList.size() > 0) {
				for (int i = 0; i < viewList.size(); i++) {
					String answercontent = viewList.get(i).getAnswercontent();
					String answer = viewList.get(i).getAnswer();		
					if(i == 0){
						view.setAnswercontent1(answercontent);
						//答案排序(1/2/3/4, 对应A/B/C/D)
						view.setAnswer1(answer);
					}
					if(i == 1){
						view.setAnswercontent2(answercontent);
						//答案排序(1/2/3/4, 对应A/B/C/D)
						view.setAnswer2(answer);
					}
					if(i == 2){
						view.setAnswercontent3(answercontent);
						//答案排序(1/2/3/4, 对应A/B/C/D)
						view.setAnswer3(answer);
					}
					if(i == 3){
						view.setAnswercontent4(answercontent);
						//答案排序(1/2/3/4, 对应A/B/C/D)
						view.setAnswer4(answer);
					}				
					if(i == 4){
						view.setAnswercontent5(answercontent);
						//答案排序(1/2/3/4, 对应A/B/C/D)
						view.setAnswer5(answer);
					}

				}
			}
			DictionarySearch dictionarysearch = new DictionarySearch();
			List<DictionaryView> dictionarylist = zhanglmServiceManage.dictionaryservicei.viewList(dictionarysearch);
			//类型
			request.setAttribute("dictionarylist", dictionarylist);
			request.setAttribute("view", view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ANSWER_INDEX;
	}

	// 修改答案
	@RequestMapping(method = RequestMethod.POST, value = "edittitleRelease/{id}")
	@UserEvent(desc = "修改答案")
	@ResponseBody
	public ResultBean editLivedirectory(@PathVariable("id") String questionid, AnswerView view) {
		ResultBean result = new ResultBean();
		try {
			
			AnswerSearch search = new AnswerSearch(); // 删除直播关联讲师数据
			search.setEqualPid(questionid);
			List<AnswerModel> viewList = zhanglmServiceManage.answerservicei.viewListall(search);
			zhanglmServiceManage.answerservicei.deletecourse(viewList);

			List<AnswerModel> zhibocoursemodelall = new ArrayList<AnswerModel>();
			AnswerModel model1 = new AnswerModel();
			//答案内容
			model1.setQuestionid(questionid);
			model1.setAnswercontent(view.getAnswercontent1());
			//答案排序(1/2/3/4, 对应A/B/C/D)
			model1.setAnswersort(view.getAnswersort1());
			//正确答案
			model1.setAnswer(view.getAnswer1());
			
			AnswerModel model2 = new AnswerModel();
			model2.setQuestionid(questionid);
			//答案内容
			model2.setAnswercontent(view.getAnswercontent2());
			//答案排序(1/2/3/4, 对应A/B/C/D)
			model2.setAnswersort(view.getAnswersort2());
			//正确答案
			model2.setAnswer(view.getAnswer2());
			AnswerModel model3 = new AnswerModel();
			model3.setQuestionid(questionid);
			//答案内容
			model3.setAnswercontent(view.getAnswercontent3());
			//答案排序(1/2/3/4, 对应A/B/C/D)
			model3.setAnswersort(view.getAnswersort3());
			//正确答案
			model3.setAnswer(view.getAnswer3());
			
			AnswerModel model4 = new AnswerModel();
			model4.setQuestionid(questionid);
			//答案内容
			model4.setAnswercontent(view.getAnswercontent4());
			//答案排序(1/2/3/4, 对应A/B/C/D)
			model4.setAnswersort(view.getAnswersort4());
			//正确答案
			model4.setAnswer(view.getAnswer4());
			
			AnswerModel model5 = new AnswerModel();
			model5.setQuestionid(questionid);
			//答案内容
			model5.setAnswercontent(view.getAnswercontent5());
			//答案排序(1/2/3/4, 对应A/B/C/D)
			model5.setAnswersort(view.getAnswersort5());
			//正确答案
			model5.setAnswer(view.getAnswer5());
			zhibocoursemodelall.add(model1);
			zhibocoursemodelall.add(model2);
			zhibocoursemodelall.add(model3);
			zhibocoursemodelall.add(model4);
			zhibocoursemodelall.add(model5);
			if(zhibocoursemodelall !=null && zhibocoursemodelall.size() > 0){
				for (AnswerModel model : zhibocoursemodelall) {
					//if(StringUtils.isNotBlank(model.getAnswersort())){
						zhanglmServiceManage.answerservicei.add(model);
					//}	
				}
			}

			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
		// TODO Auto-generated method stub
		
	}
	
}
