package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.mvc.search.zhanglm.BbsFanSearch;
import com.jrzh.mvc.search.zhanglm.BbsMenuSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsFanView;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;

@Controller(BbsFanController.LOCATION +"/BbsFanController")
@RequestMapping(BbsFanController.LOCATION)
public class BbsFanController extends BaseAdminController{
	public static final String LOCATION = "statistics/admin/bbsFan";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String MODULE = "zhanglm_bbsFan";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		try {
			List<BbsMenuView> menuList = new ArrayList<BbsMenuView>();
			BbsMenuSearch search = new BbsMenuSearch();
			List<BbsMenuView> viewList = zhanglmServiceManage.bbsMenuService.viewList(search);
			for(BbsMenuView view : viewList){
				if(StringUtils.isNotBlank(view.getPid())){
					menuList.add(view);
				}
			}
			request.setAttribute("menuList", menuList);
		} catch (ProjectException e) {
			e.printStackTrace();
		} 
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "BbsFan列表查询")
	@ResponseBody
	public EasyuiDataGrid<BbsFanView> datagrid(BbsFanSearch search) {
		EasyuiDataGrid<BbsFanView> dg = new EasyuiDataGrid<BbsFanView>();
	    try{	
	    	dg = zhanglmServiceManage.bbsFanService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@Override
	protected void setData() {
	}

}
