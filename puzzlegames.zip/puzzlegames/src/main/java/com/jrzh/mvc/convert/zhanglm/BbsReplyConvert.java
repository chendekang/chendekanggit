package com.jrzh.mvc.convert.zhanglm;

import org.apache.commons.lang.StringUtils;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.BbsReplyModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.view.zhanglm.BbsReplyView;

public class BbsReplyConvert implements BaseConvertI<BbsReplyModel, BbsReplyView> {

	@Override
	public BbsReplyModel addConvert(BbsReplyView view) throws ProjectException {
		BbsReplyModel model = new BbsReplyModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public BbsReplyModel editConvert(BbsReplyView view, BbsReplyModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public BbsReplyView convertToView(BbsReplyModel model) throws ProjectException {
		BbsReplyView view = new BbsReplyView();
		ReflectUtils.copySameFieldToTarget(model, view);
		MemberModel member = model.getMember();
		if(null != member){
			String userName = member.getNickName();
			String userPhoto = member.getPhoto();
			if(StringUtils.isNotBlank(userName)){
				view.setUserName(userName);
			}else{
				view.setUserName("用户未设置昵称");
			}
			if(StringUtils.isNotBlank(userPhoto)){
				view.setUserPhoto(userPhoto);
			}
		}
		
		return view;
	}

}
