package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.search.zhanglm.BbsMenuSearch;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;

public interface BbsMenuServiceI  extends BaseServiceI<BbsMenuModel, BbsMenuSearch, BbsMenuView>{

	void addAndFile(BbsMenuModel model, FileModel file, SessionUser user)throws Exception;

	void editAndFile(BbsMenuModel model, FileModel file, SessionUser user)throws Exception;

	void deleteAndFile(BbsMenuModel model, FileModel file, SessionUser user)throws Exception;
	
	List<BbsMenuView> viewMenu(BbsMenuSearch search, MemberModel user)throws ProjectException;

	BbsMenuView viewMenuByCode(String code, MemberModel member)throws ProjectException;

	BbsMenuView viewMenuByid(String boardId, String userId) throws ProjectException;

	List<BbsMenuView> newviewMenu(BbsMenuSearch search, MemberModel member) throws ProjectException;
}