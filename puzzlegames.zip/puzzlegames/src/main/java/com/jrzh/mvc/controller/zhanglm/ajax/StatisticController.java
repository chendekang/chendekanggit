package com.jrzh.mvc.controller.zhanglm.ajax;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jrzh.common.bean.excel.ExcelBean;
import com.jrzh.config.ProjectConfigration;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAjaxController;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.search.zhanglm.MemberSearch;
import com.jrzh.mvc.search.zhanglm.WithdrawAuditLogSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.MemberView;
import com.jrzh.mvc.view.zhanglm.WithdrawAuditLogView;
import com.jrzh.tools.ExcelTools;

@Controller(StatisticController.LOCATION +"/StatisticController")
@RequestMapping(StatisticController.LOCATION)
public class StatisticController extends BaseAjaxController {
	public static final String LOCATION = "zhanglm/ajax/statistic";

	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	private ProjectConfigration projectConfigration;
	
	@RequestMapping(method = RequestMethod.POST,value = "registerExport")
	@UserEvent(desc = "注册统计报表导出")
	public void registerExport(MemberSearch search) {
		String url = this.getClass().getClassLoader().getResource("StatisticRegister.properties").getFile();
		File file = new File(url.replace("%20", " "));
		ExcelTools excel = new ExcelTools(file);
		try {
			List<MemberView> viewList = zhanglmServiceManage.memberService.viewList(search);
			List<List<?>> sourceLists = new ArrayList<List<?>>();
			sourceLists.add(viewList);
			ExcelBean excelBean = excel.getExcelBean(sourceLists);
			String exportFileName = "注册统计报表" + UUID.randomUUID().toString() + ".xls";
			excelBean.setFileUrl(projectConfigration.getFileRootUrl() + "exportExcel/"+exportFileName);
			excel.exportExcel(excelBean);
			excel.download(exportFileName, excelBean, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "withdRegisterExport")
	@UserEvent(desc = "提现审核记录注册统计报表导出")
	public void withdRegisterExport(WithdrawAuditLogSearch search) {
		String url = this.getClass().getClassLoader().getResource("WithdStatisticRegister.properties").getFile();
		
		File file = new File(url.replace("%20", " "));
		
		ExcelTools excel = new ExcelTools(file);
		try {
			search.setNeAuditState(BusinessConstants.WITHDROW_AUDIT_STATUS.AUDING);
			List<WithdrawAuditLogView> viewList = zhanglmServiceManage.withdrawAuditLogService.viewList(search);
			List<List<?>> sourceLists = new ArrayList<List<?>>();
			
			sourceLists.add(viewList);
			ExcelBean excelBean = excel.getExcelBean(sourceLists);
			String exportFileName = "注册统计报表" + UUID.randomUUID().toString() + ".xls";
			excelBean.setFileUrl(projectConfigration.getFileRootUrl() + "exportExcel/"+exportFileName);
			excel.exportExcel(excelBean);
			excel.download(exportFileName, excelBean, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void setData() {
		// TODO Auto-generated method stub

	}

}
