package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class CommentReplySearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String equalTopicId;
	private String equalcommentId;
	
	private String equserId;
	


	public String getEquserId() {
		return equserId;
	}

	public void setEquserId(String equserId) {
		this.equserId = equserId;
	}

	public String getEqualcommentId() {
		return equalcommentId;
	}

	public void setEqualcommentId(String equalcommentId) {
		this.equalcommentId = equalcommentId;
	}

	public String getEqualTopicId() {
		return equalTopicId;
	}

	public void setEqualTopicId(String equalTopicId) {
		this.equalTopicId = equalTopicId;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalTopicId)){
			dc.add(Restrictions.eq("replyId", equalTopicId));
		}
		if(StringUtils.isNotBlank(equalcommentId)){
			dc.add(Restrictions.eq("commentId", equalcommentId));
		}
		
		if(StringUtils.isNotBlank(equalcommentId)){
			dc.add(Restrictions.eq("commentId", equalcommentId));
		}
/*		if(StringUtils.isNotBlank(equserId)){
			dc.add(Restrictions.eq("replyuserId", equserId));
		}
		*/
		if(StringUtils.isNotBlank(equserId)){
			dc.add(Restrictions.eq("userId", equserId));
		}
	}

}