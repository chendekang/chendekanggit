package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.SignInModel;
import com.jrzh.mvc.view.zhanglm.SignInView;

public class SignInConvert implements BaseConvertI<SignInModel, SignInView> {

	@Override
	public SignInModel addConvert(SignInView view) throws ProjectException {
		SignInModel model = new SignInModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public SignInModel editConvert(SignInView view, SignInModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public SignInView convertToView(SignInModel model) throws ProjectException {
		SignInView view = new SignInView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
