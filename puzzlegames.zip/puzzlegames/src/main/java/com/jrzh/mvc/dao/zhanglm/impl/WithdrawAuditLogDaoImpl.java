package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.WithdrawAuditLogDaoI;
import com.jrzh.mvc.model.zhanglm.WithdrawAuditLogModel;

@Repository("withdrawAuditLogDao")
public class WithdrawAuditLogDaoImpl extends BaseDaoImpl<WithdrawAuditLogModel> implements WithdrawAuditLogDaoI{

}