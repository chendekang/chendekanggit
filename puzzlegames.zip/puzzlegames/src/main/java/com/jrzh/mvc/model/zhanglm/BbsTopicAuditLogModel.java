package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_bbs_topic_audit_log")
public class BbsTopicAuditLogModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 关联话题ID
     */
    @Column(name = "_topic_id")
    private String topicId;
    /**
     * 话题标题
     */
    @Column(name = "_topic_title")
    private String topicTitle;
    /**
     * 用户名称
     */
    @Column(name = "_user_name")
    private String userName;
    /**
     * 审核人
     */
    @Column(name = "_auditer")
    private String auditer;
    /**
     * 审核说明
     */
    @Column(name = "_opinion")
    private String opinion;
    /**
     * 审核状态
     */
    @Column(name = "_status")
    private Integer status;
    /**
     * 审核时间
     */
    @Column(name="_audit_time")
	private Date auditTime;
    /**
     * 发布时间
     */
    @Column(name="_issue_time")
	private Date issueTime;
    public Date getIssueTime() {
		return issueTime;
	}

	public void setIssueTime(Date issueTime) {
		this.issueTime = issueTime;
	}

	public Date getAuditTime() {
		return auditTime;
	}

	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}

	public void setTopicId(String topicId) {
        this.topicId = topicId;
    }
    
    public String getTopicId() {
        return this.topicId;
    }
    public void setTopicTitle(String topicTitle) {
        this.topicTitle = topicTitle;
    }
    
    public String getTopicTitle() {
        return this.topicTitle;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String getUserName() {
        return this.userName;
    }
    public void setAuditer(String auditer) {
        this.auditer = auditer;
    }
    
    public String getAuditer() {
        return this.auditer;
    }
    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }
    
    public String getOpinion() {
        return this.opinion;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    
    public Integer getStatus() {
        return this.status;
    }

}