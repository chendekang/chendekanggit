package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class MessageTemplateSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String likeName;
		
	private Boolean equalIsSendMobile;
	
	private Boolean equalIsSendPlatform;

	
	public Boolean getEqualIsSendPlatform() {
		return equalIsSendPlatform;
	}

	public void setEqualIsSendPlatform(Boolean equalIsSendPlatform) {
		this.equalIsSendPlatform = equalIsSendPlatform;
	}

	public Boolean getEqualIsSendMobile() {
		return equalIsSendMobile;
	}

	public void setEqualIsSendMobile(Boolean equalIsSendMobile) {
		this.equalIsSendMobile = equalIsSendMobile;
	}

	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(likeName)){
			dc.add(Restrictions.like("name", "%"+likeName+"%"));
		}
		if(null != equalIsSendMobile){
			dc.add(Restrictions.eq("isSendMobile", equalIsSendMobile));
		}
		if(null != equalIsSendPlatform){
			dc.add(Restrictions.eq("isSendPlatform", equalIsSendPlatform));
		}
	}

}