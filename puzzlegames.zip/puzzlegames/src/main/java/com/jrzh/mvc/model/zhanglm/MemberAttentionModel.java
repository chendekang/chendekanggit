package com.jrzh.mvc.model.zhanglm;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_member_attentions")
public class MemberAttentionModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 用户ID
     */
    @Column(name = "_member_id")
    private String memberId;
    /**
     * 粉丝ID
     */
    @Column(name = "_fans_id")
    private String fansId;
    /**
     * 关联关注用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_member_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel member;
    /**
     * 关联粉丝用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_fans_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel fans;

    public MemberModel getMember() {
		return member;
	}

	public void setMember(MemberModel member) {
		this.member = member;
	}

	public MemberModel getFans() {
		return fans;
	}

	public void setFans(MemberModel fans) {
		this.fans = fans;
	}

	public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
    
    public String getMemberId() {
        return this.memberId;
    }
    public void setFansId(String fansId) {
        this.fansId = fansId;
    }
    
    public String getFansId() {
        return this.fansId;
    }

}