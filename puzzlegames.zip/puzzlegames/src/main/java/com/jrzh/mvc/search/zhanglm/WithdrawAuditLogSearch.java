package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class WithdrawAuditLogSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private Integer equalAuditState;
	
	private String likeUserName;
	
	private String equalUserId;
	
	private Integer neAuditState;
	
	
	
	public Integer getNeAuditState() {
		return neAuditState;
	}


	public void setNeAuditState(Integer neAuditState) {
		this.neAuditState = neAuditState;
	}


	public String getEqualUserId() {
		return equalUserId;
	}


	public void setEqualUserId(String equalUserId) {
		this.equalUserId = equalUserId;
	}


	public String getLikeUserName() {
		return likeUserName;
	}


	public void setLikeUserName(String likeUserName) {
		this.likeUserName = likeUserName;
	}


	public Integer getEqualAuditState() {
		return equalAuditState;
	}


	public void setEqualAuditState(Integer equalAuditState) {
		this.equalAuditState = equalAuditState;
	}


	@Override
	public void setDc(DetachedCriteria dc) {
		if(equalAuditState!=null){
			dc.add(Restrictions.eq("auditState", equalAuditState));
		}
		if(StringUtils.isNotBlank(likeUserName)){
			dc.add(Restrictions.like("userName", "%"+likeUserName+"%"));
		}
		if(StringUtils.isNotBlank(equalUserId)){
			dc.add(Restrictions.eq("userId", equalUserId));
		}
		if(null != neAuditState){
			dc.add(Restrictions.ne("auditState", neAuditState));
			
		}
	}

}