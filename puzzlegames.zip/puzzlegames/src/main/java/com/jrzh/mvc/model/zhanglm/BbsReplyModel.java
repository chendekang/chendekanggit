package com.jrzh.mvc.model.zhanglm;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_bbs_reply")
public class BbsReplyModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 话题ID
     */
    @Column(name = "_topic_id")
    private String topicId;
    /**
     * 回复内容
     */
    @Column(name = "_content")
    private String content;
    /**
     * 用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 关联用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_user_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel member;

    
    /**
     * 点赞数
     */
    @Column(name = "_praise")
    private Integer praise;
    
    
    
    /**
     *评论回复数
     */
    @Column(name = "_reply_number")
    private Integer replynumber;
    
    
    
    public Integer getReplynumber() {
		return replynumber;
	}

	public void setReplynumber(Integer replynumber) {
		this.replynumber = replynumber;
	}

	public Integer getPraise() {
		return praise;
	}

	public void setPraise(Integer praise) {
		this.praise = praise;
	}

	public MemberModel getMember() {
		return member;
	}

	public void setMember(MemberModel member) {
		this.member = member;
	}

	public void setTopicId(String topicId) {
        this.topicId = topicId;
    }
    
    public String getTopicId() {
        return this.topicId;
    }
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getContent() {
        return this.content;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }

}