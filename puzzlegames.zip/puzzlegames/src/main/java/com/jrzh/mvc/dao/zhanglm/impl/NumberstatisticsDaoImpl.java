package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.NumberstatisticsDaoI;
import com.jrzh.mvc.model.zhanglm.NumberstatisticsModel;

@Repository("NumberstatisticsDaoI")
public class NumberstatisticsDaoImpl extends BaseDaoImpl<NumberstatisticsModel> implements NumberstatisticsDaoI{

}