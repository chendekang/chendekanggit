package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.PlazaDataModel;
import com.jrzh.mvc.view.zhanglm.PlazaDataView;

public class PlazaDataConvert implements BaseConvertI<PlazaDataModel, PlazaDataView> {

	@Override
	public PlazaDataModel addConvert(PlazaDataView view) throws ProjectException {
		PlazaDataModel model = new PlazaDataModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public PlazaDataModel editConvert(PlazaDataView view, PlazaDataModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public PlazaDataView convertToView(PlazaDataModel model) throws ProjectException {
		PlazaDataView view = new PlazaDataView();
		ReflectUtils.copySameFieldToTarget(model, view);
		view.setDataCategoryStr(view.getDataCategory().toString());
		return view;
	}

}
