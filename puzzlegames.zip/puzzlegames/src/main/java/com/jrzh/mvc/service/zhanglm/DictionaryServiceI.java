package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.DictionaryModel;
import com.jrzh.mvc.search.zhanglm.DictionarySearch;
import com.jrzh.mvc.view.zhanglm.DictionaryView;

public interface DictionaryServiceI extends BaseServiceI<DictionaryModel, DictionarySearch, DictionaryView>{




}