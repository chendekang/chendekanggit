package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.MemberUserModel;
import com.jrzh.mvc.search.zhanglm.MemberUserSearch;
import com.jrzh.mvc.view.zhanglm.MemberUserView;

public interface MemberUserServiceI  extends BaseServiceI<MemberUserModel, MemberUserSearch, MemberUserView>{

}