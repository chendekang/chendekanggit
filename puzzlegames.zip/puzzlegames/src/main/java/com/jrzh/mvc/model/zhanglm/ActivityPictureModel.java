package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_activity_picture")
public class ActivityPictureModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 图片名称
     */
    @Column(name = "_img_name")
    private String imgName;
    /**
     * 图片路径
     */
    @Column(name = "_img_url")
    private String imgUrl;
    
    /**
     * 请求地此
     */
    @Column(name = "_action_nurl")
    private String actionurl;
    /**
     * 图片类型
     */
    @Column(name = "_img_type")
    private String imgType;

    
    public String getActionurl() {
		return actionurl;
	}

	public void setActionurl(String actionurl) {
		this.actionurl = actionurl;
	}

	public void setImgName(String imgName) {
        this.imgName = imgName;
    }
    
    public String getImgName() {
        return this.imgName;
    }
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
    
    public String getImgUrl() {
        return this.imgUrl;
    }
    public void setImgType(String imgType) {
        this.imgType = imgType;
    }
    
    public String getImgType() {
        return this.imgType;
    }

}