package com.jrzh.mvc.controller.zhanglm.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.BbsPraiseConvert;
import com.jrzh.mvc.model.zhanglm.BbsPraiseModel;
import com.jrzh.mvc.search.zhanglm.BbsPraiseSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsPraiseView;

@Controller(BbsPraiseController.LOCATION +"/BbsPraiseController")
@RequestMapping(BbsPraiseController.LOCATION)
public class BbsPraiseController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/bbsPraise";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_bbsPraise";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "BbsPraise点赞列表查询")
	@ResponseBody
	public EasyuiDataGrid<BbsPraiseView> datagrid(BbsPraiseSearch search) {
		EasyuiDataGrid<BbsPraiseView> dg = new EasyuiDataGrid<BbsPraiseView>();
	    try{
	    	dg = zhanglmServiceManage.bbsPraiseService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new BbsPraiseView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "BbsPraise增加")
	@ResponseBody
	public ResultBean add(BbsPraiseView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			BbsPraiseModel model =new BbsPraiseConvert().addConvert(view);
			zhanglmServiceManage.bbsPraiseService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.bbsPraiseService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "BbsPraise编辑")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, BbsPraiseView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			BbsPraiseModel model = zhanglmServiceManage.bbsPraiseService.findById(id);
			model = new BbsPraiseConvert().editConvert(view, model);
			zhanglmServiceManage.bbsPraiseService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "BbsPraise删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			BbsPraiseModel model = zhanglmServiceManage.bbsPraiseService.findById(id);
			zhanglmServiceManage.bbsPraiseService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "BbsPraise启用/禁用")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			BbsPraiseModel model = zhanglmServiceManage.bbsPraiseService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.bbsPraiseService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
