package com.jrzh.mvc.service.zhanglm.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.CommentReplyConvert;
import com.jrzh.mvc.dao.zhanglm.CommentReplyDaoI;
import com.jrzh.mvc.model.zhanglm.BbsReplyPraiseModel;
import com.jrzh.mvc.model.zhanglm.CommentReplyModel;
import com.jrzh.mvc.search.zhanglm.BbsReplyPraiseSearch;
import com.jrzh.mvc.search.zhanglm.CommentReplySearch;
import com.jrzh.mvc.service.zhanglm.CommentReplyServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;
import com.jrzh.mvc.view.zhanglm.CommentReplyView;

@Service("commentReplyService")
public class CommentReplyServiceImpl extends
		BaseServiceImpl<CommentReplyModel, CommentReplySearch, CommentReplyView> implements
		CommentReplyServiceI {
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	@Resource(name = "commentReplyDao")
	private CommentReplyDaoI commentReplyDao;

	@Override
	public BaseDaoI<CommentReplyModel> getDao() {
		return commentReplyDao;
	}

	@Override
	public BaseConvertI<CommentReplyModel, CommentReplyView> getConvert() {
		return new CommentReplyConvert();
	}

	@Override
	public List<CommentReplyView> viewListCommentReply(CommentReplySearch commentreplysearch,String userId) throws ProjectException {
		List<CommentReplyView> viewList = this.viewList(commentreplysearch);
		for(CommentReplyView view : viewList){
	/*		//获取当前用户名
			BbsTopicView topic = zhanglmServiceManage.bbsTopicService.findViewById(view.getReplyId());
			view.setCurrentuser(topic.getUserName());*/	
			if(StringUtils.isNotBlank(userId)){
				BbsReplyPraiseSearch search = new BbsReplyPraiseSearch();	
				search.setEqualreplyId(view.getId());
				search.setEqualUserId(userId);
				BbsReplyPraiseModel model = zhanglmServiceManage.BbsReplyPraiseServiceI.findBySearch(search);
				if(model != null){
					view.setIsPraise(true);
				}else{
					view.setIsPraise(false);
				}
			}else{
				view.setIsPraise(false);
			}
		}
		return viewList;
	}

}
