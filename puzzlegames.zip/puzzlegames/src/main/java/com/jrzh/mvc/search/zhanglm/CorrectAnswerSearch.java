package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class CorrectAnswerSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String equalPid;

	private String id;
	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getEqualPid() {
		return equalPid;
	}


	public void setEqualPid(String equalPid) {
		this.equalPid = equalPid;
	}
	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalPid)){
			dc.add(Restrictions.eq("questionid", equalPid));
		}
		
		if(StringUtils.isNotBlank(id)){
			dc.add(Restrictions.eq("id", id));
		}


	}


}