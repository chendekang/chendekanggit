package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_collect")
public class CollectModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 关联用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_user_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel member;
    /**
     * 题目ID
     */
    @Column(name = "_circle_id")
    private String circleId;
    /**
     * 关联话题
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = TitleReleaseModel.class)
	@JoinColumn(name = "_circle_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private TitleReleaseModel circle;
    /**
     * 收藏时间
     */
    @Column(name = "_datetime")
    private Date datetime;

    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }
    public void setCircleId(String circleId) {
        this.circleId = circleId;
    }
    
    public String getCircleId() {
        return this.circleId;
    }
    public void setDatetime(Date datetime) {
        this.datetime = datetime;
    }
    
    public Date getDatetime() {
        return this.datetime;
    }

}