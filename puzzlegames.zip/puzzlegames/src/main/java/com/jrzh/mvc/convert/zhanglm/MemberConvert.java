package com.jrzh.mvc.convert.zhanglm;

import org.apache.commons.lang.StringUtils;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.view.zhanglm.MemberView;

public class MemberConvert implements BaseConvertI<MemberModel, MemberView> {
	
	@Override
	public MemberModel addConvert(MemberView view) throws ProjectException {
		MemberModel model = new MemberModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public MemberModel editConvert(MemberView view, MemberModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public MemberView convertToView(MemberModel model) throws ProjectException {
		MemberView view = new MemberView();
		if(null == model.getMcoin()){
			model.setMcoin(0.0);
		}
		ReflectUtils.copySameFieldToTarget(model, view);
		view.setLoginChannelStr(BusinessConstants.LOGIN_CHANNEL.valueMap.get(view.getLoginChannel()));
		if(StringUtils.isBlank(view.getRealName())){
			view.setRealName("用户未实名");
			view.setIdCard("用户未实名");
		}
		if(StringUtils.isBlank(view.getBankAcco())){
			view.setBankAcco("用户未绑卡");
		}
		if(StringUtils.isBlank(view.getNickName())){
			view.setNickName("未设置昵称");
		}
		if(StringUtils.isBlank(view.getSignature())){
			view.setSignature("未设置个性签名");
		}
		if(StringUtils.isBlank(view.getIntro())){
			view.setIntro("未设置个人简介");
		}
		view.setFansId(model.getId());
		return view;
	}

}
