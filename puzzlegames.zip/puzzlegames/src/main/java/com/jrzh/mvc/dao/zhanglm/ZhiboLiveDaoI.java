package com.jrzh.mvc.dao.zhanglm;

import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.ZhiboLiveModel;

public interface ZhiboLiveDaoI extends BaseDaoI<ZhiboLiveModel>{

}
