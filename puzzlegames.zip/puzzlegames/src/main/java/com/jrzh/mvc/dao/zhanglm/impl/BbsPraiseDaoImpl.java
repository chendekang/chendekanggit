package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.BbsPraiseDaoI;
import com.jrzh.mvc.model.zhanglm.BbsPraiseModel;

@Repository("bbsPraiseDao")
public class BbsPraiseDaoImpl extends BaseDaoImpl<BbsPraiseModel> implements BbsPraiseDaoI{

}