package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.DownloadModel;
import com.jrzh.mvc.search.zhanglm.DownloadSearch;
import com.jrzh.mvc.view.zhanglm.DownloadView;

public interface DownloadServiceI  extends BaseServiceI<DownloadModel, DownloadSearch, DownloadView>{

}