package com.jrzh.mvc.service.zhanglm.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.convert.zhanglm.BbsTopicConvert;
import com.jrzh.mvc.dao.zhanglm.BbsTopicDaoI;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.model.zhanglm.BbsPraiseModel;
import com.jrzh.mvc.model.zhanglm.BbsTopicAuditLogModel;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.model.zhanglm.MemberMsgModel;
import com.jrzh.mvc.model.zhanglm.PlazaDataModel;
import com.jrzh.mvc.search.zhanglm.BbsFanSearch;
import com.jrzh.mvc.search.zhanglm.BbsPraiseSearch;
import com.jrzh.mvc.search.zhanglm.BbsTopicSearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.service.zhanglm.BbsTopicServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;
import com.jrzh.tools.HtmlTools;

@Service("bbsTopicService")
public class BbsTopicServiceImpl extends
		BaseServiceImpl<BbsTopicModel, BbsTopicSearch, BbsTopicView> implements
		BbsTopicServiceI {

	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Resource(name = "bbsTopicDao")
	private BbsTopicDaoI bbsTopicDao;

	@Override
	public BaseDaoI<BbsTopicModel> getDao() {
		return bbsTopicDao;
	}

	@Override
	public BaseConvertI<BbsTopicModel, BbsTopicView> getConvert() {
		return new BbsTopicConvert();
	}
	
	@Override
	public void editAndLog(BbsTopicModel model,SessionUser user) throws ProjectException {
		this.edit(model, user);
		String topicId = model.getId();
		Integer status = model.getStatus();
		//添加审核记录
		BbsTopicAuditLogModel auditLog = new BbsTopicAuditLogModel();
		auditLog.setTopicTitle(model.getTitle());
		auditLog.setTopicId(topicId);
		auditLog.setUserName(model.getUserName());
		auditLog.setStatus(model.getStatus());
		auditLog.setAuditer(user.getName());
		auditLog.setOpinion(model.getOpinion());
		auditLog.setAuditTime(model.getAuditTime());
		auditLog.setIssueTime(model.getCreateTime());
		zhanglmServiceManage.bbsTopicAuditLogService.add(auditLog, user);
		//发送消息通知用户
		MemberMsgModel memberMsg = new MemberMsgModel();
		memberMsg.setSenderId(user.getId());
		memberMsg.setUserId(model.getUserId());
		memberMsg.setTitle("话题审核结果");
		memberMsg.setContent("您的话题【"+model.getTitle()+"】"+BusinessConstants.BBS_TOPIC_STATUS.valueMap.get(status)+"，"+"审核说明："+model.getOpinion());
		memberMsg.setStatus(BusinessConstants.MEMBER_MSG_STATUS.NOT_READ);
		zhanglmServiceManage.memberMsgService.add(memberMsg, user);
		//审核通过的操作
		if(status.equals(BusinessConstants.BBS_TOPIC_STATUS.AUDIT)){
			//圈子关联用户话题数+1，并计算平均值
			//------------旧功能-----------------
		/*	String menuCode = model.getMenuCode();
			BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
			BbsFanSearch fanSearch = new BbsFanSearch();*/
			//------------新功能-----------------
			String menuCode = model.getMenuid();
			BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("id", menuCode);
			BbsFanSearch fanSearch = new BbsFanSearch();
			fanSearch.setEqualMenuId(menu.getId());
			fanSearch.setEqualUserId(model.getUserId());
			BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
			Long fanTopic = fan.getTopicNum();
			Long fanPraise = fan.getPraiseNum();
			Long fanReply = fan.getReplyNum();
			fanTopic++;
			fan.setTopicNum(fanTopic);
			Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
			fan.setAverage(fanAverage);
			zhanglmServiceManage.bbsFanService.edit(fan, user);
			//话题发布到广场
			PlazaDataModel plazaData = zhanglmServiceManage.plazaDataService.findByField("dataId", topicId);
			if(plazaData != null){
				zhanglmServiceManage.plazaDataService.edit(plazaData, user);
			}else{
				plazaData = new PlazaDataModel();
				plazaData.setDataId(topicId);
				plazaData.setUserId(model.getUserId());
				plazaData.setDataCategory(BusinessConstants.PLAZA_DATA_CATEGORY.TOPIC);
				zhanglmServiceManage.plazaDataService.add(plazaData, user);
			}
		}
	}
	
	@Override
	public BbsTopicView viewFirstTopic(BbsTopicSearch search,SessionUser user) throws ProjectException {
		BbsTopicView view = this.firstView(search);
		DefaultSearch defaultSearch = new DefaultSearch();
		defaultSearch.setEqualIsDisable(false);
		DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
		//默认头像
		if(view != null){
			if(StringUtils.isBlank(view.getUserPhoto())){
				if(defaultImg != null){
					view.setUserPhoto(defaultImg.getImgUrl());
				}
			}
		}
		//查看是否点赞
		BbsPraiseSearch praiseSearch = new BbsPraiseSearch();
		if(null != view){
			String content = HtmlTools.delHTMLTag(view.getContent());
			if(content.length() > 30){
				view.setContent(content.subSequence(0, 30) + "...");
			}
			praiseSearch.setEqualTopicId(view.getId());
			if(user != null){
				praiseSearch.setEqualUserId(user.getId());
				BbsPraiseModel model = zhanglmServiceManage.bbsPraiseService.findBySearch(praiseSearch);
				if(model != null){
					view.setIsPraise(true);
				}else{
					view.setIsPraise(false);
				}
			}else{
				view.setIsPraise(false);
			}
		}
		return view;
	}
	
	@Override
	public List<BbsTopicView> viewListTopic(BbsTopicSearch search,SessionUser user) throws ProjectException {
		List<BbsTopicView> viewList = this.viewList(search);
		DefaultSearch defaultSearch = new DefaultSearch();
		defaultSearch.setEqualIsDisable(false);
		DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
		for(BbsTopicView view : viewList){
			String dataId = view.getDataId();
			BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(dataId);
			//展示图
			if(StringUtils.isNotBlank(topic.getImgUrl())){
				view.setImgUrl(topic.getImgUrl());
			}else{
				view.setImgUrl("null");
			}
			//默认头像
			if(StringUtils.isBlank(view.getUserPhoto())){
				if(defaultImg != null){
					view.setUserPhoto(defaultImg.getImgUrl());
				}
			}
	
			//取简介 
			String content = HtmlTools.delHTMLTag(view.getContent());
			if(content.length() > 30){
				view.setContent(content.subSequence(0, 30) + "...");
			}
			//查看是否点赞
			BbsPraiseSearch praiseSearch = new BbsPraiseSearch();
			praiseSearch.setEqualTopicId(view.getId());
			if(user != null){
				praiseSearch.setEqualUserId(user.getId());
				BbsPraiseModel model = zhanglmServiceManage.bbsPraiseService.findBySearch(praiseSearch);
				if(model != null){
					view.setIsPraise(true);
				}else{
					view.setIsPraise(false);
				}
			}else{
				view.setIsPraise(false);
			}
		}
		return viewList;
	}

	@Override
	public List<BbsTopicView> newviewListTopic(BbsTopicSearch search, String userId) throws ProjectException {
		List<BbsTopicView> viewList = this.viewList(search);
		DefaultSearch defaultSearch = new DefaultSearch();
		defaultSearch.setEqualIsDisable(false);
		DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
		for(BbsTopicView view : viewList){
			String dataId = view.getDataId();
			BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(dataId);
			//展示图
			if(StringUtils.isNotBlank(topic.getImgUrl())){
				view.setImgUrl(topic.getImgUrl());
			}else{
				view.setImgUrl("null");
			}
			//默认头像
			if(StringUtils.isBlank(view.getUserPhoto())){
				if(defaultImg != null){
					view.setUserPhoto(defaultImg.getImgUrl());
				}
			}
	
			//取简介 
			String content = HtmlTools.delHTMLTag(view.getContent());
			if(content.length() > 30){
				view.setContent(content.subSequence(0, 30) + "...");
			}
			//查看是否点赞
			BbsPraiseSearch praiseSearch = new BbsPraiseSearch();
			praiseSearch.setEqualTopicId(view.getId());
			if(StringUtils.isNotBlank(userId)){
				praiseSearch.setEqualUserId(userId);
				BbsPraiseModel model = zhanglmServiceManage.bbsPraiseService.findBySearch(praiseSearch);
				if(model != null){
					view.setIsPraise(true);
				}else{
					view.setIsPraise(false);
				}
			}else{
				view.setIsPraise(false);
			}
		}
		return viewList;
	}
	
	
	/*
	 * 添加后台话题并发倒广场数据
	 * 
	 * */
	@Override
	public void addTopic(BbsTopicModel model, SessionUser user) throws ProjectException {
		this.add(model, user);
		//直播发布到广场
	/*	PlazaDataModel plazaData = new PlazaDataModel();
		plazaData.setDataId(model.getId());
		plazaData.setUserId(model.getUserId());
		plazaData.setDataCategory(BusinessConstants.PLAZA_DATA_CATEGORY.TOPIC);
		zhanglmServiceManage.plazaDataService.add(plazaData, user);	*/	
	}
}
