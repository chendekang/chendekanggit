package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.search.zhanglm.BbsTopicSearch;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;

public interface BbsTopicServiceI  extends BaseServiceI<BbsTopicModel, BbsTopicSearch, BbsTopicView>{

	void editAndLog(BbsTopicModel model, SessionUser user)throws ProjectException;

	List<BbsTopicView> viewListTopic(BbsTopicSearch search, SessionUser user)throws ProjectException;

	BbsTopicView viewFirstTopic(BbsTopicSearch search, SessionUser user)throws ProjectException;

	List<BbsTopicView> newviewListTopic(BbsTopicSearch search, String userId) throws ProjectException;

	void addTopic(BbsTopicModel model, SessionUser sessionUser) throws ProjectException;

}