package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.BbsFanDaoI;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;

@Repository("bbsFanDao")
public class BbsFanDaoImpl extends BaseDaoImpl<BbsFanModel> implements BbsFanDaoI{

}