package com.jrzh.mvc.service.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.AategoryModel;
import com.jrzh.mvc.search.zhanglm.AategorySearch;
import com.jrzh.mvc.view.zhanglm.AategoryView;

public interface AategoryServiceI  extends BaseServiceI<AategoryModel, AategorySearch, AategoryView>{

	void addAndFiles(AategoryModel model, FileModel[] fileModels, SessionUser sessionUser) throws ProjectException;



}