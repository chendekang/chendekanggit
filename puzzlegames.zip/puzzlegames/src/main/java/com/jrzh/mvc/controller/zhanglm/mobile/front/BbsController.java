package com.jrzh.mvc.controller.zhanglm.mobile.front;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.controller.zhanglm.mobile.BaseMobileController;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.model.zhanglm.DownloadModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.search.zhanglm.BbsFanSearch;
import com.jrzh.mvc.search.zhanglm.BbsMenuSearch;
import com.jrzh.mvc.search.zhanglm.BbsPraiseSearch;
import com.jrzh.mvc.search.zhanglm.BbsReplySearch;
import com.jrzh.mvc.search.zhanglm.BbsTopicSearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.DownloadSearch;
import com.jrzh.mvc.search.zhanglm.SharePageSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsFanView;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;
import com.jrzh.mvc.view.zhanglm.BbsPraiseView;
import com.jrzh.mvc.view.zhanglm.BbsReplyView;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;
import com.jrzh.mvc.view.zhanglm.CommentReplyView;
import com.jrzh.mvc.view.zhanglm.SharePageView;
import com.jrzh.mvc.view.zhanglm.SnapshotView;

@Controller(BbsController.LOCATION + "BbsController")
@RequestMapping(BbsController.LOCATION)
public class BbsController extends BaseMobileController {
	public static final String LOCATION = "zhanglm/mobile/bbs/";
	
	public static final String INDEX_PAGE = LOCATION + "index";
	
	public static final String BOARD_PAGE = LOCATION + "board";
	
	public static final String COMMENT_PAGE = LOCATION + "comment";
	
	public static final String MENU_PAGE = LOCATION + "menu";
	
	public static final String KLINE_PAGE = LOCATION + "Kline";
	
	public static final String down_App_PAGE = LOCATION + "downApp";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "kLine")
	public String kLine(){
		try {
			String symbol = request.getParameter("goldSymbol");
			String[] resymbol = symbol.split(" ");
			symbol = "";
			for (int i = 0; i < resymbol.length; i++) {
				if(i == 0){
					symbol = resymbol[i];
				}else{
					symbol += "+"+resymbol[i];
				}
			}
			System.out.println(symbol);
			request.setAttribute("goldSymbol", symbol);

			SnapshotView view = zhanglmServiceManage.snapshotService.findViewByField("symbol", symbol);
			DecimalFormat df = new DecimalFormat("######0.00");
			Double value = 0.0;
			Double valueO = 0.0;
			if(view.getBid1price()!=null && view.getClose()!=null){
				if( view.getBid1price()!=0){
					value = view.getClose() / view.getBid1price();
				}
				valueO = view.getClose() - view.getBid1price();
			}
			request.setAttribute("value", df.format(value));
			request.setAttribute("valueO", df.format(valueO));
			request.setAttribute("view", view);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return KLINE_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "comment")
	public String comment() {
		try {
			SessionUser user = getMobileUser();
			if(user != null){
				request.setAttribute("userId", user.getId());
			}
			String type = request.getParameter("type");
			if(StringUtils.isNotBlank(type)){
				request.setAttribute("type", type);
			}
			String topicId = request.getParameter("topicId");
			BbsTopicView topic = new BbsTopicView();
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			if(StringUtils.isNotBlank(topicId)){
				topic = zhanglmServiceManage.bbsTopicService.findViewById(topicId);
				if(StringUtils.isBlank(topic.getUserPhoto())){
					if(defaultImg != null){
						topic.setUserPhoto(defaultImg.getImgUrl());
					}
				}
				request.setAttribute("topic", topic);
				BbsPraiseSearch search = new BbsPraiseSearch();
				search.setEqualTopicId(topicId);
				List<BbsPraiseView> viewList = zhanglmServiceManage.bbsPraiseService.viewList(search);
				for(BbsPraiseView view : viewList){
					if(StringUtils.isBlank(view.getUserPhoto())){
						if(defaultImg != null){
							view.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				request.setAttribute("praiseList", viewList);
				BbsReplySearch replySearch = new BbsReplySearch();
				replySearch.setEqualTopicId(topicId);
				List<BbsReplyView> replyList = zhanglmServiceManage.bbsReplyService.viewList(replySearch);
				for(BbsReplyView reply : replyList){
					if(StringUtils.isBlank(reply.getUserPhoto())){
						if(defaultImg != null){
							reply.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				request.setAttribute("replyList", replyList);
				List<CommentReplyView>  commentList = zhanglmServiceManage.commentReplyService.findAllView();
				request.setAttribute("commentList", commentList);
			}
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return COMMENT_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		try {
			String browser = request.getParameter("browser");
			if(StringUtils.isNotBlank(browser)){
				request.setAttribute("browser", browser);
			}
			BbsFanSearch fansSearch = new BbsFanSearch();
			SessionUser user = getMobileUser();
			MemberModel member = null;
			if(null != user){
				fansSearch.setEqualUserId(user.getId());
				member = zhanglmServiceManage.memberService.findById(user.getId());
				request.setAttribute("userId", user.getId());
				List<BbsFanModel> list = zhanglmServiceManage.bbsFanService.list(fansSearch);
				BbsMenuSearch myMenuSearch = new BbsMenuSearch();
				myMenuSearch.setEqualIsDisable(false);
				int x = list.size();
				if(x> 0){
					String[] inId = new String[x];
					for(int i=0;i<x;i++){
						inId[i] = list.get(i).getMenuId();
					}
					myMenuSearch.setInId(inId);
					List<BbsMenuView> myList = zhanglmServiceManage.bbsMenuService.viewMenu(myMenuSearch,member);
					request.setAttribute("myList", myList);
				}
			}
			List<BbsMenuView> menuList = new ArrayList<BbsMenuView>();
			BbsMenuSearch search = new BbsMenuSearch();
			search.setEqualIsDisable(false);
			List<BbsMenuView> viewList = zhanglmServiceManage.bbsMenuService.viewList(search);
			for(BbsMenuView menu : viewList){
				if(StringUtils.isBlank(menu.getPid())){
					search.setEqualPid(menu.getId());
					Long count = zhanglmServiceManage.bbsMenuService.count(search);
					menu.setBroadNum(count);
					menuList.add(menu);
				}
			}
			request.setAttribute("menuList", menuList);
			search.setEqualPid(null);
			search.setEqualIsLock(true);
			List<BbsMenuView> boardMenuList  = zhanglmServiceManage.bbsMenuService.viewMenu(search,member);
			request.setAttribute("boardMenuList", boardMenuList);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "board")
	public String board() {
		try {
			String menuCode = request.getParameter("code");
			String type = request.getParameter("type");
			if(StringUtils.isNotBlank(type)){
				request.setAttribute("type", type);
			}
			SessionUser user = getMobileUser();
			MemberModel member = null;
			if(user != null){
				request.setAttribute("userId", user.getId());
				member = zhanglmServiceManage.memberService.findById(user.getId());
			}
			BbsMenuView view = zhanglmServiceManage.bbsMenuService.viewMenuByCode(menuCode, member);
			request.setAttribute("view", view);
			BbsFanSearch fanSearch = new BbsFanSearch();
			fanSearch.setEqualMenuId(view.getId());
			fanSearch.setSort("average");
			fanSearch.setOrder(BaseSearch.Order_Type_Desc);
			fanSearch.setRows(6);
			List<BbsFanView> fansList = zhanglmServiceManage.bbsFanService.viewList(fanSearch);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(new DefaultSearch());
			if(defaultImg != null){
				for( BbsFanView fan : fansList){
					if(StringUtils.isBlank(fan.getUserPhoto())){
						fan.setUserPhoto(defaultImg.getImgUrl());
					}
				}
			}
			request.setAttribute("fansNum", fansList.size());
			request.setAttribute("fansList", fansList);
			BbsTopicSearch search = new BbsTopicSearch();
			search.setEqualMenuCode(menuCode);
			search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			search.setSort("average");
			search.setOrder(BaseSearch.Order_Type_Desc);
			BbsTopicView hotView = zhanglmServiceManage.bbsTopicService.viewFirstTopic(search,user);
			request.setAttribute("hotView", hotView);
			search.setSort("auditTime");
			List<BbsTopicView> topicList = zhanglmServiceManage.bbsTopicService.viewListTopic(search, user);
			request.setAttribute("topicList", topicList);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return BOARD_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "menu")
	public String menu(BbsMenuSearch search ) {
		try {
			String code = request.getParameter("code");
			search.setEqualIsDisable(false);
			search.setEqualPid(code);
			SessionUser user = getMobileUser();
			MemberModel member = null;
			if(user != null){
				request.setAttribute("userId", user.getId());
				member = zhanglmServiceManage.memberService.findById(user.getId());
			}
			List<BbsMenuView> boardMenuList = zhanglmServiceManage.bbsMenuService.viewMenu(search,member);
			BbsMenuView menu = zhanglmServiceManage.bbsMenuService.findViewById(code);
			request.setAttribute("menu", menu);
			request.setAttribute("boardMenuList", boardMenuList);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return MENU_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "downApp")
	public String downApp() {
		try {
			Map<String,Object> map = new HashMap<String, Object>();
			SessionUser user = getMobileUser();
			if(user != null){
				request.setAttribute("userId", user.getId());
			}
			String topicId = request.getParameter("topicId");
			BbsTopicView topic = new BbsTopicView();
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			if(null != topicId){
				topic = zhanglmServiceManage.bbsTopicService.findViewById(topicId);
				if(StringUtils.isBlank(topic.getUserPhoto())){
					if(defaultImg != null){
						topic.setUserPhoto(defaultImg.getImgUrl());
					}
				}
			}
			request.setAttribute("topic", topic);
			DownloadSearch downSearch = new DownloadSearch(); 
			downSearch.setOrder(BaseSearch.Order_Type_Desc);
			downSearch.setEqualIsDisable(false);
			downSearch.setEqualType("0");
			DownloadModel  rest = zhanglmServiceManage.downloadService.first(downSearch);
			if(rest!=null){
				map.put("rest", rest.getUrl());
			}
			downSearch.setEqualType("1");
			DownloadModel  ios = zhanglmServiceManage.downloadService.first(downSearch);
			if(ios != null){
				map.put("ios", ios.getUrl());
			}
			downSearch.setEqualType("2");
			DownloadModel  android = zhanglmServiceManage.downloadService.first(downSearch);
			if(android != null){
				map.put("android", android.getUrl());
			}
			request.setAttribute("map", map);
			SharePageSearch pageSearch =new SharePageSearch();
			pageSearch.setEqualIsDisable(false);
			pageSearch.setOrder(BaseSearch.Order_Type_Desc);
			SharePageView pageView = zhanglmServiceManage.sharePageService.firstView(pageSearch);
			request.setAttribute("pageView", pageView);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return down_App_PAGE;
	}
}
