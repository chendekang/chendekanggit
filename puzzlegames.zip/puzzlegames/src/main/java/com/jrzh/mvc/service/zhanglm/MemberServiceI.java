package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.zhanglm.MemberAttentionModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.search.zhanglm.MemberSearch;
import com.jrzh.mvc.view.zhanglm.MemberView;

public interface MemberServiceI  extends BaseServiceI<MemberModel, MemberSearch, MemberView>{

	MemberView ViewDataById(String id, String userId)throws ProjectException;

	List<MemberView> ViewDataList(List<MemberAttentionModel> attentionlist,SessionUser user) throws ProjectException;

	List<MemberView> ViewFansDataList(List<MemberAttentionModel> attentionlist,SessionUser user) throws ProjectException;

}