package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import com.jrzh.common.utils.DateUtil;
import com.jrzh.framework.base.search.BaseSearch;

public class HistorysTransactioSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String equalSymbol;
	
	private String geStartTime;
	
	private String leEndTime;
		
	public String getEqualSymbol() {
		return equalSymbol;
	}

	public void setEqualSymbol(String equalSymbol) {
		this.equalSymbol = equalSymbol;
	}

	public String getGeStartTime() {
		return geStartTime;
	}

	public void setGeStartTime(String geStartTime) {
		this.geStartTime = geStartTime;
	}

	public String getLeEndTime() {
		return leEndTime;
	}

	public void setLeEndTime(String leEndTime) {
		this.leEndTime = leEndTime;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalSymbol)){
			dc.add(Restrictions.eq("instid", equalSymbol));
		}
		if(StringUtils.isNotBlank(geStartTime)){
			dc.add(Restrictions.ge("datetime", DateUtil.format(geStartTime,"yyyy-MM-dd HH:mm:ss")));
		}
		if(StringUtils.isNotBlank(leEndTime)){
			dc.add(Restrictions.le("datetime", DateUtil.format(leEndTime,"yyyy-MM-dd HH:mm:ss")));
		}
	}

}