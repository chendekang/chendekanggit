package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.CommentReplyDaoI;
import com.jrzh.mvc.model.zhanglm.CommentReplyModel;

@Repository("commentReplyDao")
public class CommentReplyDaoImpl extends BaseDaoImpl<CommentReplyModel> implements CommentReplyDaoI{

}