package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.NumberstatisticsModel;
import com.jrzh.mvc.view.zhanglm.NumberstatisticsView;
public class NumberstatisticsConvert implements BaseConvertI<NumberstatisticsModel, NumberstatisticsView> {

	@Override
	public NumberstatisticsModel addConvert(NumberstatisticsView view) throws ProjectException {
		NumberstatisticsModel model = new NumberstatisticsModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public NumberstatisticsModel editConvert(NumberstatisticsView view, NumberstatisticsModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public NumberstatisticsView convertToView(NumberstatisticsModel model) throws ProjectException {
		NumberstatisticsView view = new NumberstatisticsView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
