package com.jrzh.mvc.model.zhanglm;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name = "zlm_appointment_account")
public class AppointmentaccountModel{
	@Id
	  @Column(name="_id")
	  @GenericGenerator(name="system-uuid", strategy="uuid")
	  @GeneratedValue(generator="system-uuid")
	  private String id;
    /**
     * 手机号码
     */
    @Column(name = "_mobile")
    private String mobile;
    
    /**
     * 姓名
     */
    @Column(name = "_name")
    private String name;
    /**
     * 状态
     */
    @Column(name = "_status")
    private Integer status;
    
    /**
     * 创建时间
     */
    @Column(name = "_create_time")
    private Date createtime;



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
    
    
    
}
