package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_server_question")
public class ServerQuestionModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 问题
     */
    @Column(name = "_question")
    private String question;
    /**
     * 答案
     */
    @Column(name = "_answer")
    private String answer;
    /**
     * 创建人
     */
    @Column(name = "_user_name")
    private String userName;

    public void setQuestion(String question) {
        this.question = question;
    }
    
    public String getQuestion() {
        return this.question;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }
    
    public String getAnswer() {
        return this.answer;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String getUserName() {
        return this.userName;
    }

}