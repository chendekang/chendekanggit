package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.TitleReleaseDaoI;
import com.jrzh.mvc.model.zhanglm.TitleReleaseModel;

@Repository("TitleReleaseDaoI")
public class TitleReleaseDaoImpl extends BaseDaoImpl<TitleReleaseModel> implements TitleReleaseDaoI{

}