package com.jrzh.mvc.dao.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.mvc.model.zhanglm.BankMessageModel;
import com.jrzh.mvc.search.zhanglm.BankMessageSearch;

public interface BankMessageDaoI {
	String save(BankMessageModel model)throws ProjectException;

	Long countBySearch(BankMessageSearch search);

	List<BankMessageModel> findListBySearch(BankMessageSearch search);
}
