package com.jrzh.mvc.constants;

import java.util.HashMap;
import java.util.Map;

import com.jrzh.mvc.model.sys.ConfigModel;

public class StaticParams {
	
	/**
	 * 系统配置缓存
	 */
	public static Map<String, ConfigModel> configMap = new HashMap<String, ConfigModel>();
	
	public static Map<String, String> configKeyValue = new HashMap<String, String>();
	
	
	public static final String EMAIL_SERVER_PORT = "25";
	
}
