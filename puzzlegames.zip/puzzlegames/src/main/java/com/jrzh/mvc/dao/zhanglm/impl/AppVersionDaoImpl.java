package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.AppVersionDaoI;
import com.jrzh.mvc.model.zhanglm.AppVersionModel;

@Repository("appVersionDao")
public class AppVersionDaoImpl extends BaseDaoImpl<AppVersionModel> implements AppVersionDaoI{

}