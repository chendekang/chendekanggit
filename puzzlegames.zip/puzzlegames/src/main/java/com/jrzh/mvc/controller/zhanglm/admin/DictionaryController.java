package com.jrzh.mvc.controller.zhanglm.admin;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.DictionaryConvert;
import com.jrzh.mvc.model.zhanglm.AnswerModel;
import com.jrzh.mvc.model.zhanglm.DictionaryModel;
import com.jrzh.mvc.model.zhanglm.TitleReleaseModel;
import com.jrzh.mvc.search.zhanglm.AnswerSearch;
import com.jrzh.mvc.search.zhanglm.DictionarySearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.DictionaryView;
@Controller(DictionaryController.LOCATION +"/DictionaryController")
@RequestMapping(DictionaryController.LOCATION)
public class DictionaryController extends BaseAdminController{
public static final String LOCATION = "zhanglm/admin/dictionary";
	public static final String INDEX_PAGE = LOCATION + "/index";
	public static final String FORM_PAGE = LOCATION + "/form";
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}

	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "字典列表查询")
	@ResponseBody
	public EasyuiDataGrid<DictionaryView> datagrid(DictionarySearch search) {
		EasyuiDataGrid<DictionaryView> dg = new EasyuiDataGrid<DictionaryView>();
	    try{
				
	    	dg = zhanglmServiceManage.dictionaryservicei.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}


	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd(DictionarySearch search) {
		try {

			request.setAttribute("view", new DictionaryView());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}

	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "字典增加")
	@ResponseBody
	public ResultBean add(DictionaryView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			DictionaryModel model =new DictionaryConvert().addConvert(view);
			zhanglmServiceManage.dictionaryservicei.add(model,getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}
	
	
	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id,DictionarySearch search) {
		try {

			DictionaryView view = zhanglmServiceManage.dictionaryservicei.findViewById(id);
			request.setAttribute("view", view);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "字典修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, DictionaryView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {

			DictionaryModel model = zhanglmServiceManage.dictionaryservicei.findById(id);
			/**
		     * 字典内容
		     */
			model.setName(view.getName());
		    /**
		     * 字典内容
		     */
			model.setContent(view.getContent());
	
		    /**
		     * 字典描述
		     */
			model.setDescribe(view.getDescribe());
			model.setLogo(view.getLogo());

			zhanglmServiceManage.dictionaryservicei.edit(model,getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "题目删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		AnswerSearch search = new AnswerSearch();
		try {
			TitleReleaseModel model = zhanglmServiceManage.titlereleaseservicei.findById(id);
			zhanglmServiceManage.titlereleaseservicei.delete(model, getSessionUser());
			//关联删除答案
			search.setEqualPid(id);//题目id
			List<AnswerModel> viewList = zhanglmServiceManage.answerservicei.viewListall(search);
			zhanglmServiceManage.answerservicei.deletecourse(viewList);
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}

	@Override
	protected void setData() {
		// TODO Auto-generated method stub
		
	}
	
}
