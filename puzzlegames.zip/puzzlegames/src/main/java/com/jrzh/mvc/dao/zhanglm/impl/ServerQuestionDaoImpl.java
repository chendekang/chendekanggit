package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.ServerQuestionDaoI;
import com.jrzh.mvc.model.zhanglm.ServerQuestionModel;

@Repository("serverQuestionDao")
public class ServerQuestionDaoImpl extends BaseDaoImpl<ServerQuestionModel> implements ServerQuestionDaoI{

}