package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.DotitleModel;
import com.jrzh.mvc.view.zhanglm.DotitleView;
public class DotitleConvert implements BaseConvertI<DotitleModel, DotitleView> {

	@Override
	public DotitleModel addConvert(DotitleView view) throws ProjectException {
		DotitleModel model = new DotitleModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public DotitleModel editConvert(DotitleView view, DotitleModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public DotitleView convertToView(DotitleModel model) throws ProjectException {
		DotitleView view = new DotitleView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
