package com.jrzh.mvc.search.zhanglm;

import org.hibernate.criterion.DetachedCriteria;

import com.jrzh.framework.base.search.BaseSearch;

public class MemberUserSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	@Override
	public void setDc(DetachedCriteria dc) {
	
	}

}