package com.jrzh.mvc.service.zhanglm;
import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.mvc.model.zhanglm.CorrectAnswerModel;
import com.jrzh.mvc.search.zhanglm.CorrectAnswerSearch;
import com.jrzh.mvc.view.zhanglm.CorrectAnswerView;
public interface CorrectAnswerServiceI{
	List<CorrectAnswerModel> viewListall(CorrectAnswerSearch search)throws ProjectException;
	void add(CorrectAnswerModel views)throws ProjectException;
	List<CorrectAnswerView> viewListallzb(CorrectAnswerSearch zhibocoursesearch);
	void deletecourse(List<CorrectAnswerModel> viewList) throws ProjectException;
	void edit(CorrectAnswerModel model) throws ProjectException;
	List<CorrectAnswerView> viewList(CorrectAnswerSearch answwer) throws ProjectException;
	CorrectAnswerModel findById(String id);


}            