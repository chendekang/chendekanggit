package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.sys.UserConvert;
import com.jrzh.mvc.convert.zhanglm.MemberConvert;
import com.jrzh.mvc.model.sys.RoleModel;
import com.jrzh.mvc.model.sys.UserModel;
import com.jrzh.mvc.model.zhanglm.GoldbinduseruserModel;
import com.jrzh.mvc.model.zhanglm.MemberLogStatisticsModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.MemberUserModel;
import com.jrzh.mvc.search.sys.RoleSearch;
import com.jrzh.mvc.search.zhanglm.MemberLogStatisticsSearch;
import com.jrzh.mvc.search.zhanglm.MemberSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.sys.UserView;
import com.jrzh.mvc.view.zhanglm.MemberLogStatisticsView;
import com.jrzh.mvc.view.zhanglm.MemberView;

@Controller(MemberController.LOCATION +"/MemberController")
@RequestMapping(MemberController.LOCATION)
public class MemberController extends BaseAdminController{
	public static final String LOCATION = "memberManage/admin/member";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String DIVIDE_FORM_PAGE = LOCATION + "/divideForm";
	
	public static final String MODULE = "zhanglm_member";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "Member列表查询")
	@ResponseBody
	public EasyuiDataGrid<MemberView> datagrid(MemberSearch search) {
		EasyuiDataGrid<MemberView> dg = new EasyuiDataGrid<MemberView>();
	    try{
	    	dg = zhanglmServiceManage.memberService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new MemberView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "Member增加")
	@ResponseBody
	public ResultBean add(MemberView view,BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		if(errors.hasErrors()){
			for(ObjectError objectError : errors.getAllErrors()){
				message = this.getMessage(objectError.getCode(),objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if(this.log.isDebugEnabled()){
			this.log.debug("doAdd() View:"+ view.toString());
		}
		try{
			MemberModel model =new MemberConvert().addConvert(view);
			message = zhanglmServiceManage.memberService.validate(model);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.memberService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.memberService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return DIVIDE_FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "Member修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, UserView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(), objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if (this.log.isDebugEnabled()) {
			this.log.debug("doEdit() View:" + view.toString());
		}
		try {
			MemberModel member = zhanglmServiceManage.memberService.findById(id);
			String name = member.getNickName();
			if(StringUtils.isBlank(name)){
				result.setMsg("用户昵称未设置，请先完善用户信息");
				return result;
			}
			UserModel model = new UserConvert().addConvert(view);
			if(null != view.getRoleIds() && view.getRoleIds().length > 0){
				RoleSearch roleSearch = new RoleSearch();
				roleSearch.setInIds(view.getRoleIds());
				model.setRoles(sysServiceManage.roleService.list(roleSearch));
			}
			model.setSex(1);
			model.setCode(view.getTel());
			model.setName(name);
			message = sysServiceManage.userService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			sysServiceManage.userService.add(model, getSessionUser());
			//添加用户关联信息
			MemberUserModel memberUser = new MemberUserModel();
			memberUser.setUserId(model.getId());
			memberUser.setMemberId(id);
			zhanglmServiceManage.memberUserService.add(memberUser, getSessionUser());
			//设置开启
			List<RoleModel> role = model.getRoles();
			String tag = role.get(0).getCode();
			member.setIsDisable(true);
			zhanglmServiceManage.memberService.edit(member, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "Member删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id, MemberView view,
	BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(),
						objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if (this.log.isDebugEnabled()) {
			this.log.debug("doDelete() View:" + view.toString());
		}
		try {
			MemberModel model = zhanglmServiceManage.memberService.findById(id);
			zhanglmServiceManage.memberService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

	
	//绑定登录用户
	@RequestMapping(method = RequestMethod.POST, value = "binduser/{id}")
	@MemberEvent(desc = "安卓/IOS绑定登录用户")
	@ResponseBody
	public ResultBean binduser(@PathVariable("id") String id,MemberLogStatisticsView view) {
		ResultBean result = new ResultBean();
		GoldbinduseruserModel binduseruser = new GoldbinduseruserModel();
		MemberLogStatisticsSearch  search = new MemberLogStatisticsSearch();
		try {
			search.setIds(id);
			MemberLogStatisticsModel md =zhanglmServiceManage.memberlogstatisticsservicei.findBySearch(search);
			MemberModel mebel =	zhanglmServiceManage.memberService.findByField("mobile", md.getMobile_phone());
			if(StringUtils.isNotBlank(mebel.getMobile())){
				binduseruser.setBinduseruserid(id);
				binduseruser.setMembersid(mebel.getId());
				String binduser = zhanglmServiceManage.memberlogstatisticsservicei.addbinduser(binduseruser);
				if(null !=binduser){
					md.setIsDisable(true);
					zhanglmServiceManage.memberlogstatisticsservicei.update(md);
					result.setStatus(ResultBean.SUCCESS);
					result.setMsg("绑定成功");
				}
			}else{
				result.setMsg("客户未注册平台用户");
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	// 取消绑定登录用户
	@RequestMapping(method = RequestMethod.POST, value = "cancelbinduser/{id}")
	@MemberEvent(desc = "安卓/IOS取消绑定登录用户")
	@ResponseBody
	public ResultBean cancelbinduser(@PathVariable("id") String id, MemberLogStatisticsView view) {
		ResultBean result = new ResultBean();
		MemberLogStatisticsSearch search = new MemberLogStatisticsSearch();
		search.setIds(id);
		String sql="DELETE FROM zlm_gold_binduser_user";
		try {
			Integer dl = zhanglmServiceManage.memberlogstatisticsservicei.delete(sql,id);
			if(null != dl){
				MemberLogStatisticsModel md = zhanglmServiceManage.memberlogstatisticsservicei.findBySearch(search);
				if (null != md) {
					md.setIsDisable(false);
					zhanglmServiceManage.memberlogstatisticsservicei.update(md);
					result.setStatus(ResultBean.SUCCESS);
					result.setMsg("删除绑定成功");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
}
