package com.jrzh.mvc.dao.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.mvc.model.zhanglm.TodayDealModel;
import com.jrzh.mvc.search.zhanglm.TodayDealSearch;

public interface TodayDealDaoI {
	String save(TodayDealModel model)throws ProjectException;

	Long countBySearch(TodayDealSearch search);

	List<TodayDealModel> findListBySearch(TodayDealSearch search);
}
