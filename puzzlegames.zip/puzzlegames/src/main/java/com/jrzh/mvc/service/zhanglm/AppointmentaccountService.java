package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.zhanglm.AppointmentaccountModel;
import com.jrzh.mvc.search.zhanglm.AppointmentaccountSearch;
import com.jrzh.mvc.view.zhanglm.AppointmentaccountView;

public interface AppointmentaccountService {

	void addall(AppointmentaccountModel model);

	AppointmentaccountModel findByField(String string, String mobile);

	EasyuiDataGrid<AppointmentaccountView> datagrid(AppointmentaccountSearch search);

	void deleteopenaccolog(AppointmentaccountModel model, SessionUser sessionUser);

}
