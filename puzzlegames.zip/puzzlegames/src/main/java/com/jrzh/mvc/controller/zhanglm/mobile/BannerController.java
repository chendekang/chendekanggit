package com.jrzh.mvc.controller.zhanglm.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.mvc.search.zhanglm.ActivityPictureSearch;
import com.jrzh.mvc.search.zhanglm.BannerSearch;
import com.jrzh.mvc.search.zhanglm.PlazaAdSearch;
import com.jrzh.mvc.search.zhanglm.TabbarSearch;
import com.jrzh.mvc.view.zhanglm.ActivityPictureView;
import com.jrzh.mvc.view.zhanglm.BannerView;
import com.jrzh.mvc.view.zhanglm.PlazaAdView;
import com.jrzh.mvc.view.zhanglm.TabbarView;


@Controller(BannerController.LOCATION + "BannerController")
@RequestMapping(BannerController.LOCATION)
public class BannerController extends BaseMobileController {
	public static final String LOCATION = "/mobile/banner/";

	@RequestMapping(method = RequestMethod.POST, value = "activityPicture")
	@MemberEvent(desc = "安卓/IOS 获取首页活动图片")
	@ResponseBody
	public MobileResultBean activityPicture(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "activityPicture");
		try {
			ActivityPictureSearch search = new ActivityPictureSearch();
			search.setEqualDisable(false);
			ActivityPictureView activityView = zhanglmServiceManage.activityPictureService.firstView(search);
			map.put("activityAdList", activityView);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "plazaAds")
	@MemberEvent(desc = "安卓/IOS 广场广告图")
	@ResponseBody
	public MobileResultBean plazaAd(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<PlazaAdView> plazaAdList = new ArrayList<PlazaAdView>();
		String message = "";
		map.put("method", "plazaAds");
		try {
			PlazaAdSearch plazaAdSearch=new PlazaAdSearch();
			//将禁用的状态
			plazaAdSearch.setEqualIsDisable(false);
			plazaAdList = zhanglmServiceManage.plazaAdService.viewList(plazaAdSearch);
			map.put("plazaAdList", plazaAdList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "banners")
	@MemberEvent(desc = "安卓/IOS广告图")
	@ResponseBody
	public MobileResultBean banner(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BannerView> bannerList = new ArrayList<BannerView>();
		String message = "";
		map.put("method", "banners");
		try {
			BannerSearch bannerSearch=new BannerSearch();
			bannerSearch.setRows(8);
			bannerList = zhanglmServiceManage.bannerService.viewList(bannerSearch);
			map.put("bannerList", bannerList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "tabBars")
	@MemberEvent(desc = "安卓/IOS TabBar图片与文字")
	@ResponseBody
	public MobileResultBean tabBars(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<TabbarView> tabBarList = new ArrayList<TabbarView>();
		String message = "";
		map.put("method", "tabBars");
		try {
			TabbarSearch search = new TabbarSearch();
			search.setSort("sortNum");
			search.setEqualIsDisable(false);
			tabBarList = zhanglmServiceManage.tabbarService.viewList(search);
			Integer version = tabBarList.get(0).getTabVersion();
			map.put("tabBarVersion", version);
			map.put("tabBarList", tabBarList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
}
