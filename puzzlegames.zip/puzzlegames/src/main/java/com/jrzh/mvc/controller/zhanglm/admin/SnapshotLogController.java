package com.jrzh.mvc.controller.zhanglm.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.SnapshotLogConvert;
import com.jrzh.mvc.model.zhanglm.SnapshotLogModel;
import com.jrzh.mvc.search.zhanglm.SnapshotLogSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.SnapshotLogView;

@Controller(SnapshotLogController.LOCATION +"/SnapshotLogController")
@RequestMapping(SnapshotLogController.LOCATION)
public class SnapshotLogController extends BaseAdminController{
	public static final String LOCATION = "productManage/admin/snapshotLog";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_snapshotLog";
	
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "SnapshotLog列表查询")
	@ResponseBody
	public EasyuiDataGrid<SnapshotLogView> datagrid(SnapshotLogSearch search) {
		EasyuiDataGrid<SnapshotLogView> dg = new EasyuiDataGrid<SnapshotLogView>();
	    try{
	    	dg = zhanglmServiceManage.snapshotLogService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new SnapshotLogView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "SnapshotLog增加")
	@ResponseBody
	public ResultBean add(SnapshotLogView view,BindingResult errors){
		ResultBean result = new ResultBean();
		//String message = "";
		try{
			SnapshotLogModel model =new SnapshotLogConvert().addConvert(view);
			zhanglmServiceManage.snapshotLogService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.snapshotLogService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "SnapshotLog修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, SnapshotLogView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		//String message = null;
		try {
			SnapshotLogModel model = zhanglmServiceManage.snapshotLogService.findById(id);
			model = new SnapshotLogConvert().editConvert(view, model);
			zhanglmServiceManage.snapshotLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "SnapshotLog删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id,BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			SnapshotLogModel model = zhanglmServiceManage.snapshotLogService.findById(id);
			zhanglmServiceManage.snapshotLogService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "SnapshotLog禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id,BindingResult errors){
		ResultBean result = new ResultBean();
		try {
			SnapshotLogModel model = zhanglmServiceManage.snapshotLogService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.snapshotLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}
	

}
