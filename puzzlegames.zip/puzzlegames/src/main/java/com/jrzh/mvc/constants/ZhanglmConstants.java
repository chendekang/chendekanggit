package com.jrzh.mvc.constants;

public interface ZhanglmConstants {
	public static final String ENCRYPTION_KEY = "GDgLwwdK270Qj1w4";

	public abstract class ENV_PARAM{
		/**
		 * 开发
		 */
		public static String DEV = "dev";
		/**
		 * 类生产（测试）环境
		 */
		public static String STATING = "stating";
		/**
		 * 生产环境
		 */
		public static String PROD = "prod";
	}
}
