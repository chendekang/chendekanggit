package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.ZhiboLiveConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.MemberUserModel;
import com.jrzh.mvc.model.zhanglm.PlazaDataModel;
import com.jrzh.mvc.model.zhanglm.ZhiboCourseModel;
import com.jrzh.mvc.model.zhanglm.ZhiboLiveModel;
import com.jrzh.mvc.search.zhanglm.SpecialColumnSearch;
import com.jrzh.mvc.search.zhanglm.ZhiboCourseSearch;
import com.jrzh.mvc.search.zhanglm.ZhiboLiveSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.DboLiveView;
import com.jrzh.mvc.view.zhanglm.SpecialColumnView;
import com.jrzh.mvc.view.zhanglm.ZhiboCourseView;
import com.jrzh.mvc.view.zhanglm.ZhiboLiveView;
import com.jrzh.tools.TestMain;

@Controller(ZhiboLiveController.LOCATION +"/ZhiboLiveController")
@RequestMapping(ZhiboLiveController.LOCATION)
public class ZhiboLiveController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/zhibo/zhiboLive";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String INDEX_ALL_PAGE = LOCATION + "/indexAll";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	public static final String LIVE_DIRECTORY= LOCATION + "/Livedirectory";
	//修改直播目录
	public static final String EDIT_LIVE_DIRECTORY= LOCATION + "/editLivedirectory";
	public static final String EDITOR_PAGE = LOCATION + "/editor";
	public static final String MODULE = "zhanglm_zhiboLive";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		try {
			List<SpecialColumnView> columnModel = zhanglmServiceManage.specialColumnService.findAllView();
			request.setAttribute("columnModel", columnModel);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "indexAll")
	public String indexAll() {
		try {
			List<SpecialColumnView> columnModel = zhanglmServiceManage.specialColumnService.findAllView();
			request.setAttribute("columnModel", columnModel);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return INDEX_ALL_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "ZhiboLive列表查询")
	@ResponseBody
	public EasyuiDataGrid<ZhiboLiveView> datagrid(ZhiboLiveSearch search) {
		EasyuiDataGrid<ZhiboLiveView> dg = new EasyuiDataGrid<ZhiboLiveView>();
	    try{
	    	MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
	    	if(memberUser != null){
	    		search.setEqualUserId(memberUser.getMemberId());
	    	}
	    	dg = zhanglmServiceManage.zhiboLiveService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "allDatagrid")
	@UserEvent(desc = "ZhiboLive列表查询")
	@ResponseBody
	public EasyuiDataGrid<ZhiboLiveView> allDatagrid(ZhiboLiveSearch search) {
		EasyuiDataGrid<ZhiboLiveView> dg = new EasyuiDataGrid<ZhiboLiveView>();
	    try{
	    	dg = zhanglmServiceManage.zhiboLiveService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd(SpecialColumnSearch search) {
		//获取专栏分类类别
		try {
			List<SpecialColumnView> viewList = zhanglmServiceManage.specialColumnService.viewList(search);
			List<String> listst = TestMain.sendSms();
			request.setAttribute("zbld",listst.get(0));
			request.setAttribute("zbsd",listst.get(1));
			request.setAttribute("zbhd",listst.get(2));
			request.setAttribute("zbud",listst.get(3));
			request.setAttribute("viewList",viewList);
			request.setAttribute("view", new ZhiboLiveView());
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "ZhiboLive增加")
	@ResponseBody
	public ResultBean add(ZhiboLiveView view,DboLiveView dbview){
		ResultBean result = new ResultBean();
		try{
			String imgName = request.getParameter("fileName");
			String imgUrl = request.getParameter("fileUrl");
			String imgType = request.getParameter("fileType");
			String zbld = request.getParameter("zbsd");//流畅
			String zbsd = request.getParameter("zbsd");//标准
			String zbhd = request.getParameter("zbhd");//高清
			String zbud = request.getParameter("zbud");//超高清
			String codes=request.getParameter("codes");
			ZhiboLiveModel model =new ZhiboLiveConvert().addConvert(view);
			if("0001".equals(codes)){
				if(StringUtils.isBlank(imgUrl)){
					result.setMsg("图片不能为空");
					return result;
				}
				if(StringUtils.isBlank(codes)){
					result.setMsg("专栏不能为空");
					return result;
				}
				if(StringUtils.isBlank(imgName)){
					result.setMsg("标题不能为空");
					return result;
				}
				if(StringUtils.isBlank(zbld)){
					result.setMsg("流畅不能为空");
					return result;
				}
				if(StringUtils.isBlank(zbsd)){
					result.setMsg("标准不能为空");
					return result;
				}
				if(StringUtils.isBlank(zbhd)){
					result.setMsg("高清不能为空");
					return result;
				}
				if(StringUtils.isBlank(zbud)){
					result.setMsg("超高清不能为空");
					return result;
				}
			} else {
				result.setMsg("请选择直播");
				return result;
			}
		
			//List<ZhiboLiveModel> zhiboModel=zhanglmServiceManage.zhiboLiveService.findAll();
			//生成随机整数1024~65535
			/*String ports=String.valueOf((int)(1024+Math.random()*64511));
			for(ZhiboLiveModel portModel : zhiboModel ){
				String port=portModel.getPort();
				if(port.equals(ports)){
					ports=String.valueOf((int)(1024+Math.random()*64511));
				}
			}*/
//		    //初始化数据
//		    model.setPort(ports);
			//发布人
			MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
			if(memberUser != null){
				String memberId  = memberUser.getMemberId();
				model.setUserId(memberId);
			}else{
				result.setMsg("管理员未绑定平台用户");
				return result;
			}
			//保存图片
			FileModel file = new FileModel();
			// 直播
			file.setName(imgName);
			file.setType(imgType);
			file.setUrl(imgUrl);
			file.setModel("zhiboLive");
			model.setImgName(imgName);
			model.setImgUrl(imgUrl);
			model.setImgType(imgType);
			model.setClickNum(0L);
			model.setColumnCode(codes);
			model.setZbld(zbld);// 流畅
			model.setZbsd(zbsd);// 标
			model.setZbhd(zbhd);// 高清
			model.setZbud(zbud);// 超高清
			// model.setZhiboUrl(BusinessConstants.RTMP_LIVE + code);
			zhanglmServiceManage.zhiboLiveService.addAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}

	
	
	
	
	//直播目录跳转
	@RequestMapping(method = RequestMethod.GET,value = "addLivedirectory/{id}")
	public String addLivedirectory(@PathVariable("id") String id) {
		ZhiboCourseSearch search = new ZhiboCourseSearch();
		ZhiboCourseView view = new ZhiboCourseView();
		//获取专栏分类类别
		try {
			search.setEqualzbId(id);
			List<ZhiboCourseModel> viewList = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(search);
			if(viewList !=null && viewList.size() > 0){
				view.setStartTime1(viewList.get(0).getStartTime());
				view.setEndTime1(viewList.get(0).getEndTime());
				view.setTitle1(viewList.get(0).getTitle());
				view.setLecturer1(viewList.get(0).getLecturer());
				
				view.setStartTime2(viewList.get(1).getStartTime());
				view.setEndTime2(viewList.get(1).getEndTime());
				view.setTitle2(viewList.get(1).getTitle());
				view.setLecturer2(viewList.get(1).getLecturer());
				
				view.setStartTime3(viewList.get(2).getStartTime());
				view.setEndTime3(viewList.get(2).getEndTime());
				view.setTitle3(viewList.get(2).getTitle());
				view.setLecturer3(viewList.get(2).getLecturer());			
			}	
			request.setAttribute("view", view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return LIVE_DIRECTORY;
	}
	//添加直播目录
	@RequestMapping(method = RequestMethod.POST,value = "addLivedirectory/{id}")
	@UserEvent(desc = "ZhiboLive增加")
	@ResponseBody
	public ResultBean addLivedirectory(@PathVariable("id") String zbId,ZhiboCourseView view){
		ResultBean result = new ResultBean();
		try{
			List<ZhiboCourseModel> zhibocoursemodelall = new ArrayList<ZhiboCourseModel>();
			ZhiboCourseModel model1 = new ZhiboCourseModel();
			model1.setZbId(zbId);
			model1.setStartTime(view.getStartTime1());
			model1.setEndTime(view.getEndTime1());
			model1.setLecturer(view.getLecturer1());
			model1.setTitle(view.getTitle1());
			ZhiboCourseModel model2 = new ZhiboCourseModel();
			model2.setZbId(zbId);
			model2.setStartTime(view.getStartTime2());
			model2.setEndTime(view.getEndTime2());
			model2.setLecturer(view.getLecturer2());
			model2.setTitle(view.getTitle2());
			ZhiboCourseModel model3 = new ZhiboCourseModel();
			model3.setZbId(zbId);
			model3.setStartTime(view.getStartTime3());
			model3.setEndTime(view.getEndTime3());
			model3.setLecturer(view.getLecturer3());
			model3.setTitle(view.getTitle3());
			zhibocoursemodelall.add(model1);
			zhibocoursemodelall.add(model2);
			zhibocoursemodelall.add(model3);
			for(ZhiboCourseModel model :zhibocoursemodelall ){
				zhanglmServiceManage.ZhiboCourseServiceI.add(model);
			}

			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}

	// 直播目录跳转编辑
	@RequestMapping(method = RequestMethod.GET, value = "editLivedirectory/{id}")
	public String editLivedirectory(@PathVariable("id") String id) {
		ZhiboCourseSearch search = new ZhiboCourseSearch();
		ZhiboCourseView view = new ZhiboCourseView();
		// 获取专栏分类类别
		try {
			search.setEqualzbId(id);
			List<ZhiboCourseModel> viewList = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(search);
			if (viewList != null && viewList.size() > 0) {
				view.setStartTime1(viewList.get(0).getStartTime());
				view.setEndTime1(viewList.get(0).getEndTime());
				view.setTitle1(viewList.get(0).getTitle());
				view.setLecturer1(viewList.get(0).getLecturer());

				view.setStartTime2(viewList.get(1).getStartTime());
				view.setEndTime2(viewList.get(1).getEndTime());
				view.setTitle2(viewList.get(1).getTitle());
				view.setLecturer2(viewList.get(1).getLecturer());

				view.setStartTime3(viewList.get(2).getStartTime());
				view.setEndTime3(viewList.get(2).getEndTime());
				view.setTitle3(viewList.get(2).getTitle());
				view.setLecturer3(viewList.get(2).getLecturer());
			}
			request.setAttribute("view", view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return EDIT_LIVE_DIRECTORY;
	}

	// 修改直播目录
	@RequestMapping(method = RequestMethod.POST, value = "editLivedirectory/{id}")
	@UserEvent(desc = "修改直播目录编辑")
	@ResponseBody
	public ResultBean editLivedirectory(@PathVariable("id") String zbId, ZhiboCourseView view) {
		ResultBean result = new ResultBean();
		try {
			List<ZhiboCourseModel> zhibocoursemodelall = new ArrayList<ZhiboCourseModel>();
			 ZhiboCourseSearch search = new ZhiboCourseSearch(); // 删除直播关联讲师数据
			 search.setEqualzbId(zbId);
			List<ZhiboCourseModel> viewList = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(search);
			zhanglmServiceManage.ZhiboCourseServiceI.deletecourse(viewList);
			ZhiboCourseModel model1 = new ZhiboCourseModel();
			model1.setZbId(zbId);
			model1.setStartTime(view.getStartTime1());
			model1.setEndTime(view.getEndTime1());
			model1.setLecturer(view.getLecturer1());
			model1.setTitle(view.getTitle1());
			ZhiboCourseModel model2 = new ZhiboCourseModel();
			model2.setZbId(zbId);
			model2.setStartTime(view.getStartTime2());
			model2.setEndTime(view.getEndTime2());
			model2.setLecturer(view.getLecturer2());
			model2.setTitle(view.getTitle2());
			ZhiboCourseModel model3 = new ZhiboCourseModel();
			model3.setZbId(zbId);
			model3.setStartTime(view.getStartTime3());
			model3.setEndTime(view.getEndTime3());
			model3.setLecturer(view.getLecturer3());
			model3.setTitle(view.getTitle3());
			zhibocoursemodelall.add(model1);
			zhibocoursemodelall.add(model2);
			zhibocoursemodelall.add(model3);

			for (ZhiboCourseModel model : zhibocoursemodelall) {
				// 修改直播目录
				zhanglmServiceManage.ZhiboCourseServiceI.edit(model);
			}
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id,SpecialColumnSearch search) {
		try {
			List<SpecialColumnView> viewList = zhanglmServiceManage.specialColumnService.viewList(search);
			request.setAttribute("viewList",viewList);
			ZhiboLiveView view = zhanglmServiceManage.zhiboLiveService.findViewById(id);
			//String url = view.getZhiboUrl();
			//String urls[] = url.split(BusinessConstants.RTMP_LIVE);
			//view.setZhiboUrl(urls[1]);
			request.setAttribute("view", view);
			request.setAttribute("file", sysServiceManage.fileService.findViewByField("formId", id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return EDITOR_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "ZhiboLive修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, ZhiboLiveView view) {
		ResultBean result = new ResultBean();
		try {
			String imgName = request.getParameter("fileName");
			String imgUrl = request.getParameter("fileUrl");
			String imgType = request.getParameter("fileType");
			String code = request.getParameter("code");//串流码
			String codes = request.getParameter("codes");//专栏编号
			if("0001".equals(codes)){
				if(StringUtils.isBlank(imgUrl)){
					result.setMsg("图片不能为空");
					return result;
				}
				if(StringUtils.isBlank(codes)){
					result.setMsg("专栏不能为空");
					return result;
				}
				if(StringUtils.isBlank(imgName)){
					result.setMsg("标题不能为空");
					return result;
				}
			} else {
				result.setMsg("请选择直播");
				return result;
			}
		
			ZhiboLiveModel model = zhanglmServiceManage.zhiboLiveService.findById(id);
			view.setClickNum(model.getClickNum());
			model = new ZhiboLiveConvert().editConvert(view, model);
			//初始化数据
			model.setImgName(imgName);
			model.setImgUrl(imgUrl);
			model.setImgType(imgType);
			//model.setZhiboUrl(BusinessConstants.RTMP_LIVE + code);
			model.setColumnCode(codes);
			//发布人
			MemberUserModel memberUser = zhanglmServiceManage.memberUserService.findByField("userId", getSessionUser().getId());
			if(memberUser != null){
				String memberId  = memberUser.getMemberId();
				model.setUserId(memberId);
			}else{
				result.setMsg("管理员未绑定平台用户");
				return result;
			}
			//保存图片
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			file.setName(imgName);
			file.setType(imgType);
			file.setUrl(imgUrl);
			zhanglmServiceManage.zhiboLiveService.editAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "ZhiboLive删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		ZhiboCourseSearch search = new ZhiboCourseSearch();
		try {
			ZhiboLiveModel model = zhanglmServiceManage.zhiboLiveService.findById(id);
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			zhanglmServiceManage.zhiboLiveService.deleteAndFile(model, file, getSessionUser());
			//广场对应直播数据删除
			PlazaDataModel plazaData = zhanglmServiceManage.plazaDataService.findByField("dataId",id);
			if(plazaData != null){
				zhanglmServiceManage.plazaDataService.delete(plazaData, getSessionUser());
			}			
			//删除直播关联讲师数据
			search.setEqualzbId(id);//直播id
			List<ZhiboCourseModel> viewList = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(search);
			zhanglmServiceManage.ZhiboCourseServiceI.deletecourse(viewList);
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "ZhiboLive禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			ZhiboLiveModel model = zhanglmServiceManage.zhiboLiveService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.zhiboLiveService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "setRecommend/{id}")
	@UserEvent(desc = "菜单设置/取消推荐")
	@ResponseBody
	public ResultBean setRecommend(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			ZhiboLiveModel model = zhanglmServiceManage.zhiboLiveService.findById(id);
			if(null != model.getIsLock()){
				model.setIsLock(!model.getIsLock());
			}else{
				model.setIsLock(true);
			}
			zhanglmServiceManage.zhiboLiveService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
