package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.EasyuiTree;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.BbsMenuConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.search.zhanglm.BbsMenuSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;

@Controller(BbsMenuController.LOCATION +"/BbsMenuController")
@RequestMapping(BbsMenuController.LOCATION)
public class BbsMenuController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/bbs/bbsMenu";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_bbsMenu";
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "treegrid")
	@UserEvent(desc = "菜单列表查询")
	@ResponseBody
	public List<BbsMenuView> treegrid(BbsMenuSearch search){
		List<BbsMenuView> list = new ArrayList<BbsMenuView>();
		try {
			search.setOrder(BaseSearch.Order_Type_Desc);
			search.setSort("sortNum");
			list = zhanglmServiceManage.bbsMenuService.viewList(search);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/**
	 * 父资源
	 * @param search
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "tree")
	@ResponseBody
	public List<EasyuiTree> tree(BbsMenuSearch search){
		List<EasyuiTree> treeList = new ArrayList<EasyuiTree>();
		search.setOrder(BaseSearch.Order_Type_Desc);
		search.setSort("sortNum");
		search.setEqualIsDisable(false);
		try {
			List<BbsMenuModel> modelList = new ArrayList<BbsMenuModel>();
			modelList = zhanglmServiceManage.bbsMenuService.list(search);
			for (int i = 0; i < modelList.size(); i++) {
				BbsMenuModel model = modelList.get(i);
				treeList.add(new BbsMenuConvert().converToEasyuiTree(model));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return treeList;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "BbsMenu列表查询")
	@ResponseBody
	public EasyuiDataGrid<BbsMenuView> datagrid(BbsMenuSearch search) {
		EasyuiDataGrid<BbsMenuView> dg = new EasyuiDataGrid<BbsMenuView>();
	    try{
	    	dg = zhanglmServiceManage.bbsMenuService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new BbsMenuView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "BbsMenu增加")
	@ResponseBody
	public ResultBean add(BbsMenuView view,BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		if(errors.hasErrors()){
			for(ObjectError objectError : errors.getAllErrors()){
				message = this.getMessage(objectError.getCode(),objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if(this.log.isDebugEnabled()){
			this.log.debug("doAdd() View:"+ view.toString());
		}
		try{
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			BbsMenuModel model =new BbsMenuConvert().addConvert(view);
			model.setImgUrl(url);
			model.setImgType(type);
			message = zhanglmServiceManage.bbsMenuService.validate(model);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			FileModel file = new FileModel();
			file.setModel("banner");
			file.setType(type);
			file.setName(view.getName());
			file.setUrl(url);
			message = sysServiceManage.fileService.validate(file);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.bbsMenuService.addAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}

	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.bbsMenuService.findViewById(id));
			request.setAttribute("file", sysServiceManage.fileService.findByField("formId", id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "BbsMenu修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, BbsMenuView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(), objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if (this.log.isDebugEnabled()) {
			this.log.debug("doEdit() View:" + view.toString());
		}
		try {
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			BbsMenuModel model = zhanglmServiceManage.bbsMenuService.findById(id);
			model = new BbsMenuConvert().editConvert(view, model);
			model.setImgUrl(url);
			model.setImgType(type);
			message = zhanglmServiceManage.bbsMenuService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			FileModel file = sysServiceManage.fileService.findByField("formId", model.getId());
			file.setModel("banner");
			file.setType(type);
			file.setName(view.getName());
			file.setUrl(url);
			message = sysServiceManage.fileService.validate(file);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.bbsMenuService.editAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "BbsMenu删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			BbsMenuModel model = zhanglmServiceManage.bbsMenuService.findById(id);
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			zhanglmServiceManage.bbsMenuService.deleteAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "菜单禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			BbsMenuModel model = zhanglmServiceManage.bbsMenuService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.bbsMenuService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "setRecommend/{id}")
	@UserEvent(desc = "菜单设置/取消推荐")
	@ResponseBody
	public ResultBean setRecommend(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			BbsMenuModel model = zhanglmServiceManage.bbsMenuService.findById(id);
			if(null != model.getIsLock()){
				model.setIsLock(!model.getIsLock());
			}else{
				model.setIsLock(true);
			}
			zhanglmServiceManage.bbsMenuService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
