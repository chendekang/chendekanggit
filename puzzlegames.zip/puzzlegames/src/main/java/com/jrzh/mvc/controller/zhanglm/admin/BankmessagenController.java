package com.jrzh.mvc.controller.zhanglm.admin;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.mvc.search.zhanglm.BankMessageSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BankMessageView;
@Controller(BankmessagenController.LOCATION +"/BankmessagenController")
@RequestMapping(BankmessagenController.LOCATION)
public class BankmessagenController extends BaseAdminController{
public static final String LOCATION = "zhanglm/admin/memberLog";
	//银行转账
	public static final String BANK_MESSAGENIDEX = LOCATION + "/bankmessagenIdex";
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;

	//银行转账统计
	@RequestMapping(method = RequestMethod.GET,value = "bankmessagenIdex")
	public String bankmessagenIdex() {
		return BANK_MESSAGENIDEX;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "querybankmessage")
	@UserEvent(desc = "银行转账统计列表查询")
	@ResponseBody
	public EasyuiDataGrid<BankMessageView> querybankmessage(BankMessageSearch search) {
		EasyuiDataGrid<BankMessageView> dg = new EasyuiDataGrid<BankMessageView>();
	    try{
	    	dg = zhanglmServiceManage.bankmessageservicei.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	//导出银行转账
	@RequestMapping(method = RequestMethod.POST, value = "exportbankmessage")
	@UserEvent(desc = "导出银行转账")
	@ResponseBody
	public void exportbankmessage(BankMessageSearch search,HttpServletResponse response) {
	    try{
	    	
	    	zhanglmServiceManage.bankmessageservicei.exportbankmessage(search,response);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
	}
	@Override
	protected void setData() {
		
	}
}
