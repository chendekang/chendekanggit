package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.AategoryModel;
import com.jrzh.mvc.view.zhanglm.AategoryView;
public class AategoryConvert implements BaseConvertI<AategoryModel, AategoryView> {

	@Override
	public AategoryModel addConvert(AategoryView view) throws ProjectException {
		AategoryModel model = new AategoryModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public AategoryModel editConvert(AategoryView view, AategoryModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public AategoryView convertToView(AategoryModel model) throws ProjectException {
		AategoryView view = new AategoryView();
		if(null != model){
			ReflectUtils.copySameFieldToTarget(model, view);
		}
		return view;
	}

}
