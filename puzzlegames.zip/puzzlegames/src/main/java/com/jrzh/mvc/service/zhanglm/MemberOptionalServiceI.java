package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.MemberOptionalModel;
import com.jrzh.mvc.search.zhanglm.MemberOptionalSearch;
import com.jrzh.mvc.view.zhanglm.MemberOptionalView;

public interface MemberOptionalServiceI  extends BaseServiceI<MemberOptionalModel, MemberOptionalSearch, MemberOptionalView>{

}