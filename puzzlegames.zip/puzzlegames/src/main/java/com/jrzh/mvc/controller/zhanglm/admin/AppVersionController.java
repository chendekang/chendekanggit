package com.jrzh.mvc.controller.zhanglm.admin;

import java.io.File;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.DateUtil;
import com.jrzh.config.ProjectConfigration;
import com.jrzh.config.zhanglm.ZhanglmConfigration;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.AppVersionConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.AppVersionModel;
import com.jrzh.mvc.search.zhanglm.AppVersionSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.AppVersionView;
import com.jrzh.tools.FileUtil;
import com.jrzh.tools.Zxing;

@Controller(AppVersionController.LOCATION +"/AppVersionController")
@RequestMapping(AppVersionController.LOCATION)
public class AppVersionController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/appVersions";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String VIEW_PAGE = LOCATION + "/view";
	
	public static final String MODULE = "zhanglm_appVersion";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@Autowired
	public ProjectConfigration projectConfigration;
	
	@Autowired
	public ZhanglmConfigration zhanglmConfigration;
	
	@RequestMapping(method = RequestMethod.GET,value = "view/{id}")
	public String view(@PathVariable("id") String id) {
		try {		
			AppVersionView view=zhanglmServiceManage.appVersionService.findViewById(id); 
			request.setAttribute("view", view);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return VIEW_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "AppVersion列表查询")
	@ResponseBody
	public EasyuiDataGrid<AppVersionView> datagrid(AppVersionSearch search) {
		EasyuiDataGrid<AppVersionView> dg = new EasyuiDataGrid<AppVersionView>();
	    try{
	    	search.setOrder(BaseSearch.Order_Type_Desc);
	    	dg = zhanglmServiceManage.appVersionService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		try {
			AppVersionSearch search=new AppVersionSearch();
			search.setOrder(AppVersionSearch.Order_Type_Desc);
			AppVersionView view=zhanglmServiceManage.appVersionService.firstView(search);
			if(null == view){
				view = new AppVersionView();
				view.setAppNumber(view.getAppNumber() == null ? 1 : (view.getAppNumber()+1));
				view.setAppName("涨了吗app"+DateUtil.format(new Date(), "yyyy-MM-dd")+"_version_"+view.getAppNumber());
			}else{
				view.setAppNumber(view.getAppNumber() == null ? 1 : (view.getAppNumber()+1));
				view.setAppName("涨了吗app"+DateUtil.format(new Date(), "yyyy-MM-dd")+"_version_"+view.getAppNumber());
			}
			request.setAttribute("view",view);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "AppVersion增加")
	@ResponseBody
	public ResultBean add(AppVersionView view,BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		try{
			AppVersionModel model =new AppVersionConvert().addConvert(view);
			//生成二维码
			String dateDir=DateUtil.format(new Date(),"yyyy-MM-dd");
			String ctxPath= projectConfigration.getFileRootUrl()+"AppQRcode/"+dateDir+"/";
			String mapPath= projectConfigration.mappingUrl+"AppQRcode/"+dateDir+"/";
			File file=new File(ctxPath);
			//如果路径不存在则创建一个新的子目录
			if(!file.exists()) file.mkdirs();	 
			String logoUrl = FileUtil.getProjectRootUrl() + "resources/css/login/images/logo_app_zhanglm.png";
			Zxing.encode(zhanglmConfigration.projectBaseUrl+"/jrzh/mobile/appversion/downApp.html", 400, 400, logoUrl, ctxPath+model.getAppName()+".jpg");
			model.setAppQrCode(mapPath+model.getAppName()+".jpg");
			//标志已生成二维码
			String url=request.getParameter("fileUrl");
			String name=request.getParameter("fileName");
			String imageformat=request.getParameter("fileType");
			if(url==null){
				message="请上传文件";
				result.setMsg(message);
				return result;
			}else{
				//单独改变首条为false也就是启用第一条
				model.setIsDisable(false);
				model.setAppUrl(url);
				FileModel fileModel=new FileModel();
				fileModel.setModel("appVersion");
				fileModel.setType(imageformat);
				fileModel.setName(name);
				fileModel.setUrl(url);
				fileModel.setSortNum(1);
				zhanglmServiceManage.appVersionService.addAndFile(model, fileModel, getSessionUser());
			}
			//把其他APP都禁用
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "AppVersion删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			
			AppVersionModel model = zhanglmServiceManage.appVersionService.findById(id);
			FileModel fileModel=sysServiceManage.fileService.findByField("formId", id);
			zhanglmServiceManage.appVersionService.deleteAndFile(model,fileModel, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "AppVersion禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			List<AppVersionModel> modelList=zhanglmServiceManage.appVersionService.findAll();
			if(modelList.size()>0){
				for(AppVersionModel appModel:modelList){
					appModel.setIsDisable(true);
					zhanglmServiceManage.appVersionService.edit(appModel, getSessionUser());
				}
			}
			AppVersionModel model = zhanglmServiceManage.appVersionService.findById(id);
			model.setIsDisable(false);
			zhanglmServiceManage.appVersionService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
