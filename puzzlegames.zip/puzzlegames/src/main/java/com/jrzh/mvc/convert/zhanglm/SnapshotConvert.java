package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.mvc.model.zhanglm.SnapshotModel;
import com.jrzh.mvc.view.zhanglm.SnapshotView;

public class SnapshotConvert {

	public SnapshotModel addConvert(SnapshotView view) throws ProjectException {
		SnapshotModel model = new SnapshotModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	public SnapshotModel editConvert(SnapshotView view, SnapshotModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	public SnapshotView convertToView(SnapshotModel model) throws ProjectException {
		SnapshotView view = new SnapshotView();
		ReflectUtils.copySameFieldToTarget(model, view);
		view.setGoldId(model.getId());
		return view;
	}

}
