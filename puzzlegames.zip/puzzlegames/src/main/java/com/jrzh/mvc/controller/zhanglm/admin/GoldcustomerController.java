package com.jrzh.mvc.controller.zhanglm.admin;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.mvc.search.zhanglm.GoidCustomerSearch;
import com.jrzh.mvc.search.zhanglm.TodayDealSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.MemberLogStatisticsView;
@Controller(GoldcustomerController.LOCATION +"/GoldcustomerController")
@RequestMapping(GoldcustomerController.LOCATION)
public class GoldcustomerController extends BaseAdminController {
	public static final String LOCATION = "zhanglm/admin/memberLog";
	// 黄金客户统计
	public static final String GOID_CUSTOMERINDEX = LOCATION + "/goldcustomerIndex";
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	// 黄金客户统计
	@RequestMapping(method = RequestMethod.GET, value = "goldcustomerIndex")
	public String goldcustomerIndex() {
		return GOID_CUSTOMERINDEX;
	}

	@RequestMapping(method = RequestMethod.POST, value = "querygoldcustomer")
	@UserEvent(desc = "黄金客户统计列表查询")
	@ResponseBody
	public EasyuiDataGrid<MemberLogStatisticsView> querygoldcustomer(GoidCustomerSearch search) {
		EasyuiDataGrid<MemberLogStatisticsView> dg = new EasyuiDataGrid<MemberLogStatisticsView>();
		try {
			
			
			dg = zhanglmServiceManage.memberlogstatisticsservicei.datagrid(search);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dg;
	}
	//导出黄金客户统计
	@RequestMapping(method = RequestMethod.POST, value = "exportlogstatistics")
	@UserEvent(desc = "导出黄金客户统计")
	@ResponseBody
	public void exportlogstatistics(GoidCustomerSearch search,HttpServletResponse response) {
	    try{
	    	
	    	zhanglmServiceManage.memberlogstatisticsservicei.exportlogstatistics(search,response);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
	}
	@Override
	protected void setData() {

	}

}
