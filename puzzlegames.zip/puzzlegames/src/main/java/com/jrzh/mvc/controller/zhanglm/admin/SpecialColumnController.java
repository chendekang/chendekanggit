package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.SpecialColumnConvert;
import com.jrzh.mvc.model.zhanglm.PlazaDataModel;
import com.jrzh.mvc.model.zhanglm.SpecialColumnModel;
import com.jrzh.mvc.model.zhanglm.ZhiboLiveModel;
import com.jrzh.mvc.search.zhanglm.SpecialColumnSearch;
import com.jrzh.mvc.search.zhanglm.ZhiboLiveSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.SpecialColumnView;

@Controller(SpecialColumnController.LOCATION +"/SpecialColumnController")
@RequestMapping(SpecialColumnController.LOCATION)
public class SpecialColumnController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/zhibo/specialColumn";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_specialColumn";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "SpecialColumn列表查询")
	@ResponseBody
	public EasyuiDataGrid<SpecialColumnView> datagrid(SpecialColumnSearch search) {
		EasyuiDataGrid<SpecialColumnView> dg = new EasyuiDataGrid<SpecialColumnView>();
	    try{
	    	dg = zhanglmServiceManage.specialColumnService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new SpecialColumnView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "SpecialColumn增加")
	@ResponseBody
	public ResultBean add(SpecialColumnView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			SpecialColumnModel model =new SpecialColumnConvert().addConvert(view);
			zhanglmServiceManage.specialColumnService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.specialColumnService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "SpecialColumn修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, SpecialColumnView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			SpecialColumnModel model = zhanglmServiceManage.specialColumnService.findById(id);
			model = new SpecialColumnConvert().editConvert(view, model);
			zhanglmServiceManage.specialColumnService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "SpecialColumn删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			SpecialColumnModel model = zhanglmServiceManage.specialColumnService.findById(id);
			ZhiboLiveSearch search = new ZhiboLiveSearch();
			search.setEqualColumnCode(model.getCode());
			List<ZhiboLiveModel>  zhiboModel = zhanglmServiceManage.zhiboLiveService.list(search);
			for(ZhiboLiveModel zhibo : zhiboModel){
			 	PlazaDataModel dataModel = zhanglmServiceManage.plazaDataService.findByField("dataId", zhibo.getId());
			 	zhanglmServiceManage.plazaDataService.delete(dataModel, getSessionUser());
			}
			Set<ZhiboLiveModel> setZhibo = new HashSet<ZhiboLiveModel>();
			setZhibo.addAll(zhiboModel);
			zhanglmServiceManage.zhiboLiveService.deletes(setZhibo, getSessionUser());
			zhanglmServiceManage.specialColumnService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "SpecialColumn禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			SpecialColumnModel model = zhanglmServiceManage.specialColumnService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.specialColumnService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
