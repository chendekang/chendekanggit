package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.DotitleDaoI;
import com.jrzh.mvc.model.zhanglm.DotitleModel;
@Repository("DotitleDaoI")
public class DotitleDaoImpl extends BaseDaoImpl<DotitleModel> implements DotitleDaoI{

}