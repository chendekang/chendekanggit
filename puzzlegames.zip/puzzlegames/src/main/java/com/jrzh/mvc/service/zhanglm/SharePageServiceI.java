package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.SharePageModel;
import com.jrzh.mvc.search.zhanglm.SharePageSearch;
import com.jrzh.mvc.view.zhanglm.SharePageView;

public interface SharePageServiceI  extends BaseServiceI<SharePageModel, SharePageSearch, SharePageView>{

	void addAndFile(SharePageModel model, FileModel file,SessionUser user) throws Exception;
	
	void editAndFile(SharePageModel model, FileModel file, SessionUser user)throws Exception;

	void deleteAndFile(SharePageModel model, FileModel file, SessionUser user)throws Exception;
}