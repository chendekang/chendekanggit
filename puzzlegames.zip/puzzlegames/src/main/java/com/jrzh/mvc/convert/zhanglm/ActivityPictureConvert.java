package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.mvc.model.zhanglm.ActivityPictureModel;
import com.jrzh.mvc.view.zhanglm.ActivityPictureView;
import com.jrzh.common.utils.ReflectUtils;

public class ActivityPictureConvert implements BaseConvertI<ActivityPictureModel, ActivityPictureView> {

	@Override
	public ActivityPictureModel addConvert(ActivityPictureView view) throws ProjectException {
		ActivityPictureModel model = new ActivityPictureModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public ActivityPictureModel editConvert(ActivityPictureView view, ActivityPictureModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public ActivityPictureView convertToView(ActivityPictureModel model) throws ProjectException {
		ActivityPictureView view = new ActivityPictureView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
