package com.jrzh.mvc.model.zhanglm;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_open_acco_log")
public class OpenAccoLogModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
	@ManyToOne(fetch = FetchType.EAGER,optional = true,cascade = CascadeType.PERSIST, targetEntity = MemberModel.class )
	@JoinColumn(name = "_user_id",referencedColumnName = "_id",insertable=false,updatable=false)
	private MemberModel user;
    /**
     * 用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 手机号码
     */
    @Column(name = "_mobile")
    private String mobile;
    /**
     * 状态
     */
    @Column(name = "_status")
    private Integer status;

    public MemberModel getUser() {
		return user;
	}

	public void setUser(MemberModel user) {
		this.user = user;
	}

	public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
    public String getMobile() {
        return this.mobile;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    
    public Integer getStatus() {
        return this.status;
    }

}