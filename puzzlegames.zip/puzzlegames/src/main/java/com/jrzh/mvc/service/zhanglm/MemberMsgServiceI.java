package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.MemberMsgModel;
import com.jrzh.mvc.search.zhanglm.MemberMsgSearch;
import com.jrzh.mvc.view.zhanglm.MemberMsgView;

public interface MemberMsgServiceI  extends BaseServiceI<MemberMsgModel, MemberMsgSearch, MemberMsgView>{

}