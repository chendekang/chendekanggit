package com.jrzh.mvc.service.zhanglm.impl;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.tools.CollectionTools;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.annotation.UniqueValue;
import com.jrzh.framework.base.model.BaseModel;
import com.jrzh.mvc.convert.zhanglm.AnswerConvert;
import com.jrzh.mvc.dao.zhanglm.AnswerDaoI;
import com.jrzh.mvc.model.zhanglm.AnswerModel;
import com.jrzh.mvc.search.zhanglm.AnswerSearch;
import com.jrzh.mvc.service.zhanglm.AnswerServiceI;
import com.jrzh.mvc.view.zhanglm.AnswerView;
@Service("AnswerServiceI")
public class AnswerServiceImpl implements
		AnswerServiceI {
	@Resource(name = "AnswerDaoI")
	private AnswerDaoI answerdaoi;

	@Override
	public List<AnswerModel> viewListall(AnswerSearch search) {
		return answerdaoi.selectByField("questionid", search.getEqualPid());
	}

	@Override
	public void add(AnswerModel saveModel) throws ProjectException {
		 String message = validate(saveModel);
		 if (StringUtils.isNotBlank(message)) throw new ProjectException(message);
		 Date date = new Date();
		 saveModel.setCeratedate(date);
		 answerdaoi.save(saveModel);
	}
	public String validate(AnswerModel saveModel) throws ProjectException {
		String message = "";
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set constraintViolations = validator.validate(saveModel, new Class[0]);
		if (constraintViolations.size() > 0) {
			message = ((ConstraintViolation) constraintViolations.iterator().next()).getMessage();
		}
		if (StringUtils.isBlank(message)) {
			Class clazz = saveModel.getClass();
			List<Field> fields = ReflectUtils.getFieldsByAnnotation(clazz, UniqueValue.class);
			if (CollectionTools.isNotBlank(fields).booleanValue()) {
				for (Field field : fields) {
					Object value = ReflectUtils.getValue(field.getName(), saveModel);
					BaseModel _m = findByField(field.getName(), value);
					if ((_m != null) && (!(_m.getId().equals(saveModel.getId())))) {
						String name = ((UniqueValue) field.getAnnotation(UniqueValue.class)).name();
						message = name + "[" + value + "]已存在";
						break;
					}
				}
			}
		}
		return message;
	}
	private BaseModel findByField(String name, Object value) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	@Override
	public void deletecourse(List<AnswerModel> viewList) throws ProjectException {
		for(AnswerModel model : viewList){
			answerdaoi.delete(model);
		}	
		
	}

	@Override
	public void edit(AnswerModel saveModel) throws ProjectException {
		  String message = validate(saveModel);
		    if (StringUtils.isNotBlank(message)) throw new ProjectException(message);
		    Date date = new Date();
			saveModel.setCeratedate(date);
		    answerdaoi.merge(saveModel);
		
	}

	@Override
	public List<AnswerView> viewListallzb(AnswerSearch zhibocoursesearch) {

		return answerdaoi.findBylistField("questionid", zhibocoursesearch.getEqualPid());
	}
	@Override
	public List<AnswerView> viewList(AnswerSearch search) throws ProjectException{
		List<AnswerModel> list = this.list(search);
		return this.convertByModelList(list);
	}
	
	public List<AnswerModel> list(AnswerSearch search){
		return  answerdaoi.findList(search);
	}

	public List<AnswerView> convertByModelList(List<AnswerModel> modelList) throws ProjectException{
		List<AnswerView> viewList = new ArrayList<AnswerView>();
		if(null != modelList && modelList.size() > 0){
			for(AnswerModel t : modelList){
				viewList.add(AnswerConvert.convertToView(t));
			}
		}
		return viewList;
	}

	@Override
	public AnswerModel findById(String id) {
		
		AnswerModel model = answerdaoi.getmodel(id);
		return model;
	}

}
