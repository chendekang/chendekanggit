package com.jrzh.mvc.service.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.zhanglm.SnapshotModel;
import com.jrzh.mvc.model.zhanglm.SnapshotSecondLogModel;
import com.jrzh.mvc.search.zhanglm.SnapshotSecondLogSearch;
import com.jrzh.mvc.view.zhanglm.SnapshotSecondLogView;

public interface SnapshotSecondLogServiceI  extends BaseServiceI<SnapshotSecondLogModel, SnapshotSecondLogSearch, SnapshotSecondLogView>{
	void saveSnapshowLog(SnapshotModel model,SessionUser systemUser) throws ProjectException;
	Integer deleteAll();
	SnapshotSecondLogModel viewLowValue(SnapshotSecondLogSearch search)throws ProjectException;
	SnapshotSecondLogModel viewHighValue(SnapshotSecondLogSearch search)throws ProjectException;
}