package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.DownloadModel;
import com.jrzh.mvc.view.zhanglm.DownloadView;

public class DownloadConvert implements BaseConvertI<DownloadModel, DownloadView> {

	@Override
	public DownloadModel addConvert(DownloadView view) throws ProjectException {
		DownloadModel model = new DownloadModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public DownloadModel editConvert(DownloadView view, DownloadModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public DownloadView convertToView(DownloadModel model) throws ProjectException {
		DownloadView view = new DownloadView();
		ReflectUtils.copySameFieldToTarget(model, view);
		view.setTypeStr(BusinessConstants.DOWNLOAD_TYPE.valueMap.get(view.getType()));
		return view;
	}

}
