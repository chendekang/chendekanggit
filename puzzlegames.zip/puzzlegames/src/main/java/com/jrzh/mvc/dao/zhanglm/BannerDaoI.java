package com.jrzh.mvc.dao.zhanglm;

import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.BannerModel;

public interface BannerDaoI extends BaseDaoI<BannerModel>{

}
