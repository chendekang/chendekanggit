package com.jrzh.mvc.model.zhanglm;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_bbs_fans")
public class BbsFanModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 圈子ID
     */
    @Column(name = "_menu_id")
    private String menuId;
    /**
     * 用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 关联用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_user_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel member;
    /**
     * 关联圈子取类别
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = BbsMenuModel.class)
	@JoinColumn(name = "_menu_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private BbsMenuModel bbsMenu;
    /**
     * 话题数
     */
    @Column(name = "_topic_num")
    private Long topicNum;
    /**
     * 点赞数
     */
    @Column(name = "_praise_num")
    private Long praiseNum;
    /**
     * 评论数
     */
    @Column(name = "_reply_num")
    private Long replyNum;
    /**
     * 平均值
     */
    @Column(name = "_average")
    private Double average;

    public BbsMenuModel getBbsMenu() {
		return bbsMenu;
	}

	public void setBbsMenu(BbsMenuModel bbsMenu) {
		this.bbsMenu = bbsMenu;
	}

	public MemberModel getMember() {
		return member;
	}

	public void setMember(MemberModel member) {
		this.member = member;
	}

	public Long getTopicNum() {
		return topicNum;
	}

	public void setTopicNum(Long topicNum) {
		this.topicNum = topicNum;
	}

	public Long getPraiseNum() {
		return praiseNum;
	}

	public void setPraiseNum(Long praiseNum) {
		this.praiseNum = praiseNum;
	}

	public Long getReplyNum() {
		return replyNum;
	}

	public void setReplyNum(Long replyNum) {
		this.replyNum = replyNum;
	}

	public Double getAverage() {
		return average;
	}

	public void setAverage(Double average) {
		this.average = average;
	}

	public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
    
    public String getMenuId() {
        return this.menuId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }

}