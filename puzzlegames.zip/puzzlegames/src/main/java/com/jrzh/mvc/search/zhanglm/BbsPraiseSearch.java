package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class BbsPraiseSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String equalTopicId;
	private String equalUserId;
		
	public String getEqualTopicId() {
		return equalTopicId;
	}

	public void setEqualTopicId(String equalTopicId) {
		this.equalTopicId = equalTopicId;
	}

	public String getEqualUserId() {
		return equalUserId;
	}

	public void setEqualUserId(String equalUserId) {
		this.equalUserId = equalUserId;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalTopicId)){
			dc.add(Restrictions.eq("topicId", equalTopicId));
		}
		if(StringUtils.isNotBlank(equalUserId)){
			dc.add(Restrictions.eq("userId", equalUserId));
		}
	}

}