package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.GoldVarietiesHistoryConvert;
import com.jrzh.mvc.dao.zhanglm.GoldVarietiesHistoryDaoI;
import com.jrzh.mvc.model.zhanglm.GoldVarietiesHistoryModel;
import com.jrzh.mvc.search.zhanglm.GoldHistorySearch;
import com.jrzh.mvc.service.zhanglm.GoldVarietiesHistoryServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.GoldVarietiesHistoryView;

@Service("goldvarietieshistoryservicei")
public class GoldVarietiesHistoryServiceImpl extends
		BaseServiceImpl<GoldVarietiesHistoryModel, GoldHistorySearch, GoldVarietiesHistoryView> implements
		GoldVarietiesHistoryServiceI {

	@Resource(name = "goldvarietieshistorydaoi")
	private GoldVarietiesHistoryDaoI goldvarietieshistorydaoi;
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;

	@Override
	public BaseDaoI<GoldVarietiesHistoryModel> getDao() {
		return goldvarietieshistorydaoi;
	}

	@Override
	public BaseConvertI<GoldVarietiesHistoryModel, GoldVarietiesHistoryView> getConvert() {
		return new GoldVarietiesHistoryConvert();
	}
	
	@Override
	public GoldVarietiesHistoryModel findByField(String fieldName, Object value) throws ProjectException {
		// TODO Auto-generated method stub
		return goldvarietieshistorydaoi.findByField(fieldName, value);
	}
	

}
