package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_member_users")
public class MemberUserModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 管理员用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 平台用户ID
     */
    @Column(name = "_member_id")
    private String memberId;

    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
    
    public String getMemberId() {
        return this.memberId;
    }

}