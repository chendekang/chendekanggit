package com.jrzh.mvc.model.zhanglm;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_bbs_praise")
public class BbsPraiseModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 话题ID
     */
    @Column(name = "_topic_id")
    private String topicId;
    /**
     * 用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 关联用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_user_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel member;
    /**
     * 评论ID
     */
    @Column(name = "_comments_id")
    private String commentsId;
    
    public String getCommentsId() {
		return commentsId;
	}

	public void setCommentsId(String commentsId) {
		this.commentsId = commentsId;
	}

	public MemberModel getMember() {
		return member;
	}

	public void setMember(MemberModel member) {
		this.member = member;
	}

	public void setTopicId(String topicId) {
        this.topicId = topicId;
    }
    
    public String getTopicId() {
        return this.topicId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }

}