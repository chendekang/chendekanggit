package com.jrzh.mvc.model.zhanglm;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.jrzh.framework.base.model.BaseModel;
@Entity
@Table(name = "sys_dictionary")
public class DictionaryModel  extends BaseModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8325348557158766471L;
	/**
     * 字典名称
     */
    @Column(name = "_name")
    private String name;
    
	/**
     * 字典内容
     */
    @Column(name = "_content")
    private String content;
    
	/**
     * 字典描述
     */
    @Column(name = "_describe")
    private String describe;
    
    /**
     * 标识
     */
    @Column(name = "_logo")
    private String logo;
    
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
