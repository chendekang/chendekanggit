package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class BbsReplySearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String equalTopicId;
	private String equaluserId;
	
	public String getEqualuserId() {
		return equaluserId;
	}

	public void setEqualuserId(String equaluserId) {
		this.equaluserId = equaluserId;
	}

	public String getEqualTopicId() {
		return equalTopicId;
	}

	public void setEqualTopicId(String equalTopicId) {
		this.equalTopicId = equalTopicId;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalTopicId)){
			dc.add(Restrictions.eq("topicId", equalTopicId));
		}
		
		if(StringUtils.isNotBlank(equaluserId)){
			dc.add(Restrictions.eq("userId", equaluserId));
		}
	}

}