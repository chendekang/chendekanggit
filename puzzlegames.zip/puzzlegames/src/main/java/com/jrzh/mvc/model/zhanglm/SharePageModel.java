package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_share_page")
public class SharePageModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 图片路径
     */
    @Column(name = "_img_url")
    private String imgUrl;
    /**
     * 标题名称
     */
    @Column(name = "_name")
    private String name;
    /**
     * 内容
     */
    @Column(name = "_content")
    private String content;

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
    
    public String getImgUrl() {
        return this.imgUrl;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getContent() {
        return this.content;
    }

}