package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.AppVersionModel;
import com.jrzh.mvc.search.zhanglm.AppVersionSearch;
import com.jrzh.mvc.view.zhanglm.AppVersionView;

public interface AppVersionServiceI  extends BaseServiceI<AppVersionModel, AppVersionSearch, AppVersionView>{

	void addAndFile(AppVersionModel model,FileModel fileModel,SessionUser sessionUser) throws Exception;
	
	void editAndFile(AppVersionModel model,FileModel fileModel,SessionUser sessionUser) throws Exception;
	
	void deleteAndFile(AppVersionModel model,FileModel findmodel,SessionUser sessionUser)throws Exception;
}