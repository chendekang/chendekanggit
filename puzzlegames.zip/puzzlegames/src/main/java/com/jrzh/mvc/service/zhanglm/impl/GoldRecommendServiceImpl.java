package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.GoldRecommendConvert;
import com.jrzh.mvc.dao.zhanglm.GoldRecommendDaoI;
import com.jrzh.mvc.model.zhanglm.GoldRecommendModel;
import com.jrzh.mvc.search.zhanglm.GoldRecommendSearch;
import com.jrzh.mvc.service.zhanglm.GoldRecommendServiceI;
import com.jrzh.mvc.view.zhanglm.GoldRecommendView;

@Service("goldRecommendService")
public class GoldRecommendServiceImpl extends
		BaseServiceImpl<GoldRecommendModel, GoldRecommendSearch, GoldRecommendView> implements
		GoldRecommendServiceI {

	@Resource(name = "goldRecommendDao")
	private GoldRecommendDaoI goldRecommendDao;

	@Override
	public BaseDaoI<GoldRecommendModel> getDao() {
		return goldRecommendDao;
	}

	@Override
	public BaseConvertI<GoldRecommendModel, GoldRecommendView> getConvert() {
		return new GoldRecommendConvert();
	}

}
