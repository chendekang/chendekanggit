package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.BbsReplyPraiseModel;
import com.jrzh.mvc.search.zhanglm.BbsReplyPraiseSearch;
import com.jrzh.mvc.view.zhanglm.BbsReplyPraiseView;

public interface BbsReplyPraiseServiceI  extends BaseServiceI<BbsReplyPraiseModel, BbsReplyPraiseSearch, BbsReplyPraiseView>{

}