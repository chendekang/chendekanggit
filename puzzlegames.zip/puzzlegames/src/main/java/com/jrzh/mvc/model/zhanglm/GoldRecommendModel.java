package com.jrzh.mvc.model.zhanglm;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_gold_recommend")
public class GoldRecommendModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 关联黄金ID
     */
    @Column(name = "_snapshot_id")
    private int snapshotId;
    
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = SnapshotModel.class)
  	@JoinColumn(name = "_snapshot_id", referencedColumnName = "id",insertable=false,updatable=false)
  	@NotFound(action=NotFoundAction.IGNORE)
    private SnapshotModel snapshot;
    

    public SnapshotModel getSnapshot() {
		return snapshot;
	}

	public void setSnapshot(SnapshotModel snapshot) {
		this.snapshot = snapshot;
	}

	public int getSnapshotId() {
		return snapshotId;
	}

	public void setSnapshotId(int snapshotId) {
		this.snapshotId = snapshotId;
	}


}