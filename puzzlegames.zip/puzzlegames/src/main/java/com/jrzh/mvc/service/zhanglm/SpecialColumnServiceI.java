package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.SpecialColumnModel;
import com.jrzh.mvc.search.zhanglm.SpecialColumnSearch;
import com.jrzh.mvc.view.zhanglm.SpecialColumnView;

public interface SpecialColumnServiceI  extends BaseServiceI<SpecialColumnModel, SpecialColumnSearch, SpecialColumnView>{

}