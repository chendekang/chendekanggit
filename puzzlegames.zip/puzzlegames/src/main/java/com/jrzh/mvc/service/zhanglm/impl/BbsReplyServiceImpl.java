package com.jrzh.mvc.service.zhanglm.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.BbsReplyConvert;
import com.jrzh.mvc.dao.zhanglm.BbsReplyDaoI;
import com.jrzh.mvc.model.zhanglm.BbsCommentsModel;
import com.jrzh.mvc.model.zhanglm.BbsReplyModel;
import com.jrzh.mvc.search.zhanglm.BbsCommentsSearch;
import com.jrzh.mvc.search.zhanglm.BbsReplySearch;
import com.jrzh.mvc.service.zhanglm.BbsReplyServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsReplyView;

@Service("bbsReplyService")
public class BbsReplyServiceImpl extends
		BaseServiceImpl<BbsReplyModel, BbsReplySearch, BbsReplyView> implements
		BbsReplyServiceI {
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	@Resource(name = "bbsReplyDao")
	private BbsReplyDaoI bbsReplyDao;

	@Override
	public BaseDaoI<BbsReplyModel> getDao() {
		return bbsReplyDao;
	}

	@Override
	public BaseConvertI<BbsReplyModel, BbsReplyView> getConvert() {
		return new BbsReplyConvert();
	}

	
	/*获取用户是否点过赞*/
	@Override
	public List<BbsReplyView> viewListbbsReply(BbsReplySearch replySearch, String userId) throws ProjectException {
	/*	BbsReplySearch replySearch = new BbsReplySearch();
		replySearch.setSort("createTime");
		replySearch.setOrder(BaseSearch.Order_Type_Desc);
		replySearch.setEqualTopicId(commentId);*/
		List<BbsReplyView> viewList = this.viewList(replySearch);
		
		for(BbsReplyView view : viewList){
			//查看是否点赞
			BbsCommentsSearch commentssearch = new BbsCommentsSearch();
			commentssearch.setEqualcommentsId(view.getId());
			if(StringUtils.isNotBlank(userId)){
				commentssearch.setEqualUserId(userId);
				BbsCommentsModel model = zhanglmServiceManage.BbsCommentsServiceI.findBySearch(commentssearch);
				if(model != null){
					view.setIsPraise(true);
				}else{
					view.setIsPraise(false);
				}
			}else{
				view.setIsPraise(false);
			}
		}
		return viewList;
	}

}
