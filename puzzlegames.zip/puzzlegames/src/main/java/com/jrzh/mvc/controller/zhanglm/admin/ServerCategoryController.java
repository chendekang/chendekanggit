package com.jrzh.mvc.controller.zhanglm.admin;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.ServerCategoryConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.ServerCategoryModel;
import com.jrzh.mvc.search.zhanglm.ServerCategorySearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.ServerCategoryView;

@Controller(ServerCategoryController.LOCATION +"/ServerCategoryController")
@RequestMapping(ServerCategoryController.LOCATION)
public class ServerCategoryController extends BaseAdminController{
	public static final String LOCATION = "serverManage/admin/serverCategory";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_serverCategory";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	private SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "ServerCategory列表查询")
	@ResponseBody
	public EasyuiDataGrid<ServerCategoryView> datagrid(ServerCategorySearch search) {
		EasyuiDataGrid<ServerCategoryView> dg = new EasyuiDataGrid<ServerCategoryView>();
	    try{
	    	dg = zhanglmServiceManage.serverCategoryService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new ServerCategoryView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "ServerCategory增加")
	@ResponseBody
	public ResultBean add(ServerCategoryView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			if(StringUtils.isBlank(url)){
				result.setMsg("图片不能为空");
				return result;
			}
			ServerCategoryModel model =new ServerCategoryConvert().addConvert(view);
			model.setImgUrl(url);
			model.setImgType(type);
			FileModel file = new FileModel();
			file.setName(view.getName());
			file.setUrl(url);
			file.setModel("serverCategory");
			file.setType(type);
			zhanglmServiceManage.serverCategoryService.addAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.serverCategoryService.findViewById(id));
			request.setAttribute("file", sysServiceManage.fileService.findViewByField("formId", id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "ServerCategory修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, ServerCategoryView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			if(StringUtils.isBlank(url)){
				result.setMsg("图片不能为空");
				return result;
			}
			ServerCategoryModel model = zhanglmServiceManage.serverCategoryService.findById(id);
			model = new ServerCategoryConvert().editConvert(view, model);
			model.setImgUrl(url);
			model.setImgType(type);
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			file.setName(view.getName());
			file.setUrl(url);
			file.setType(type);
			zhanglmServiceManage.serverCategoryService.editAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "ServerCategory删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			ServerCategoryModel model = zhanglmServiceManage.serverCategoryService.findById(id);
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			zhanglmServiceManage.serverCategoryService.deleteAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "ServerCategory禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			ServerCategoryModel model = zhanglmServiceManage.serverCategoryService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.serverCategoryService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
