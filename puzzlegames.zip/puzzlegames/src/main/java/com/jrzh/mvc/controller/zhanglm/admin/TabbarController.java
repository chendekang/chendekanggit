package com.jrzh.mvc.controller.zhanglm.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.TabbarConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.TabbarModel;
import com.jrzh.mvc.search.zhanglm.TabbarSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.TabbarView;

@Controller(TabbarController.LOCATION +"/TabbarController")
@RequestMapping(TabbarController.LOCATION)
public class TabbarController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/tabbar";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String VIEW_PAGE = LOCATION + "/view";
	
	public static final String MODULE = "zhanglm_tabbar";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "Tabbar列表查询")
	@ResponseBody
	public EasyuiDataGrid<TabbarView> datagrid(TabbarSearch search) {
		EasyuiDataGrid<TabbarView> dg = new EasyuiDataGrid<TabbarView>();
	    try{
	    	dg = zhanglmServiceManage.tabbarService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new TabbarView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "Tabbar增加")
	@ResponseBody
	public ResultBean add(TabbarView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			String[] url = request.getParameterValues("fileUrl");
			String[] type = request.getParameterValues("fileType");
			FileModel[] fileModels = new FileModel[2];
			TabbarModel model =new TabbarConvert().addConvert(view);
			if(url != null && url.length > 1){
				for(int i =0;i<fileModels.length;i++){
					FileModel file = new FileModel();
					file.setModel("tabbar");
					file.setName(view.getTabName());
					file.setType(type[i]);
					file.setUrl(url[i]);
					fileModels[i] = file;
				}
				model.setDefaultImgUrl(url[0]);
				model.setPressedImgUrl(url[1]);
				model.setDefaulImgType(type[0]);
				model.setPressedImgType(type[1]);
			}else{
				result.setMsg("请上传图片");
				return result;
			}
			zhanglmServiceManage.tabbarService.addAndFiles(model, fileModels, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.tabbarService.findViewById(id));
			request.setAttribute("file", sysServiceManage.fileService.findViewByField("formId", id));
			request.setAttribute("pressedFile", sysServiceManage.fileService.findViewByField("formId", id+"-p"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "Tabbar修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, TabbarView view) {
		ResultBean result = new ResultBean();
		try {
			String[] url = request.getParameterValues("fileUrl");
			String[] type = request.getParameterValues("fileType");
			FileModel[] fileModels = new FileModel[2];
			fileModels[0] = sysServiceManage.fileService.findByField("formId", id);
			fileModels[1] = sysServiceManage.fileService.findByField("formId", id+"-p");
			TabbarModel model = zhanglmServiceManage.tabbarService.findById(id);
			model = new TabbarConvert().editConvert(view, model);
			if(url != null && url.length > 1){
				for(int i =0;i<fileModels.length;i++){
					FileModel file = fileModels[i];
					file.setModel("tabbar");
					file.setName(view.getTabName());
					file.setType(type[i]);
					file.setUrl(url[i]);
				}
				model.setDefaultImgUrl(url[0]);
				model.setPressedImgUrl(url[1]);
				model.setDefaulImgType(type[0]);
				model.setPressedImgType(type[1]);
			}else{
				result.setMsg("请上传图片");
				return result;
			}
			zhanglmServiceManage.tabbarService.editAndFiles(model, fileModels, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "Tabbar删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			TabbarModel model = zhanglmServiceManage.tabbarService.findById(id);
			FileModel[] fileModels = new FileModel[2];
			fileModels[0] = sysServiceManage.fileService.findByField("formId", id);
			fileModels[1] = sysServiceManage.fileService.findByField("formId", id+"-pressed");
			zhanglmServiceManage.tabbarService.deleteAndFiles(model, fileModels, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "Tabbar禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			TabbarModel model = zhanglmServiceManage.tabbarService.findById(id);
			Integer tabBarVersion = model.getTabVersion();
			TabbarSearch search = new TabbarSearch();
			search.setEqualTabBarVersion(tabBarVersion);
			List<TabbarModel> modelList = zhanglmServiceManage.tabbarService.list(search);
			Boolean flag = model.getIsDisable();
			for(TabbarModel tabBar : modelList){
				tabBar.setIsDisable(!flag);
				zhanglmServiceManage.tabbarService.edit(model, getSessionUser());
			}
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "view")
	public String view(TabbarSearch search) {
		try {
			search.setEqualIsDisable(false);
			search.setSort("sortNum");
			List<TabbarView> viewList = zhanglmServiceManage.tabbarService.viewList(search);
			request.setAttribute("viewList", viewList);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return VIEW_PAGE;
	}
	
	@Override
	protected void setData() {
	}

}
