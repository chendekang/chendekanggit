package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Service;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.HistorysTransactionDaoI;
import com.jrzh.mvc.model.zhanglm.HistorysTransactionModel;
@Service("historystransactionDaoi")
public class HistorysTransactionDaoImpl extends BaseDaoImpl<HistorysTransactionModel> implements HistorysTransactionDaoI{

}
