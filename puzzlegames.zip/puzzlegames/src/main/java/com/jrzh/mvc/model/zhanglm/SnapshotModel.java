package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.jrzh.framework.base.BaseObject;

@Entity
@Table(name = "snapshot")
public class SnapshotModel extends BaseObject {
	private static final long serialVersionUID = 1L;
    
    /**
     * 
     */
	@Id
    @Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    /**
     * 产品代码
     */
    @Column(name = "symbol")
    private String symbol;
    /**
     * 产品名称
     */
    @Column(name = "name")
    private String name;
    /**
     * 日期时间
     */
    @Column(name = "datetime")
    private Date datetime;
    /**
     * 开盘价
     */
    @Column(name = "open")
    private Double open;
    /**
     * 最高价
     */
    @Column(name = "high")
    private Double high;
    /**
     * 最低价
     */
    @Column(name = "low")
    private Double low;
    /**
     * 最新价
     */
    @Column(name = "close")
    private Double close;
    /**
     * 买价
     */
    @Column(name = "bid1price")
    private Double bid1price;
    /**
     * 买量
     */
    @Column(name = "bid1volume")
    private Integer bid1volume;
    /**
     * 卖价
     */
    @Column(name = "ask1price")
    private Double ask1price;
    /**
     * 卖量
     */
    @Column(name = "ask1volume")
    private Integer ask1volume;
    /**
     * 昨收价
     */
    @Column(name = "pclose")
    private Double pclose;
    /**
     * 成交价
     */
    @Column(name = "tvolume")
    private Double tvolume;
    /**
     * 持仓量
     */
    @Column(name = "tvalue")
    private Double tvalue;

    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getId() {
        return this.id;
    }
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }
    
    public String getSymbol() {
        return this.symbol;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    public void setDatetime(Date datetime) {
        this.datetime = datetime;
    }
    
    public Date getDatetime() {
        return this.datetime;
    }
    public void setOpen(Double open) {
        this.open = open;
    }
    
    public Double getOpen() {
        return this.open;
    }
    public void setHigh(Double high) {
        this.high = high;
    }
    
    public Double getHigh() {
        return this.high;
    }
    public void setLow(Double low) {
        this.low = low;
    }
    
    public Double getLow() {
        return this.low;
    }
    public void setClose(Double close) {
        this.close = close;
    }
    
    public Double getClose() {
        return this.close;
    }
    public void setBid1price(Double bid1price) {
        this.bid1price = bid1price;
    }
    
    public Double getBid1price() {
        return this.bid1price;
    }
    public void setBid1volume(Integer bid1volume) {
        this.bid1volume = bid1volume;
    }
    
    public Integer getBid1volume() {
        return this.bid1volume;
    }
    public void setAsk1price(Double ask1price) {
        this.ask1price = ask1price;
    }
    
    public Double getAsk1price() {
        return this.ask1price;
    }
    public void setAsk1volume(Integer ask1volume) {
        this.ask1volume = ask1volume;
    }
    
    public Integer getAsk1volume() {
        return this.ask1volume;
    }
    public void setPclose(Double pclose) {
        this.pclose = pclose;
    }
    
    public Double getPclose() {
        return this.pclose;
    }
    public void setTvolume(Double tvolume) {
        this.tvolume = tvolume;
    }
    
    public Double getTvolume() {
        return this.tvolume;
    }
    public void setTvalue(Double tvalue) {
        this.tvalue = tvalue;
    }
    
    public Double getTvalue() {
        return this.tvalue;
    }

}