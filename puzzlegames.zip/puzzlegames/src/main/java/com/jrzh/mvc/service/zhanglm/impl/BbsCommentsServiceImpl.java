package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.BbsCommentsConvert;
import com.jrzh.mvc.dao.zhanglm.BbsCommentsDaoI;
import com.jrzh.mvc.model.zhanglm.BbsCommentsModel;
import com.jrzh.mvc.search.zhanglm.BbsCommentsSearch;
import com.jrzh.mvc.service.zhanglm.BbsCommentsServiceI;
import com.jrzh.mvc.view.zhanglm.BbsCommentsView;

@Service("BbsCommentsService")
public class BbsCommentsServiceImpl extends
		BaseServiceImpl<BbsCommentsModel, BbsCommentsSearch, BbsCommentsView> implements
		BbsCommentsServiceI {

	@Resource(name = "bbsCommentsDaoi")
	private BbsCommentsDaoI bbsCommentsDaoi;

	@Override
	public BaseDaoI<BbsCommentsModel> getDao() {
		return bbsCommentsDaoi;
	}

	@Override
	public BaseConvertI<BbsCommentsModel, BbsCommentsView> getConvert() {
		return new BbsCommentsConvert();
	}

}
