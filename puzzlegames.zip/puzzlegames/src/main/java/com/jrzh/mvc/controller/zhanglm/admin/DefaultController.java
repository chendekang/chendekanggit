package com.jrzh.mvc.controller.zhanglm.admin;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.DefaultConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.DefaultView;

@Controller(DefaultController.LOCATION +"/DefaultController")
@RequestMapping(DefaultController.LOCATION)
public class DefaultController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/default";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_default";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "Default列表查询")
	@ResponseBody
	public EasyuiDataGrid<DefaultView> datagrid(DefaultSearch search) {
		EasyuiDataGrid<DefaultView> dg = new EasyuiDataGrid<DefaultView>();
	    try{
	    	dg = zhanglmServiceManage.defaultService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new DefaultView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "Default增加")
	@ResponseBody
	public ResultBean add(DefaultView view,BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
			if(this.log.isDebugEnabled()){
				this.log.debug("doAdd() View:"+ view.toString());
			}
			try{
			   String url = request.getParameter("fileUrl");
			   String type = request.getParameter("fileType");
			   DefaultModel model =new DefaultConvert().addConvert(view);
			   model.setImgUrl(url);
			   model.setImgType(type);
			   message = zhanglmServiceManage.defaultService.validate(model);
			   if(StringUtils.isNotBlank(message)){
					result.setMsg(message);
					return result;
				}
			   FileModel file=new FileModel();
				file.setModel("default");
				file.setType(type);
				file.setName(view.getImgName());
				file.setUrl(url);
				message = sysServiceManage.fileService.validate(file);
				if(StringUtils.isNotBlank(message)){
					result.setMsg(message);
					return result;
				}
			   zhanglmServiceManage.defaultService.addAndFile(model, file,getSessionUser());
			   result.setStatus(ResultBean.SUCCESS);
			   result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}

	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.defaultService.findViewById(id));
			request.setAttribute("file", sysServiceManage.fileService.findByField("formId", id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "Default修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, DefaultView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (this.log.isDebugEnabled()) {
			this.log.debug("doEdit() View:" + view.toString());
		}
		try {
			if(StringUtils.isBlank(view.getImgName())){
				result.setMsg("文件名称不能为空");
				return result;
			}
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			DefaultModel model = zhanglmServiceManage.defaultService.findById(id);
			model = new DefaultConvert().editConvert(view, model);
			model.setImgUrl(url);
			model.setImgType(type);
			message = zhanglmServiceManage.defaultService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			FileModel file = sysServiceManage.fileService.findByField("formId", model.getId());
			file.setModel("default");
			file.setType(type);
			file.setName(view.getImgName());
			file.setUrl(url);
			message = sysServiceManage.fileService.validate(file);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.defaultService.editAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "Default删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id, DefaultView view) {
		ResultBean result = new ResultBean();
		if (this.log.isDebugEnabled()) {
			this.log.debug("doDelete() View:" + view.toString());
		}
		try {
			DefaultModel model = zhanglmServiceManage.defaultService.findById(id);
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			zhanglmServiceManage.defaultService.deleteAndFile(model,file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "Default禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			DefaultModel model = zhanglmServiceManage.defaultService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.defaultService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
