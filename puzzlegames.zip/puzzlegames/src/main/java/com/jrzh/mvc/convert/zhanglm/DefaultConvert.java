package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.view.zhanglm.DefaultView;

public class DefaultConvert implements BaseConvertI<DefaultModel, DefaultView> {

	@Override
	public DefaultModel addConvert(DefaultView view) throws ProjectException {
		DefaultModel model = new DefaultModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public DefaultModel editConvert(DefaultView view, DefaultModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public DefaultView convertToView(DefaultModel model) throws ProjectException {
		DefaultView view = new DefaultView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
