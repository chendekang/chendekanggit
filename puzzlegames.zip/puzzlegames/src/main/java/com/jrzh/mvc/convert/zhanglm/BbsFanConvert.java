package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.view.zhanglm.BbsFanView;

public class BbsFanConvert implements BaseConvertI<BbsFanModel, BbsFanView> {

	@Override
	public BbsFanModel addConvert(BbsFanView view) throws ProjectException {
		BbsFanModel model = new BbsFanModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public BbsFanModel editConvert(BbsFanView view, BbsFanModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public BbsFanView convertToView(BbsFanModel model) throws ProjectException {
		BbsFanView view = new BbsFanView();
		ReflectUtils.copySameFieldToTarget(model, view);
		MemberModel member = model.getMember();
		BbsMenuModel bbsMenu=model.getBbsMenu();
		if(null != member){
			view.setUserName(member.getNickName());	
			view.setUserPhoto(member.getPhoto());
		}
		if(null != bbsMenu){
			view.setMenuName(bbsMenu.getName());
		}
		return view;
	}

}
