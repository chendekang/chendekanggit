package com.jrzh.mvc.controller.zhanglm.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.convert.zhanglm.WithdrawAuditLogConvert;
import com.jrzh.mvc.model.zhanglm.WithdrawAuditLogModel;
import com.jrzh.mvc.search.zhanglm.WithdrawAuditLogSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.WithdrawAuditLogView;

/**
 * 提交审核
 * @author Administrator
 *
 */
@Controller(WithdrawAuditController.LOCATION +"/WithdrawAuditController")
@RequestMapping(WithdrawAuditController.LOCATION)
public class WithdrawAuditController extends BaseAdminController{
	public static final String LOCATION = "financeManage/admin/withdrawAudit";
	                               
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String AUDIT_FORM_PAGE = LOCATION + "/auditForm";
	
	public static final String MODULE = "zhanglm_withdrawAudit";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "pass/{id}")
	public String auditForm(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.withdrawAuditLogService.findViewById(id));
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return AUDIT_FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "noPass/{id}")
	public String noPass(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.withdrawAuditLogService.findViewById(id));
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return AUDIT_FORM_PAGE;
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "pass/{id}")
	@UserEvent(desc = "withdrawAudit审核通过")
	@ResponseBody
	public ResultBean pass(@PathVariable("id") String id, WithdrawAuditLogView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			WithdrawAuditLogModel model = zhanglmServiceManage.withdrawAuditLogService.findById(id);
//			model.setStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			model.setIsDisable(true);
			//审核说明存入
			model.setStatus(view.getStatus());
			//审核状态:已通过审核
			model.setAuditState(BusinessConstants.WITHDROW_AUDIT_STATUS.AUDIT);
			//审核人
			model.setAuditor(getSessionUser().getName());
			//存入数据库
			zhanglmServiceManage.withdrawAuditLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("审核完成");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "noPass/{id}")
	@UserEvent(desc = "withdrawAudit审核不通过")
	@ResponseBody
	public ResultBean noPass(@PathVariable("id") String id, WithdrawAuditLogView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			WithdrawAuditLogModel model = zhanglmServiceManage.withdrawAuditLogService.findById(id);
			model.setIsDisable(false);
			//审核说明存入
			model.setStatus(view.getStatus());
			//审核状态:未通过审核
			model.setAuditState(BusinessConstants.WITHDROW_AUDIT_STATUS.NOT_AUDIT);
			//审核人
			model.setAuditor(getSessionUser().getName());
			zhanglmServiceManage.withdrawAuditLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("审核完成");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "WithdrawAuditLog审核列表查询")
	@ResponseBody
	public EasyuiDataGrid<WithdrawAuditLogView> datagrid(WithdrawAuditLogSearch search) {
		EasyuiDataGrid<WithdrawAuditLogView> dg = new EasyuiDataGrid<WithdrawAuditLogView>();
	    try{
	    	
	    	search.setEqualAuditState(BusinessConstants.WITHDROW_AUDIT_STATUS.AUDING);
	    	dg = zhanglmServiceManage.withdrawAuditLogService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new WithdrawAuditLogView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "WithdrawAuditLog增加")
	@ResponseBody
	public ResultBean add(WithdrawAuditLogView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			WithdrawAuditLogModel model =new WithdrawAuditLogConvert().addConvert(view);
			zhanglmServiceManage.withdrawAuditLogService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.withdrawAuditLogService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "WithdrawAuditLog修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, WithdrawAuditLogView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			WithdrawAuditLogModel model = zhanglmServiceManage.withdrawAuditLogService.findById(id);
			model = new WithdrawAuditLogConvert().editConvert(view, model);
			zhanglmServiceManage.withdrawAuditLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "WithdrawAuditLog删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			WithdrawAuditLogModel model = zhanglmServiceManage.withdrawAuditLogService.findById(id);
			zhanglmServiceManage.withdrawAuditLogService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "WithdrawAuditLog审核通过/审核不通过")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			WithdrawAuditLogModel model = zhanglmServiceManage.withdrawAuditLogService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.withdrawAuditLogService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
