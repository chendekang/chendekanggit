package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.ServerCategoryDaoI;
import com.jrzh.mvc.model.zhanglm.ServerCategoryModel;

@Repository("serverCategoryDao")
public class ServerCategoryDaoImpl extends BaseDaoImpl<ServerCategoryModel> implements ServerCategoryDaoI{

}