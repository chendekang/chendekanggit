package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.zhanglm.GoldHistoryModel;
import com.jrzh.mvc.search.zhanglm.GoldHistorySearch;
import com.jrzh.mvc.view.zhanglm.GoldHistoryView;

public interface GoldHistoryServiceI  extends BaseServiceI<GoldHistoryModel, GoldHistorySearch, GoldHistoryView>{

	void addAndReset(List<GoldHistoryView> list, SessionUser user)throws Exception;

}