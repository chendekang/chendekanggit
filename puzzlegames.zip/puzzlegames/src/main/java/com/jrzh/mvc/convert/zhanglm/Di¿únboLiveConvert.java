package com.jrzh.mvc.convert.zhanglm;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.DboLiveModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.SpecialColumnModel;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.DboLiveView;

public class DiǎnboLiveConvert implements BaseConvertI<DboLiveModel, DboLiveView> {

	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Override
	public DboLiveModel addConvert(DboLiveView view) throws ProjectException {
		DboLiveModel model = new DboLiveModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	
	@Override
	public DboLiveModel editConvert(DboLiveView view, DboLiveModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public DboLiveView convertToView(DboLiveModel model) throws ProjectException {
		DboLiveView view = new DboLiveView();
		if(null != model){
			ReflectUtils.copySameFieldToTarget(model, view);
			SpecialColumnModel specialColumn = model.getSpecialColumn();
			if (null != specialColumn) {
				view.setColumnCode(specialColumn.getCode());
				view.setColumnName(specialColumn.getName());
			} else {
				view.setColumnCode("无");
				view.setColumnName("专栏已删除");
			}
			MemberModel member = model.getMember();
			view.setUserName(member.getNickName());
			view.setUserIntro(member.getIntro());
			// 设置时间格式(只要时分)
			SimpleDateFormat sdf = new SimpleDateFormat("HH-mm");
			String start = sdf.format(model.getStartTime()).replaceAll("-", ":");
			String end = sdf.format(model.getEndTime()).replaceAll("-", ":");
			view.setTodayTime(start + "~" + end);
			view.setPhoto(member.getPhoto());
			view.setUserIntro(member.getIntro());
			// 判断是否在直播中 false为未直播 true为正在直播
			Boolean flag = false;
			Long starts = model.getStartTime().getTime();
			Long Ends = model.getEndTime().getTime();
			view.setTotaltime(Ends-starts);
			Long date = new Date().getTime();
			if (starts <= date && Ends >= date) {
				flag = true;
			}
			view.setJudgeZhibo(flag);
			view.setZhiboId(model.getId());
		}
		return view;
	}

}
