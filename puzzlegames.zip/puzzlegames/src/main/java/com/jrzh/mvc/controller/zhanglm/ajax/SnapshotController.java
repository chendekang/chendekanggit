package com.jrzh.mvc.controller.zhanglm.ajax;

import java.text.DecimalFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAjaxController;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.SnapshotView;

@Controller(SnapshotController.LOCATION +"/SnapshotController")
@RequestMapping(SnapshotController.LOCATION)
public class SnapshotController extends BaseAjaxController{
	public static final String LOCATION = "zhanglm/ajax/snapshot";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.POST, value = "goldInfo")
	@UserEvent(desc = "产品数据")
	@ResponseBody
	public ResultBean goldInfo(){
		ResultBean result = new ResultBean();
		try {
			String symbol = request.getParameter("symbol");
			String[] resymbol = symbol.split(" ");
			symbol = "";
			for (int i = 0; i < resymbol.length; i++) {
				if(i == 0){
					symbol = resymbol[i];
				}else{
					symbol += "+"+resymbol[i];
				}
			}
			SnapshotView view = zhanglmServiceManage.snapshotService.findViewByField("symbol", symbol);
			DecimalFormat df = new DecimalFormat("######0.00");
			Double value = 0.0;
			Double valueO = 0.0;
			if(view.getBid1price()!=null && view.getClose()!=null){
				if( view.getBid1price()!=0){
					value = view.getClose() / view.getBid1price();
				}
				valueO = view.getClose() - view.getBid1price();
			}
			result.setStatus(ResultBean.SUCCESS);
			result.setObjs(new Object[]{df.format(value),df.format(valueO),view});
		} catch (ProjectException e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}

	@Override
	protected void setData() {
		// TODO Auto-generated method stub
		
	}
}
