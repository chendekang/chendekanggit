package com.jrzh.mvc.controller.zhanglm.ajax;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAjaxController;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.model.sys.UserModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.MemberUserModel;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;

@Controller(MemberController.LOCATION +"/MemberController")
@RequestMapping(MemberController.LOCATION)
public class MemberController extends BaseAjaxController{
	public static final String LOCATION = "zhanglm/ajax/member";

	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;

	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "MemberUser删除/注销管理员")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			MemberUserModel model = zhanglmServiceManage.memberUserService.findByField("memberId", id);
			UserModel user = sysServiceManage.userService.findById(model.getUserId());
			MemberModel member = zhanglmServiceManage.memberService.findById(id);
			//删除
			sysServiceManage.userService.delete(user, getSessionUser());
			zhanglmServiceManage.memberUserService.delete(model, getSessionUser());
			//注销
			member.setIsDisable(false);
			zhanglmServiceManage.memberService.edit(member, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("注销成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
		
	}
	

}
