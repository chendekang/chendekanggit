package com.jrzh.mvc.controller.zhanglm.mobile;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.model.zhanglm.DboLiveModel;
import com.jrzh.mvc.model.zhanglm.MemberAttentionModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.ZhiboCourseModel;
import com.jrzh.mvc.model.zhanglm.ZhiboLiveModel;
import com.jrzh.mvc.search.sys.UserSearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.DboLiveSearch;
import com.jrzh.mvc.search.zhanglm.MemberAttentionSearch;
import com.jrzh.mvc.search.zhanglm.MemberSearch;
import com.jrzh.mvc.search.zhanglm.SpecialColumnSearch;
import com.jrzh.mvc.search.zhanglm.ZhiboCourseSearch;
import com.jrzh.mvc.search.zhanglm.ZhiboLiveSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.sys.UserView;
import com.jrzh.mvc.view.zhanglm.DboLiveView;
import com.jrzh.mvc.view.zhanglm.ZhiboCourseView;
import com.jrzh.mvc.view.zhanglm.ZhiboLiveView;
import com.jrzh.tools.DateUtil;
@Controller(newZhiboController.LOCATION + "ZhiboController")
@RequestMapping(newZhiboController.LOCATION)
public class newZhiboController extends BaseMobileController {
	public static final String LOCATION = "/zhibo/";
	public Logger logger = Logger.getLogger(newZhiboController.class);
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	/*获取直播轮播图 */
/*	@RequestMapping(method = RequestMethod.POST, value = "banners")
	@MemberEvent(desc = "安卓/IOS直播广告图")
	@ResponseBody
	public MobileResultBean banner(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<ZhiboAdView> zbList = new ArrayList<ZhiboAdView>();
		String message = "";
		map.put("method", "banners");
		try {
			ZhiboAdSearch zhiboadsearch=new ZhiboAdSearch();
			zhiboadsearch.setRows(8);
			zbList = zhanglmServiceManage.zhiboAdServiceI.viewList(zhiboadsearch);
			for(ZhiboAdView view : zbList){
				view.setImgPremiereTimeStr("开播时间 ："+DateUtil.formatDate(view.getImgPremiereTime()));
				
			}			
			if(zbList !=null && zbList.size() > 0){
				map.put("bannerList", zbList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
		    }else{
		    	map.put("bannerList", zbList);
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
		    }
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods column"+e.getMessage());
		}
		result.setMessage(message);                                            
		return result;
	}*/
	
	/*--------------------新接口 获取直播推荐-------测试完成----------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "banners")
	@MemberEvent(desc = "安卓/IOS直播广告图")
	@ResponseBody
	public MobileResultBean banners(ZhiboLiveSearch search,DboLiveSearch dbsearch) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		ZhiboCourseSearch zhibocoursesearch = new ZhiboCourseSearch();
		List<ZhiboCourseModel> zhibocourseview = new ArrayList<ZhiboCourseModel>();
		map.put("method", "banners");
		String message = "";
		try {
			// search.setRows(3);
			// 直播
			search.setEqualIsLock(true);
			List<ZhiboLiveView> recommendList = zhanglmServiceManage.zhiboLiveService.viewList(search);
			// 点播
			dbsearch.setEqualIsLock(true);
			List<DboLiveView> dbList = zhanglmServiceManage.dboLiveServiceI.viewList(dbsearch);
			DefaultSearch defaultsearch = new DefaultSearch();
			ZhiboLiveView zb = new ZhiboLiveView();
			// 直播set值
			if (recommendList != null && recommendList.size() > 0) {
				for (ZhiboLiveView zhibo : recommendList) {
					zhibo.setIntro("直播讲师:" + zhibo.getUserName());
					// 查询上传图片
					defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
					DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
					// 用户个人头像
					if (null == zhibo.getPhoto()) {
						zhibo.setPhoto(defaultModel.getImgUrl());
					}
					// 查询关注多少粉丝
					MemberAttentionSearch gzsearch = new MemberAttentionSearch();
					// 直r粉丝数量
					gzsearch.setEqualMemberId(zhibo.getUserId());
					Long fansNum = zhanglmServiceManage.memberAttentionService.count(gzsearch);
					if (null == fansNum) {
						zhibo.setFanNum(new Long(0));
					} else {
						zhibo.setFanNum(fansNum);
					}
					// 直播
					if ("0001".equals(zhibo.getColumnCode())) {
						zhibocoursesearch.setEqualzbId(zhibo.getId());
						zhibocourseview = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(zhibocoursesearch);
						if (zhibocourseview != null && zhibocourseview.size() > 0) {
							zb.setStartTime1(zhibocourseview.get(0).getStartTime());
							zb.setEndTime1(zhibocourseview.get(0).getEndTime());
							zb.setTitle1(zhibocourseview.get(0).getTitle());
							zb.setLecturer1(zhibocourseview.get(0).getLecturer());
							zb.setStartTime2(zhibocourseview.get(1).getStartTime());
							zb.setEndTime2(zhibocourseview.get(1).getEndTime());
							zb.setTitle2(zhibocourseview.get(1).getTitle());
							zb.setLecturer2(zhibocourseview.get(1).getLecturer());
							zb.setStartTime3(zhibocourseview.get(2).getStartTime());
							zb.setEndTime3(zhibocourseview.get(2).getEndTime());
							zb.setTitle3(zhibocourseview.get(2).getTitle());
							zb.setLecturer3(zhibocourseview.get(2).getLecturer());
						}
						// 设置时间格式(只要时分)
						/*
						 * SimpleDateFormat sdf = new SimpleDateFormat("HH-mm");
						 * String start1
						 * =sdf.format(zb.getStartTime1()).replaceAll("-", ":");
						 * String end1
						 * =sdf.format(zb.getEndTime1()).replaceAll("-", ":");
						 * String start2
						 * =sdf.format(zb.getStartTime2()).replaceAll("-", ":");
						 * String end2
						 * =sdf.format(zb.getEndTime2()).replaceAll("-", ":");
						 * String start3 =
						 * sdf.format(zb.getStartTime3()).replaceAll("-",":");
						 * String end3
						 * =sdf.format(zb.getEndTime3()).replaceAll("-", ":");
						 * zhibo.setTodaytimeperiod1(start1 + "~" + end1);
						 * zhibo.setTodaytimeperiod2(start2 + "~" + end2);
						 * zhibo.setTodaytimeperiod3(start3 + "~" + end3);
						 */
						// 判断是否在直播中 false为未直播 true为正在直播
						Boolean flag = false;
						Long starts1 = zb.getStartTime1().getTime();
						Long Ends1 = zb.getEndTime1().getTime();
						Long starts2 = zb.getStartTime2().getTime();
						Long Ends2 = zb.getEndTime2().getTime();
						Long starts3 = zb.getStartTime3().getTime();
						Long Ends3 = zb.getEndTime3().getTime();
						Long date = new Date().getTime();
						if (starts1 <= date && Ends1 >= date) {
							flag = true;
						}else{
							zhibo.setStartTime(zb.getStartTime1());
						
						}
						if (starts2 <= date && Ends2 >= date) {
							flag = true;
						}else{
							zhibo.setStartTime(zb.getStartTime2());
						
						}
						if (starts3 <= date && Ends3 >= date) {
							flag = true;
						}else{
							zhibo.setStartTime(zb.getStartTime3());
						
						}
						zhibo.setJudgeZhibo(flag);
						// 判断是否在直播中 false为点播播 true为1是直播
						zhibo.setJudgeDianbo(true);
					}
				}
			}

			// 点播set值
			List<DboLiveView> dbview = new ArrayList<DboLiveView>();
			if (dbList != null && dbList.size() > 0) {
				for (DboLiveView dbo : dbList) {
					dbo.setIntro("直播讲师:" + dbo.getUserName());
					defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
					DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
					if (null == dbo.getPhoto()) {
						dbo.setPhoto(defaultModel.getImgUrl());
					}
					// 查询关注多少粉丝
					MemberAttentionSearch gzsearch = new MemberAttentionSearch();
					// 点播粉丝数量
					gzsearch.setEqualMemberId(dbo.getUserId());
					Long fansNum = zhanglmServiceManage.memberAttentionService.count(gzsearch);
					if (null == fansNum) {
						dbo.setFanNum(new Long(0));
					} else {
						dbo.setFanNum(fansNum);
					}
					// 点播
					if ("0002".equals(dbo.getColumnCode())) {
						// 判断是否在直播中 false为未直播 true为正在直播
						Boolean flag = false;
						Long starts1 = dbo.getStartTime().getTime();
						Long Ends1 = dbo.getEndTime().getTime();
						Long date = new Date().getTime();
						if (starts1 <= date && Ends1 >= date) {
							flag = true;
						}
						dbo.setJudgeZhibo(flag);
						// 判断是否在直播中 false为点播播 true为1是直播
						dbo.setJudgeDianbo(false);
					}
					// 添加集合
					dbview.add(dbo);
				}

			}
			map.put("zbList", recommendList);
			map.put("dbList", dbview);
			result.setObject(map);
			message = "获取推荐直播成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods index"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}
	
	
	
	/*--------------------新接口 获取直播专栏-----------测试完成-----------------*/
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST, value = "column")
	@MemberEvent(desc ="安卓/IOS 直播专栏")
	@ResponseBody
	public MobileResultBean column(SpecialColumnSearch search,ZhiboLiveSearch zbsearch) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		ZhiboCourseSearch zhibocoursesearch = new ZhiboCourseSearch();
		ZhiboLiveView zhibo = new ZhiboLiveView();
		map.put("method", "column");
		String message = "";
		try {
			//根据创建日期查询
			//String ceratedate="2017-01-12 00:00:00";
			//ZhiboLiveView view = zhanglmServiceManage.zhiboLiveService.findViewByField("zbdate", ceratedate);
			List<ZhiboLiveView> recommendList = zhanglmServiceManage.zhiboLiveService.viewList(zbsearch);
/*			if(zhibocourseview !=null && zhibocourseview.size() > 0){
				SimpleDateFormat sdf = new SimpleDateFormat("HH-mm");
				for(ZhiboCourseView view : zhibocourseview){
					String start =sdf.format(view.getStartTime()).replaceAll("-", ":");
					String end =sdf.format(view.getEndTime()).replaceAll("-", ":"); 
					view.setStartTime(sdf.parse(start));//开始时间
					view.setEndTime(sdf.parse(end));//结束时间
					view.setTitle(view.getTitle());//标题
					view.setLecturer(view.getLecturer());//讲师
				}			
				SimpleDateFormat sdf = new SimpleDateFormat("HH-mm");
				String start1 =sdf.format(zhibocourseview.get(0).getStartTime()).replaceAll("-", ":");
				String end1 =sdf.format(zhibocourseview.get(0).getEndTime()).replaceAll("-", ":");
				String start2 =sdf.format(zhibocourseview.get(1).getStartTime()).replaceAll("-", ":");
				String end2 =sdf.format(zhibocourseview.get(1).getEndTime()).replaceAll("-", ":");
				String start3 =sdf.format(zhibocourseview.get(2).getStartTime()).replaceAll("-", ":");
				String end3 =sdf.format(zhibocourseview.get(2).getEndTime()).replaceAll("-", ":");
				zhibo.setStartTime1(zhibocourseview.get(0).getStartTime());
				zhibo.setEndTime1(zhibocourseview.get(0).getEndTime());
				zhibo.setTitle1(zhibocourseview.get(0).getTitle());
				zhibo.setLecturer1(zhibocourseview.get(0).getLecturer());
				zhibo.setStartTime2(zhibocourseview.get(1).getStartTime());
				zhibo.setEndTime2(zhibocourseview.get(1).getEndTime());
				zhibo.setTitle2(zhibocourseview.get(1).getTitle());
				zhibo.setLecturer2(zhibocourseview.get(1).getLecturer());
				zhibo.setStartTime3(zhibocourseview.get(2).getStartTime());
				zhibo.setEndTime3(zhibocourseview.get(2).getEndTime());
				zhibo.setTitle3(zhibocourseview.get(2).getTitle());
				zhibo.setLecturer3(zhibocourseview.get(2).getLecturer());					
				zhibo.setTodaytimeperiod1(start1 + "~" + end1);
				zhibo.setTodaytimeperiod2(start2 + "~" + end2);
				zhibo.setTodaytimeperiod3(start3 + "~" + end3);
			}*/
			//List<SpecialColumnView> columnList = zhanglmServiceManage.specialColumnService.viewList(search);
			if(recommendList !=null && recommendList.size() > 0){
				zhibocoursesearch.setEqualzbId(recommendList.get(0).getId());
				List<ZhiboCourseView> zhibocourseview = zhanglmServiceManage.ZhiboCourseServiceI.viewListallzb(zhibocoursesearch);
				map.put("columnList", zhibocourseview);
				result.setObject(map);
				message = "获取成功";
				result.setStatus(MobileResultBean.SUCCESS);
		    }else{
		    	message = "当前时间没数据";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
		    }
		} catch (Exception e) {
			e.printStackTrace();	
			logger.info("methods column"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}
	
	/*获取名家列表     -----测试完成*/
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST, value = "famousList")
	@MemberEvent(desc ="安卓/IOS 获取名家列表")
	@ResponseBody
	public MobileResultBean famousList() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		ZhiboCourseSearch zhibocoursesearch = new ZhiboCourseSearch();
		ZhiboLiveView zhibo = new ZhiboLiveView();
		List<UserView> usview = new ArrayList<UserView>();
		map.put("method", "famousList");
		String message = "";
		try {
			//1.根据角色查出所有用户，根据用户查询讲师信息
			UserSearch user = new UserSearch();
			//讲师
			MemberSearch me = new MemberSearch();
			me.setEqualState(1);
			//平台用户
			List<MemberModel> sysuser = zhanglmServiceManage.memberService.list(me);
/*			UserView v = new UserView();
			for(UserModel mod : sysuser){
				v.setId(mod.getId());
				v.setName(mod.getName());//姓名
			}*/
			if(sysuser !=null && sysuser.size() > 0){
				map.put("famousList", sysuser);
				result.setObject(map);
				message = "获取成功";
				result.setStatus(MobileResultBean.SUCCESS);
		    }else{
		    	message = "当前时间没数据";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
		    }
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods column"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}
	
	/*--------------------新接口 获取直播推荐-------测试完成----------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "recommend")
	@MemberEvent(desc ="安卓/IOS 获取推荐直播")
	@ResponseBody
	public MobileResultBean recommend(ZhiboLiveSearch search,DboLiveSearch dbsearch) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		ZhiboCourseSearch zhibocoursesearch = new ZhiboCourseSearch();
		List<ZhiboCourseModel> zhibocourseview = new ArrayList<ZhiboCourseModel>();
		map.put("method", "recommend");
		String message = "";
		try {
			// search.setRows(3);
			// 直播
			search.setEqualIsLock(true);
			List<ZhiboLiveView> recommendList = zhanglmServiceManage.zhiboLiveService.viewList(search);
			// 点播
			dbsearch.setEqualIsLock(true);
			List<DboLiveView> dbList = zhanglmServiceManage.dboLiveServiceI.viewList(dbsearch);
			DefaultSearch defaultsearch = new DefaultSearch();
			ZhiboLiveView zb = new ZhiboLiveView();
			// 直播set值
			if (recommendList != null && recommendList.size() > 0) {
				for (ZhiboLiveView zhibo : recommendList) {
					zhibo.setIntro("直播讲师:" + zhibo.getUserName());
					// 查询上传图片
					defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
					DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
					// 用户个人头像
					if (null == zhibo.getPhoto()) {
						zhibo.setPhoto(defaultModel.getImgUrl());
					}
					// 查询关注多少粉丝
					MemberAttentionSearch gzsearch = new MemberAttentionSearch();
					// 直r粉丝数量
					gzsearch.setEqualMemberId(zhibo.getUserId());
					Long fansNum = zhanglmServiceManage.memberAttentionService.count(gzsearch);
					if (null == fansNum) {
						zhibo.setFanNum(new Long(0));
					} else {
						zhibo.setFanNum(fansNum);
					}
					// 直播
					if ("0001".equals(zhibo.getColumnCode())) {
						zhibocoursesearch.setEqualzbId(zhibo.getId());
						zhibocourseview = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(zhibocoursesearch);
						if (zhibocourseview != null && zhibocourseview.size() > 0) {
							zb.setStartTime1(zhibocourseview.get(0).getStartTime());
							zb.setEndTime1(zhibocourseview.get(0).getEndTime());
							zb.setTitle1(zhibocourseview.get(0).getTitle());
							zb.setLecturer1(zhibocourseview.get(0).getLecturer());
							zb.setStartTime2(zhibocourseview.get(1).getStartTime());
							zb.setEndTime2(zhibocourseview.get(1).getEndTime());
							zb.setTitle2(zhibocourseview.get(1).getTitle());
							zb.setLecturer2(zhibocourseview.get(1).getLecturer());
							zb.setStartTime3(zhibocourseview.get(2).getStartTime());
							zb.setEndTime3(zhibocourseview.get(2).getEndTime());
							zb.setTitle3(zhibocourseview.get(2).getTitle());
							zb.setLecturer3(zhibocourseview.get(2).getLecturer());
						}
						// 设置时间格式(只要时分)
						/*
						 * SimpleDateFormat sdf = new SimpleDateFormat("HH-mm");
						 * String start1
						 * =sdf.format(zb.getStartTime1()).replaceAll("-", ":");
						 * String end1
						 * =sdf.format(zb.getEndTime1()).replaceAll("-", ":");
						 * String start2
						 * =sdf.format(zb.getStartTime2()).replaceAll("-", ":");
						 * String end2
						 * =sdf.format(zb.getEndTime2()).replaceAll("-", ":");
						 * String start3 =
						 * sdf.format(zb.getStartTime3()).replaceAll("-",":");
						 * String end3
						 * =sdf.format(zb.getEndTime3()).replaceAll("-", ":");
						 * zhibo.setTodaytimeperiod1(start1 + "~" + end1);
						 * zhibo.setTodaytimeperiod2(start2 + "~" + end2);
						 * zhibo.setTodaytimeperiod3(start3 + "~" + end3);
						 */
						// 判断是否在直播中 false为未直播 true为正在直播
						Boolean flag = false;
						Long starts1 = zb.getStartTime1().getTime();
						Long Ends1 = zb.getEndTime1().getTime();
						Long starts2 = zb.getStartTime2().getTime();
						Long Ends2 = zb.getEndTime2().getTime();
						Long starts3 = zb.getStartTime3().getTime();
						Long Ends3 = zb.getEndTime3().getTime();
						Long date = new Date().getTime();
						if (starts1 <= date && Ends1 >= date) {
							flag = true;
						}else{
							zhibo.setStartTime(zb.getStartTime1());
						
						}
						if (starts2 <= date && Ends2 >= date) {
							flag = true;
						}else{
							zhibo.setStartTime(zb.getStartTime2());
						
						}
						if (starts3 <= date && Ends3 >= date) {
							flag = true;
						}else{
							zhibo.setStartTime(zb.getStartTime3());
						
						}
						zhibo.setJudgeZhibo(flag);
						// 判断是否在直播中 false为点播播 true为1是直播
						zhibo.setJudgeDianbo(true);
					}
				}
			}

			// 点播set值
			List<DboLiveView> dbview = new ArrayList<DboLiveView>();
			if (dbList != null && dbList.size() > 0) {
				for (DboLiveView dbo : dbList) {
					dbo.setIntro("直播讲师:" + dbo.getUserName());
					defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
					DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
					if (null == dbo.getPhoto()) {
						dbo.setPhoto(defaultModel.getImgUrl());
					}
					// 查询关注多少粉丝
					MemberAttentionSearch gzsearch = new MemberAttentionSearch();
					// 点播粉丝数量
					gzsearch.setEqualMemberId(dbo.getUserId());
					Long fansNum = zhanglmServiceManage.memberAttentionService.count(gzsearch);
					if (null == fansNum) {
						dbo.setFanNum(new Long(0));
					} else {
						dbo.setFanNum(fansNum);
					}
					// 点播
					if ("0002".equals(dbo.getColumnCode())) {
						// 判断是否在直播中 false为未直播 true为正在直播
						Boolean flag = false;
						Long starts1 = dbo.getStartTime().getTime();
						Long Ends1 = dbo.getEndTime().getTime();
						Long date = new Date().getTime();
						if (starts1 <= date && Ends1 >= date) {
							flag = true;
						}
						dbo.setJudgeZhibo(flag);
						// 判断是否在直播中 false为点播播 true为1是直播
						dbo.setJudgeDianbo(false);
					}
					// 添加集合
					dbview.add(dbo);
				}

			}
			map.put("zbList", recommendList);
			map.put("dbList", dbview);
			result.setObject(map);
			message = "获取推荐直播成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods index"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "getlive")
	@MemberEvent(desc ="安卓/IOS 获取直播")
	@ResponseBody
	public MobileResultBean getlive(ZhiboLiveSearch search,String famoudId) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		ZhiboCourseSearch zhibocoursesearch = new ZhiboCourseSearch();
		List<ZhiboCourseModel> zhibocourseview = new ArrayList<ZhiboCourseModel>();
		map.put("method", "recommend");
		String message = "";
		try {
			// search.setRows(3);
			// 直播
			search.setEqualUserId(famoudId);
			List<ZhiboLiveView> recommendList = zhanglmServiceManage.zhiboLiveService.viewList(search);
			DefaultSearch defaultsearch = new DefaultSearch();
			ZhiboLiveView zb = new ZhiboLiveView();
			// 直播set值
			if (recommendList != null && recommendList.size() > 0) {
				for (ZhiboLiveView zhibo : recommendList) {
					zhibo.setIntro("直播讲师:" + zhibo.getUserName());
					// 查询上传图片
					defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
					DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
					// 用户个人头像
					if (null == zhibo.getPhoto()) {
						zhibo.setPhoto(defaultModel.getImgUrl());
					}
					// 查询关注多少粉丝
					MemberAttentionSearch gzsearch = new MemberAttentionSearch();
					// 直r粉丝数量
					gzsearch.setEqualMemberId(zhibo.getUserId());
					Long fansNum = zhanglmServiceManage.memberAttentionService.count(gzsearch);
					if (null == fansNum) {
						zhibo.setFanNum(new Long(0));
					} else {
						zhibo.setFanNum(fansNum);
					}
					// 直播
					if ("0001".equals(zhibo.getColumnCode())) {
						zhibocoursesearch.setEqualzbId(zhibo.getId());
						zhibocourseview = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(zhibocoursesearch);
						if (zhibocourseview != null && zhibocourseview.size() > 0) {
							zb.setStartTime1(zhibocourseview.get(0).getStartTime());
							zb.setEndTime1(zhibocourseview.get(0).getEndTime());
							zb.setTitle1(zhibocourseview.get(0).getTitle());
							zb.setLecturer1(zhibocourseview.get(0).getLecturer());
							zb.setStartTime2(zhibocourseview.get(1).getStartTime());
							zb.setEndTime2(zhibocourseview.get(1).getEndTime());
							zb.setTitle2(zhibocourseview.get(1).getTitle());
							zb.setLecturer2(zhibocourseview.get(1).getLecturer());
							zb.setStartTime3(zhibocourseview.get(2).getStartTime());
							zb.setEndTime3(zhibocourseview.get(2).getEndTime());
							zb.setTitle3(zhibocourseview.get(2).getTitle());
							zb.setLecturer3(zhibocourseview.get(2).getLecturer());
						}
						// 设置时间格式(只要时分)
						/*
						 * SimpleDateFormat sdf = new SimpleDateFormat("HH-mm");
						 * String start1
						 * =sdf.format(zb.getStartTime1()).replaceAll("-", ":");
						 * String end1
						 * =sdf.format(zb.getEndTime1()).replaceAll("-", ":");
						 * String start2
						 * =sdf.format(zb.getStartTime2()).replaceAll("-", ":");
						 * String end2
						 * =sdf.format(zb.getEndTime2()).replaceAll("-", ":");
						 * String start3 =
						 * sdf.format(zb.getStartTime3()).replaceAll("-",":");
						 * String end3
						 * =sdf.format(zb.getEndTime3()).replaceAll("-", ":");
						 * zhibo.setTodaytimeperiod1(start1 + "~" + end1);
						 * zhibo.setTodaytimeperiod2(start2 + "~" + end2);
						 * zhibo.setTodaytimeperiod3(start3 + "~" + end3);
						 */
						// 判断是否在直播中 false为未直播 true为正在直播
						Boolean flag = false;
						Long starts1 = zb.getStartTime1().getTime();
						Long Ends1 = zb.getEndTime1().getTime();
						Long starts2 = zb.getStartTime2().getTime();
						Long Ends2 = zb.getEndTime2().getTime();
						Long starts3 = zb.getStartTime3().getTime();
						Long Ends3 = zb.getEndTime3().getTime();
						//Long date1 =DateUtil.getTime(datetime);
						Long date1 = new Date().getTime();
						int j = 0;
						int i = 3;
						while (j<=i) {
							if(date1 < starts1){
								zhibo.setStartTime(zb.getStartTime1());
								zhibo.setEndTime(zb.getEndTime1());
								break;
							}else if(starts1 <= date1 && Ends1 >= date1){
								zhibo.setStartTime(zb.getStartTime1());
								zhibo.setEndTime(zb.getEndTime1());
								break;
							}else if(date1 > Ends1){
								zhibo.setStartTime(zb.getStartTime2());
							}
							
							
							if(date1 < starts2){
								zhibo.setStartTime(zb.getStartTime2());
								zhibo.setEndTime(zb.getEndTime2());
								break;
							}else if(starts2 <= date1 && Ends2 >= date1){
								zhibo.setStartTime(zb.getStartTime2());
								zhibo.setEndTime(zb.getEndTime2());
								break;
							}else if(date1 > Ends2){
								zhibo.setStartTime(zb.getStartTime3());
							}
							
							
							if(date1 < starts3){
								zhibo.setStartTime(zb.getStartTime3());
								zhibo.setEndTime(zb.getEndTime3());
								break;
							}else if(starts3 <= date1 && Ends3 >= date1){
								zhibo.setStartTime(zb.getStartTime3());
								zhibo.setEndTime(zb.getEndTime3());
							}
							j++;
						}
						
						
				/*		Long date = new Date().getTime();
						if (starts1 <= date && Ends1 >= date) {
							
							flag = true;
						}else{
							zhibo.setStartTime(zb.getStartTime1());
						}
						if (starts2 <= date && Ends2 >= date) {
							
							flag = true;
						}else{
							zhibo.setStartTime(zb.getStartTime2());
						
						}
						if (starts3 <= date && Ends3 >= date) {
						
							flag = true;
						}else{
							zhibo.setStartTime(zb.getStartTime3());
						}*/
						zhibo.setJudgeZhibo(flag);
						// 判断是否在直播中 false为点播播 true为1是直播
						zhibo.setJudgeDianbo(true);
					}
				}
			}
			if(recommendList != null && recommendList.size() > 0){
				map.put("zbList", recommendList);
				result.setObject(map);
				message = "获取直播成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				map.put("zbList", recommendList);
				result.setObject(map);
				message = "没有获取直播数据";
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods index"+e.getMessage());
		}
		result.setMessage(message);	
		return result; 
	}
	/*--------------------新接口获取单个直播----------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "single")
	@MemberEvent(desc ="安卓/IOS 获取单个直播")
	@ResponseBody
	public MobileResultBean single(){
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		ZhiboCourseSearch zhibocoursesearch = new ZhiboCourseSearch();
		List<ZhiboCourseModel> zhibocourseview = new ArrayList<ZhiboCourseModel>();
		map.put("method", "single");
		String message = "";
		try {
			
			
			//当前时间
			String datetime =request.getParameter("datetime");
			if(StringUtils.isBlank(datetime)){
				result.setMessage("直播时间不能为空");
				return result;
			}
			String zhiboId = request.getParameter("zhiboId"); //直播id
			if(StringUtils.isBlank(zhiboId)){
				result.setMessage("直播id不能为空");
				return result;
			}
			String talentId=request.getParameter("talentId");//正在直播牛人ID用户id
			String fanId=request.getParameter("fanId");     //当前操作用户IDid
			MemberAttentionSearch search = new MemberAttentionSearch();
			search.setEqualMemberId(talentId);
			search.setEqualFansId(fanId);
			Boolean flag=false;//false默认
			if(StringUtils.isNotEmpty(fanId)){
				MemberAttentionModel memberAttention = zhanglmServiceManage.memberAttentionService.findBySearch(search);
				if(null != memberAttention){
					flag=true;//true为已关注
				}
			}
			ZhiboLiveView zb = new ZhiboLiveView();
			zhibocoursesearch.setEqualzbId(zhiboId);
			zhibocourseview = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(zhibocoursesearch);
			ZhiboLiveView singleOne=zhanglmServiceManage.zhiboLiveService.findViewById(zhiboId);
			//直播
			if("0001".equals(singleOne.getColumnCode())){
				DefaultSearch defaultsearch = new DefaultSearch();
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if(null == singleOne.getPhoto()){
					singleOne.setPhoto(defaultModel.getImgUrl());
				}
				if (zhibocourseview != null && zhibocourseview.size() > 0) {
					zb.setStartTime1(zhibocourseview.get(0).getStartTime());
					zb.setEndTime1(zhibocourseview.get(0).getEndTime());
					zb.setTitle1(zhibocourseview.get(0).getTitle());
					zb.setLecturer1(zhibocourseview.get(0).getLecturer());
					zb.setStartTime2(zhibocourseview.get(1).getStartTime());
					zb.setEndTime2(zhibocourseview.get(1).getEndTime());
					zb.setTitle2(zhibocourseview.get(1).getTitle());
					zb.setLecturer2(zhibocourseview.get(1).getLecturer());
					zb.setStartTime3(zhibocourseview.get(2).getStartTime());
					zb.setEndTime3(zhibocourseview.get(2).getEndTime());
					zb.setTitle3(zhibocourseview.get(2).getTitle());
					zb.setLecturer3(zhibocourseview.get(2).getLecturer());
				}
				Long starts1 = zb.getStartTime1().getTime();
				Long Ends1 = zb.getEndTime1().getTime();
				Long starts2 = zb.getStartTime2().getTime();
				Long Ends2 = zb.getEndTime2().getTime();
				Long starts3 = zb.getStartTime3().getTime();
				Long Ends3 = zb.getEndTime3().getTime();
				Long date1 =DateUtil.getTime(datetime);
				int j = 0;
				int i = 3;
				while (j<=i) {
					if(date1 < starts1){
						singleOne.setStartTime(zb.getStartTime1());
						singleOne.setEndTime(zb.getEndTime1());
						break;
					}else if(starts1 <= date1 && Ends1 >= date1){
						singleOne.setStartTime(zb.getStartTime1());
						singleOne.setEndTime(zb.getEndTime1());
						break;
					}else if(date1 > Ends1){
						singleOne.setStartTime(zb.getStartTime2());
					}
					
					
					if(date1 < starts2){
						singleOne.setStartTime(zb.getStartTime2());
						singleOne.setEndTime(zb.getEndTime2());
						break;
					}else if(starts2 <= date1 && Ends2 >= date1){
						singleOne.setStartTime(zb.getStartTime2());
						singleOne.setEndTime(zb.getEndTime2());
						break;
					}else if(date1 > Ends2){
						singleOne.setStartTime(zb.getStartTime3());
					}
					
					
					if(date1 < starts3){
						singleOne.setStartTime(zb.getStartTime3());
						singleOne.setEndTime(zb.getEndTime3());
						break;
					}else if(starts3 <= date1 && Ends3 >= date1){
						singleOne.setStartTime(zb.getStartTime3());
						singleOne.setEndTime(zb.getEndTime3());
					}
					j++;
				}
	/*
				while (j<=i) {
					if(date1 < starts1){
						singleOne.setStartTime(zb.getStartTime1());
						singleOne.setEndTime(zb.getEndTime1());
						break;
					}else if(starts1 <= date1 && Ends1 >= date1){
						singleOne.setStartTime(zb.getStartTime1());
						singleOne.setEndTime(zb.getEndTime1());
						break;
					}else if(date1 > Ends1){
						singleOne.setStartTime(zb.getStartTime2());
						
					}
					
					
					if(date1 < starts2){
						singleOne.setStartTime(zb.getStartTime2());
						singleOne.setEndTime(zb.getEndTime2());
						break;
					}else if(starts2 <= date1 && Ends2 >= date1){
						singleOne.setStartTime(zb.getStartTime2());
						singleOne.setEndTime(zb.getEndTime2());
						break;
					}else if(date1 > Ends2){
						singleOne.setStartTime(zb.getStartTime3());
						break;
					}
					
					
					if(date1 < starts3){

						singleOne.setStartTime(zb.getStartTime3());
						singleOne.setEndTime(zb.getEndTime3());
						if(date1 > Ends1){
							singleOne.setStartTime(zb.getStartTime2());
						}else if(date1 > Ends2){
							singleOne.setStartTime(zb.getStartTime3());
							break;
						}
						break;
					}else if(starts3 <= date1 && Ends3 >= date1){
						singleOne.setStartTime(zb.getStartTime3());
						singleOne.setEndTime(zb.getEndTime3());
					}
					j++;
				}*/
			
				map.put("flag", flag);
				map.put("zbsingleOne",singleOne);
				result.setObject(map);
				message = "获取成功";
				result.setStatus(MobileResultBean.SUCCESS);
				result.setMessage(message);
				return result; 
			}
			//点播
			DboLiveView dbList = zhanglmServiceManage.dboLiveServiceI.findViewById(zhiboId);
			if("0002".equals(dbList.getColumnCode())){
				DefaultSearch defaultsearch = new DefaultSearch();
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if(null == dbList.getPhoto()){
					dbList.setPhoto(defaultModel.getImgUrl());
				}
				map.put("flag", flag);
				map.put("dbsingleOne",dbList);
				result.setObject(map);
				message = "获取成功";
				result.setStatus(MobileResultBean.SUCCESS);
				result.setMessage(message);
				return result; 
			}
			map.put("flag", flag);
			map.put("singleOne",singleOne);
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	
	/*--------------------新接口 单个名人往期回看   未测试----------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "previousWatchSingle")
	@MemberEvent(desc ="安卓/IOS 单个名人往期回看")
	@ResponseBody
	public MobileResultBean previousWatchSingle(ZhiboLiveSearch search,DboLiveSearch dbsearch) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "previousWatchSingle");
		String message = "";
		try {
			//点播set值
			//点播
			//dbsearch.setEqualIsLock(true);
			List<DboLiveView> dbList = zhanglmServiceManage.dboLiveServiceI.viewList(dbsearch);
			DefaultSearch defaultsearch = new DefaultSearch();
			List<DboLiveView> dbview = new ArrayList<DboLiveView>();
			for (DboLiveView dbo : dbList) {
				dbo.setIntro("直播讲师:" + dbo.getUserName());
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if (null == dbo.getPhoto()) {
					dbo.setPhoto(defaultModel.getImgUrl());
				}
				//查询关注多少粉丝
				MemberAttentionSearch gzsearch = new MemberAttentionSearch();
				//点播粉丝数量 
				gzsearch.setEqualMemberId(dbo.getUserId());
				Long fansNum = zhanglmServiceManage.memberAttentionService.count(gzsearch);
				if(null == fansNum){
					dbo.setFanNum(new Long(0));
				}else{
					dbo.setFanNum(fansNum);
				}
				// 点播
				if ("0002".equals(dbo.getColumnCode())) {
					// 判断是否在直播中 false为未直播 true为正在直播
					Boolean flag = false;
					Long starts1 = dbo.getStartTime().getTime();
					Long Ends1 = dbo.getEndTime().getTime();
					Long date = new Date().getTime();
					if (starts1 <= date && Ends1 >= date) {
						flag = true;
					}
					dbo.setJudgeZhibo(flag);
					// 判断是否在直播中 false为点播播 true为1是直播
					dbo.setJudgeDianbo(false);
				} 
				//添加集合
				dbview.add(dbo);
			}
			
			if (dbview != null && dbview.size() > 0) {
				map.put("WatchList", dbview);
				result.setObject(map);
				message = "获取推荐直播成功";
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				map.put("WatchList", dbview);
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods index"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}

	//播放次数   测试完成
	@RequestMapping(method = RequestMethod.POST, value = "zhiboClick")
	@MemberEvent(desc ="安卓/IOS 直播点击量+1")
	@ResponseBody
	public MobileResultBean zhiboClick() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "zhiboClick");
		String message = "";
		try {
			String zhiboId = request.getParameter("zhiboId");
			ZhiboLiveModel zhibo = zhanglmServiceManage.zhiboLiveService.findById(zhiboId);
			DboLiveModel dbo = zhanglmServiceManage.dboLiveServiceI.findById(zhiboId);
			if(null != zhibo){
				if("0001".equals(zhibo.getColumnCode())){
					Long cilckNum = zhibo.getClickNum();
					if(null != cilckNum){
						zhibo.setClickNum(++cilckNum);
					}else{
						zhibo.setClickNum(1L);
					}
					zhanglmServiceManage.zhiboLiveService.edit(zhibo, getSessionUser());
					result.setObject(map);
					message = "点击量更改成功";
					result.setStatus(MobileResultBean.SUCCESS);
				}
				
			}
			if(null != dbo){
				if("0002".equals(dbo.getColumnCode())) {	
					Long cilckNum = dbo.getClickNum();
					if (null != cilckNum) {
						dbo.setClickNum(++cilckNum);
					} else {
						dbo.setClickNum(1L);
					}
					zhanglmServiceManage.dboLiveServiceI.edit(dbo, getSessionUser());
					result.setObject(map);
					message = "点击量更改成功";
					result.setStatus(MobileResultBean.SUCCESS);
				}
			}
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods zhiboClick"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}

	//在线人线统计     未测试完成
	@RequestMapping(method = RequestMethod.POST, value = "onlinePeopleAmount")
	@MemberEvent(desc ="安卓/IOS 直播在线人数+1")
	@ResponseBody
	public MobileResultBean onlinePeopleAmount() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "onlinePeopleAmount");
		String message = "";
		try {
			String zhiboId = request.getParameter("zhiboId");

			result.setObject(map);
			message = "点击量更改成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods onlinePeopleAmount"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}
	
	

	@RequestMapping(method = RequestMethod.POST, value = "previousNewWatch")
	@MemberEvent(desc ="安卓/IOS 往期回看（最新）")
	@ResponseBody
	public MobileResultBean previousNewWatch(DboLiveSearch search,String famoudId) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "previousNewWatch");
		String message = "";
		try {
			//search.setEqualIsLock(true);
			//search.setRows(3);
			search.setOrder(BaseSearch.Order_Type_Desc);
			search.setEqualUserId(famoudId);
			List<DboLiveView> recommendList = zhanglmServiceManage.dboLiveServiceI.viewList(search);
			DefaultSearch defaultsearch = new DefaultSearch();
			for (DboLiveView zhibo : recommendList) {
					zhibo.setIntro("直播讲师:" + zhibo.getUserName());
					defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
					DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
					if (null == zhibo.getPhoto()) {
						zhibo.setPhoto(defaultModel.getImgUrl());
					}
			}
			if (recommendList != null && recommendList.size() > 0) {
				map.put("NewWatchList", recommendList);
				result.setObject(map);
				message = "获取直播成功";
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "没获取数据";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods index"+e.getMessage());
		}
		result.setMessage(message);
		return result; 
	}

	@RequestMapping(method = RequestMethod.POST, value = "previousTopicWatch")
	@MemberEvent(desc = "安卓/IOS 往期回看（最热）")
	@ResponseBody
	public MobileResultBean previousTopicWatch(DboLiveSearch search,String famoudId) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "previousTopicWatch");
		String message = "";
		try {
			// search.setEqualIsLock(true);
			// search.setRows(3);
			search.setEqualUserId(famoudId);
			List<DboLiveView> recommendList = zhanglmServiceManage.dboLiveServiceI.viewList(search);
			DefaultSearch defaultsearch = new DefaultSearch();
			for (DboLiveView zhibo : recommendList) {
				zhibo.setIntro("直播讲师:" + zhibo.getUserName());
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if (null == zhibo.getPhoto()) {
					zhibo.setPhoto(defaultModel.getImgUrl());
				}
			}
			if (recommendList != null && recommendList.size() > 0) {
				map.put("TopicWatchList", recommendList);
				result.setObject(map);
				message = "获取直播成功";
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "没获取数据";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods index" + e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	
	/*
	 * 直播分享后记录分享后回调数量
	 * 
	 * */
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "Sharelive")
	@MemberEvent(desc = "安卓/IOS圈子 直播分享量")
	@ResponseBody
	public MobileResultBean setSharenumber(String zhiboId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "setSharelive");
		String message = "";
		try {
			if(StringUtils.isBlank(zhiboId)){
				result.setMessage("直播id不能为空");
				return result;
			}
			//直播分享数量     Sharenumber
			ZhiboLiveModel zhiboliveModel = zhanglmServiceManage.zhiboLiveService.findById(zhiboId);
			if (null != zhiboliveModel) {
				Integer sharenum = zhiboliveModel.getShareNum();
				if(null != sharenum){
					zhiboliveModel.setShareNum(++sharenum);
				}else{
					zhiboliveModel.setShareNum(1);
				}
				zhanglmServiceManage.zhiboLiveService.edit(zhiboliveModel, getSessionUser());
				map.put("ShareView", zhiboliveModel);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---setSharenumber---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
}
