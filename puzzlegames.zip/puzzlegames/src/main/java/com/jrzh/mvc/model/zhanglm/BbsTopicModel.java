package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_bbs_topic")
public class BbsTopicModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 标题
     */
    @Column(name = "_title")
    private String title;
    /**
     * 内容
     */
    @Column(name = "_content")
    private String content;
    /**
     * 发布用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 关联用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_user_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel member;
    /**
     * 发布用户昵称
     */
    @Column(name = "_user_name")
    private String userName;
    /**
     * 评论数
     */
    @Column(name = "_discuss")
    private Integer discuss;
    /**
     * 点赞数
     */
    @Column(name = "_praise")
    private Integer praise;
    
    /**
     * 阅读数
     */
    @Column(name = "_readAccount")
    private Integer readAccount;
    
    /**
     * 转发数
     */
    @Column(name = "_transmit")
    private Integer transmit;
    /**
     * 收藏数
     */
    @Column(name = "_collection")
    private Integer collection;
    /**
     * 点击量
     */
    @Column(name = "_click_num")
    private Long clickNum;
    /**
     * 平均值
     */
    @Column(name = "_average")
    private Double average;
    /**
     * 所属类别   改过代码
     */
/*    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = BbsMenuModel.class)
	@JoinColumn(name = "_menu_code", referencedColumnName = "_code",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private BbsMenuModel bbsMenu;*/
        
    /**
     * 所属类别      新圈子改过代码
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = BbsMenuModel.class)
	@JoinColumn(name = "_menu_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private BbsMenuModel bbsMenu;
    /**
     * 所属类别
     */
    @Column(name = "_menu_code")
    private String menuCode;
    /**
     * 话题评论id
     */
    @Column(name = "_menu_id")
    private String menuid;
    /**
     * 状态
     */
    @Column(name = "_status")
    private Integer status;
    /**
     * 审核人
     */
    @Column(name = "_auditer")
    private String auditer;
    /**
     * 审核说明
     */
    @Column(name = "_opinion")
    private String opinion;
    /**
     * 审核时间
     */
    @Column(name="_audit_time")
	private Date auditTime;
    /**
     * 图片路径
     */
    @Column(name="_img_url")
	private String imgUrl;
    
    
    public Integer getReadAccount() {
		return readAccount;
	}

	public void setReadAccount(Integer readAccount) {
		this.readAccount = readAccount;
	}

	public Integer getTransmit() {
		return transmit;
	}

	public void setTransmit(Integer transmit) {
		this.transmit = transmit;
	}

	public Integer getCollection() {
		return collection;
	}

	public void setCollection(Integer collection) {
		this.collection = collection;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public Long getClickNum() {
		return clickNum;
	}

	public void setClickNum(Long clickNum) {
		this.clickNum = clickNum;
	}

	public Double getAverage() {
		return average;
	}

	public void setAverage(Double average) {
		this.average = average;
	}

	public MemberModel getMember() {
		return member;
	}

	public void setMember(MemberModel member) {
		this.member = member;
	}

	public Date getAuditTime() {
		return auditTime;
	}

	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}

	public String getAuditer() {
		return auditer;
	}

	public void setAuditer(String auditer) {
		this.auditer = auditer;
	}

	public String getOpinion() {
		return opinion;
	}

	public void setOpinion(String opinion) {
		this.opinion = opinion;
	}

	public BbsMenuModel getBbsMenu() {
		return bbsMenu;
	}

	public void setBbsMenu(BbsMenuModel bbsMenu) {
		this.bbsMenu = bbsMenu;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setTitle(String title) {
        this.title = title;
    }
    
    public String getTitle() {
        return this.title;
    }
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getContent() {
        return this.content;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }
    public void setDiscuss(Integer discuss) {
        this.discuss = discuss;
    }
    
    public Integer getDiscuss() {
        return this.discuss;
    }
    public void setPraise(Integer praise) {
        this.praise = praise;
    }
    
    public Integer getPraise() {
        return this.praise;
    }
    public void setMenuCode(String menuCode) {
        this.menuCode = menuCode;
    }
    
    public String getMenuCode() {
        return this.menuCode;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    
    public Integer getStatus() {
        return this.status;
    }

	public String getMenuid() {
		return menuid;
	}

	public void setMenuid(String menuid) {
		this.menuid = menuid;
	}

}