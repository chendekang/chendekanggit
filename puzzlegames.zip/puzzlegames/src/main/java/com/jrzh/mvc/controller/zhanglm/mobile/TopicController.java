package com.jrzh.mvc.controller.zhanglm.mobile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.mvc.model.zhanglm.AategoryModel;
import com.jrzh.mvc.model.zhanglm.AnswerModel;
import com.jrzh.mvc.model.zhanglm.BbsCommentsModel;
import com.jrzh.mvc.model.zhanglm.BbsReplyModel;
import com.jrzh.mvc.model.zhanglm.BbsReplyPraiseModel;
import com.jrzh.mvc.model.zhanglm.CollectModel;
import com.jrzh.mvc.model.zhanglm.CommentReplyModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.NumberstatisticsModel;
import com.jrzh.mvc.model.zhanglm.TitleReleaseModel;
import com.jrzh.mvc.model.zhanglm.UseranswersModel;
import com.jrzh.mvc.search.zhanglm.AategorySearch;
import com.jrzh.mvc.search.zhanglm.AnswerSearch;
import com.jrzh.mvc.search.zhanglm.BbsCommentsSearch;
import com.jrzh.mvc.search.zhanglm.BbsReplyPraiseSearch;
import com.jrzh.mvc.search.zhanglm.BbsReplySearch;
import com.jrzh.mvc.search.zhanglm.CollectSearch;
import com.jrzh.mvc.search.zhanglm.CommentReplySearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.NumberstatisticsSearch;
import com.jrzh.mvc.search.zhanglm.ResponseAndResponseSearch;
import com.jrzh.mvc.search.zhanglm.SharePageSearch;
import com.jrzh.mvc.search.zhanglm.TitleReleaseSearch;
import com.jrzh.mvc.search.zhanglm.UseranswersSearch;
import com.jrzh.mvc.view.zhanglm.AategoryView;
import com.jrzh.mvc.view.zhanglm.AnswerView;
import com.jrzh.mvc.view.zhanglm.BbsPraiseView;
import com.jrzh.mvc.view.zhanglm.BbsReplyView;
import com.jrzh.mvc.view.zhanglm.CommentReplyView;
import com.jrzh.mvc.view.zhanglm.SharePageView;
import com.jrzh.mvc.view.zhanglm.TitleReleaseView;

@Controller(TopicController.LOCATION + "TopicController")
@RequestMapping(TopicController.LOCATION)
public class TopicController extends BaseMobileController {
	public static final String LOCATION = "/mobile/topic/";
	public Logger logger = Logger.getLogger(TopicController.class);
	public static int tag =0;

	@RequestMapping(method = RequestMethod.POST, value = "getHomeHotTopics")
	@MemberEvent(desc ="安卓/IOS 获取首页推荐题目")
	@ResponseBody
	public MobileResultBean recommend(String currPage,String pageSize,String userId) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "getHomeHotTopics");
		String message = "";
		Long number = 0L;
		UseranswersSearch usersearch = new UseranswersSearch();
		try {
		/*	if(StringUtils.isBlank(userId)){
				result.setMessage("用户id不能为空");
				return result;
			}*/
			TitleReleaseSearch search = new TitleReleaseSearch();
			search.setEqualIsDisable(true);
			search.setPage(Integer.parseInt(currPage));
			search.setRows(Integer.parseInt(pageSize));
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Desc);
			List<TitleReleaseView> resultview1 = zhanglmServiceManage.titlereleaseservicei.viewListReply(search,userId);

			//根据用户id查询所有做过题目
		/*	List<UseranswersModel> userlist=null;
			if(StringUtils.isNotBlank(userId)){
				usersearch.setEqualUserId(userId);
				userlist = zhanglmServiceManage.useranswersservicei.list(usersearch);
			}
			if(userlist != null && userlist.size() > 0){
				for (int i = 0; i < resultview1.size(); i++) {
					for (int j = 0; j < userlist.size(); j++) {
						//if(StringUtils.isNotBlank(resultview1.get(i).getId())){
							if (resultview1.get(i).getId().equals(userlist.get(j).getQid())) {
								resultview1.remove(i);
								break;
							}
						//}
					}
				}
			}*/
			
			number = zhanglmServiceManage.titlereleaseservicei.count(search);
			if(resultview1 != null && resultview1.size() > 0){
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("homeHotTopicViewList", resultview1);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("homeHotTopicViewList", resultview1);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods getHomeHotTopics"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "getTopicType")
	@MemberEvent(desc = "安卓/IOS圈子 获取题目类型")
	@ResponseBody
	public MobileResultBean getTopicType(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getTopicType");
		try {	
			AategorySearch aategorysearch = new AategorySearch();
			List<AategoryView> aategorylist  = zhanglmServiceManage.aategoryservicei.viewList(aategorysearch);
		    if(aategorylist !=null && aategorylist.size() > 0 ){
		    	map.put("topicTypeList", aategorylist);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
		    }else{
		    	map.put("topicTypeList", aategorylist);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
		    }
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods getTopicType"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	

	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST, value = "getTopicTypetitle")
	@MemberEvent(desc = "安卓/IOS圈子 获取题目类型所有题目")
	@ResponseBody
	public MobileResultBean getTopicTypetitle(String currPage,String pageSize,String typeid,String userId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getTopicTypetitle");
		Long number = 0L;
		UseranswersSearch usersearch = new UseranswersSearch();
		UseranswersSearch usersearch2 = new UseranswersSearch();
		
		TitleReleaseSearch search = new TitleReleaseSearch();
		
		TitleReleaseSearch search2 = new TitleReleaseSearch();
		try {
			search.setEqcategoryid(typeid);
			search.setPage(Integer.parseInt(currPage));
			search.setRows(Integer.parseInt(pageSize));
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Asc);
			//获取所有题目
			List<TitleReleaseModel> resultview1 = zhanglmServiceManage.titlereleaseservicei.list(search);
			//获取所有题目
			List<TitleReleaseModel>  compare= zhanglmServiceManage.titlereleaseservicei.list(search);
			search2.setEqtitleqtag(1);
			//根据用户id查询所有做过题目
			List<UseranswersModel> userlist = null;
			if(StringUtils.isNotBlank(userId)){
				usersearch.setEqualUserId(userId);
				usersearch.setEqcategoryid(typeid);
				userlist = zhanglmServiceManage.useranswersservicei.list(usersearch);
			}
/*			
			for(TitleReleaseModel t : resultview1){
				search2.setEqid(t.getId());
				
				List<TitleReleaseModel> resultview2 = zhanglmServiceManage.titlereleaseservicei.list(search2);
				//获取所有题目
				
				int a = resultview1.size();
				int b = resultview2.size();
				if(a==b){
				}else{
				}
			}
		*/
			//search2.setEqid(resultview1.get(i).getId());
			search2.setEqcategoryid(typeid);
			List<TitleReleaseModel> resultview2 = zhanglmServiceManage.titlereleaseservicei.list(search2);
			//根据用户id查询所有做过题目
			List<UseranswersModel> userlist2 = null;
			if(StringUtils.isNotBlank(userId)){
				usersearch2.setEqualUserId(userId);
				usersearch2.setEqcategoryid(typeid);
			}
			if(userlist != null && userlist.size() > 0){
				for (int i = 0; i < userlist.size(); i++) {
					if(resultview2 != null && resultview2.size() > 0){
						if(userlist.get(i) != null){
						//	usersearch2.setEqtopicId(resultview1.get(i).getId());
							userlist2 = zhanglmServiceManage.useranswersservicei.list(usersearch2);
						}
						//获取所有题目
						int a = userlist2.size();
						int b = compare.size();
						if(a==b){
							break;
						}else{
							for (int j = 0; j < resultview1.size(); j++) {
								if(userlist.get(i) != null){
									if (userlist.get(i).getQid().equals(resultview1.get(j).getId())) {
										
										//if(resultview1.get(i) != null){
											
									/*		if(resultview1.get(i).getTag() != null){
												if(resultview1.get(i).getTag() == 1){
													continue;
												}
											}else{*/
												resultview1.remove(j);
											//}
										//}
									}
									
								}
							}
						}
					}
				}
			}
			
			List<TitleReleaseView> view = new ArrayList<TitleReleaseView>();
				if(resultview1 != null && resultview1.size() > 0){
					for(TitleReleaseModel title : resultview1){
						TitleReleaseView v = new TitleReleaseView();
						//获取分类名称
						AategoryModel aategory = zhanglmServiceManage.aategoryservicei.findById(title.getCategoryid());
						v.setId(title.getId());
						v.setCategoryid(title.getCategoryid());
						v.setTypeName(aategory.getTypeName());
						v.setContent(title.getTitle());
						v.setDiscuss(title.getDiscuss());
						view.add(v);
					}
				}
			number = zhanglmServiceManage.titlereleaseservicei.count(search);
			if(view != null && view.size() > 0){
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("TopicTypetitle", view);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("TopicTypetitle", view);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getTopicTypetitle---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	

	@RequestMapping(method = RequestMethod.POST, value = "getBankHotTopics")
	@MemberEvent(desc = "安卓/IOS圈子 获取题库推荐题目")
	@ResponseBody
	public MobileResultBean getBankHotTopics(String currPage,String pageSize,String userId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getBankHotTopics");
		Long number = 0L;
		UseranswersSearch usersearch = new UseranswersSearch();
		try {
			
			/*if(StringUtils.isBlank(userId)){
				result.setMessage("用户id不能为空");
				return result;
			}*/
			TitleReleaseSearch search = new TitleReleaseSearch();
			search.setEqualIsDisable(true);
			search.setPage(Integer.parseInt(currPage));
			search.setRows(Integer.parseInt(pageSize));
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Asc);
			List<TitleReleaseModel> resultview1 = zhanglmServiceManage.titlereleaseservicei.list(search);

			//根据用户id查询所有做过题目
		/*	List<UseranswersModel> userlist = null;
			if(StringUtils.isNotBlank(userId)){
				usersearch.setEqualUserId(userId);
				userlist = zhanglmServiceManage.useranswersservicei.list(usersearch);
			}
			if(userlist != null && userlist.size() > 0){
				for (int i = 0; i < resultview1.size(); i++) {
					for (int j = 0; j < userlist.size(); j++) {
						//if(StringUtils.isNotBlank(resultview1.get(i).getId())){
							if (resultview1.get(i).getId().equals(userlist.get(j).getQid())) {
								resultview1.remove(i);
								break;
							}
						//}
					}
				}
			}
			*/
			
			List<TitleReleaseView> view = new ArrayList<TitleReleaseView>();
			if(resultview1 != null && resultview1.size() > 0){

				for(TitleReleaseModel title : resultview1){
					TitleReleaseView v = new TitleReleaseView();
					//获取分类名称
					AategoryModel aategory = zhanglmServiceManage.aategoryservicei.findById(title.getCategoryid());
					v.setId(title.getId());
					v.setCategoryid(title.getCategoryid());
					v.setTypeName(aategory.getTypeName());
					v.setContent(title.getTitle());
					v.setDiscuss(title.getDiscuss());
					v.setSorting(title.getSorting());
					view.add(v);
				}
			}
			number = zhanglmServiceManage.titlereleaseservicei.count(search);
			if(view != null && view.size() > 0){
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("userBoardList", view);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("userBoardList", view);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getBankHotTopics---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	

	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST, value = "getTopic")
	@MemberEvent(desc = "安卓/IOS 获取题目选项详情")
	@ResponseBody
	public MobileResultBean getTopic(String topicId,String userId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getTopic");
		AnswerSearch answersearch= new AnswerSearch();
		TitleReleaseSearch titlereleasesearch = new TitleReleaseSearch();
		UseranswersSearch usersearch = new UseranswersSearch();
		try {
			if(StringUtils.isBlank(topicId)){
				result.setMessage("题目id不能为空");
				return result;
			}		
			//最后要结果
			TitleReleaseView titlereleaseview = new TitleReleaseView();
			//获取分类名称
			AategoryModel aategory=null;
			//获取选项与内容
			List<AnswerView> answer=null;
			//第一条页面传参数标题id
			TitleReleaseModel titlereleasemodel = zhanglmServiceManage.titlereleaseservicei.findById(topicId);	
			if(StringUtils.isNotBlank(titlereleasemodel.getCategoryid())){
				 aategory = zhanglmServiceManage.aategoryservicei.findById(titlereleasemodel.getCategoryid());
			}
		
			if(null != titlereleasemodel){
				answersearch.setEqualPid(titlereleasemodel.getId());
				answer = zhanglmServiceManage.answerservicei.viewListallzb(answersearch);
			}
			titlereleaseview.setId(titlereleasemodel.getId());// 题目id
			titlereleaseview.setContent(titlereleasemodel.getContent());// 题目内容
			if (StringUtils.isNotBlank(titlereleasemodel.getImgurl())) {
				titlereleaseview.setImgurl(titlereleasemodel.getImgurl());// 题目图片url
			
			} else {
				titlereleaseview.setImgurl("");// 题目图片url
			}
			titlereleaseview.setCategoryid(titlereleasemodel.getCategoryid());// 分类id
			titlereleaseview.setTypeName(aategory.getTypeName());// 分类名称
			//根据分类id查询所有题目
			List<TitleReleaseModel> titlerelease =null;
			//用户id查询所有做过题
	
			if(StringUtils.isNotBlank(titlereleasemodel.getCategoryid())){
				//查询序列号
				TitleReleaseModel title= zhanglmServiceManage.titlereleaseservicei.findById(topicId);
				titlereleasesearch.setEqcategoryid(titlereleasemodel.getCategoryid());
				if(null != title){
					titlereleasesearch.setEqsorting(title.getSorting());
				}
			    titlerelease = zhanglmServiceManage.titlereleaseservicei.list(titlereleasesearch);
			    UseranswersModel usernalist=null;
			    if(StringUtils.isNotBlank(userId)){
			    	usersearch.setEqualUserId(userId);
			    	usersearch.setEqtopicId(topicId);
					usernalist = zhanglmServiceManage.useranswersservicei.findBySearch(usersearch);
			    }
				if(usernalist != null){
					//for (int i = 0; i < usernalist.size(); i++) {
						if (usernalist.getQid().equals(topicId)) {
							titlereleaseview.setWhethercommit("1");//如果是1就是已做过
							titlereleaseview.setAnswer(usernalist.getAnswer());
							//标识做过
					    	//title.setTag(1);
					    	//zhanglmServiceManage.titlereleaseservicei.edit(title, getSessionUser());
						}else{
							titlereleaseview.setWhethercommit("0");//如果是0就是没做过
							titlereleaseview.setAnswer("");//如果是0就是没做过
						}
					//}
				}else{
					titlereleaseview.setWhethercommit("0");//如果是0就是没做过
					titlereleaseview.setAnswer("");//如果是0就是没做过
				}
			}	
			
		    if(titlerelease != null && titlerelease.size() > 0){
			    
		    	//获取下题id
		    	titlereleaseview.setNexttitleid(titlerelease.get(0).getId());
		    	//titlereleaseview.setSorting(titlerelease.get(0).getSorting());
		    }else{
		    	
		/*    	if(titlereleasemodel.getTag() != null){
		    		if(titlereleasemodel.getTag() ==1){
		    			
		    			titlereleasesearch.setEqtitleqtag(1);
		    			titlerelease = zhanglmServiceManage.titlereleaseservicei.list(titlereleasesearch);
		    			//获取下题id
		    			titlereleaseview.setNexttitleid(titlerelease.get(0).getId());
		    		}
		    	}*/
		    }
			CollectSearch search = new CollectSearch();
			CollectModel model=null;
			if(StringUtils.isNotBlank(userId)){
				search.setEqualCircleId(topicId);
				search.setEqualUserId(userId);
				model = zhanglmServiceManage.collectService.findBySearch(search);
			}
			if(model != null){
				titlereleaseview.setWhethercollection(1);//1是已收藏了
			}else{
				titlereleaseview.setWhethercollection(0);//0是没收藏了
			}
			if(titlereleaseview != null){
				//题目内容
				map.put("topicView", titlereleaseview);
				//题目选项
				map.put("answerViewList", answer);
				message = "获取成功"; 
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				map.put("topicView", titlereleaseview);
				map.put("answerViewList", answer);
				message = "没有题目"; 
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getTopic---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST, value = "sendAnswer")
	@MemberEvent(desc = "安卓/IOS 提交答案")
	@ResponseBody
	public MobileResultBean sendAnswer(String answerId,String topicId,String userId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "sendAnswer");
		AnswerSearch answersearch= new AnswerSearch();
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				if(StringUtils.isBlank(answerId)){
					result.setMessage("答案id不能为空");
					return result;
				}
				if(StringUtils.isBlank(topicId)){
					result.setMessage("题目id不能为空");
					return result;
				}
				
				NumberstatisticsSearch numberstatisticssearch = new NumberstatisticsSearch();
				/*这里需要统计在线人数个数*/
				NumberstatisticsModel numberstatisticsmodel = new NumberstatisticsModel();
				numberstatisticsmodel.setUserId(userId);
				numberstatisticsmodel.setTopicId(topicId);
				numberstatisticssearch.setEqualUserId(userId);//用户id
				numberstatisticssearch.setEqtopicId(topicId);//题目id
				NumberstatisticsModel mode =zhanglmServiceManage.numberstatisticsservicei.findBySearch(numberstatisticssearch);
			//	NumberstatisticsModel mode =zhanglmServiceManage.numberstatisticsservicei.findByField("userId", userId);
				if(null == mode){
					zhanglmServiceManage.numberstatisticsservicei.add(numberstatisticsmodel, getSessionUser());
				}	

				TitleReleaseView titlereleaseview = new TitleReleaseView();
				//题目
				TitleReleaseModel titlereleasemodel = zhanglmServiceManage.titlereleaseservicei.findById(topicId);	
				//答案
				UseranswersModel usermode = new UseranswersModel();
				UseranswersSearch useranswerssearch = new UseranswersSearch();
				useranswerssearch.setEqualUserId(userId);
				useranswerssearch.setEqtopicId(topicId);
		
				//获取选项与内容
				//题目
				AnswerModel answermodel = zhanglmServiceManage.answerservicei.findById(answerId);
				if(null != answermodel){
				
					Double correctcount = titlereleasemodel.getCorrectcount();
					Integer wrongcount = titlereleasemodel.getWrongcount();
					if("1".equals(answermodel.getAnswer())){
						map.put("isCurrect", MobileResultBean.SUCCESS);//1代码回答正确
						usermode.setResult(MobileResultBean.SUCCESS);
						if(null != correctcount){
							correctcount++;
							titlereleasemodel.setCorrectcount(correctcount); 	
						}else{
							titlereleasemodel.setCorrectcount(1d);
						}
					}else{
						map.put("isCurrect", MobileResultBean.ERROR);//0代码回答错误
						usermode.setResult(MobileResultBean.ERROR);
						if(null != wrongcount){
							wrongcount++;
							titlereleasemodel.setWrongcount(wrongcount);
							titlereleasemodel.setWrongcount(1);
						}
					}	
				}	
				//查询题目列表
				TitleReleaseModel title= zhanglmServiceManage.titlereleaseservicei.findById(topicId);
				UseranswersModel usermodel = zhanglmServiceManage.useranswersservicei.findBySearch(useranswerssearch);
				if(null == usermodel ){
					usermode.setUid(userId);
					usermode.setQid(topicId);
					usermode.setAnswer(answerId);
					usermode.setCategoryid(title.getCategoryid());
					
					
					//加一个分类id
					
					
					
					
					
					//添加用户答案
					zhanglmServiceManage.useranswersservicei.add(usermode, getSessionUser());
				
					if(null != title){
						//标识做过
						title.setTag(1);
						zhanglmServiceManage.titlereleaseservicei.edit(title, getSessionUser());
					}
				}
/*
				UseranswersSearch usersearch = new UseranswersSearch();
				TitleReleaseModel title = zhanglmServiceManage.titlereleaseservicei.findById(topicId);
				UseranswersModel usernalist = null;
				if (StringUtils.isNotBlank(userId)) {
					usersearch.setEqualUserId(userId);
					usersearch.setEqtopicId(topicId);
					usernalist = zhanglmServiceManage.useranswersservicei.findBySearch(usersearch);
				}
				if (usernalist != null) {
					// for (int i = 0; i < usernalist.size(); i++) {
					if (usernalist.getQid().equals(topicId)) {
						//titlereleaseview.setWhethercommit("1");// 如果是1就是已做过
						//titlereleaseview.setAnswer(usernalist.getAnswer());
						// 标识做过
						if(title != null ){
							title.setTag(1);
							zhanglmServiceManage.titlereleaseservicei.edit(title, getSessionUser());
						}
					} else {
						//titlereleaseview.setWhethercommit("0");// 如果是0就是没做过
						//titlereleaseview.setAnswer("");// 如果是0就是没做过
					}
					// }
				}
				
				*/
				
				//题目评论数增加数
				TitleReleaseModel titleModel = zhanglmServiceManage.titlereleaseservicei.findById(topicId);
				//Integer praiseNum = topicModel.getPraise();
				Integer discussNum = titleModel.getDiscuss();
				if(null != discussNum){
					titleModel.setDiscuss(discussNum + 1);
				} else {
					titleModel.setDiscuss(1);
				}
				BbsReplySearch bbsreplysearch = new BbsReplySearch();
				// 添加评论数据
				BbsReplyModel reply = new BbsReplyModel();
				//bbsreplysearch.setEqualTopicId(topicId);
				//bbsreplysearch.setEqualuserId(userId);
				
				//BbsReplyModel bbsreplymodel = zhanglmServiceManage.bbsReplyService.findBySearch(bbsreplysearch);
				//if(null == bbsreplymodel){
					reply.setTopicId(topicId);
					reply.setUserId(userId);
					reply.setContent(answermodel.getAnswercontent());
					reply.setPraise(0);
					zhanglmServiceManage.bbsReplyService.add(reply, getSessionUser());
				//}
				zhanglmServiceManage.titlereleaseservicei.edit(titleModel, getSessionUser());
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getTopic---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	
	@RequestMapping(method = RequestMethod.POST, value = "getSharePage")
	@MemberEvent(desc ="安卓/IOS 获取分享页面内容")
	@ResponseBody
	public MobileResultBean getSharePage() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "getSharePage");
		String message = "";
		try {
			SharePageSearch search = new SharePageSearch();
			search.setEqualIsDisable(false);
			search.setOrder(BaseSearch.Order_Type_Desc);
			SharePageView pageView = zhanglmServiceManage.sharePageService.firstView(search);
			map.put("pageView", pageView);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	

	/*
	 * 获取分享题目一条数据
	 * 
	 * */
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "setSharenumber")
	@MemberEvent(desc = "安卓/IOS圈子 获取题目一条数据")
	@ResponseBody
	public MobileResultBean setSharenumber(String topicId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "setSharenumber");
		String message = "";
		try {
			if(StringUtils.isBlank(topicId)){
				result.setMessage("题目id不能为空");
				return result;
			}
			//分享题目
			TitleReleaseModel topicModel = zhanglmServiceManage.titlereleaseservicei.findById(topicId);
			if (null != topicModel) {
				map.put("ShareView", topicModel);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---setSharenumber---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST, value = "getTopicParsing")
	@MemberEvent(desc = "安卓/IOS 获取题目解析")
	@ResponseBody
	public MobileResultBean getTopicParsing(String topicId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getTopicParsing");
		AnswerSearch answersearch= new AnswerSearch();
		try {
			TitleReleaseView titlereleaseview = new TitleReleaseView();
			TitleReleaseModel titlereleasemodel = zhanglmServiceManage.titlereleaseservicei.findById(topicId);
			// 获取分类名称
			AategoryModel aategory = null;
			if (StringUtils.isNotBlank(titlereleasemodel.getCategoryid())) {
				aategory = zhanglmServiceManage.aategoryservicei.findById(titlereleasemodel.getCategoryid());
			}
			titlereleaseview.setId(titlereleasemodel.getId());// 题目id
			titlereleaseview.setCategoryid(titlereleasemodel.getCategoryid());// 分类id
			titlereleaseview.setTypeName(aategory.getTypeName());// 分类名称
			titlereleaseview.setAnalysis(titlereleasemodel.getAnalysis());// 题目解析
			if (null != titlereleaseview) {
				// 题目解析内容
				map.put("parsingView", titlereleaseview);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				map.put("parsingView", titlereleaseview);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getTopicParsing---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "addComment")
	@MemberEvent(desc = "安卓/IOS圈子添加题目评论")
	@ResponseBody
	public MobileResultBean addComment(String topicId,String content){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addComment");
		try {
	
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				MemberModel member = zhanglmServiceManage.memberService.findById(userId);
				if(StringUtils.isBlank(topicId)){
					result.setMessage("题目id不能为空");
					return result;
				}
				if(StringUtils.isBlank(content)){
					result.setMessage("评论内容不能为空");
					return result;
				}
				//添加评论数据
				BbsReplyModel reply = new BbsReplyModel();
				reply.setTopicId(topicId);
				reply.setUserId(userId);
				reply.setContent(content);
				reply.setPraise(0);

				//题目评论数
				TitleReleaseModel titleModel = zhanglmServiceManage.titlereleaseservicei.findById(topicId);
				Integer discussNum = titleModel.getDiscuss();
				if(null != discussNum){
					++discussNum;
					titleModel.setDiscuss(discussNum);
				}else{
					titleModel.setDiscuss(1);
				}
				zhanglmServiceManage.bbsReplyService.add(reply, getSessionUser());
				zhanglmServiceManage.titlereleaseservicei.edit(titleModel, getSessionUser());
				message = "谢谢评论";
				System.out.println(message);
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);	
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---addComment---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "getTopicComment")
	@MemberEvent(desc = "安卓/IOS圈子 获取评论的评论列表")
	@ResponseBody
	public MobileResultBean getTopicComment(String topicId,String userId,String currPage,String pageSize){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getTopicComment	");
		Long number = 0L;
		try {
			if(StringUtils.isBlank(topicId)){
				result.setMessage("题目id不能为空");	
				return result;
			}
			BbsReplySearch replySearch = new BbsReplySearch();
			TitleReleaseView topic = new TitleReleaseView();
			List<BbsPraiseView> viewList = new ArrayList<BbsPraiseView>();
			//添加评论内容
			List<BbsReplyView> replyList = new ArrayList<BbsReplyView>();
			List<CommentReplyView> commentList = new ArrayList<CommentReplyView>();
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			if(StringUtils.isNotBlank(topicId)){
				topic = zhanglmServiceManage.titlereleaseservicei.findViewById(topicId);
				//查询回复  评论列表
				replySearch.setEqualTopicId(topic.getId());
				replySearch.setPage(Integer.parseInt(currPage));
				replySearch.setRows(Integer.parseInt(pageSize));
				replySearch.setSort("createTime");
				replySearch.setOrder(BaseSearch.Order_Type_Desc);
				replyList = zhanglmServiceManage.bbsReplyService.viewListbbsReply(replySearch,userId);
				for(BbsReplyView reply : replyList){
					if(null ==reply.getReplynumber()){
						reply.setReplynumber(0);
					}
					if(StringUtils.isBlank(reply.getUserPhoto())){
						if(defaultImg != null){
							reply.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				//查公共回复信息
				CommentReplySearch commentreplysearch = new CommentReplySearch();
				for(BbsReplyView reply : replyList){
					commentreplysearch.setSort("createTime");
					commentreplysearch.setOrder(BaseSearch.Order_Type_Desc);
					commentreplysearch.setEqualcommentId(reply.getId());
					commentList = zhanglmServiceManage.commentReplyService.viewListCommentReply(commentreplysearch,userId);
					reply.setCommentreplyview(commentList);
				}
			}
			number = zhanglmServiceManage.bbsReplyService.count(replySearch);
			if (replyList != null && replyList.size() > 0) {
				map.put("currPage", currPage);
				map.put("number", number);
				//题目评论集合
				map.put("commentViewList", replyList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getTopicComment---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	

	@RequestMapping(method = RequestMethod.POST, value = "addCommentReply")
	@MemberEvent(desc = "安卓/IOS圈子 添加评论的回复")
	@ResponseBody
	public MobileResultBean addCommentReply(String userId,String comment,String commentId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addCommentReply");
		try {
			if(!isLogin()){
				message = "登陆失效";
			} else {
				CommentReplyModel model = new CommentReplyModel();
				model.setContent(comment);
				// model.setReplyId(replyId);
				model.setUserId(userId);
				model.setCommentId(commentId);
				model.setPraise(0);
				zhanglmServiceManage.commentReplyService.add(model, getMobileUser());
				// 评论回复+1
				BbsReplyModel topicModel = zhanglmServiceManage.bbsReplyService.findById(commentId);
				Integer replynumber = topicModel.getReplynumber();
				// Integer discussNum = topicModel.getDiscuss();
				if (null != replynumber) {
					replynumber++;
					topicModel.setReplynumber(replynumber);
				} else {
					topicModel.setReplynumber(1);
				}
				zhanglmServiceManage.bbsReplyService.edit(topicModel, getSessionUser());
				message = "评论回复成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(message);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "addReply")
	@MemberEvent(desc = "安卓/IOS圈子 添加回复的回复")
	@ResponseBody
	public MobileResultBean addReply(String userId,String comment,String replyId,String commentId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addReply");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				if(StringUtils.isBlank(replyId)){
					result.setMessage("回复id不能为空");
					return result;
				}					
				CommentReplyModel model = new CommentReplyModel();
				CommentReplyModel commentreplymodel = zhanglmServiceManage.commentReplyService.findById(replyId);
				if(null != commentreplymodel){
					model.setReplyname(commentreplymodel.getMember().getNickName());
				}
				model.setContent(comment);
				model.setReplyId(replyId);
				model.setUserId(userId);
				//model.setReplyuserId(userId);//回复人用户id
				model.setCommentId(commentId);
				model.setState(1);//1是回复回复
				zhanglmServiceManage.commentReplyService.add(model,getMobileUser());
				message = "评论回复成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(message);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "getCommentReplys")
	@MemberEvent(desc = "安卓/IOS圈子  获取评论的回复")
	@ResponseBody
	public MobileResultBean getCommentReplys(String commentId,String userId,String currPage,String pageSize){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getCommentReplys	");
		CommentReplySearch commentreplysearch = new CommentReplySearch();
		ResponseAndResponseSearch ResponseAndResponseSearch=new ResponseAndResponseSearch();
		Long number = 0L;
		try {
			 List<CommentReplyView> commentreplyview=null;
			if (StringUtils.isNotBlank(commentId)) {
				
				commentreplysearch.setPage(Integer.parseInt(currPage));
				commentreplysearch.setRows(Integer.parseInt(pageSize));
				commentreplysearch.setSort("createTime");
				commentreplysearch.setOrder(BaseSearch.Order_Type_Desc);
				commentreplysearch.setEqualcommentId(commentId);
				commentreplyview = zhanglmServiceManage.commentReplyService.viewListCommentReply(commentreplysearch,
						userId);
			}
			number = zhanglmServiceManage.commentReplyService.count(commentreplysearch);
			if (commentreplyview != null && commentreplyview.size() > 0) {
				map.put("currPage", currPage);
				map.put("number", number);
				//题目评论集合
				map.put("replyViewList", commentreplyview);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getCommentReplys---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "commentAddPraise")
	@MemberEvent(desc = "安卓/IOS圈子 评论点赞")
	@ResponseBody
	public MobileResultBean commentAddPraise(String commentId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "commentAddPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				
				if(StringUtils.isBlank(commentId)){
					result.setMessage("评论id不能为空");
					return result;
				}	
				BbsCommentsSearch search = new BbsCommentsSearch();	
				search.setEqualcommentsId(commentId);
				search.setEqualUserId(userId);
				BbsCommentsModel praiseModel = zhanglmServiceManage.BbsCommentsServiceI.findBySearch(search);
				if(praiseModel != null){
					result.setMessage("您已点过赞了");
					return result;
				}
				//添加点赞数据
				praiseModel = new BbsCommentsModel();
				praiseModel.setCommentsId(commentId);
				praiseModel.setUserId(userId);
				zhanglmServiceManage.BbsCommentsServiceI.add(praiseModel, getSessionUser());
				
				//话题点赞+1，计算平均数
				BbsReplyModel topicModel = zhanglmServiceManage.bbsReplyService.findById(commentId);
				Integer praiseNum = topicModel.getPraise();
				if(null != praiseNum){
					praiseNum++;
					topicModel.setPraise(praiseNum);
				}else{
					topicModel.setPraise(1);
				}
				zhanglmServiceManage.bbsReplyService.edit(topicModel, getSessionUser());
				message = "谢谢点赞";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "replyAddPraise")
	@MemberEvent(desc = "安卓/IOS圈子 回复点赞")
	@ResponseBody
	public MobileResultBean replyAddPraise(String replyId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "replyAddPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				if(StringUtils.isBlank(replyId)){
					result.setMessage("回复id不能为空");
					return result;
				}
				String userId = getSessionUser().getId();
				//评论id
				//String commentsId = request.getParameter("commentsId");
				//查看用户是否点过赞
				//BbsPraiseSearch search = new BbsPraiseSearch();
				BbsReplyPraiseSearch search = new BbsReplyPraiseSearch();	
				search.setEqualreplyId(replyId);
				search.setEqualUserId(userId);
				BbsReplyPraiseModel praiseModel = zhanglmServiceManage.BbsReplyPraiseServiceI.findBySearch(search);
				if(praiseModel != null){
					result.setMessage("您已点过赞了");
					return result;
				}
				//添加回复点赞数据
				praiseModel = new BbsReplyPraiseModel();
				praiseModel.setReplypraiseid(replyId);
				praiseModel.setUserId(userId);
				zhanglmServiceManage.BbsReplyPraiseServiceI.add(praiseModel, getSessionUser());
				
				//回复点赞+1
				CommentReplyModel commentreplymodel = zhanglmServiceManage.commentReplyService.findById(replyId);
				Integer praiseNum = commentreplymodel.getPraise();
				if(null != praiseNum){
					praiseNum++;
					commentreplymodel.setPraise(praiseNum);
				}else{
					commentreplymodel.setPraise(1);
				}
				zhanglmServiceManage.commentReplyService.edit(commentreplymodel, getSessionUser());
				message = "谢谢点赞";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}

	@RequestMapping(method = RequestMethod.POST, value = "addCollect")
	@MemberEvent(desc = "安卓/IOS 添加收藏")
	@ResponseBody
	public MobileResultBean collect(String circleId){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "addCollect");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				
				if(StringUtils.isBlank(circleId)){
					result.setMessage("收藏id不能为空");
					return result;
				}
				CollectModel model = new CollectModel();
				//话题id
				model.setCircleId(circleId);
				model.setUserId(userId);
				zhanglmServiceManage.collectService.add(model, getSessionUser());

				message = "收藏成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---addCollect---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "cancelCollect")
	@MemberEvent(desc = "安卓/IOS 取消收藏")
	@ResponseBody
	public MobileResultBean cancelCollect(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "cancelCollect");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String circleId = request.getParameter("circleId");
				if(StringUtils.isBlank(circleId)){
					result.setMessage("收藏id不能为空");
					return result;
				}
				String userId = getSessionUser().getId();
				CollectSearch search = new CollectSearch();
				search.setEqualUserId(userId);
				search.setEqualCircleId(circleId);
				CollectModel model = zhanglmServiceManage.collectService.findBySearch(search);
				zhanglmServiceManage.collectService.delete(model, getSessionUser());
				message = "取消收藏成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---cancelCollect---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	

	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "getReplysposttitle")
	@MemberEvent(desc = "安卓/IOS圈子  获取回复后题目")
	@ResponseBody
	public MobileResultBean getReplysposttitle(String userId,String currPage,String pageSize){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getReplysposttitle");
		CommentReplySearch commentreplysearch = new CommentReplySearch();
		ResponseAndResponseSearch ResponseAndResponseSearch=new ResponseAndResponseSearch();
		Long number = 0L;
		try {
			if (StringUtils.isBlank(userId)) {
				result.setMessage("用户id不能为空");
				return result;
			}
			BbsReplySearch bbsreplysearch = new BbsReplySearch();
			//commentreplysearch.setPage(Integer.parseInt(currPage));
			//commentreplysearch.setRows(Integer.parseInt(pageSize));
			//commentreplysearch.setSort("createTime");
			//commentreplysearch.setOrder(BaseSearch.Order_Type_Desc);
/*			commentreplysearch.setEquserId(userId);
			List<CommentReplyView> commentreplyview = zhanglmServiceManage.commentReplyService.viewList(commentreplysearch);
			Set<CommentReplyView> commentreply = new HashSet<CommentReplyView>();
			if(commentreplyview != null && commentreplyview.size() > 0){
				commentreply.addAll(commentreplyview);
			}*/
			List<TitleReleaseView> replymodel = new ArrayList<TitleReleaseView>();
			// for(CommentReplyView reqly : commentreply){
			//获取所有评论
			bbsreplysearch.setEqualuserId(userId);
			bbsreplysearch.setSort("createTime");
			bbsreplysearch.setOrder(BaseSearch.Order_Type_Desc);
			List<BbsReplyView> bbsreplyview = zhanglmServiceManage.bbsReplyService.viewList(bbsreplysearch);
			for (BbsReplyView bbsreply : bbsreplyview) {
				
				TitleReleaseView titlemodel = zhanglmServiceManage.titlereleaseservicei.findViewById(bbsreply.getTopicId());
				if (null != titlemodel) {
					// 获取分类名称
					AategoryModel aategory = zhanglmServiceManage.aategoryservicei.findById(titlemodel.getCategoryid());
					if (null != aategory) {
						titlemodel.setTypeName(aategory.getTypeName());
					}
					replymodel.add(titlemodel);
				}
			}
			//number = zhanglmServiceManage.commentReplyService.count(commentreplysearch);
			if (replymodel != null && replymodel.size() > 0) {
				//map.put("currPage", currPage);
			//	map.put("number", number);
				// map.put("authorView", topic);
				// 题目评论集合
				map.put("collentView", replymodel);
				// map.put("commentList", commentList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.SUCCESS);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getReplysposttitle---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}

	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "addreport")
	@MemberEvent(desc = "安卓/IOS圈子  添加举报")
	@ResponseBody
	public MobileResultBean report(String userId,String replyId,String commenId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addreport");
		CommentReplySearch commentreplysearch = new CommentReplySearch();
		ResponseAndResponseSearch ResponseAndResponseSearch=new ResponseAndResponseSearch();
		Long number = 0L;
		try {
			if (StringUtils.isBlank(userId)) {
				result.setMessage("用户id不能为空");
				return result;
			}
			commentreplysearch.setEquserId(userId);
			List<CommentReplyView> commentreplyview = zhanglmServiceManage.commentReplyService.viewList(commentreplysearch);
			Set<CommentReplyView> commentreply = new HashSet<CommentReplyView>();
			if(commentreplyview != null && commentreplyview.size() > 0){
				commentreply.addAll(commentreplyview);
			}
			List<TitleReleaseView> replymodel = new ArrayList<TitleReleaseView>();
						
			for(CommentReplyView reqly : commentreply){
				
				BbsReplyModel commentmodel = zhanglmServiceManage.bbsReplyService.findById(reqly.getCommentId());
				if(null != commentmodel){
					TitleReleaseView titlemodel = zhanglmServiceManage.titlereleaseservicei.findViewById(commentmodel.getTopicId());
					if(null != titlemodel){
						//获取分类名称
						AategoryModel aategory = zhanglmServiceManage.aategoryservicei.findById(titlemodel.getCategoryid());
						if(null != aategory){
							titlemodel.setTypeName(aategory.getTypeName());
						}
						replymodel.add(titlemodel);
					}
				} 	
			}

			number = zhanglmServiceManage.commentReplyService.count(commentreplysearch);
			if (replymodel != null && replymodel.size() > 0) {
				map.put("collentlsit", replymodel);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---addreport---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}	
	
	
	@RequestMapping(method = RequestMethod.POST, value = "cancelcommentAddPraise")
	@MemberEvent(desc = "安卓/IOS 取消 评论点赞")
	@ResponseBody
	public MobileResultBean cancelcommentAddPraise(String commentId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "cancelcommentAddPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				
				if (StringUtils.isBlank(commentId)) {
					result.setMessage("评论id不能为空");
					return result;
				}
				String userId = getSessionUser().getId();
				BbsCommentsSearch search = new BbsCommentsSearch();	
				search.setEqualcommentsId(commentId);
				search.setEqualUserId(userId);
				BbsCommentsModel praiseModel = zhanglmServiceManage.BbsCommentsServiceI.findBySearch(search);
				if(null != praiseModel){
					zhanglmServiceManage.BbsCommentsServiceI.delete(praiseModel, getSessionUser());
					BbsReplyModel topicModel = zhanglmServiceManage.bbsReplyService.findById(commentId);
					Integer praiseNum = topicModel.getPraise();
					if(null != praiseNum){
						praiseNum--;
						topicModel.setPraise(praiseNum);
					}else{
						topicModel.setPraise(0);
					}
					zhanglmServiceManage.bbsReplyService.edit(topicModel, getSessionUser());
				}else{
					message = "已取消过点赞";
					result.setStatus(MobileResultBean.ERROR);
					result.setMessage(message);
					return result;
				}
				message = "取消点赞成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	

	@RequestMapping(method = RequestMethod.POST, value = "cancelreplyAddPraise")
	@MemberEvent(desc = "安卓/IOS 取消 回复信息点赞")
	@ResponseBody
	public MobileResultBean cancelreplyAddPraise(String replyId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "cancelreplyAddPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				if(StringUtils.isBlank(replyId)){
					result.setMessage("回复id不能为空");
					return result;
				}
				String userId = getSessionUser().getId();
				BbsReplyPraiseSearch search = new BbsReplyPraiseSearch();	
				search.setEqualreplyId(replyId);
				search.setEqualUserId(userId);
				BbsReplyPraiseModel praiseModel = zhanglmServiceManage.BbsReplyPraiseServiceI.findBySearch(search);
				if(null != praiseModel){
					zhanglmServiceManage.BbsReplyPraiseServiceI.delete(praiseModel, getSessionUser());				
					//回复点赞+1
					CommentReplyModel commentreplymodel = zhanglmServiceManage.commentReplyService.findById(replyId);
					Integer praiseNum = commentreplymodel.getPraise();
					if(null != praiseNum){
						praiseNum--;
						commentreplymodel.setPraise(praiseNum);
					}else{
						commentreplymodel.setPraise(0);
					}
					zhanglmServiceManage.commentReplyService.edit(commentreplymodel, getSessionUser());
				}else{
					message = "已取消过点赞";
					result.setStatus(MobileResultBean.ERROR);
					result.setMessage(message);
					return result;
				}

				message = "取消点赞成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
}
