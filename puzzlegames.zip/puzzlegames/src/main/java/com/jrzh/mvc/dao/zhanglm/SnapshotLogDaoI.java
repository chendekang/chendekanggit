package com.jrzh.mvc.dao.zhanglm;

import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.SnapshotLogModel;

public interface SnapshotLogDaoI extends BaseDaoI<SnapshotLogModel>{

}
