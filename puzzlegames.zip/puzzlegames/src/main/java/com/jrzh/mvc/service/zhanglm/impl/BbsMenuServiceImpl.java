package com.jrzh.mvc.service.zhanglm.impl;

import java.util.HashSet;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.convert.zhanglm.BbsMenuConvert;
import com.jrzh.mvc.dao.zhanglm.BbsMenuDaoI;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.PlazaDataModel;
import com.jrzh.mvc.search.zhanglm.BbsFanSearch;
import com.jrzh.mvc.search.zhanglm.BbsMenuSearch;
import com.jrzh.mvc.search.zhanglm.BbsTopicSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.BbsMenuServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;

@Service("bbsMenuService")
public class BbsMenuServiceImpl extends
		BaseServiceImpl<BbsMenuModel, BbsMenuSearch, BbsMenuView> implements
		BbsMenuServiceI {

	@Autowired
	public SysServiceManage sysServiceManage;
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Resource(name = "bbsMenuDao")
	private BbsMenuDaoI bbsMenuDao;

	@Override
	public BaseDaoI<BbsMenuModel> getDao() {
		return bbsMenuDao;
	}

	@Override
	public BaseConvertI<BbsMenuModel, BbsMenuView> getConvert() {
		return new BbsMenuConvert();
	}

	@Override
	public void addAndFile(BbsMenuModel model, FileModel file, SessionUser user)throws Exception {
		this.add(model, user);
		if(file != null){
			file.setFormId(model.getId());
			sysServiceManage.fileService.add(file, user);
		}
	}

	@Override
	public void editAndFile(BbsMenuModel model, FileModel file, SessionUser user)throws Exception {
		this.edit(model, user);
		if(file != null){
			sysServiceManage.fileService.edit(file, user);
		}
	}

	@Override
	public void deleteAndFile(BbsMenuModel model, FileModel file,SessionUser user)throws Exception {
		String code = model.getCode();
		String menuId = model.getId();
		this.delete(model, user);
		if(file != null){
			sysServiceManage.fileService.delete(file, user);
		}
		//删除该圈子下的所有话题
		BbsTopicSearch search = new BbsTopicSearch();
		search.setEqualMenuCode(code);
		List<BbsTopicModel> topicList = zhanglmServiceManage.bbsTopicService.list(search);
		//删除广场相关的数据
		for(BbsTopicModel topic : topicList){
			PlazaDataModel data = zhanglmServiceManage.plazaDataService.findByField("dataId", topic.getId());
			zhanglmServiceManage.plazaDataService.delete(data, user);
		}
		if(topicList.size() > 0){
			HashSet<BbsTopicModel> topicSet = new HashSet<BbsTopicModel>();
			topicSet.addAll(topicList);
			zhanglmServiceManage.bbsTopicService.deletes(topicSet, user);
		}
		//删除该圈子的关注信息
		BbsFanSearch fanSearch = new BbsFanSearch();
		fanSearch.setEqualMenuId(menuId);
		List<BbsFanModel> fansList = zhanglmServiceManage.bbsFanService.list(fanSearch);
		if(fansList.size() > 0){
			HashSet<BbsFanModel> fansSet = new HashSet<BbsFanModel>();
			fansSet.addAll(fansList);
			zhanglmServiceManage.bbsFanService.deletes(fansSet, user);
		}
	}

	@Override
	public List<BbsMenuView> viewMenu(BbsMenuSearch search,MemberModel user)throws ProjectException {
		List<BbsMenuView> viewList  = this.viewList(search);
		for(BbsMenuView view : viewList){
			//观点数量
			BbsTopicSearch topicSearch = new BbsTopicSearch();
			topicSearch.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			topicSearch.setEqualMenuCode(view.getCode());
			Long topicNum = zhanglmServiceManage.bbsTopicService.count(topicSearch); 
			view.setTopicNum(topicNum);
			//粉丝数量
			BbsFanSearch fansSearch = new BbsFanSearch();
			fansSearch.setEqualMenuId(view.getId());
			Long fansNum = zhanglmServiceManage.bbsFanService.count(fansSearch);
			view.setUserNum(fansNum);
			view.setIsAdd(false);
			//当前用户是否加入
			if(null != user){
				fansSearch.setEqualUserId(user.getId());
				BbsFanModel fans = zhanglmServiceManage.bbsFanService.findBySearch(fansSearch);
				if(fans != null){
					view.setIsAdd(true);
				}else{
					view.setIsAdd(false);
				}
			}
		}
		return viewList;
	}


	@Override
	public BbsMenuView viewMenuByCode(String code,MemberModel user)throws ProjectException {
			BbsMenuView view  = findViewByField("code", code);
			//观点数量
			BbsTopicSearch topicSearch = new BbsTopicSearch();
			topicSearch.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			topicSearch.setEqualMenuCode(view.getCode());
			Long topicNum = zhanglmServiceManage.bbsTopicService.count(topicSearch); 
			view.setTopicNum(topicNum);
			//粉丝数量
			BbsFanSearch fansSearch = new BbsFanSearch();
			fansSearch.setEqualMenuId(view.getId());
			Long fansNum = zhanglmServiceManage.bbsFanService.count(fansSearch);
			view.setUserNum(fansNum);
			//当前用户是否加入
			if(user != null){
				fansSearch.setEqualUserId(user.getId());
				fansSearch.setEqualMenuId(code);
				BbsFanModel fans = zhanglmServiceManage.bbsFanService.findBySearch(fansSearch);
				if(fans != null){
					view.setIsAdd(true);
				}else{
					view.setIsAdd(false);
				}
			}else{
				view.setIsAdd(false);
			}
		return view;
	}
	//圈子的详细信息
	@Override
	public BbsMenuView viewMenuByid(String boardId, String userid) throws ProjectException {
		BbsMenuView view  = findViewByField("id", boardId);
		//观点数量
		BbsTopicSearch topicSearch = new BbsTopicSearch();
		topicSearch.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
		topicSearch.setEqualmenuid(view.getId());
		Long topicNum = zhanglmServiceManage.bbsTopicService.count(topicSearch); 
		view.setTopicNum(topicNum);
		//粉丝数量
		BbsFanSearch fansSearch = new BbsFanSearch();
		fansSearch.setEqualMenuId(view.getId());
		Long fansNum = zhanglmServiceManage.bbsFanService.count(fansSearch);
		view.setUserNum(fansNum);
		//当前用户是否加入
		if(StringUtils.isNotBlank(userid)){
			fansSearch.setEqualUserId(userid);
			fansSearch.setEqualMenuId(boardId);
			BbsFanModel fans = zhanglmServiceManage.bbsFanService.findBySearch(fansSearch);
			if(fans != null){
				view.setIsAdd(true);
			}else{
				view.setIsAdd(false);
			}
		}else{
			view.setIsAdd(false);
		}
	return view;
	}

	
	//圈子首页
	@Override
	public List<BbsMenuView> newviewMenu(BbsMenuSearch search, MemberModel user) throws ProjectException {
		List<BbsMenuView> viewList  = this.viewList(search);
		for(BbsMenuView view : viewList){
			//观点数量
			BbsTopicSearch topicSearch = new BbsTopicSearch();
			topicSearch.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			topicSearch.setEqualmenuid(view.getId());
			Long topicNum = zhanglmServiceManage.bbsTopicService.count(topicSearch); 
			view.setTopicNum(topicNum);
			//粉丝数量
			BbsFanSearch fansSearch = new BbsFanSearch();
			fansSearch.setEqualMenuId(view.getId());
			Long fansNum = zhanglmServiceManage.bbsFanService.count(fansSearch);
			view.setUserNum(fansNum);
			view.setIsAdd(false);
			//当前用户是否加入
			if(null != user){
				fansSearch.setEqualUserId(user.getId());
				fansSearch.setEqualMenuId(view.getId());
				BbsFanModel fans = zhanglmServiceManage.bbsFanService.findBySearch(fansSearch);
				if(fans != null){
					view.setIsAdd(true);
				}else{
					view.setIsAdd(false);
				}
			}
		}
		return viewList;
	}
	
}
