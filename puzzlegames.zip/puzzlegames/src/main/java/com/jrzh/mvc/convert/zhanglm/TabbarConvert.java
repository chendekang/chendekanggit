package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.TabbarModel;
import com.jrzh.mvc.view.zhanglm.TabbarView;

public class TabbarConvert implements BaseConvertI<TabbarModel, TabbarView> {

	@Override
	public TabbarModel addConvert(TabbarView view) throws ProjectException {
		TabbarModel model = new TabbarModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public TabbarModel editConvert(TabbarView view, TabbarModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public TabbarView convertToView(TabbarModel model) throws ProjectException {
		TabbarView view = new TabbarView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
