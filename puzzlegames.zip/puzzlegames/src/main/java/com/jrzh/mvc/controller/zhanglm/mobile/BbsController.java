package com.jrzh.mvc.controller.zhanglm.mobile;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.config.ProjectConfigration;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.model.zhanglm.BbsPraiseModel;
import com.jrzh.mvc.model.zhanglm.BbsReplyModel;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.model.zhanglm.CommentReplyModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.MemberMsgModel;
import com.jrzh.mvc.search.zhanglm.BbsFanSearch;
import com.jrzh.mvc.search.zhanglm.BbsMenuSearch;
import com.jrzh.mvc.search.zhanglm.BbsPraiseSearch;
import com.jrzh.mvc.search.zhanglm.BbsTopicSearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.SharePageSearch;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;
import com.jrzh.mvc.view.zhanglm.SharePageView;


@Controller(BbsController.LOCATION + "BbsController")
@RequestMapping(BbsController.LOCATION)
public class BbsController extends BaseMobileController {
	public static final String LOCATION = "/mobile/bbs/";

	@Autowired
	private ProjectConfigration projectConfigration;
	
	@RequestMapping(method = RequestMethod.POST, value = "menus")
	@MemberEvent(desc = "安卓/IOS圈子 主菜单分类")
	@ResponseBody
	public MobileResultBean banner(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsMenuView> menuList = new ArrayList<BbsMenuView>();
		String message = "";
		map.put("method", "menus");
		try {
			BbsMenuSearch search = new BbsMenuSearch();
			search.setEqualIsDisable(false);
			List<BbsMenuView> viewList = zhanglmServiceManage.bbsMenuService.viewList(search);
			for(BbsMenuView menu : viewList){
				if(StringUtils.isBlank(menu.getPid())){
					menuList.add(menu);
				}
			}
			map.put("menuList", menuList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "boardMenus")
	@MemberEvent(desc = "安卓/IOS圈子 版块菜单")
	@ResponseBody
	public MobileResultBean boardMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsMenuView> boardMenuList = new ArrayList<BbsMenuView>();
		String message = "";
		map.put("method", "boardMenus");
		try {
			String pid = request.getParameter("pid");
			BbsMenuSearch search = new BbsMenuSearch();
			search.setEqualIsDisable(false);
			search.setEqualPid(pid);
			boardMenuList = zhanglmServiceManage.bbsMenuService.viewList(search);
			map.put("boardMenuList", boardMenuList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "aloneMenus")
	@MemberEvent(desc = "安卓/IOS圈子 获取单个版块菜单")
	@ResponseBody
	public MobileResultBean aloneMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "aloneMenus");
		try {
			String code = request.getParameter("code");
			BbsMenuSearch search = new BbsMenuSearch();
			search.setEqualCode(code);
			BbsMenuModel bbsMenu = zhanglmServiceManage.bbsMenuService.findBySearch(search);
			map.put("bbsMenu", bbsMenu.getName());
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "alonePMenus")
	@MemberEvent(desc = "安卓/IOS圈子 获取父类版块菜单")
	@ResponseBody
	public MobileResultBean alonePMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "alonePMenus");
		try {
			String menuId = request.getParameter("code");
			BbsMenuModel bbsMenu = zhanglmServiceManage.bbsMenuService.findById(menuId);
			map.put("bbsMenu", bbsMenu.getName());
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "getBoardMenus")
	@MemberEvent(desc = "安卓/IOS圈子 获取已关注的版块菜单列表")
	@ResponseBody
	public MobileResultBean getBoardMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsMenuView> boardMenuList = new ArrayList<BbsMenuView>();
		String message = "";
		map.put("method", "getBoardMenus");
		try {
			String[] inId = null;
			String talentId = request.getParameter("talentId");
			BbsFanSearch fanSearch = new BbsFanSearch();
			fanSearch.setEqualUserId(talentId);
			List<BbsFanModel> fanList = zhanglmServiceManage.bbsFanService.list(fanSearch);
			if(fanList.size()>0){
				inId = new String[fanList.size()];
				for(int i=0;i<fanList.size();i++){
					inId[i] = fanList.get(i).getMenuId();
				}
				BbsMenuSearch search = new BbsMenuSearch();
				search.setInId(inId);
				search.setEqualIsDisable(false);
				List<BbsMenuView> viewList = zhanglmServiceManage.bbsMenuService.viewList(search);
				for(BbsMenuView view : viewList){
					if(StringUtils.isNotBlank(view.getPid())){
						boardMenuList.add(view);
					}
				}
			}
			map.put("boardMenuList", boardMenuList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "hotBoardMenus")
	@MemberEvent(desc = "安卓/IOS圈子 推荐版块菜单")
	@ResponseBody
	public MobileResultBean hotBoardMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsMenuView> boardMenuList = new ArrayList<BbsMenuView>();
		String message = "";
		map.put("method", "hotBoardMenus");
		try {
			BbsMenuSearch search = new BbsMenuSearch();
			search.setEqualIsDisable(false);
			search.setEqualIsLock(true);
			boardMenuList = zhanglmServiceManage.bbsMenuService.viewList(search);
			map.put("hotList", boardMenuList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "bbsTopics")
	@MemberEvent(desc = "安卓/IOS圈子 分类版块话题")
	@ResponseBody
	public MobileResultBean bbsTopics(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsTopicView> topicList = new ArrayList<BbsTopicView>();
		String message = "";
		map.put("method", "bbsTopics");
		try {
			String menuCode = request.getParameter("menuCode");
			BbsTopicSearch search = new BbsTopicSearch();
			//通过审核的话题
			search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			search.setEqualMenuCode(menuCode);
			topicList = zhanglmServiceManage.bbsTopicService.viewList(search);
			DefaultSearch defaultsearch = new DefaultSearch();
			for(BbsTopicView topic : topicList){
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
			if(null == topic.getUserPhoto()){
				topic.setUserPhoto(defaultModel.getImgUrl());
			}
			}
			map.put("topicList", topicList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "publishTopic")
	@MemberEvent(desc = "安卓/IOS圈子 发表话题")
	@ResponseBody
	public MobileResultBean publishTopic(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "publishTopic");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String title = request.getParameter("title");//标题
				String content = request.getParameter("content");//内容
				String menuCode = request.getParameter("menuCode");//版块代码
				String imgurl = request.getParameter("imgUrl");//图片路径
				System.out.println(imgurl);
				if(StringUtils.isBlank(title)){
					result.setMessage("标题不能为空");
					return result;
				}
				if(StringUtils.isBlank(content)){
					result.setMessage("内容不能为空");
					return result;
				}
				if(StringUtils.isBlank(menuCode)){
					result.setMessage("请选择要发布的圈子");
					return result;
				}
				BbsTopicModel model = new BbsTopicModel();
				model.setTitle(title);
				model.setContent(content);
				model.setUserId(getSessionUser().getId());
				model.setUserName(getSessionUser().getName());
				model.setDiscuss(0);
				model.setPraise(0);
				model.setMenuCode(menuCode);
				if(StringUtils.isNotBlank(imgurl)){
					model.setImgUrl(imgurl);
				}
				model.setStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDING);
				zhanglmServiceManage.bbsTopicService.add(model, getSessionUser());
				System.out.println(model);
				message = "发布成功，等待工作人员审核";
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setObject(map);
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "myPublishTopic")
	@MemberEvent(desc = "安卓/IOS圈子 我发布的话题(观点)")
	@ResponseBody
	public MobileResultBean myPublishTopic(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsTopicView> topicList = new ArrayList<BbsTopicView>();
		String message = "";
		map.put("method", "myPublishTopic");
		String currPage = request.getParameter("currPage");
		String pageSize = request.getParameter("pageSize");
		Long number = 0L;
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				BbsTopicSearch search = new BbsTopicSearch();
				search.setPage(Integer.parseInt(currPage));
				search.setRows(Integer.parseInt(pageSize));
				search.setEqualUserId(getSessionUser().getId());
				search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
				topicList = zhanglmServiceManage.bbsTopicService.viewListTopic(search, getSessionUser());
				DefaultSearch defaultsearch = new DefaultSearch();
				for(BbsTopicView topic : topicList){
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if(null == topic.getUserPhoto()){
					topic.setUserPhoto(defaultModel.getImgUrl());
				}
				}
				number = zhanglmServiceManage.bbsTopicService.count(search);
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("topicList", topicList);
				message = "获取成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "publishTopicList")
	@MemberEvent(desc = "安卓/IOS圈子 已发布的话题(观点)")
	@ResponseBody
	public MobileResultBean publishTopicList(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsTopicView> topicList = new ArrayList<BbsTopicView>();
		String message = "";
		map.put("method", "publishTopicList");
		try {
			BbsTopicSearch search = new BbsTopicSearch();
			search.setSort("auditTime");
			search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			topicList = zhanglmServiceManage.bbsTopicService.viewListTopic(search, getMobileUser());
			DefaultSearch defaultsearch = new DefaultSearch();
			for(BbsTopicView topic : topicList){
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if(null == topic.getUserPhoto()){
					topic.setUserPhoto(defaultModel.getImgUrl());
				}
			}
			map.put("topicList", topicList);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "joinBroad")
	@MemberEvent(desc = "安卓/IOS圈子 加入圈子")
	@ResponseBody
	public MobileResultBean joinBroad(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "joinBroad");
		try {
			
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String broadId = request.getParameter("broadId");
				String browser = request.getParameter("browser");
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findById(broadId);
				if(null != menu){
					BbsFanModel model = new BbsFanModel();
					model.setMenuId(broadId);
					model.setUserId(getSessionUser().getId());
					model.setTopicNum(0L);
					model.setPraiseNum(0L);
					model.setReplyNum(0L);
					zhanglmServiceManage.bbsFanService.add(model, getSessionUser());
					message = "加入成功";
					result.setStatus(MobileResultBean.SUCCESS);
				}else{
					message = "圈子不存在";
				}
				result.setObject(browser);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "addPraise")
	@MemberEvent(desc = "安卓/IOS圈子 话题点赞")
	@ResponseBody
	public MobileResultBean addPraise(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				String topicId = request.getParameter("topicId");
				//查看用户是否点过赞
				BbsPraiseSearch search = new BbsPraiseSearch();
				search.setEqualTopicId(topicId);
				search.setEqualUserId(userId);
				BbsPraiseModel praiseModel = zhanglmServiceManage.bbsPraiseService.findBySearch(search);
				if(praiseModel != null){
					result.setMessage("您已点过赞了");
					return result;
				}
				//添加点赞数据
				praiseModel = new BbsPraiseModel();
				praiseModel.setTopicId(topicId);
				praiseModel.setUserId(userId);
				zhanglmServiceManage.bbsPraiseService.add(praiseModel, getSessionUser());
				//话题点赞+1，计算平均数
				BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(topicId);
				Integer praiseNum = topicModel.getPraise();
				Integer discussNum = topicModel.getDiscuss();
				if(null != praiseNum){
					praiseNum++;
					topicModel.setPraise(praiseNum);
				}else{
					topicModel.setPraise(1);
				}
				Double average = (double) ((praiseNum + discussNum)/2);
				topicModel.setAverage(average);
				zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());
				//关联表用户点赞数+1,计算平均值
				String menuCode = topicModel.getMenuCode();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan != null){
					Long fanTopic = fan.getTopicNum();
					Long fanPraise = fan.getPraiseNum();
					Long fanReply = fan.getReplyNum();
					fanPraise++;
					fan.setPraiseNum(fanPraise);
					Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
					fan.setAverage(fanAverage);
					zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				}
				message = "谢谢点赞";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "addReply")
	@MemberEvent(desc = "安卓/IOS圈子 话题评论")
	@ResponseBody
	public MobileResultBean addReply(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addReply");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				MemberModel member = zhanglmServiceManage.memberService.findById(userId);
				String topicId = request.getParameter("topicId");
				String content = request.getParameter("content");
				if(StringUtils.isBlank(content)){
					result.setMessage("评论内容不能为空");
					return result;
				}
				//添加评论数据
				BbsReplyModel reply = new BbsReplyModel();
				reply.setTopicId(topicId);
				reply.setUserId(userId);
				reply.setContent(content);
				//评论+1,计算平均数
				BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(topicId);
				Integer praiseNum = topicModel.getPraise();
				Integer discussNum = topicModel.getDiscuss();
				if(null != discussNum){
					topicModel.setDiscuss(discussNum + 1);
				}else{
					topicModel.setDiscuss(1);
				}
				Double average = (double) ((praiseNum + discussNum)/2);
				topicModel.setAverage(average);
				//关联表用户评论数+1,计算平均值
				String menuCode = topicModel.getMenuCode();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan == null){
					result.setMessage("请您先关注该圈子");
					return result;
				}
				Long fanTopic = fan.getTopicNum();
				Long fanPraise = fan.getPraiseNum();
				Long fanReply = fan.getReplyNum();
				fanReply++;
				fan.setReplyNum(fanReply);
				Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
				fan.setAverage(fanAverage);
				//通知用户话题已被评论
				MemberMsgModel memberMsg = new MemberMsgModel();
				memberMsg.setSenderId(userId);
				memberMsg.setUserId(topicModel.getUserId());
				memberMsg.setTitle("观点被评论");
				memberMsg.setContent("用户"+member.getNickName()+"评论了您的观点【"+topicModel.getTitle()+"】：" + content);
				memberMsg.setStatus(BusinessConstants.MEMBER_MSG_STATUS.NOT_READ);
				//入库
				zhanglmServiceManage.bbsReplyService.add(reply, getSessionUser());
				zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());
				zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				zhanglmServiceManage.memberMsgService.add(memberMsg, getSessionUser());
				message = "谢谢评论";
				System.out.println(message);
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "topicReply")
	@MemberEvent(desc = "安卓/IOS圈子 添加话题回复")
	@ResponseBody
	public MobileResultBean topicReply(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "topicReply");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				//话题Id
				String replyId = request.getParameter("replyId");
				String comment = request.getParameter("comment");
				String userId = request.getParameter("userId");
				String commentId = request.getParameter("commentId");
				BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(replyId);
				if(topic != null){
					BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", topic.getMenuCode());
					BbsFanSearch fanSearch = new BbsFanSearch();
					fanSearch.setEqualMenuId(menu.getId());
					fanSearch.setEqualUserId(userId);
					BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
					if(fan == null){
						result.setMessage("请您先关注该圈子");
						return result;
					}
					CommentReplyModel model = new CommentReplyModel();
					model.setContent(comment);
					model.setReplyId(replyId);
					model.setUserId(userId);
					model.setCommentId(commentId);
					zhanglmServiceManage.commentReplyService.add(model,getMobileUser());
					message = "评论回复成功";
					result.setStatus(MobileResultBean.SUCCESS);
				}else{
					message = "该话题不存在";
				}
			}
			result.setObject(message);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "topicClick")
	@MemberEvent(desc ="安卓/IOS 话题点击量+1")
	@ResponseBody
	public MobileResultBean topicClick() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "topicClick");
		String message = "";
		try {
			String topicId = request.getParameter("topicId");
			BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(topicId);
			Long ClickNum = topic.getClickNum();
			if(null != ClickNum){
				topic.setClickNum(++ClickNum);
			}else{
				topic.setClickNum(1L);
			}
			zhanglmServiceManage.bbsTopicService.edit(topic, getSessionUser());
			result.setObject(map);
			message = "点击量更改成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "getSharePage")
	@MemberEvent(desc ="安卓/IOS 获取分享页面内容")
	@ResponseBody
	public MobileResultBean getSharePage() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "getSharePage");
		String message = "";
		try {
			SharePageSearch search = new SharePageSearch();
			search.setEqualIsDisable(false);
			search.setOrder(BaseSearch.Order_Type_Desc);
			SharePageView pageView = zhanglmServiceManage.sharePageService.firstView(search);
			map.put("pageView", pageView);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "recommend")
	@MemberEvent(desc ="安卓/IOS 获取推荐话题")
	@ResponseBody
	public MobileResultBean recommend() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		List<BbsTopicView> topicView = new ArrayList<BbsTopicView>();
		map.put("method", "recommend");
		String message = "";
		try {
			BbsTopicSearch search = new BbsTopicSearch();
			search.setEqualIsDisable(true);
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Desc);
			search.setRows(2);
			topicView = zhanglmServiceManage.bbsTopicService.viewListTopic(search,getMobileUser());
			System.out.println(topicView);
			map.put("topicView", topicView);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "topicPhoto")
	@MemberEvent(desc = "安卓/IOS圈子 上传话题图片")
	@ResponseBody
	public MobileResultBean topicPhoto(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "topicPhoto");
		String model = request.getParameter("model");
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				Map<String, MultipartFile> fileMap = multipartRequest.getFileMap();
				MultipartFile multipartFile =null;
				String fileName = "";
				String ctxPath = projectConfigration.getFileRootUrl() +"file/" + model+ "/";
				String mapPath = projectConfigration.mappingUrl + "file/" + model+ "/";
				File file = new File(ctxPath);
				if(!file.exists()) file.mkdirs();
				for(Map.Entry<String,MultipartFile > set:fileMap.entrySet()){
					multipartFile = set.getValue();//文件名
					fileName = multipartFile.getOriginalFilename();
		            String suffix = fileName.indexOf(".") != -1 ? fileName.substring(fileName.lastIndexOf("."), fileName.length()) : null;
		            String newFileName =  "photo"+getSessionUser().getId() + (suffix!=null?suffix:"");// 构成新文件名。
		            File uploadFile = new File(file.getPath() + "/"+newFileName);
		            try {  
		            	FileCopyUtils.copy(multipartFile.getBytes(), uploadFile); 
		                map.put("filePath", mapPath + newFileName);
		                message = "上传成功";
						result.setStatus(MobileResultBean.SUCCESS);
						result.setObject(map);
		            }catch (Exception e) {
		            	e.printStackTrace();
		            	message = e.getMessage();
					}
				}
			}
		result.setObject(map);
		result.setMessage(message);
		return result;
	}
	
}
