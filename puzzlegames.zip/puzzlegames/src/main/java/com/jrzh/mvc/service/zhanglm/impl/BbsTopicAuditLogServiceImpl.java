package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.BbsTopicAuditLogConvert;
import com.jrzh.mvc.dao.zhanglm.BbsTopicAuditLogDaoI;
import com.jrzh.mvc.model.zhanglm.BbsTopicAuditLogModel;
import com.jrzh.mvc.search.zhanglm.BbsTopicAuditLogSearch;
import com.jrzh.mvc.service.zhanglm.BbsTopicAuditLogServiceI;
import com.jrzh.mvc.view.zhanglm.BbsTopicAuditLogView;

@Service("bbsTopicAuditLogService")
public class BbsTopicAuditLogServiceImpl extends
		BaseServiceImpl<BbsTopicAuditLogModel, BbsTopicAuditLogSearch, BbsTopicAuditLogView> implements
		BbsTopicAuditLogServiceI {

	@Resource(name = "bbsTopicAuditLogDao")
	private BbsTopicAuditLogDaoI bbsTopicAuditLogDao;

	@Override
	public BaseDaoI<BbsTopicAuditLogModel> getDao() {
		return bbsTopicAuditLogDao;
	}

	@Override
	public BaseConvertI<BbsTopicAuditLogModel, BbsTopicAuditLogView> getConvert() {
		return new BbsTopicAuditLogConvert();
	}

}
