package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.ZhiboAdModel;
import com.jrzh.mvc.view.zhanglm.ZhiboAdView;

public class ZhiboAdConvert implements BaseConvertI<ZhiboAdModel, ZhiboAdView> {

	@Override
	public ZhiboAdModel addConvert(ZhiboAdView view) throws ProjectException {
		ZhiboAdModel model = new ZhiboAdModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public ZhiboAdModel editConvert(ZhiboAdView view, ZhiboAdModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public ZhiboAdView convertToView(ZhiboAdModel model) throws ProjectException {
		ZhiboAdView view = new ZhiboAdView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
