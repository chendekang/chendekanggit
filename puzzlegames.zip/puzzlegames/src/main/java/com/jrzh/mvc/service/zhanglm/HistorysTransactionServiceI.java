package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.mvc.model.zhanglm.HistorysTransactionModel;
import com.jrzh.mvc.search.zhanglm.HistorysTransactioSearch;;

public interface HistorysTransactionServiceI{
	Integer deleteAll();
	HistorysTransactionModel viewLowValue(HistorysTransactioSearch search)throws ProjectException;
	HistorysTransactionModel viewHighValue(HistorysTransactioSearch search)throws ProjectException;
	List<HistorysTransactionModel> list(HistorysTransactioSearch logSearch);
}
