package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.DictionaryDaoI;
import com.jrzh.mvc.model.zhanglm.DictionaryModel;

@Repository("DictionaryDaoI")
public class DictionaryDaoImpl extends BaseDaoImpl<DictionaryModel> implements DictionaryDaoI{

}