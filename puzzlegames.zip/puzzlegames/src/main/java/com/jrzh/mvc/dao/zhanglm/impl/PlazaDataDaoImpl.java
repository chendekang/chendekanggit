package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.PlazaDataDaoI;
import com.jrzh.mvc.model.zhanglm.PlazaDataModel;

@Repository("plazaDataDao")
public class PlazaDataDaoImpl extends BaseDaoImpl<PlazaDataModel> implements PlazaDataDaoI{

}