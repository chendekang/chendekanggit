package com.jrzh.mvc.model.zhanglm;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.annotation.UniqueValue;
import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_special_column")
public class SpecialColumnModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 编号
     */
	@UniqueValue(name = "专栏编号")
    @Column(name = "_code")
    private String code;
    /**
     * 名称
     */
    @Column(name = "_name")
    private String name;

    public void setCode(String code) {
        this.code = code;
    }
    
    public String getCode() {
        return this.code;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }

}