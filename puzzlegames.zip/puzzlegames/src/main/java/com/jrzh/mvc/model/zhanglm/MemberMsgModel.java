package com.jrzh.mvc.model.zhanglm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_member_msgs")
public class MemberMsgModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 消息标题
     */
    @Column(name = "_title")
    private String title;
    /**
     * 消息内容
     */
    @Column(name = "_content")
    private String content;
    /**
     * 收信人ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 消息状态
     */
    @Column(name = "_status")
    private Integer status;
    /**
     * 发件人ID
     */
    @Column(name = "_sender_id")
    private String senderId;

    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getTitle() {
        return this.title;
    }
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getContent() {
        return this.content;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    
    public Integer getStatus() {
        return this.status;
    }
    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }
    
    public String getSenderId() {
        return this.senderId;
    }

}