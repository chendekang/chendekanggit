package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.DictionaryModel;
import com.jrzh.mvc.view.zhanglm.DictionaryView;
public class DictionaryConvert implements BaseConvertI<DictionaryModel, DictionaryView>{
	@Override
	public DictionaryModel addConvert(DictionaryView view) throws ProjectException {
		DictionaryModel model = new DictionaryModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}
	@Override
	public DictionaryModel editConvert(DictionaryView view, DictionaryModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}
	@Override
	public DictionaryView convertToView(DictionaryModel model) throws ProjectException {
		DictionaryView view = new DictionaryView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}


}
