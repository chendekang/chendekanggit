package com.jrzh.mvc.controller.zhanglm.mobile.front;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.controller.zhanglm.mobile.BaseMobileController;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.search.zhanglm.BbsTopicSearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;
import com.jrzh.mvc.view.zhanglm.MemberView;

@Controller(newMemberController.LOCATION + "newMemberController")
@RequestMapping(newMemberController.LOCATION)
public class newMemberController extends BaseMobileController {
	public static final String LOCATION = "/mobile/famous/";
	public Logger logger = Logger.getLogger(newMemberController.class);
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "famousDetail")
	@MemberEvent(desc = "安卓/IOS圈子 获取名家的详细信息")
	@ResponseBody
	public MobileResultBean famousdetail(String famousId,String userId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsMenuView> menuList = new ArrayList<BbsMenuView>();
		String message = "";
		map.put("method", "famousDetail");
		try {
			//移动端区分页面参数
			String type = request.getParameter("type");
			if(StringUtils.isNotBlank(type)){
				request.setAttribute("type", type);
			}
			//获取当前操作用户	
			SessionUser user = getMobileUser();
			if(null != user){
				request.setAttribute("userId", user.getId());
			}
			//获取牛人ID
			//String talentId=request.getParameter("talentId");
			//if(StringUtils.isBlank(talentId)){
				//发布话题id
				//String topicId = request.getParameter("famousId");
				
	
				
				//String userid = request.getParameter("userId");
				/*BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(famousId);
				String topicId = topic.getUserId();*/
			//}
			MemberView talent=zhanglmServiceManage.memberService.ViewDataById(famousId, userId);
			if(StringUtils.isBlank(talent.getPhoto())){
				DefaultSearch defaultsearch = new DefaultSearch();
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if(defaultModel != null){
					talent.setPhoto(defaultModel.getImgUrl());
				}
			}
			//传牛人用户的信息到页面
			//request.setAttribute("talent", talent);
			//牛人关注
		/*	MemberAttentionSearch attentionSearch = new MemberAttentionSearch();
			attentionSearch.setEqualFansId(talentId);
			attentionSearch.setRows(5);
			List<MemberAttentionView> attentionList = zhanglmServiceManage.memberAttentionService.viewList(attentionSearch);
			//用户默认头像
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			for(MemberAttentionView view : attentionList){
				if(StringUtils.isBlank(view.getPhoto())){
					if(defaultImg != null){
						view.setPhoto(defaultImg.getImgUrl());
					}
				}
			}
			request.setAttribute("attentionList", attentionList);
			//牛人观点
			BbsTopicSearch topicSearch=new BbsTopicSearch();
			topicSearch.setEqualUserId(talentId);
			List<BbsTopicView> topicList=zhanglmServiceManage.bbsTopicService.viewListTopic(topicSearch, user);
			request.setAttribute("topicList", topicList);*/
			if(null != talent){
				map.put("famousView", talent);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods famousdetail"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	
	
	
	@RequestMapping(method = RequestMethod.POST,value = "famousTopics")
	@MemberEvent(desc = "安卓/IOS圈子 获取名家的用户观点集合")
	@ResponseBody
	public MobileResultBean famoustopics(String currPage,String pageSize,String famousId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "famoustopics");
		//请求页数
		//String currPage = request.getParameter("currPage");
		//每页条数
		//String pageSize = request.getParameter("pageSize");
		//发布话题id
		//String topicId = request.getParameter("famousId");
		Long number = 0L;
		try {
			if(StringUtils.isBlank(currPage)){
				result.setMessage("请求页数不能为空");
				return result;
			}
			if(StringUtils.isBlank(famousId)){
				result.setMessage("发布话题id不能为空");
				return result;
			}
			//获取当前操作用户	
			SessionUser user = getMobileUser();

			//BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(topicId);
			//牛人观点
			BbsTopicSearch topicSearch=new BbsTopicSearch();
			topicSearch.setEqualUserId(famousId);
			topicSearch.setPage(Integer.parseInt(currPage));
			topicSearch.setRows(Integer
			    		.parseInt(pageSize));
			topicSearch.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			topicSearch.setSort("createTime");
			topicSearch.setOrder(BaseSearch.Order_Type_Desc);
			List<BbsTopicView> topicList=zhanglmServiceManage.bbsTopicService.viewListTopic(topicSearch, user);

			number = zhanglmServiceManage.bbsTopicService.count(topicSearch);
			if(topicList != null && topicList.size() > 0){
				map.put("number", number);
				map.put("currPage", currPage);
				map.put("bbsTopicList", topicList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				map.put("number", number);
				map.put("currPage", currPage);
				map.put("bbsTopicList", topicList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---famoustopics---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "bbsAuthor")
	@MemberEvent(desc = "安卓/IOS圈子获取名家获取作者信息")
	@ResponseBody
	public MobileResultBean bbsauthor(String topicId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "bbsauthor");
		//话题ID
		//String topicId = request.getParameter("topicId");
		try {
			if(StringUtils.isBlank(topicId)){
				result.setMessage("话题id不能为空");
				return result;
			}
/*			SessionUser user = getMobileUser();
			if(user != null){
				request.setAttribute("userId", user.getId());
			}
			String type = request.getParameter("type");
			if(StringUtils.isNotBlank(type)){
				request.setAttribute("type", type);
			}
			//String topicId = request.getParameter("topicId");
*/			BbsTopicView topic = new BbsTopicView();
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			if(StringUtils.isNotBlank(topicId)){
				topic = zhanglmServiceManage.bbsTopicService.findViewById(topicId);
				if(StringUtils.isBlank(topic.getUserPhoto())){
					if(defaultImg != null){
						topic.setUserPhoto(defaultImg.getImgUrl());
					}
				}
		/*		BbsPraiseSearch search = new BbsPraiseSearch();
				search.setEqualTopicId(topicId);
				List<BbsPraiseView> viewList = zhanglmServiceManage.bbsPraiseService.viewList(search);
				for(BbsPraiseView view : viewList){
					if(StringUtils.isBlank(view.getUserPhoto())){
						if(defaultImg != null){
							view.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				request.setAttribute("praiseList", viewList);*/
				//查询回复
		/*		BbsReplySearch replySearch = new BbsReplySearch();
				replySearch.setEqualTopicId(topicId);
				List<BbsReplyView> replyList = zhanglmServiceManage.bbsReplyService.viewList(replySearch);
				for(BbsReplyView reply : replyList){
					if(StringUtils.isBlank(reply.getUserPhoto())){
						if(defaultImg != null){
							reply.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				
				request.setAttribute("replyList", replyList);
				//查公共
				List<CommentReplyView>  commentList = zhanglmServiceManage.commentReplyService.findAllView();
				request.setAttribute("commentList", commentList);*/
			}
			// }
			if (null != topic) {
				map.put("authorView", topic);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---bbsauthor---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "bbsContent")
	@MemberEvent(desc = "安卓/IOS圈子获取观点信息")
	@ResponseBody
	public MobileResultBean bbsContent(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "bbsContent");
		//话题ID
		String topicId = request.getParameter("topicId");
		try {
			if(StringUtils.isBlank(topicId)){
				result.setMessage("话题id不能为空");
				return result;
			}
/*			SessionUser user = getMobileUser();
			if(user != null){
				request.setAttribute("userId", user.getId());bbsComments
			}
			String type = request.getParameter("type");
			if(StringUtils.isNotBlank(type)){
				request.setAttribute("type", type);
			}bbsComments
			//String topicId = request.getParameter("topicId");
			 * 
*/				
			//阅读数
			BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(topicId);
			Integer readaccount = topicModel.getReadAccount();
			if(null != readaccount){
				readaccount++;
				topicModel.setReadAccount(readaccount);
			}else{
				topicModel.setReadAccount(1);
			}
			zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());	
			
			BbsTopicView topic = new BbsTopicView();
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			if(StringUtils.isNotBlank(topicId)){
				topic = zhanglmServiceManage.bbsTopicService.findViewById(topicId);
				if(StringUtils.isBlank(topic.getUserPhoto())){
					if(defaultImg != null){
						topic.setUserPhoto(defaultImg.getImgUrl());
					}
				}	
		/*		BbsPraiseSearch search = new BbsPraiseSearch();
				search.setEqualTopicId(topicId);
				List<BbsPraiseView> viewList = zhanglmServiceManage.bbsPraiseService.viewList(search);
				for(BbsPraiseView view : viewList){
					if(StringUtils.isBlank(view.getUserPhoto())){
						if(defaultImg != null){
							view.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				request.setAttribute("praiseList", viewList);*/
				//查询回复
		/*		BbsReplySearch replySearch = new BbsReplySearch();
				replySearch.setEqualTopicId(topicId);
				List<BbsReplyView> replyList = zhanglmServiceManage.bbsReplyService.viewList(replySearch);
				for(BbsReplyView reply : replyList){
					if(StringUtils.isBlank(reply.getUserPhoto())){
						if(defaultImg != null){
							reply.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				
				request.setAttribute("replyList", replyList);
				//查公共
				List<CommentReplyView>  commentList = zhanglmServiceManage.commentReplyService.findAllView();
				request.setAttribute("commentList", commentList);*/
			}
		
			
			// }
			if (null != topic) {
				map.put("authorView", topic);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---bbsContent---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	/*
	 * 
	 * 接口用于返回评论数，点赞数和分享数的
	 * 
	 * */
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "getReturnsnumber")
	@MemberEvent(desc = "安卓/IOS圈子接口用于返回评论数，点赞数和分享数的")
	@ResponseBody
	public MobileResultBean getReturnsnumber(String topicId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getReturnsnumber");
		try {
			if(StringUtils.isBlank(topicId)){
				result.setMessage("观点id不能为空");
				return result;
			}				
			//获取评论数
			BbsTopicView topic = new BbsTopicView();
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			if(StringUtils.isNotBlank(topicId)){
				topic = zhanglmServiceManage.bbsTopicService.findViewById(topicId);
				if(StringUtils.isBlank(topic.getUserPhoto())){
					if(defaultImg != null){
						topic.setUserPhoto(defaultImg.getImgUrl());
					}
				}	

			}
		
			
			
			//获取收藏数
			
			//获取分享数
			if (null != topic) {
				map.put("authorView", topic);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---bbsContent---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
}
