package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.BbsReplyPraiseDaoI;
import com.jrzh.mvc.model.zhanglm.BbsReplyPraiseModel;

@Repository("bbsReplyPraiseDaoI")
public class BbsReplyPraiseDaoImpl extends BaseDaoImpl<BbsReplyPraiseModel> implements BbsReplyPraiseDaoI{

}