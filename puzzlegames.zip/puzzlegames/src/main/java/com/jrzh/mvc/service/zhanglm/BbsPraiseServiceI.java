package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.BbsPraiseModel;
import com.jrzh.mvc.search.zhanglm.BbsPraiseSearch;
import com.jrzh.mvc.view.zhanglm.BbsPraiseView;

public interface BbsPraiseServiceI  extends BaseServiceI<BbsPraiseModel, BbsPraiseSearch, BbsPraiseView>{

}