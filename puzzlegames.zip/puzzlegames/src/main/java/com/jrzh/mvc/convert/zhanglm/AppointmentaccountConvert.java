package com.jrzh.mvc.convert.zhanglm;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.mvc.model.zhanglm.AppointmentaccountModel;
import com.jrzh.mvc.view.zhanglm.AppointmentaccountView;
public class AppointmentaccountConvert {

	public AppointmentaccountModel addConvert(AppointmentaccountView view) throws ProjectException {
		AppointmentaccountModel model = new AppointmentaccountModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	public AppointmentaccountModel editConvert(AppointmentaccountView view, AppointmentaccountModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	public AppointmentaccountView convertToView(AppointmentaccountModel model) throws ProjectException {
		AppointmentaccountView view = new AppointmentaccountView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
