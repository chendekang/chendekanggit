package com.jrzh.mvc.controller.zhanglm.mobile;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.common.cache.Cache;
import com.jrzh.common.cache.CacheManager;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.tools.ValidateTools;
import com.jrzh.common.utils.DateUtil;
import com.jrzh.common.utils.HttpClientHelper;
import com.jrzh.common.utils.PasswordUtils;
import com.jrzh.config.ProjectConfigration;
import com.jrzh.config.zhanglm.ZhanglmConfigration;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.constants.ConfigConstants;
import com.jrzh.mvc.convert.zhanglm.MemberConvert;
import com.jrzh.mvc.model.zhanglm.BankMessageModel;
import com.jrzh.mvc.model.zhanglm.CollectModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.model.zhanglm.GoldbinduseruserModel;
import com.jrzh.mvc.model.zhanglm.MemberAttentionModel;
import com.jrzh.mvc.model.zhanglm.MemberLogStatisticsModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.MemberMsgModel;
import com.jrzh.mvc.model.zhanglm.SignInModel;
import com.jrzh.mvc.model.zhanglm.TodayDealModel;
import com.jrzh.mvc.search.zhanglm.BbsReplyPraiseSearch;
import com.jrzh.mvc.search.zhanglm.BbsReplySearch;
import com.jrzh.mvc.search.zhanglm.CollectSearch;
import com.jrzh.mvc.search.zhanglm.CommentReplySearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.MemberAttentionSearch;
import com.jrzh.mvc.search.zhanglm.MemberLogStatisticsSearch;
import com.jrzh.mvc.search.zhanglm.MemberMsgSearch;
import com.jrzh.mvc.search.zhanglm.MemberSearch;
import com.jrzh.mvc.search.zhanglm.SignInSearch;
import com.jrzh.mvc.view.zhanglm.CollectView;
import com.jrzh.mvc.view.zhanglm.MemberLogStatisticsView;
import com.jrzh.mvc.view.zhanglm.MemberMsgView;
import com.jrzh.mvc.view.zhanglm.MemberView;
import com.jrzh.mvc.view.zhanglm.TodayDealView;

@Controller(MemberController.LOCATION + "MemberController")
@RequestMapping(MemberController.LOCATION)
public class MemberController extends BaseMobileController{ 
	public static final String LOCATION = "/mobile/member/";
	
	@Autowired
	private ZhanglmConfigration zhanglmConfigration;
	
	@Autowired
	private ProjectConfigration projectConfigration;
	
	@RequestMapping(method = RequestMethod.POST, value = "sendMobileMsg")
	@MemberEvent(desc ="安卓/IOS发送手机短信(注册时)")
	@ResponseBody
	public MobileResultBean sendMobileMsg(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "sendMobileMsg");
		try {
			String mobile = request.getParameter("mobile");
			if (StringUtils.isBlank(mobile)) {
				message = "手机号码不能为空！";
			}else if (!ValidateTools.isMobile(mobile)) {
				message = "手机号码不合法！";
			}else{
				MemberModel member = zhanglmServiceManage.memberService.findByField("mobile", mobile);
				if(member !=null){
					message = "手机号已注册";
					result.setMessage(message);
					return result;
				}
				String code = sendMobileCode(mobile);
				message = "发送成功";
				map.put("code", code);
				result.setStatus(MobileResultBean.SUCCESS);
				result.setObject(map);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "forgetMsg")
	@MemberEvent(desc ="安卓/IOS发送手机短信(忘记密码时)")
	@ResponseBody
	public MobileResultBean forgetMsg(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "forgetMsg");
		try {
			String mobile = request.getParameter("mobile");
			if (StringUtils.isBlank(mobile)) {
				message = "手机号码不能为空！";
			}else if (!ValidateTools.isMobile(mobile)) {
				message = "手机号码不合法！";
			}else{
				MemberModel member = zhanglmServiceManage.memberService.findByField("mobile", mobile);
				if(member ==null){
					message = "手机号未注册";
					result.setMessage(message);
					return result;
				}
				String code = sendMobileCode(mobile);
				message = "发送成功";
				map.put("code", code);
				result.setStatus(MobileResultBean.SUCCESS);
				result.setObject(map);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	@RequestMapping(method=RequestMethod.POST, value="upload")
	@MemberEvent(desc = "安卓/IOS用户头像上传")
	@ResponseBody
    public MobileResultBean upload(HttpServletRequest request) throws IOException{
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "upload");
		String model = request.getParameter("model");
		String userId = request.getParameter("userId");
		MemberModel member = null;
		try {
			member = zhanglmServiceManage.memberService.findById(userId);
		} catch (ProjectException e1) {
			e1.printStackTrace();
		}
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		Map<String, MultipartFile> fileMap = multipartRequest.getFileMap();
		MultipartFile multipartFile =null;
		String fileName = "";
		String ctxPath = projectConfigration.getFileRootUrl() +"file/" + model+ "/";
		String mapPath = projectConfigration.mappingUrl + "file/" + model+ "/";
		File file = new File(ctxPath);
		if(!file.exists()) file.mkdirs();
		for(Map.Entry<String,MultipartFile > set:fileMap.entrySet()){
			multipartFile = set.getValue();//文件名
			fileName = multipartFile.getOriginalFilename();
            String suffix = fileName.indexOf(".") != -1 ? fileName.substring(fileName.lastIndexOf("."), fileName.length()) : null;
            String newFileName =  "photo"+userId + (suffix!=null?suffix:"");// 构成新文件名。
            File uploadFile = new File(file.getPath() + "/"+newFileName);
            try {  
            	FileCopyUtils.copy(multipartFile.getBytes(), uploadFile); 
                map.put("filePath", mapPath + newFileName);
                if(member != null){
                	member.setPhoto(mapPath + newFileName);
                }else{
                	throw new ProjectException("用户不存在"); 
                }
                zhanglmServiceManage.memberService.edit(member, SessionUser.getSystemUser());
                message = "上传成功";
				result.setStatus(MobileResultBean.SUCCESS);
				result.setObject(map);
            }catch (Exception e) {
            	e.printStackTrace();
            	message = e.getMessage();
			}
		}
		result.setMessage(message);
        return result;
    }
	@RequestMapping(method = RequestMethod.POST, value = "getMemberPhoto")
	@MemberEvent(desc = "安卓/IOS获取用户头像")
	@ResponseBody
	public MobileResultBean getMemberPhoto(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "getMemberPhoto");
		String userId = request.getParameter("userId");
		try {			
				if(StringUtils.isBlank(userId)){
					message = "userId不能为空";
				}else{
					MemberModel member = zhanglmServiceManage.memberService.findById(userId);
					if(member!=null) {
						String memberHeadPhoto = member.getPhoto();
						map.put("memberHeadPhoto", memberHeadPhoto);
						message = "获取成功";
						result.setStatus(MobileResultBean.SUCCESS);
						result.setObject(map);
					} else {
						message = "用户不存在";
						System.out.println("mobile:member is null ,find by name!");
					}
				}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "register")
	@MemberEvent(desc ="安卓/IOS注册")
	@ResponseBody
	public MobileResultBean register(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		MemberView memberView = new MemberView();
		map.put("method", "register");
		try {
			String mobile = request.getParameter("mobile");
			String code = request.getParameter("code");
			String password = request.getParameter("password");
			if (StringUtils.isNotBlank(validateMobileCode(mobile, code))) {
				message = validateMobileCode(mobile, code);
			}else if (StringUtils.isBlank(mobile)) {
				message = "用户名不能为空！";
			}else if (StringUtils.isBlank(password)) {
				message = "密码不能为空！";
			}else if(zhanglmServiceManage.memberService.findByField("mobile", mobile) != null){
					message = "手机号已注册";
			}else{
				memberView.setMobile(mobile);
				memberView.setLoginPass(PasswordUtils.encryptPassword(password));
				memberView.setLoginChannel(BusinessConstants.LOGIN_CHANNEL.PLATFORM);//平台注册
				MemberModel model = new MemberConvert().addConvert(memberView);
				//初始化用户数据
				model.setBalance(0.0);
				model.setCapital(0.0);
				model.setMcoin(0.0);
				zhanglmServiceManage.memberService.add(model, SessionUser.getSystemUser());
				SessionUser user = new SessionUser();
				user.setId(model.getId());
				user.setName(model.getNickName());
				user.setCode(model.getMobile());
				Cache cache = new Cache();
				cache.setKey("user");
				cache.setValue(user);
				CacheManager.putCache("userCache"+user.getId(), cache);
				String url = zhanglmConfigration.projectCacheUrl;
				Map<String, String> params = new HashMap<String, String>();
				params.put("userId", model.getId());
				params.put("nickName", model.getNickName());
				params.put("mobile", mobile);
				String cacheResult = HttpClientHelper.doPost(url, params);
				System.out.println(cacheResult);
				message = "注册成功";
				map.put("userId",model.getId());
				result.setStatus(MobileResultBean.SUCCESS);
				result.setObject(map);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST, value = "login")
	@MemberEvent(desc = "安卓/IOS登录")
	@ResponseBody
	public MobileResultBean login(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		MemberLogStatisticsSearch search = new MemberLogStatisticsSearch();
		map.put("method", "login");
		try {
			String loginType = request.getParameter("loginType");
			Integer loginChannel = Integer.parseInt(loginType);
			if(loginChannel.equals(BusinessConstants.LOGIN_CHANNEL.PLATFORM)){
				String loginName = request.getParameter("mobile");
				String password = request.getParameter("password");
				map.put("channel",BusinessConstants.LOGIN_CHANNEL.PLATFORM);
				if (StringUtils.isBlank(loginName)) {
					message = "用户名不能为空";
				}else if (StringUtils.isBlank(password)) {
					message = "密码不能为空";
				}else{
					MemberModel model = zhanglmServiceManage.memberService.findByField("mobile", loginName);
					if(model==null){
						message ="用户名不存在";
					}else if (!StringUtils.equals(model.getLoginPass(),PasswordUtils.encryptPassword(password))) {
						message = "密码不正确";
					}else{
						String photo = model.getPhoto();
						String nickName = model.getNickName();
						if(StringUtils.isBlank(photo)){
							photo = "/static/projects/file/memberHeadPic/photo4028810355a467040155a47ca4c30002.jpg";
						}
						if(StringUtils.isBlank(nickName)){
							nickName = "用户未设置昵称";
						}
						String userId = model.getId();
						String mobile = model.getMobile();
						SessionUser user = new SessionUser();
						user.setId(userId);
						user.setName(nickName);
						user.setCode(mobile);
						Cache cache = new Cache();
						cache.setKey("user");
						cache.setValue(user);
						CacheManager.putCache("userCache"+user.getId(), cache);
						//同步缓存
				/*		String url = zhanglmConfigration.projectCacheUrl;
						Map<String, String> params = new HashMap<String, String>();
						params.put("userId", userId);
						params.put("nickName", nickName);
						params.put("mobile", mobile);
						String cacheResult = HttpClientHelper.doPost(url, params);
						System.out.println(cacheResult);*/
						message = "登陆成功";
						//评论数
						BbsReplySearch bbsreplysearch = new BbsReplySearch();
						bbsreplysearch.setEqualuserId(userId);
						//收藏数量
						CollectSearch collectSearch = new CollectSearch();
						collectSearch.setEqualUserId(userId);
						Long collect = zhanglmServiceManage.collectService.count(collectSearch);
	
						Long replynumber = zhanglmServiceManage.bbsReplyService.count(bbsreplysearch);
					//	Long replynumber = zhanglmServiceManage.commentReplyService.count(CommentReplySearch);
						map.put("userId", String.valueOf(model.getId()));
						map.put("userPhoto", photo);
						map.put("userNickName", nickName);
						map.put("mobile", mobile);
						map.put("collect", collect);
						//评论回复数量
						map.put("replynumber", replynumber);
						result.setStatus(MobileResultBean.SUCCESS);
						result.setObject(map);
					}
				}
			}else{
				String loginChannelStr = BusinessConstants.LOGIN_CHANNEL.valueMap.get(loginChannel);
				if(StringUtils.isNotBlank(loginChannelStr)){
					MemberModel model = new MemberModel();
					MemberView memberView = new MemberView();
					String nickName = request.getParameter("nickName");//昵称
					String photo = request.getParameter("photo");//头像
					System.out.println("获取信息："+nickName+">>>>头像："+photo);
					if(StringUtils.isBlank(nickName)){
						result.setMessage("获取第三方登陆用户信息失败");
						return result;
					}
					memberView.setLoginChannel(loginChannel);//注册渠道
					if(loginChannel.equals(BusinessConstants.LOGIN_CHANNEL.QQ)){
						String qqNo = request.getParameter("qq");
						model = zhanglmServiceManage.memberService.findByField("qqNo", qqNo);
						memberView.setQqNo(qqNo);
						map.put("channel",BusinessConstants.LOGIN_CHANNEL.QQ);
					}
					if(loginChannel.equals(BusinessConstants.LOGIN_CHANNEL.WEIBO)){
						String weiboNo = request.getParameter("weibo");
						model = zhanglmServiceManage.memberService.findByField("weiboNo", weiboNo);
						memberView.setWeiboNo(weiboNo);
						map.put("channel",BusinessConstants.LOGIN_CHANNEL.WEIBO);
					}
					if(loginChannel.equals(BusinessConstants.LOGIN_CHANNEL.WECHAT)){
						String wechatNo = request.getParameter("wechat");
						model = zhanglmServiceManage.memberService.findByField("wechatNo", wechatNo);
						memberView.setWechatNo(wechatNo);
						map.put("channel",BusinessConstants.LOGIN_CHANNEL.WECHAT);
					}
					
					
					if(null == model){
						memberView.setNickName(nickName);
						memberView.setPhoto(photo);
						model = new MemberConvert().addConvert(memberView);
						zhanglmServiceManage.memberService.add(model, SessionUser.getSystemUser());
					}else{
						model.setNickName(nickName);
						model.setPhoto(photo);
						zhanglmServiceManage.memberService.edit(model, SessionUser.getSystemUser());
					}
					String userId = model.getId();
					String name = model.getNickName();
					String mobile = model.getMobile();
					SessionUser user = new SessionUser();
					user.setId(userId);
					user.setName(name);
					user.setCode(mobile);
					Cache cache = new Cache();
					cache.setKey("user");
					cache.setValue(user);
					CacheManager.putCache("userCache"+user.getId(), cache);
					//同步缓存
				/*	String url = zhanglmConfigration.projectCacheUrl;
					Map<String, String> params = new HashMap<String, String>();
					params.put("userId", userId);
					params.put("nickName", name);
					params.put("mobile", mobile);
					String cacheResult = HttpClientHelper.doPost(url, params);
					System.out.println(cacheResult);*/
					message = "登陆成功";
					//评论数量
					BbsReplySearch bbsreplysearch = new BbsReplySearch();
					bbsreplysearch.setEqualuserId(userId);
					//收藏数量
					CollectSearch collectSearch = new CollectSearch();
					collectSearch.setEqualUserId(userId);
					Long collect = zhanglmServiceManage.collectService.count(collectSearch);

					Long replynumber = zhanglmServiceManage.bbsReplyService.count(bbsreplysearch);
					map.put("userId", String.valueOf(model.getId()));
					map.put("userPhoto", photo);
					map.put("userNickName", nickName);
					map.put("mobile", mobile);
					map.put("collect", collect);
					//评论回复数量
					map.put("replynumber", replynumber);
					result.setStatus(MobileResultBean.SUCCESS);
					result.setObject(map);
				}else{
					message = "请填写正确的loginType值";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
		
	@RequestMapping(method = RequestMethod.POST, value = "writeUserIntro")
	@MemberEvent(desc = "安卓/IOS修改个人简介")
	@ResponseBody
	public MobileResultBean writeUserIntro(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "writeUserIntro");
		try {
			String intro = request.getParameter("intro");//个人简介
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MemberModel member = zhanglmServiceManage.memberService.findById(getSessionUser().getId());
				member.setIntro(intro);
				zhanglmServiceManage.memberService.edit(member, getSessionUser());
				message = "修改成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setObject(map);
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "passwordChange")
	@MemberEvent(desc = "安卓/IOS修改登录密码")
	@ResponseBody
	public MobileResultBean passwordChange(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "passwordChange");
		String oldPass = request.getParameter("oldPassword");
		String newPass = request.getParameter("newPassword");
		try {			
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MemberModel member = zhanglmServiceManage.memberService.findById(getSessionUser().getId());
				String oldPassWord = PasswordUtils.encryptPassword(oldPass);
				if(StringUtils.equals(oldPassWord, member.getLoginPass())){
					String newPassword = PasswordUtils.encryptPassword(newPass);
					member.setLoginPass(newPassword);
					zhanglmServiceManage.memberService.edit(member, getSessionUser());
					message="修改成功";
					result.setStatus(MobileResultBean.SUCCESS);
					result.setObject(map);
				}else{
					message = "原始密码不正确";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "writeUserNickName")
	@MemberEvent(desc = "安卓/IOS修改昵称")
	@ResponseBody
	public MobileResultBean writeUserNickName(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "writeUserNickName");
		try {
			String nickName = request.getParameter("nickName");//昵称
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MemberModel member = zhanglmServiceManage.memberService.findById(getSessionUser().getId());
				member.setNickName(nickName);
				zhanglmServiceManage.memberService.edit(member, getSessionUser());
				message = "修改成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "writeUserSign")
	@MemberEvent(desc = "安卓/IOS修改个性签名")
	@ResponseBody
	public MobileResultBean writeUserSign(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "writeUserInfo");
		try {
			String signature = request.getParameter("signature");//个性签名
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MemberModel member = zhanglmServiceManage.memberService.findById(getSessionUser().getId());
				member.setSignature(signature);
				zhanglmServiceManage.memberService.edit(member, getSessionUser());
				message = "修改成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "setMobile")
	@MemberEvent(desc ="安卓/IOS绑定手机")
	@ResponseBody
	public MobileResultBean setMobile(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "setMobile");
		try {
			String mobile = request.getParameter("mobile");
			String code = request.getParameter("code");
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MemberModel member = zhanglmServiceManage.memberService.findById(getSessionUser().getId());
				if (StringUtils.isNotBlank(validateMobileCode(mobile, code))) {
					message = validateMobileCode(mobile, code);
				}else if (StringUtils.isBlank(mobile)) {
					message = "用户名不能为空！";
				}else if(zhanglmServiceManage.memberService.findByField("mobile", mobile) != null){
						message = "手机号已注册";
				}else{
					member.setMobile(mobile);
					zhanglmServiceManage.memberService.edit(member, getSessionUser());
					message = "更改成功";
					result.setStatus(MobileResultBean.SUCCESS);
					result.setObject(map);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "getUserInfo")
	@MemberEvent(desc = "安卓/IOS 获取用户信息")
	@ResponseBody
	public MobileResultBean getUserInfo(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "getUserInfo");
		try {
			String userId = request.getParameter("userId");//用户ID
			DefaultSearch defaultsearch = new DefaultSearch();
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
			MemberView member = zhanglmServiceManage.memberService.findViewById(userId);
			if(null == member.getPhoto()){
				member.setPhoto(defaultModel.getImgUrl());
			}
			//关注数量
			MemberAttentionSearch search = new MemberAttentionSearch();
			search.setEqualFansId(member.getId());
			Long attentionNum = zhanglmServiceManage.memberAttentionService.count(search);
			member.setAttentionNum(attentionNum);
			//粉丝数量
			search.setEqualFansId(null);
			search.setEqualMemberId(member.getId());
			Long fansNum = zhanglmServiceManage.memberAttentionService.count(search);
			member.setFansNum(fansNum);
			//收藏数量
			CollectSearch collectSearch = new CollectSearch();
			collectSearch.setEqualUserId(member.getId());
			Long collect = zhanglmServiceManage.collectService.count(collectSearch);
			member.setCollect(collect);
			//获取客服电话
			String serviceMobile = sysServiceManage.configService.getValue(ConfigConstants.PLATFORM_TELEPHONE);
			if(StringUtils.isBlank(serviceMobile)){
				serviceMobile = "未设置客服电话";
			}
			member.setServiceMobile(serviceMobile);
			//是否有未读信息
			MemberMsgSearch msgSearch = new MemberMsgSearch();
			msgSearch.setEqualUserId(userId);
			msgSearch.setEqualStatus(BusinessConstants.MEMBER_MSG_STATUS.NOT_READ);
			Long count = zhanglmServiceManage.memberMsgService.count(msgSearch);
			if(count > 0){
				member.setIsNotRead(true);
			}else{
				member.setIsNotRead(false);
			}
			message = "获取成功";
			map.put("user", member);
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "readMsg")
	@MemberEvent(desc = "安卓/IOS 标记为已读")
	@ResponseBody
	public MobileResultBean readMsg(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "readMsg");
		try {
		   if(!isLogin()){
			   message = "登陆失效";
		   }else{
			  String msgId = request.getParameter("msgId");
			  MemberMsgSearch search = new MemberMsgSearch();
			  search.setEqualUserId(getSessionUser().getId());
			  List<MemberMsgModel> model = zhanglmServiceManage.memberMsgService.list(search);
			  for(MemberMsgModel member : model){
				  if(member.getId().equals(msgId)){
			          member.setStatus(BusinessConstants.MEMBER_MSG_STATUS.READED);
			          zhanglmServiceManage.memberMsgService.edit(member, getSessionUser());
				  }
			  }
			  message = "更改成功";
			  result.setObject(map);
			  result.setStatus(MobileResultBean.SUCCESS);
		   }
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "getMemberMsgs")
	@MemberEvent(desc = "安卓/IOS 获取用户消息")
	@ResponseBody
	public MobileResultBean getMemberMsgs(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<MemberMsgView> msgList = new ArrayList<MemberMsgView>();
		map.put("method", "getMemberMsgs");
		String currPage = request.getParameter("currPage");
		String pageSize = request.getParameter("pageSize");
		Long number = 0L;
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MemberMsgSearch search = new MemberMsgSearch();
				search.setPage(Integer.parseInt(currPage));;
				search.setRows(Integer.parseInt(pageSize));
				search.setOrder(BaseSearch.Order_Type_Desc);
				search.setEqualUserId(getSessionUser().getId());
				msgList = zhanglmServiceManage.memberMsgService.viewList(search);
				number = zhanglmServiceManage.memberMsgService.count(search);
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("msgList", msgList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "emptyMemberMsgs")
	@MemberEvent(desc = "安卓/IOS 清空用户消息")
	@ResponseBody
	public MobileResultBean emptyMemberMsgs(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<MemberMsgModel> msgList = new ArrayList<MemberMsgModel>();
		map.put("method", "emptyMemberMsgs");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MemberMsgSearch search = new MemberMsgSearch();
				search.setEqualUserId(getSessionUser().getId());
				msgList =zhanglmServiceManage.memberMsgService.list(search);
				Set<MemberMsgModel> delSet = new HashSet<MemberMsgModel>();
				delSet.addAll(msgList);
				zhanglmServiceManage.memberMsgService.deletes(delSet, getSessionUser());
				message = "已清空";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "attention")
	@MemberEvent(desc = "安卓/IOS 添加关注")
	@ResponseBody
	public MobileResultBean attention(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "attention");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String memberId = request.getParameter("memberId");
				System.out.println(memberId);
				String fansId = getSessionUser().getId();
				if(StringUtils.equals(memberId, fansId)){
					result.setMessage("自己不能关注自己");
					return result;
				}
				MemberAttentionSearch search = new MemberAttentionSearch();
				search.setEqualFansId(fansId);
				search.setEqualMemberId(memberId);
				MemberAttentionModel model = zhanglmServiceManage.memberAttentionService.findBySearch(search);
				if(model != null){
					result.setMessage("您已经关注过了");
					return result;
				}else{
					model = new MemberAttentionModel();
					model.setMemberId(memberId);
					model.setFansId(fansId);
					zhanglmServiceManage.memberAttentionService.add(model, getSessionUser());
					message = "关注成功";
					result.setObject(map);
					result.setStatus(MobileResultBean.SUCCESS);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "cancelAttention")
	@MemberEvent(desc = "安卓/IOS 取消关注")
	@ResponseBody
	public MobileResultBean cancelAttention(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "cancelAttention");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String memberId = request.getParameter("memberId");
				String fansId = getSessionUser().getId();
				MemberAttentionSearch search = new MemberAttentionSearch();
				search.setEqualFansId(fansId);
				search.setEqualMemberId(memberId);
				MemberAttentionModel model = zhanglmServiceManage.memberAttentionService.findBySearch(search);
				zhanglmServiceManage.memberAttentionService.delete(model, getSessionUser());
				message = "取消关注成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "myAttentions")
	@MemberEvent(desc = "安卓/IOS 我的关注列表")
	@ResponseBody
	public MobileResultBean myAttentions(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<MemberAttentionModel> viewList = new ArrayList<MemberAttentionModel>();
		List<MemberView> attentionList = new ArrayList<MemberView>();
		map.put("method", "myAttentions");
		String currPage = request.getParameter("currPage");
		String pageSize = request.getParameter("pageSize");
		Long number = 0L;
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MemberAttentionSearch search = new MemberAttentionSearch();
				search.setPage(Integer.parseInt(currPage));;
				search.setRows(Integer.parseInt(pageSize));
				search.setOrder(BaseSearch.Order_Type_Desc);
				search.setEqualFansId(getSessionUser().getId());
				viewList = zhanglmServiceManage.memberAttentionService.list(search);
				number = zhanglmServiceManage.memberAttentionService.count(search);
				attentionList = zhanglmServiceManage.memberService.ViewDataList(viewList, getSessionUser());
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("attentionList", attentionList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "myFans")
	@MemberEvent(desc = "安卓/IOS 我的粉丝列表")
	@ResponseBody
	public MobileResultBean myFans(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<MemberAttentionModel> viewList = new ArrayList<MemberAttentionModel>();
		List<MemberView> fansList = new ArrayList<MemberView>();
		String currPage = request.getParameter("currPage");
		String pageSize = request.getParameter("pageSize");
		Long number = 0L;
		map.put("method", "myFans");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MemberAttentionSearch search = new MemberAttentionSearch();
				//将页数与条数存入
				search.setEqualMemberId(getSessionUser().getId());
				search.setPage(Integer.parseInt(currPage));
				search.setRows(Integer.parseInt(pageSize));
				search.setOrder(BaseSearch.Order_Type_Desc);
				viewList = zhanglmServiceManage.memberAttentionService.list(search);
				//粉丝总数
				number = zhanglmServiceManage.memberAttentionService.count(search);
				fansList = zhanglmServiceManage.memberService.ViewFansDataList(viewList, getMobileUser());
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("fansList", fansList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "addCollect")
	@MemberEvent(desc = "安卓/IOS 添加收藏")
	@ResponseBody
	public MobileResultBean collect(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "addCollect");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String circleId = request.getParameter("circleId");
				String userId = getSessionUser().getId();
				CollectSearch search = new CollectSearch();
				search.setEqualCircleId(circleId);
				search.setEqualUserId(userId);
				CollectModel model = zhanglmServiceManage.collectService.findBySearch(search);
				if(model != null){
					result.setMessage("您已经收藏了");
					return result;
				}
				model = new CollectModel();
				model.setCircleId(circleId);
				model.setUserId(userId);
				zhanglmServiceManage.collectService.add(model, getSessionUser());
				message = "收藏成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "cancelCollect")
	@MemberEvent(desc = "安卓/IOS 取消收藏")
	@ResponseBody
	public MobileResultBean cancelCollect(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "cancelCollect");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String circleId = request.getParameter("circleId");
				String userId = getSessionUser().getId();
				CollectSearch search = new CollectSearch();
				search.setEqualUserId(userId);
				search.setEqualCircleId(circleId);
				CollectModel model = zhanglmServiceManage.collectService.findBySearch(search);
				zhanglmServiceManage.collectService.delete(model, getSessionUser());
				message = "取消收藏成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "myCollect")
	@MemberEvent(desc = "安卓/IOS 我的收藏列表")
	@ResponseBody
	public MobileResultBean myCollect(CollectSearch search){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "myCollect");
		String currPage = request.getParameter("currPage");
		String pageSize = request.getParameter("pageSize");
		Long number = 0L;
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
			    search.setEqualUserId(getSessionUser().getId());
			    search.setPage(Integer.parseInt(currPage));;
			    search.setRows(Integer
			    		.parseInt(pageSize));
				search.setSort("datetime");
				search.setOrder(BaseSearch.Order_Type_Desc);
				List<CollectView> collectList = zhanglmServiceManage.collectService.collectListMobile(search);
				number = zhanglmServiceManage.collectService.count(search);
	
				
				if(collectList != null && collectList.size() > 0){
					map.put("number", number);
					map.put("currPage", currPage);
					map.put("collectList", collectList);
					message = "获取成功";
					result.setObject(map);
					result.setStatus(MobileResultBean.SUCCESS);
				}else{
					map.put("number", number);
					map.put("currPage", currPage);
					map.put("collectList", collectList);
					message = "没有收藏";
					result.setObject(map);
					result.setStatus(MobileResultBean.SUCCESS);
					return result;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "emptyCollect")
	@MemberEvent(desc = "安卓/IOS 清空我的收藏列表")
	@ResponseBody
	public MobileResultBean emptyCollect(CollectSearch search){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "emptyCollect");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
			    search.setEqualUserId(getSessionUser().getId());
				List<CollectModel> collectList = zhanglmServiceManage.collectService.list(search);
				Set<CollectModel> delCollect = new HashSet<CollectModel>();
				if(collectList != null && collectList.size() > 0){
					delCollect.addAll(collectList);
					zhanglmServiceManage.collectService.deletes(delCollect, getSessionUser());
				/*	for(CollectModel coll : collectList){
						BbsTopicModel bbstopic = zhanglmServiceManage.bbsTopicService.findByField("id", coll.getCircleId());
						Integer tag = bbstopic.getCollection();
						bbstopic.setCollection(--tag);
						zhanglmServiceManage.bbsTopicService.edit(bbstopic, getSessionUser());
					}*/
				}
			
				
				
				if(collectList != null && collectList.size() > 0){
					message = "已清空";
					result.setObject(map);
					result.setStatus(MobileResultBean.SUCCESS);
				}else{
					message = "没有数据";
					result.setObject(map);
					result.setStatus(MobileResultBean.SUCCESS);
					return result;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "forget")
	@MemberEvent(desc ="安卓/IOS 忘记密码")
	@ResponseBody
	public MobileResultBean forget(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		MemberView memberView = new MemberView();
		map.put("method", "forget");
		try {
			//用户名，手机验证码，新密码
			String mobile = request.getParameter("mobile");
			String code = request.getParameter("code");
			String password = request.getParameter("password");
			if (StringUtils.isNotBlank(validateMobileCode(mobile, code))) {
				message = validateMobileCode(mobile, code);
			}else if (StringUtils.isBlank(mobile)) {
				message = "用户名不能为空！";
			}else if (StringUtils.isBlank(password)) {
				message = "密码不能为空！";
			}else if(zhanglmServiceManage.memberService.findByField("mobile", mobile) == null){
					message = "手机号未注册";
			}else{
				memberView.setMobile(mobile);
				memberView.setLoginPass(PasswordUtils.encryptPassword(password));
				MemberSearch search = new MemberSearch();
				search.setEqualMobile(mobile);
				MemberModel member = zhanglmServiceManage.memberService.findBySearch(search);
				String newPassword = PasswordUtils.encryptPassword(password);
				if(StringUtils.equals(newPassword, member.getLoginPass())){
					message = "新密码跟旧密码不能相同";
				}else {
				member.setLoginPass(newPassword);
				zhanglmServiceManage.memberService.edit(member, getMobileUser());
				message = "修改密码成功";
				result.setStatus(MobileResultBean.SUCCESS);
				result.setObject(map);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}

	@RequestMapping(method = RequestMethod.POST, value = "signIn")
	@MemberEvent(desc = "安卓/IOS 用户签到")
	@ResponseBody
	public MobileResultBean signIn(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "signIn");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				SignInSearch search = new SignInSearch();
				search.setEqualUserId(getSessionUser().getId());
				SignInModel signIn = zhanglmServiceManage.signInService.findBySearch(search);
				if(null == signIn){
					Date date = new Date();
					SignInModel model = new SignInModel();
					model.setUserId(getSessionUser().getId());
					model.setDate(date);
					zhanglmServiceManage.signInService.add(model, getSessionUser());
					message = "签到成功";
				}else{
					message = "请不要重复签到";
				}
				
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "getSignIn")
	@MemberEvent(desc = "安卓/IOS 获取用户签到纪录")
	@ResponseBody
	public MobileResultBean getSignIn(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<Map<String, Object>> signList = new ArrayList<Map<String,Object>>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Boolean isSign = null;
		map.put("method", "getSignIn");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				//获取用户前90条签到日期
				SignInSearch search = new SignInSearch();
				search.setEqualUserId(getSessionUser().getId());
				search.setRows(90);
				search.setOrder(BaseSearch.Order_Type_Desc);
				List<SignInModel> List = zhanglmServiceManage.signInService.list(search);
				for(SignInModel model : List){
					Map<String,Object> newMap = new HashMap<String, Object>();
					newMap.put("date", sdf.format(model.getDate()));
					signList.add(newMap);
				}
				//获取当前用户是否签到
				Date date = new Date();
				SignInSearch searchTwo = new SignInSearch();
				searchTwo.setEqualUserId(getSessionUser().getId());
				searchTwo.setEqualDate(DateUtil.format(date, "yyyy-MM-dd"));
			    SignInModel signIn = zhanglmServiceManage.signInService.findBySearch(searchTwo);
				if(null != signIn){
					isSign = true;
				}else{
					isSign = false;
				}
				String today = String.valueOf(sdf.format(date));
				map.put("today", today);
				map.put("isSign", isSign);
				map.put("signList", signList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "syncUser")
	@MemberEvent(desc = "安卓/IOS 同步用户缓存")
	@ResponseBody
	public MobileResultBean syncUser(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "bufferMemory");
		try {
			String userId = request.getParameter("userId");
			String nickName = request.getParameter("nickName");
			String mobile = request.getParameter("mobile");
			SessionUser user = new SessionUser();
		    user.setId(userId);
		    user.setName(nickName);
		    user.setCode(mobile);
		    Cache cache = new Cache();
		    cache.setKey("user");
		    cache.setValue(user);
		    CacheManager.putCache("userCache"+user.getId(), cache);
		    message = "存入成功";
		    result.setObject(map);
		    result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "syncTourist")
	@MemberEvent(desc = "安卓/IOS 同步游客缓存")
	@ResponseBody
	public MobileResultBean syncTourist(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "syncTourist");
		try {
			String tourId = request.getParameter("tourId");
			CacheManager.getCacheInfo("userCache" + tourId);
		    Cache cache = new Cache();
		    cache.setKey("tour");
	    	cache.setValue(tourId);
		    CacheManager.putCache("userCache"+tourId, cache);
		    message = "存入成功";
		    result.setObject(map);
		    result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "deleteMemory")
	@MemberEvent(desc = "安卓/IOS 同步清除缓存")
	@ResponseBody
	public MobileResultBean deleteMemory(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "deleteMemory");
		try {
			String cacheKey = request.getParameter("cacheKey");
			CacheManager.clearOnly(cacheKey);
			message = "删除成功";
			result.setStatus(MobileResultBean.SUCCESS);
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	
	//统计黄金登录数量
	@RequestMapping(method = RequestMethod.POST, value = "getMemberStatisticalogin")
	@MemberEvent(desc = "安卓/IOS统计黄金使用数量")
	@ResponseBody
	public MobileResultBean getMemberStatisticalogin(MemberLogStatisticsView view) {
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "getMemberStatisticalogin");
		try {	
			if (StringUtils.isBlank(view.getMobile_phone())){
				message="手机号不能为空";
				return result;
			}
			MemberLogStatisticsModel model = new MemberLogStatisticsModel();
			MemberLogStatisticsSearch  search = new MemberLogStatisticsSearch();
			if(null != view){
				//model.setId(UUID.randomUUID().toString());
				model.setAcct_no(view.getAcct_no());
				model.setB_sys_stat(view.getB_sys_stat());
				model.setBranch_id(view.getBranch_id());
				model.setCust_id(view.getCust_id());
				if(StringUtils.isNotBlank(view.getCust_name())){
					model.setCust_name(URLDecoder.decode(view.getCust_name(),"utf-8"));
				}			
				model.setExch_date(view.getExch_date());
				model.setLast_exch_date(view.getLast_exch_date());
				model.setLast_login_date(view.getLast_login_date());
				model.setLast_login_time(view.getLast_login_time());
				model.setM_sys_stat(view.getM_sys_stat());
				model.setMember_id(view.getMember_id());
				model.setMobile_phone(view.getMobile_phone());
				model.setUserID(view.getUserID());
				model.setIsDisable(true);
				//查询一条
				search.setEqualmobilephone(view.getMobile_phone());
				MemberLogStatisticsModel md =zhanglmServiceManage.memberlogstatisticsservicei.findBySearch(search);
				GoldbinduseruserModel binduseruser = new GoldbinduseruserModel();
				if(null != md ){
					if(view.getMobile_phone().equals(md.getMobile_phone())){
						//zhanglmServiceManage.memberlogstatisticsservicei.update(model);
					}
				}else{
					String goid = zhanglmServiceManage.memberlogstatisticsservicei.add(model);
					if (StringUtils.isNotBlank(goid)){
						MemberModel mebel =	zhanglmServiceManage.memberService.findByField("mobile", view.getMobile_phone());
						if(StringUtils.isNotEmpty(mebel.getMobile())){
							binduseruser.setBinduseruserid(goid);
							binduseruser.setMembersid(mebel.getId());
							String binduser = zhanglmServiceManage.memberlogstatisticsservicei.addbinduser(binduseruser);
							if(null !=binduser){
								message = "绑定成功";
								result.setStatus(MobileResultBean.SUCCESS);
								result.setObject(map);
							}
						}else{
							result.setStatus(MobileResultBean.SUCCESS);
							result.setObject(map);
						}
					}else{
						message = "客户未注册本平台";
						//result.setStatus(MobileResultBean.ERROR);
						//result.setObject(map);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			//message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	//银行转账信息接口
	@RequestMapping(method = RequestMethod.POST, value = "bankMessage")
	@MemberEvent(desc = "统计银行转账信息接口")
	@ResponseBody
	public MobileResultBean bankMessage() {
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "bankMessage");
		try {
			String accNo = request.getParameter("accNo"); 
			String transferFund = request.getParameter("transferFund"); 
			String transfertime = request.getParameter("transfertime"); 
			String bankCard = request.getParameter("bankCard"); 
			BankMessageModel model = new BankMessageModel();
			if (StringUtils.isBlank(accNo)){
				message="客户号不能为空";
				return result;
			}
			model.setAccNo(accNo);
			model.setTransferFund(transferFund);
			model.setTransfertime(transfertime);
			model.setBankCard(bankCard);
			String bankMessageid = zhanglmServiceManage.bankmessageservicei.add(model);
			if (StringUtils.isNotBlank(bankMessageid)){
				message = "添加成功";
				result.setStatus(MobileResultBean.SUCCESS);
				result.setObject(map);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	//统计当日成交信息记录
	@RequestMapping(method = RequestMethod.POST, value = "todayDeal")
	@MemberEvent(desc = "统计当日成交信息记录")
	@ResponseBody
	public MobileResultBean todayDeal(TodayDealView view) {
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "todayDeal");
		try {
			if (StringUtils.isBlank(view.getAccNo())){
				message="客户号不能为空";
				return result;
			}
			TodayDealModel model = new TodayDealModel();
			if(view != null){
				model.setAccNo(view.getAccNo());
				model.setCommision(view.getCommision());
				model.setDealAccount(view.getDealAccount());
				model.setDeposit(view.getDeposit());
				model.setDirection(view.getDirection());
				model.setEachPrice(view.getEachPrice());
				model.setInstId(view.getInstId());
				model.setLocalOrderNo(view.getLocalOrderNo());
				model.setTradeDate(view.getTradeDate());
				if(model != null){
					String todaydealid = zhanglmServiceManage.todaydealservicei.add(model);
					if (StringUtils.isNotBlank(todaydealid)){
						message = "添加成功";
						result.setStatus(MobileResultBean.SUCCESS);
						result.setObject(map);
					}
				}
			}
		
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
}
