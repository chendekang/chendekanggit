package com.jrzh.mvc.controller.zhanglm.mobile;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.config.ProjectConfigration;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.BbsCommentsModel;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;
import com.jrzh.mvc.model.zhanglm.BbsMenuModel;
import com.jrzh.mvc.model.zhanglm.BbsPraiseModel;
import com.jrzh.mvc.model.zhanglm.BbsReplyModel;
import com.jrzh.mvc.model.zhanglm.BbsReplyPraiseModel;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.model.zhanglm.CollectModel;
import com.jrzh.mvc.model.zhanglm.CommentReplyModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.model.zhanglm.MemberAttentionModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.MemberMsgModel;
import com.jrzh.mvc.search.zhanglm.BbsCommentsSearch;
import com.jrzh.mvc.search.zhanglm.BbsFanSearch;
import com.jrzh.mvc.search.zhanglm.BbsMenuSearch;
import com.jrzh.mvc.search.zhanglm.BbsPraiseSearch;
import com.jrzh.mvc.search.zhanglm.BbsReplyPraiseSearch;
import com.jrzh.mvc.search.zhanglm.BbsTopicSearch;
import com.jrzh.mvc.search.zhanglm.CollectSearch;
import com.jrzh.mvc.search.zhanglm.CommentReplySearch;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.MemberAttentionSearch;
import com.jrzh.mvc.search.zhanglm.SharePageSearch;
import com.jrzh.mvc.view.zhanglm.BbsFanView;
import com.jrzh.mvc.view.zhanglm.BbsMenuView;
import com.jrzh.mvc.view.zhanglm.BbsPraiseView;
import com.jrzh.mvc.view.zhanglm.BbsReplyView;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;
import com.jrzh.mvc.view.zhanglm.CommentReplyView;
import com.jrzh.mvc.view.zhanglm.SharePageView;

@Controller(newBbsController.LOCATION + "newBbsController")
@RequestMapping(newBbsController.LOCATION)
public class newBbsController extends BaseMobileController {
	public static final String LOCATION = "/mobile/newbbs/";
	public Logger logger = Logger.getLogger(newBbsController.class);
	@Autowired
	private ProjectConfigration projectConfigration;
	/*--------------------新第一个接口index首页----------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "boardMenus")
	@MemberEvent(desc = "安卓/IOS圈子 index首页")
	@ResponseBody
	public MobileResultBean index(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsMenuView> boardMenuList = new ArrayList<BbsMenuView>();
		String message = "";
		map.put("method", "boardMenus");
		try {	
			
			/*String pid = request.getParameter("pid");
			BbsMenuSearch search = new BbsMenuSearch();
			search.setEqualIsDisable(false);
			search.setEqualPid(pid);
			boardMenuList = zhanglmServiceManage.bbsMenuService.viewList(search);
			map.put("boardMenuList", boardMenuList);*/
			
			BbsFanSearch fansSearch = new BbsFanSearch();
			SessionUser user = getMobileUser();
			MemberModel member = null;
			if(null != user){
				fansSearch.setEqualUserId(user.getId());
				member = zhanglmServiceManage.memberService.findById(user.getId());
				request.setAttribute("userId", user.getId());
				List<BbsFanModel> list = zhanglmServiceManage.bbsFanService.list(fansSearch);
				BbsMenuSearch myMenuSearch = new BbsMenuSearch();
				myMenuSearch.setEqualIsDisable(false);
				int x = list.size();
				if(x> 0){
					String[] inId = new String[x];
					for(int i=0;i<x;i++){
						inId[i] = list.get(i).getMenuId();
					}
					myMenuSearch.setInId(inId);
					List<BbsMenuView> myList = zhanglmServiceManage.bbsMenuService.viewMenu(myMenuSearch,member);
					request.setAttribute("myList", myList);
				}
			}
			BbsMenuSearch search = new BbsMenuSearch();
/*			search.setEqualIsDisable(false);
			List<BbsMenuView> menuList = new ArrayList<BbsMenuView>();
			List<BbsMenuView> viewList = zhanglmServiceManage.bbsMenuService.viewList(search);
			for(BbsMenuView menu : viewList){
				if(StringUtils.isBlank(menu.getPid())){
					search.setEqualPid(menu.getId());
					Long count = zhanglmServiceManage.bbsMenuService.count(search);
					menu.setBroadNum(count);
					menuList.add(menu);
				}
			}
			request.setAttribute("menuList", menuList);*/
			//search.setEqualPid(null);
			//是否推荐1是true false否是0
			search.setEqualIsLock(true);
		    boardMenuList  = zhanglmServiceManage.bbsMenuService.newviewMenu(search,member);
		    if(boardMenuList !=null && boardMenuList.size() > 0 ){
		    	map.put("boardMenuList", boardMenuList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
		    }else{
		    	message = "没获取数据";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
		    }
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("methods index"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	/*--------------------新第二个接口手机话题发表圈子名称----------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "userBoardMenus")
	@MemberEvent(desc = "安卓/IOS圈子 版块菜单")
	@ResponseBody
	public MobileResultBean userBoardMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsMenuModel> resultview = new ArrayList<BbsMenuModel>();
		String message = "";
		map.put("method", "userBoardMenus");
		try {
			String userId = request.getParameter("userId");
			if(StringUtils.isBlank(userId)){
				result.setMessage("用户id不能为空");
				return result;
			}
			BbsFanSearch search = new BbsFanSearch();
			search.setEqualUserId(userId);
			List<BbsFanView> viewList = zhanglmServiceManage.bbsFanService.viewList(search);		
			HashSet<BbsFanView> setbbsfan = new HashSet<BbsFanView>();
			if(viewList != null && viewList.size() > 0){
				for(BbsFanView view : viewList){
					BbsFanView v = new BbsFanView();
					v.setMenuId(view.getMenuId());
					setbbsfan.add(v);
				}

				for (BbsFanView vs : setbbsfan) {

					BbsMenuModel bbsmenu = zhanglmServiceManage.bbsMenuService.findByField("id", vs.getMenuId());
					resultview.add(bbsmenu);
				} 	
			}
			if(resultview != null && resultview.size() > 0){
				
				map.put("userBoardList", resultview);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---userBoardMenus---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	/*--------------------新第三个接口手机话题保存----------------------------*/
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST, value = "publishTopic")
	@MemberEvent(desc = "安卓/IOS圈子 发表话题")
	@ResponseBody
	public MobileResultBean publishTopic(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "publishTopic");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String title = request.getParameter("title");//标题
				String content = request.getParameter("content");//内容
				String boardId = request.getParameter("boardId");//版块代码
				//String menuCode = request.getParameter("menuCode");//版块代码
				String imgurl = request.getParameter("imgUrl");//图片路径
				System.out.println(imgurl);
				if(StringUtils.isBlank(title)){
					result.setMessage("标题不能为空");
					return result;
				}
				if(StringUtils.isBlank(content)){
					result.setMessage("内容不能为空");
					return result;
				}
				if(StringUtils.isBlank(boardId)){
					result.setMessage("请选择要发布的圈子");
					return result;
				}
				BbsTopicModel model = new BbsTopicModel();
				model.setTitle(title);
				model.setContent(content);
				model.setUserId(getSessionUser().getId());
				model.setUserName(getSessionUser().getName());
				model.setDiscuss(0);
				model.setPraise(0);
				//model.setMenuCode(menuCode);
				model.setMenuid(boardId);
				if(StringUtils.isNotBlank(imgurl)){
					model.setImgUrl(imgurl);
				}
				model.setStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDING);
				if(null != model){
					zhanglmServiceManage.bbsTopicService.addTopic(model, getSessionUser());
					System.out.println(model);
					message = "发布成功，等待工作人员审核";
					result.setObject(map);
					result.setStatus(MobileResultBean.SUCCESS);
				}else{
					message = "发布失败";
					result.setMessage(message);
					result.setStatus(MobileResultBean.ERROR);
					return result;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---publishTopic---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	/*--------------------新第四个接口获取圈子的详细信息---------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "bbsDetail")
	@MemberEvent(desc = "安卓/IOS圈子的详细信息")
	@ResponseBody
	public MobileResultBean bbsdetail(String boardId,String userId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "bbsDetail");
		try {
			//String boardId = request.getParameter("boardId");
			//String userId = request.getParameter("userId");
			if(StringUtils.isBlank(boardId)){
				result.setMessage("圈子id不能为空");
				return result;
			}
/*			if(StringUtils.isBlank(userId)){
				result.setMessage("userId不能为空");
				return result;
			}*/
	/*		String type = request.getParameter("type");
			if(StringUtils.isNotBlank(type)){
				request.setAttribute("type", type);
			}*/
	/*		SessionUser user = getMobileUser();
			MemberModel member = null;
			if(user != null){
				request.setAttribute("userId", user.getId());
				member = zhanglmServiceManage.memberService.findById(user.getId());
			}*/

			BbsMenuView view = zhanglmServiceManage.bbsMenuService.viewMenuByid(boardId, userId);
/*			request.setAttribute("view", view);	
			BbsFanSearch fanSearch = new BbsFanSearch();
			fanSearch.setEqualMenuId(view.getId());
			fanSearch.setSort("average");
			fanSearch.setOrder(BaseSearch.Order_Type_Desc);
			fanSearch.setRows(6);
			List<BbsFanView> fansList = zhanglmServiceManage.bbsFanService.viewList(fanSearch);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(new DefaultSearch());
			if(defaultImg != null){
				for( BbsFanView fan : fansList){
					if(StringUtils.isBlank(fan.getUserPhoto())){
						fan.setUserPhoto(defaultImg.getImgUrl());
					}
				}
			}
			request.setAttribute("fansNum", fansList.size());
			request.setAttribute("fansList", fansList);
			BbsTopicSearch search = new BbsTopicSearch();
			search.setEqualMenuCode(menuCode);
			search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			search.setSort("average");
			search.setOrder(BaseSearch.Order_Type_Desc);
			BbsTopicView hotView = zhanglmServiceManage.bbsTopicService.viewFirstTopic(search,user);
			request.setAttribute("hotView", hotView);
			search.setSort("auditTime");
			List<BbsTopicView> topicList = zhanglmServiceManage.bbsTopicService.viewListTopic(search, user);
			request.setAttribute("topicList", topicList);*/			
			if(null != view){
				map.put("menuView", view);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---bbsdetail---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	/*--------------------新第五个接口获取圈子的活跃用户---------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "bbsPeoples")
	@MemberEvent(desc = "安卓/IOS获取圈子的活跃用户")
	@ResponseBody
	public MobileResultBean bbspeoples(String currPage,String boardId,String pageSize) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "bbsPeoples");
		//请求页数
		//String currPage = request.getParameter("currPage");
		//每页条数
		//String pageSize = request.getParameter("pageSize");
		//圈子id
		//String boardId = request.getParameter("boardId");
		Long number = 0L;
		try {
			if(StringUtils.isBlank(boardId)){
				result.setMessage("圈子id不能为空");
				return result;
			}	
			// BbsMenuModel view =
			// zhanglmServiceManage.bbsMenuService.findByField("id", boardId);
			BbsFanSearch fanSearch = new BbsFanSearch();
			fanSearch.setEqualMenuId(boardId);
			fanSearch.setPage(Integer.parseInt(currPage));
			fanSearch.setRows(Integer
			    		.parseInt(pageSize));
			fanSearch.setSort("average");
			fanSearch.setOrder(BaseSearch.Order_Type_Desc);
	/*		fanSearch.setEqualMenuId(boardId);
			fanSearch.setSort("average");
			fanSearch.setOrder(BaseSearch.Order_Type_Desc);
			fanSearch.setRows(6);*/
			List<BbsFanView> fansList = zhanglmServiceManage.bbsFanService.viewList(fanSearch);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(new DefaultSearch());
			if (defaultImg != null) {
				for (BbsFanView fan : fansList) {
					if (StringUtils.isBlank(fan.getUserPhoto())) {
						fan.setUserPhoto(defaultImg.getImgUrl());
					}
				}
			}
			//request.setAttribute("fansNum", fansList.size());
			//request.setAttribute("fansList", fansList);
			/*BbsTopicSearch search = new BbsTopicSearch();
			search.setEqualMenuCode(menuCode);
			search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			search.setSort("average");
			search.setOrder(BaseSearch.Order_Type_Desc);
			BbsTopicView hotView = zhanglmServiceManage.bbsTopicService.viewFirstTopic(search, user);
			request.setAttribute("hotView", hotView);
			search.setSort("auditTime");
			List<BbsTopicView> topicList = zhanglmServiceManage.bbsTopicService.viewListTopic(search, user);
			request.setAttribute("topicList", topicList);*/
			number = zhanglmServiceManage.bbsFanService.count(fanSearch);
			if(fansList != null && fansList.size() > 0){
				map.put("number", number);
				map.put("currPage", currPage);
				map.put("peopleViewList", fansList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---bbspeoples---"+e.getMessage());
		};
		result.setMessage(message);
		return result;
	}
	
	/*--------------------新第六个接口获取圈子的话题观点---------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "bbsComments")
	@MemberEvent(desc = "安卓/IOS获取圈子的话题观点")
	@ResponseBody
	public MobileResultBean bbscomments(String boardId,String currPage,String pageSize,String userId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
/*		map.put("method", "bbsComments");
		//请求页数
		String currPage = request.getParameter("currPage");
		//每页条数
		String pageSize = request.getParameter("pageSize");
		//圈子编码
		String boardId = request.getParameter("boardId");*/
		Long number = 0L;
		try {
			if(StringUtils.isBlank(boardId)){
				result.setMessage("圈子id不能为空");
				return result;
			}
			if(StringUtils.isBlank(currPage)){
				result.setMessage("请求页数不能为空");
				return result;
			}
			SessionUser user = getMobileUser();
			BbsTopicSearch search = new BbsTopicSearch();
			search.setPage(Integer.parseInt(currPage));
			search.setRows(Integer
			    		.parseInt(pageSize));
			search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Desc);
			//BbsTopicView hotView = zhanglmServiceManage.bbsTopicService.viewFirstTopic(search,user);
			//request.setAttribute("hotView", hotView);
			//search.setSort("auditTime");
			search.setEqualmenuid(boardId);
			List<BbsTopicView> topicList = zhanglmServiceManage.bbsTopicService.newviewListTopic(search, userId);
			//List<BbsReplyView> topicList = zhanglmServiceManage.bbsReplyService.viewListReply(search, user);	
			//request.setAttribute("topicList", topicList);			
			number = zhanglmServiceManage.bbsTopicService.count(search);
			if(topicList != null && topicList.size() > 0){
				map.put("number", number);
				map.put("currPage", currPage);
				map.put("commentView", topicList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}else{
				map.put("number", number);
				map.put("currPage", currPage);
				map.put("commentView", topicList);
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---bbscomments---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	/*--------------------新第七个接口 加入圈子---------------------------*/
	@RequestMapping(method = RequestMethod.POST, value = "joinBroad")
	@MemberEvent(desc = "安卓/IOS圈子 加入圈子")
	@ResponseBody
	public MobileResultBean joinBroad(String boardId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "joinBroad");
		try {
			
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				//String boardId = request.getParameter("boardId");
				if(StringUtils.isBlank(boardId)){
					result.setMessage("圈子id不能为空");
					return result;
				}
				//String userId = request.getParameter("userId");
				//String browser = request.getParameter("browser");
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findById(boardId);
				if(null != menu){
					BbsFanModel model = new BbsFanModel();
					model.setMenuId(boardId);
					model.setUserId(getSessionUser().getId());
					model.setTopicNum(0L);
					model.setPraiseNum(0L);
					model.setReplyNum(0L);	
					zhanglmServiceManage.bbsFanService.add(model, getSessionUser());
					message = "加入成功";
					result.setStatus(MobileResultBean.SUCCESS);
				}else{
					message = "圈子不存在";
					result.setMessage(message);
					result.setStatus(MobileResultBean.ERROR);
					return result;
				}
				//result.setObject(browser);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---joinBroad---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	

	/*--------------------新第八个接口 获取名家已加入的圈子列表---------------------------*/
	/*
	 * 观点我的圈子
	 * 
	 * */
	@RequestMapping(method = RequestMethod.POST,value = "getFamousBoardMenus")
	@MemberEvent(desc = "安卓/IOS圈子获取名家已加入的圈子列表")
	@ResponseBody
	public MobileResultBean getfamousboardmenus(String famousId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getfamousboardmenus");
		//名家个人ID
		//String famousId = request.getParameter("famousId");
		List<BbsMenuView> myList =new ArrayList<BbsMenuView>();
		try {
			if(StringUtils.isBlank(famousId)){
				result.setMessage("名家个人ID不能为空");
				return result;
			}
			BbsFanSearch fansSearch = new BbsFanSearch();
			// SessionUser user = getMobileUser();
			// if(null != user){
			fansSearch.setEqualUserId(famousId);
			MemberModel member = zhanglmServiceManage.memberService.findById(famousId);
			List<BbsFanModel> list = zhanglmServiceManage.bbsFanService.list(fansSearch);
			BbsMenuSearch myMenuSearch = new BbsMenuSearch();
			myMenuSearch.setEqualIsDisable(false);
			int x = list.size();
			if (x > 0) {
				String[] inId = new String[x];
				for (int i = 0; i < x; i++) {
					inId[i] = list.get(i).getMenuId();
				}
				myMenuSearch.setInId(inId);
				myList = zhanglmServiceManage.bbsMenuService.viewMenu(myMenuSearch, member);
			}
			// }
			if (myList != null && myList.size() > 0) {
				map.put("boardMenuList", myList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getfamousboardmenus---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	


	
	
	
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "getCommentDetail")
	@MemberEvent(desc = "安卓/IOS圈子评论的详情信息 头部")
	@ResponseBody
	public MobileResultBean getCommentDetail(String topicId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getCommentDetail	");
		//话题ID
		//String topicId = request.getParameter("commentId");
		try {
			if(StringUtils.isBlank(topicId)){
				result.setMessage("话题id不能为空");
				return result;
			}
/*			SessionUser user = getMobileUser();
			if(user != null){
				request.setAttribute("userId", user.getId());
			}
			String type = request.getParameter("type");
			if(StringUtils.isNotBlank(type)){
				request.setAttribute("type", type);
			}
			//String topicId = request.getParameter("topicId");
*/			BbsTopicView topic = new BbsTopicView();
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			if(StringUtils.isNotBlank(topicId)){
				topic = zhanglmServiceManage.bbsTopicService.findViewById(topicId);
				if(StringUtils.isBlank(topic.getUserPhoto())){
					if(defaultImg != null){
						topic.setUserPhoto(defaultImg.getImgUrl());
					}
				}	
				BbsPraiseSearch search = new BbsPraiseSearch();
				search.setEqualTopicId(topicId);
				List<BbsPraiseView> viewList = zhanglmServiceManage.bbsPraiseService.viewList(search);
				for(BbsPraiseView view : viewList){
					if(StringUtils.isBlank(view.getUserPhoto())){
						if(defaultImg != null){
							view.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				request.setAttribute("praiseList", viewList);
				//查询回复
		/*		BbsReplySearch replySearch = new BbsReplySearch();
				replySearch.setEqualTopicId(topicId);
				List<BbsReplyView> replyList = zhanglmServiceManage.bbsReplyService.viewList(replySearch);
				for(BbsReplyView reply : replyList){
					if(StringUtils.isBlank(reply.getUserPhoto())){
						if(defaultImg != null){
							reply.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				
				request.setAttribute("replyList", replyList);
				//查公共
				List<CommentReplyView>  commentList = zhanglmServiceManage.commentReplyService.findAllView();
				request.setAttribute("commentList", commentList);*/
			}
			// }
			if (null != topic) {
				map.put("authorView", topic);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---bbsContent---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
/*	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "getComments")
	@MemberEvent(desc = "安卓/IOS圈子获取评论的评论列表")
	@ResponseBody
	public MobileResultBean famoustopics(String commentId,String userId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "getComments	");
		//话题ID
		//String topicId = request.getParameter("commentId");
		try {
			if(StringUtils.isBlank(commentId)){
				result.setMessage("话题id不能为空");
				return result;
			}
			SessionUser user = getMobileUser();
			if(user != null){
				request.setAttribute("userId", user.getId());
			}
			String type = request.getParameter("type");
			if(StringUtils.isNotBlank(type)){
				request.setAttribute("type", type);
			}
			//String topicId = request.getParameter("topicId");
			BbsTopicView topic = new BbsTopicView();
			List<BbsPraiseView> viewList = new ArrayList<BbsPraiseView>();
			List<BbsReplyView> replyList = new ArrayList<BbsReplyView>();
			List<CommentReplyView> commentList = new ArrayList<CommentReplyView>();
			DefaultSearch defaultSearch = new DefaultSearch();
			defaultSearch.setEqualIsDisable(false);
			DefaultModel defaultImg = zhanglmServiceManage.defaultService.first(defaultSearch);
			if(StringUtils.isNotBlank(commentId)){
				topic = zhanglmServiceManage.bbsTopicService.findViewById(commentId);
				if(StringUtils.isBlank(topic.getUserPhoto())){
					if(defaultImg != null){
						topic.setUserPhoto(defaultImg.getImgUrl());
					}
				}	
				BbsPraiseSearch search = new BbsPraiseSearch();
				search.setEqualTopicId(commentId);
				 viewList = zhanglmServiceManage.bbsPraiseService.viewList(search);
				for(BbsPraiseView view : viewList){
					if(StringUtils.isBlank(view.getUserPhoto())){
						if(defaultImg != null){
							view.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				request.setAttribute("praiseList", viewList);
				//查询回复  评论列表
				BbsReplySearch replySearch = new BbsReplySearch();
				replySearch.setEqualTopicId(commentId);
				replyList = zhanglmServiceManage.bbsReplyService.viewListbbsReply(commentId,userId);
				for(BbsReplyView reply : replyList){
					if(StringUtils.isBlank(reply.getUserPhoto())){
						if(defaultImg != null){
							reply.setUserPhoto(defaultImg.getImgUrl());
						}
					}
				}
				
				request.setAttribute("replyList", replyList);
				//查公共回复信息
				CommentReplySearch commentreplysearch = new CommentReplySearch();
				commentreplysearch.setSort("createTime");
				commentreplysearch.setOrder(BaseSearch.Order_Type_Desc);
				commentreplysearch.setEqualTopicId(commentId);
				commentList = zhanglmServiceManage.commentReplyService.viewListCommentReply(commentreplysearch,userId);
				//commentList = zhanglmServiceManage.commentReplyService.findAllView();
				request.setAttribute("commentList", commentList);
			}
			// }
			if (topic != null) {
				map.put("authorView", topic);
				map.put("commentView", replyList);
				map.put("commentList", commentList);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getComments---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	*/
	

	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "addCommentReply")
	@MemberEvent(desc = "安卓/IOS圈子添加评论的评论")
	@ResponseBody
	public MobileResultBean addCommentReply(String commentId,String content){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addCommentReply");
		try {
	
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				MemberModel member = zhanglmServiceManage.memberService.findById(userId);
				//话题ID
				//String topicId = request.getParameter("commentId");
				if(StringUtils.isBlank(commentId)){
					result.setMessage("话题id不能为空");
					return result;
				}

				//String content = request.getParameter("content");
				if(StringUtils.isBlank(content)){
					result.setMessage("评论内容不能为空");
					return result;
				}
				//添加评论数据
				BbsReplyModel reply = new BbsReplyModel();
				reply.setTopicId(commentId);
				reply.setUserId(userId);
				reply.setContent(content);
				reply.setPraise(0);
				//评论+1,计算平均数
				BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(commentId);
				Integer praiseNum = topicModel.getPraise();
				Integer discussNum = topicModel.getDiscuss();
				if(null != discussNum){
					topicModel.setDiscuss(discussNum + 1);
				}else{
					topicModel.setDiscuss(1);
				}
				Double average = (double) ((praiseNum + discussNum)/2);
				topicModel.setAverage(average);
				//关联表用户评论数+1,计算平均值
			
				
				//-----------------------这里明天做----------------------------------------------------------------------
				String menuCode = topicModel.getMenuid();
				//String menuCode = topicModel.getMenuCode();
				//BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("id", menuCode);
				
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan == null){
					result.setMessage("请您先关注该圈子");
					return result;
				}
				Long fanTopic = fan.getTopicNum();
				Long fanPraise = fan.getPraiseNum();
				Long fanReply = fan.getReplyNum();
				fanReply++;
				fan.setReplyNum(fanReply);
				Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
				fan.setAverage(fanAverage);
				//通知用户话题已被评论
				MemberMsgModel memberMsg = new MemberMsgModel();	
				memberMsg.setSenderId(userId);
				memberMsg.setUserId(topicModel.getUserId());
				memberMsg.setTitle("观点被评论");
				memberMsg.setContent("用户"+member.getNickName()+"评论了您的观点【"+topicModel.getTitle()+"】：" + content);
				memberMsg.setStatus(BusinessConstants.MEMBER_MSG_STATUS.NOT_READ);
				//入库
				zhanglmServiceManage.bbsReplyService.add(reply, getSessionUser());
				zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());
				zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				zhanglmServiceManage.memberMsgService.add(memberMsg, getSessionUser());
				message = "谢谢评论";
				System.out.println(message);
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);	
			
/*			if (null != topic) {
				map.put("authorView", topic);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}*/
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---addCommentReply---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	
	/*-----------新接口话题回复-----------------*/
	@RequestMapping(method = RequestMethod.POST, value = "topicReply")
	@MemberEvent(desc = "安卓/IOS圈子 添加话题回复")
	@ResponseBody
	public MobileResultBean topicReply(String userId,String replyId,String comment,String commentId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "topicReply");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				//话题Id
				//String replyId = request.getParameter("replyId");
				//内容
				//String comment = request.getParameter("comment");
				//用户id
				//String userId= request.getParameter("userId");
				//评论id
				//String commentId = request.getParameter("commentId");
				BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(replyId);
				if(topic != null){
					BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("id", topic.getMenuid());
					BbsFanSearch fanSearch = new BbsFanSearch();
					fanSearch.setEqualMenuId(menu.getId());
					fanSearch.setEqualUserId(userId);
					BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
					if(fan == null){
						result.setMessage("请您先关注该圈子");
						return result;
					}
					CommentReplyModel model = new CommentReplyModel();
					model.setContent(comment);
					model.setReplyId(replyId);
					model.setUserId(userId);
					model.setCommentId(commentId);
					model.setPraise(0);
					zhanglmServiceManage.commentReplyService.add(model,getMobileUser());
					message = "评论回复成功";
					result.setStatus(MobileResultBean.SUCCESS);
				}else{
					message = "该话题不存在";
				}
			}
			result.setObject(message);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	
	
	
	/*--------------------新接口 话题点赞-----------------*/
	@RequestMapping(method = RequestMethod.POST, value = "addtopicPraise")
	@MemberEvent(desc = "安卓/IOS圈子 话题点赞")
	@ResponseBody
	public MobileResultBean addtopicPraise(String topicId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addtopicPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				//话题id
				//String topicId = request.getParameter("topicId");
				//查看用户是否点过赞
				BbsPraiseSearch search = new BbsPraiseSearch();
				search.setEqualTopicId(topicId);
				search.setEqualUserId(userId);
				BbsPraiseModel praiseModel = zhanglmServiceManage.bbsPraiseService.findBySearch(search);
				if(praiseModel != null){
					result.setMessage("您已点过赞了");
					return result;
				}
				//添加点赞数据
				praiseModel = new BbsPraiseModel();
				praiseModel.setTopicId(topicId);
				praiseModel.setUserId(userId);
				zhanglmServiceManage.bbsPraiseService.add(praiseModel, getSessionUser());
				//话题点赞+1，计算平均数
				BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(topicId);
				Integer praiseNum = topicModel.getPraise();
				Integer discussNum = topicModel.getDiscuss();
				if(null != praiseNum){
					praiseNum++;
					topicModel.setPraise(praiseNum);
				}else{
					topicModel.setPraise(1);
				}
				Double average = (double) ((praiseNum + discussNum)/2);
				topicModel.setAverage(average);
				zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());
				//关联表用户点赞数+1,计算平均值
				//String menuCode = topicModel.getMenuCode();
				//BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				String menuid = topicModel.getMenuid();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("id", menuid);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan != null){
					Long fanTopic = fan.getTopicNum();
					Long fanPraise = fan.getPraiseNum();
					Long fanReply = fan.getReplyNum();
					fanPraise++;
					fan.setPraiseNum(fanPraise);
					Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
					fan.setAverage(fanAverage);
					zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				}
				message = "谢谢点赞";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	/*
	 * 取消话题点赞
	 * */
	@RequestMapping(method = RequestMethod.POST, value = "canceltopicPraise")
	@MemberEvent(desc = "安卓/IOS圈子 取消话题点赞")
	@ResponseBody
	public MobileResultBean canceltopicPraise(String topicId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "canceltopicPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				//话题id
				//String topicId = request.getParameter("topicId");
				//查看用户是否点过赞
				BbsPraiseSearch search = new BbsPraiseSearch();
				search.setEqualTopicId(topicId);
				search.setEqualUserId(userId);
				BbsPraiseModel praiseModel = zhanglmServiceManage.bbsPraiseService.findBySearch(search);
				if(null != praiseModel){
					zhanglmServiceManage.bbsPraiseService.delete(praiseModel, getSessionUser());
					//话题点赞+1，计算平均数
					BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(topicId);
					Integer praiseNum = topicModel.getPraise();
					Integer discussNum = topicModel.getDiscuss();
					if(null != praiseNum){
						praiseNum--;
						topicModel.setPraise(praiseNum);
					}else{
						topicModel.setPraise(0);
					}
					Double average = (double) ((praiseNum + discussNum)/2);
					topicModel.setAverage(average);
					zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());
				}else{					
					message = "已取消过点赞";
					result.setStatus(MobileResultBean.ERROR);
					result.setMessage(message);
					return result;
				}
				//关联表用户点赞数+1,计算平均值
				//String menuCode = topicModel.getMenuCode();
				//BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				
			/*	String menuid = topicModel.getMenuid();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("id", menuid);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan != null){
					Long fanTopic = fan.getTopicNum();
					Long fanPraise = fan.getPraiseNum();
					Long fanReply = fan.getReplyNum();
					fanPraise++;
					fan.setPraiseNum(fanPraise);
					Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
					fan.setAverage(fanAverage);
					zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				}*/
				message = "取消点赞成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	/*--------------------新接口  评论点赞-----------------*/
	@RequestMapping(method = RequestMethod.POST, value = "commentAddPraise")
	@MemberEvent(desc = "安卓/IOS圈子 评论点赞")
	@ResponseBody
	public MobileResultBean commentAddPraise(String commentsId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "commentAddPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				//评论id
				//String commentsId = request.getParameter("commentsId");
				//查看用户是否点过赞
				//BbsPraiseSearch search = new BbsPraiseSearch();
				BbsCommentsSearch search = new BbsCommentsSearch();	
				search.setEqualcommentsId(commentsId);
				search.setEqualUserId(userId);
				BbsCommentsModel praiseModel = zhanglmServiceManage.BbsCommentsServiceI.findBySearch(search);
				if(praiseModel != null){
					result.setMessage("您已点过赞了");
					return result;
				}
				//添加点赞数据
				praiseModel = new BbsCommentsModel();
				praiseModel.setCommentsId(commentsId);
				praiseModel.setUserId(userId);
				zhanglmServiceManage.BbsCommentsServiceI.add(praiseModel, getSessionUser());
				
				
				//话题点赞+1，计算平均数
				BbsReplyModel topicModel = zhanglmServiceManage.bbsReplyService.findById(commentsId);
				Integer praiseNum = topicModel.getPraise();
				//Integer discussNum = topicModel.getDiscuss();
				if(null != praiseNum){
					praiseNum++;
					topicModel.setPraise(praiseNum);
				}else{
					topicModel.setPraise(1);
				}
				//Double average = (double) ((praiseNum + discussNum)/2);
				//topicModel.setAverage(average);
				zhanglmServiceManage.bbsReplyService.edit(topicModel, getSessionUser());
			/*	//关联表用户点赞数+1,计算平均值
				String menuCode = topicModel.getMenuCode();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan != null){
					Long fanTopic = fan.getTopicNum();
					Long fanPraise = fan.getPraiseNum();
					Long fanReply = fan.getReplyNum();
					fanPraise++;
					fan.setPraiseNum(fanPraise);
					Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
					fan.setAverage(fanAverage);
					zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				}*/
				message = "谢谢点赞";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	
	/*--------------------取消 评论点赞-----------------*/
	@RequestMapping(method = RequestMethod.POST, value = "cancelcommentAddPraise")
	@MemberEvent(desc = "安卓/IOS圈子 取消 评论点赞")
	@ResponseBody
	public MobileResultBean cancelcommentAddPraise(String commentsId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "cancelcommentAddPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				//评论id
				//String commentsId = request.getParameter("commentsId");
				//查看用户是否点过赞
				//BbsPraiseSearch search = new BbsPraiseSearch();
				BbsCommentsSearch search = new BbsCommentsSearch();	
				search.setEqualcommentsId(commentsId);
				search.setEqualUserId(userId);
				BbsCommentsModel praiseModel = zhanglmServiceManage.BbsCommentsServiceI.findBySearch(search);
				if(null != praiseModel){
					zhanglmServiceManage.BbsCommentsServiceI.delete(praiseModel, getSessionUser());
					
					
					//话题点赞+1，计算平均数
					BbsReplyModel topicModel = zhanglmServiceManage.bbsReplyService.findById(commentsId);
					Integer praiseNum = topicModel.getPraise();
					//Integer discussNum = topicModel.getDiscuss();
					if(null != praiseNum){
						praiseNum--;
						topicModel.setPraise(praiseNum);
					}else{
						topicModel.setPraise(0);
					}
					//Double average = (double) ((praiseNum + discussNum)/2);
					//topicModel.setAverage(average);
					zhanglmServiceManage.bbsReplyService.edit(topicModel, getSessionUser());
				}else{
					message = "已取消过点赞";
					result.setStatus(MobileResultBean.ERROR);
					result.setMessage(message);
					return result;
				}
			
			/*	//关联表用户点赞数+1,计算平均值
				String menuCode = topicModel.getMenuCode();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan != null){
					Long fanTopic = fan.getTopicNum();
					Long fanPraise = fan.getPraiseNum();
					Long fanReply = fan.getReplyNum();
					fanPraise++;
					fan.setPraiseNum(fanPraise);
					Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
					fan.setAverage(fanAverage);
					zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				}*/
				message = "取消点赞成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	/*--------------------新接口  回复信息点赞-----------------*/
	@RequestMapping(method = RequestMethod.POST, value = "replyAddPraise")
	@MemberEvent(desc = "安卓/IOS圈子 评论点赞")
	@ResponseBody
	public MobileResultBean replyAddPraise(String replyId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "replyAddPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				if(StringUtils.isBlank(replyId)){
					result.setMessage("回复id不能为空");
					return result;
				}
				String userId = getSessionUser().getId();
				//评论id
				//String commentsId = request.getParameter("commentsId");
				//查看用户是否点过赞
				//BbsPraiseSearch search = new BbsPraiseSearch();
				BbsReplyPraiseSearch search = new BbsReplyPraiseSearch();	
				search.setEqualreplyId(replyId);
				search.setEqualUserId(userId);
				BbsReplyPraiseModel praiseModel = zhanglmServiceManage.BbsReplyPraiseServiceI.findBySearch(search);
				if(praiseModel != null){
					result.setMessage("您已点过赞了");
					return result;
				}
				//添加回复点赞数据
				praiseModel = new BbsReplyPraiseModel();
				praiseModel.setReplypraiseid(replyId);
				praiseModel.setUserId(userId);
				zhanglmServiceManage.BbsReplyPraiseServiceI.add(praiseModel, getSessionUser());
				
				
				//回复点赞+1
				CommentReplyModel commentreplymodel = zhanglmServiceManage.commentReplyService.findById(replyId);
				Integer praiseNum = commentreplymodel.getPraise();
				//Integer discussNum = topicModel.getDiscuss();
				if(null != praiseNum){
					praiseNum++;
					commentreplymodel.setPraise(praiseNum);
				}else{
					commentreplymodel.setPraise(1);
				}
				//Double average = (double) ((praiseNum + discussNum)/2);
				//topicModel.setAverage(average);
				zhanglmServiceManage.commentReplyService.edit(commentreplymodel, getSessionUser());
			/*	//关联表用户点赞数+1,计算平均值
				String menuCode = topicModel.getMenuCode();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan != null){
					Long fanTopic = fan.getTopicNum();
					Long fanPraise = fan.getPraiseNum();
					Long fanReply = fan.getReplyNum();
					fanPraise++;
					fan.setPraiseNum(fanPraise);
					Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
					fan.setAverage(fanAverage);
					zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				}*/
				message = "谢谢点赞";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	
	
	
	/*取消 回复信息点赞*/
	@RequestMapping(method = RequestMethod.POST, value = "cancelreplyAddPraise")
	@MemberEvent(desc = "安卓/IOS圈子 取消 回复信息点赞")
	@ResponseBody
	public MobileResultBean cancelreplyAddPraise(String replyId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "cancelreplyAddPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				if(StringUtils.isBlank(replyId)){
					result.setMessage("回复id不能为空");
					return result;
				}
				String userId = getSessionUser().getId();
				//评论id
				//String commentsId = request.getParameter("commentsId");
				//查看用户是否点过赞
				//BbsPraiseSearch search = new BbsPraiseSearch();
				BbsReplyPraiseSearch search = new BbsReplyPraiseSearch();	
				search.setEqualreplyId(replyId);
				search.setEqualUserId(userId);
				BbsReplyPraiseModel praiseModel = zhanglmServiceManage.BbsReplyPraiseServiceI.findBySearch(search);
				if(null != praiseModel){
					zhanglmServiceManage.BbsReplyPraiseServiceI.delete(praiseModel, getSessionUser());				
					//回复点赞+1
					CommentReplyModel commentreplymodel = zhanglmServiceManage.commentReplyService.findById(replyId);
					Integer praiseNum = commentreplymodel.getPraise();
					//Integer discussNum = topicModel.getDiscuss();
					if(null != praiseNum){
						praiseNum--;
						commentreplymodel.setPraise(praiseNum);
					}else{
						commentreplymodel.setPraise(0);
					}
					//Double average = (double) ((praiseNum + discussNum)/2);
					//topicModel.setAverage(average);
					zhanglmServiceManage.commentReplyService.edit(commentreplymodel, getSessionUser());
				}else{
					message = "已取消过点赞";
					result.setStatus(MobileResultBean.ERROR);
					result.setMessage(message);
					return result;
				}
	
			/*	//关联表用户点赞数+1,计算平均值
				String menuCode = topicModel.getMenuCode();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan != null){
					Long fanTopic = fan.getTopicNum();
					Long fanPraise = fan.getPraiseNum();
					Long fanReply = fan.getReplyNum();
					fanPraise++;
					fan.setPraiseNum(fanPraise);
					Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
					fan.setAverage(fanAverage);
					zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				}*/
				message = "取消点赞成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	/*
	 * 获取分享页面内容
	 * 
	 * */
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "getSgarePage")
	@MemberEvent(desc = "安卓/IOS圈子获取分享页面内容")
	@ResponseBody
	public MobileResultBean getSgarePage(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "getSgarePage");
		String message = "";
		try {
			SharePageSearch search = new SharePageSearch();
			search.setEqualIsDisable(false);
			search.setOrder(BaseSearch.Order_Type_Desc);
			SharePageView pageView = zhanglmServiceManage.sharePageService.firstView(search);
			if (null != pageView) {
				map.put("pageView", pageView);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---getSgarePage---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	/*
	 * 观点分享后记录分享后回调数量
	 * 
	 * */
	@SuppressWarnings("unused")
	@RequestMapping(method = RequestMethod.POST,value = "setSharenumber")
	@MemberEvent(desc = "安卓/IOS圈子 记录分享后回调数量")
	@ResponseBody
	public MobileResultBean setSharenumber(String topicId){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "setSharenumber");
		String message = "";
		try {
			if(StringUtils.isBlank(topicId)){
				result.setMessage("观点id不能为空");
				return result;
			}
			//分享数量
			BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(topicId);
			if (null != topicModel) {
				Integer transmit = topicModel.getTransmit();
				if(null != transmit){
					topicModel.setTransmit(++transmit);
				}else{
					topicModel.setTransmit(1);
				}
				zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());
				map.put("ShareView", topicModel);
				message = "获取成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			} else {
				message = "获取失败";
				result.setStatus(MobileResultBean.ERROR);
				result.setMessage(message);
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---setSharenumber---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "aloneMenus")
	@MemberEvent(desc = "安卓/IOS圈子 获取单个版块菜单")
	@ResponseBody
	public MobileResultBean aloneMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "aloneMenus");
		try {
			String code = request.getParameter("code");
			BbsMenuSearch search = new BbsMenuSearch();
			search.setEqualCode(code);
			BbsMenuModel bbsMenu = zhanglmServiceManage.bbsMenuService.findBySearch(search);
			map.put("bbsMenu", bbsMenu.getName());
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);	
		return result;
	}
	
	
	
	
	
	
	
	
	
	@RequestMapping(method = RequestMethod.POST, value = "alonePMenus")
	@MemberEvent(desc = "安卓/IOS圈子 获取父类版块菜单")
	@ResponseBody
	public MobileResultBean alonePMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "alonePMenus");
		try {
			String menuId = request.getParameter("code");
			BbsMenuModel bbsMenu = zhanglmServiceManage.bbsMenuService.findById(menuId);
			map.put("bbsMenu", bbsMenu.getName());
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "getBoardMenus")
	@MemberEvent(desc = "安卓/IOS圈子 获取已关注的版块菜单列表")
	@ResponseBody
	public MobileResultBean getBoardMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsMenuView> boardMenuList = new ArrayList<BbsMenuView>();
		String message = "";
		map.put("method", "getBoardMenus");
		try {
			String[] inId = null;
			String talentId = request.getParameter("talentId");
			BbsFanSearch fanSearch = new BbsFanSearch();
			fanSearch.setEqualUserId(talentId);
			List<BbsFanModel> fanList = zhanglmServiceManage.bbsFanService.list(fanSearch);
			if(fanList.size()>0){
				inId = new String[fanList.size()];
				for(int i=0;i<fanList.size();i++){
					inId[i] = fanList.get(i).getMenuId();
				}
				BbsMenuSearch search = new BbsMenuSearch();
				search.setInId(inId);
				search.setEqualIsDisable(false);
				List<BbsMenuView> viewList = zhanglmServiceManage.bbsMenuService.viewList(search);
				for(BbsMenuView view : viewList){
					if(StringUtils.isNotBlank(view.getPid())){
						boardMenuList.add(view);
					}
				}
			}
			map.put("boardMenuList", boardMenuList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "hotBoardMenus")
	@MemberEvent(desc = "安卓/IOS圈子 推荐版块菜单")
	@ResponseBody
	public MobileResultBean hotBoardMenus(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsMenuView> boardMenuList = new ArrayList<BbsMenuView>();
		String message = "";
		map.put("method", "hotBoardMenus");
		try {
			BbsMenuSearch search = new BbsMenuSearch();
			search.setEqualIsDisable(false);
			search.setEqualIsLock(true);
			boardMenuList = zhanglmServiceManage.bbsMenuService.viewList(search);
			map.put("hotList", boardMenuList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "bbsTopics")
	@MemberEvent(desc = "安卓/IOS圈子 分类版块话题")
	@ResponseBody
	public MobileResultBean bbsTopics(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsTopicView> topicList = new ArrayList<BbsTopicView>();
		String message = "";
		map.put("method", "bbsTopics");
		try {
			String menuCode = request.getParameter("menuCode");
			BbsTopicSearch search = new BbsTopicSearch();
			//通过审核的话题
			search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			search.setEqualMenuCode(menuCode);
			topicList = zhanglmServiceManage.bbsTopicService.viewList(search);
			DefaultSearch defaultsearch = new DefaultSearch();
			for(BbsTopicView topic : topicList){
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
			if(null == topic.getUserPhoto()){
				topic.setUserPhoto(defaultModel.getImgUrl());
			}
			}
			map.put("topicList", topicList);
			message = "获取成功";
			result.setObject(map);
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	

	
	@RequestMapping(method = RequestMethod.POST, value = "myPublishTopic")
	@MemberEvent(desc = "安卓/IOS圈子 我发布的话题(观点)")
	@ResponseBody
	public MobileResultBean myPublishTopic(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsTopicView> topicList = new ArrayList<BbsTopicView>();
		String message = "";
		map.put("method", "myPublishTopic");
		String currPage = request.getParameter("currPage");
		String pageSize = request.getParameter("pageSize");
		Long number = 0L;
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				BbsTopicSearch search = new BbsTopicSearch();
				search.setPage(Integer.parseInt(currPage));
				search.setRows(Integer.parseInt(pageSize));
				search.setEqualUserId(getSessionUser().getId());
				search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
				topicList = zhanglmServiceManage.bbsTopicService.viewListTopic(search, getSessionUser());
				DefaultSearch defaultsearch = new DefaultSearch();
				for(BbsTopicView topic : topicList){
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if(null == topic.getUserPhoto()){
					topic.setUserPhoto(defaultModel.getImgUrl());
				}
				}
				number = zhanglmServiceManage.bbsTopicService.count(search);
				map.put("currPage", currPage);
				map.put("number", number);
				map.put("topicList", topicList);
				message = "获取成功";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "publishTopicList")
	@MemberEvent(desc = "安卓/IOS圈子 已发布的话题(观点)")
	@ResponseBody
	public MobileResultBean publishTopicList(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		List<BbsTopicView> topicList = new ArrayList<BbsTopicView>();
		String message = "";
		map.put("method", "publishTopicList");
		try {
			BbsTopicSearch search = new BbsTopicSearch();
			search.setSort("auditTime");
			search.setEqualStatus(BusinessConstants.BBS_TOPIC_STATUS.AUDIT);
			topicList = zhanglmServiceManage.bbsTopicService.viewListTopic(search, getMobileUser());
			DefaultSearch defaultsearch = new DefaultSearch();
			for(BbsTopicView topic : topicList){
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if(null == topic.getUserPhoto()){
					topic.setUserPhoto(defaultModel.getImgUrl());
				}
			}
			map.put("topicList", topicList);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}

	
/*	@RequestMapping(method = RequestMethod.POST, value = "addPraise")
	@MemberEvent(desc = "安卓/IOS圈子 话题点赞")
	@ResponseBody
	public MobileResultBean addPraise(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addPraise");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				String topicId = request.getParameter("topicId");
				//查看用户是否点过赞
				BbsPraiseSearch search = new BbsPraiseSearch();
				search.setEqualTopicId(topicId);
				search.setEqualUserId(userId);
				BbsPraiseModel praiseModel = zhanglmServiceManage.bbsPraiseService.findBySearch(search);
				if(praiseModel != null){
					result.setMessage("您已点过赞了");
					return result;
				}
				//添加点赞数据
				praiseModel = new BbsPraiseModel();
				praiseModel.setTopicId(topicId);
				praiseModel.setUserId(userId);
				zhanglmServiceManage.bbsPraiseService.add(praiseModel, getSessionUser());
				//话题点赞+1，计算平均数
				BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(topicId);
				Integer praiseNum = topicModel.getPraise();
				Integer discussNum = topicModel.getDiscuss();
				if(null != praiseNum){
					praiseNum++;
					topicModel.setPraise(praiseNum);
				}else{
					topicModel.setPraise(1);
				}
				Double average = (double) ((praiseNum + discussNum)/2);
				topicModel.setAverage(average);
				zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());
				//关联表用户点赞数+1,计算平均值
				String menuCode = topicModel.getMenuCode();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan != null){
					Long fanTopic = fan.getTopicNum();
					Long fanPraise = fan.getPraiseNum();
					Long fanReply = fan.getReplyNum();
					fanPraise++;
					fan.setPraiseNum(fanPraise);
					Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
					fan.setAverage(fanAverage);
					zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				}
				message = "谢谢点赞";
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}*/
/*	
	@RequestMapping(method = RequestMethod.POST, value = "addReply")
	@MemberEvent(desc = "安卓/IOS圈子 话题评论")
	@ResponseBody
	public MobileResultBean addReply(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "addReply");
		try {
			if(!isMobileLogin()){
				message = "登陆失效";
			}else{
				String userId = getSessionUser().getId();
				MemberModel member = zhanglmServiceManage.memberService.findById(userId);
				String topicId = request.getParameter("topicId");
				String content = request.getParameter("content");
				if(StringUtils.isBlank(content)){
					result.setMessage("评论内容不能为空");
					return result;
				}
				//添加评论数据
				BbsReplyModel reply = new BbsReplyModel();
				reply.setTopicId(topicId);
				reply.setUserId(userId);
				reply.setContent(content);
				//评论+1,计算平均数
				BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(topicId);
				Integer praiseNum = topicModel.getPraise();
				Integer discussNum = topicModel.getDiscuss();
				if(null != discussNum){
					topicModel.setDiscuss(discussNum + 1);
				}else{
					topicModel.setDiscuss(1);
				}
				Double average = (double) ((praiseNum + discussNum)/2);
				topicModel.setAverage(average);
				//关联表用户评论数+1,计算平均值
				String menuCode = topicModel.getMenuCode();
				BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", menuCode);
				BbsFanSearch fanSearch = new BbsFanSearch();
				fanSearch.setEqualMenuId(menu.getId());
				fanSearch.setEqualUserId(userId);
				BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
				if(fan == null){
					result.setMessage("请您先关注该圈子");
					return result;
				}
				Long fanTopic = fan.getTopicNum();
				Long fanPraise = fan.getPraiseNum();
				Long fanReply = fan.getReplyNum();
				fanReply++;
				fan.setReplyNum(fanReply);
				Double fanAverage = (double) ((fanTopic + fanPraise + fanReply)/3);
				fan.setAverage(fanAverage);
				//通知用户话题已被评论
				MemberMsgModel memberMsg = new MemberMsgModel();
				memberMsg.setSenderId(userId);
				memberMsg.setUserId(topicModel.getUserId());
				memberMsg.setTitle("观点被评论");
				memberMsg.setContent("用户"+member.getNickName()+"评论了您的观点【"+topicModel.getTitle()+"】：" + content);
				memberMsg.setStatus(BusinessConstants.MEMBER_MSG_STATUS.NOT_READ);
				//入库
				zhanglmServiceManage.bbsReplyService.add(reply, getSessionUser());
				zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());
				zhanglmServiceManage.bbsFanService.edit(fan, getSessionUser());
				zhanglmServiceManage.memberMsgService.add(memberMsg, getSessionUser());
				message = "谢谢评论";
				System.out.println(message);
				result.setStatus(MobileResultBean.SUCCESS);
			}
			result.setObject(map);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}*/
	
/*	@RequestMapping(method = RequestMethod.POST, value = "topicReply")
	@MemberEvent(desc = "安卓/IOS圈子 添加话题回复")
	@ResponseBody
	public MobileResultBean topicReply(){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "topicReply");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				//话题Id
				String replyId = request.getParameter("replyId");
				String comment = request.getParameter("comment");
				String userId = request.getParameter("userId");
				String commentId = request.getParameter("commentId");
				BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(replyId);
				if(topic != null){
					BbsMenuModel menu = zhanglmServiceManage.bbsMenuService.findByField("code", topic.getMenuCode());
					BbsFanSearch fanSearch = new BbsFanSearch();
					fanSearch.setEqualMenuId(menu.getId());
					fanSearch.setEqualUserId(userId);
					BbsFanModel fan = zhanglmServiceManage.bbsFanService.findBySearch(fanSearch);
					if(fan == null){
						result.setMessage("请您先关注该圈子");
						return result;
					}
					CommentReplyModel model = new CommentReplyModel();
					model.setComment(comment);
					model.setReplyId(replyId);
					model.setUserId(userId);
					model.setCommentId(commentId);
					zhanglmServiceManage.commentReplyService.add(model,getMobileUser());
					message = "评论回复成功";
					result.setStatus(MobileResultBean.SUCCESS);
				}else{
					message = "该话题不存在";
				}
			}
			result.setObject(message);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}*/
	
	@RequestMapping(method = RequestMethod.POST, value = "topicClick")
	@MemberEvent(desc ="安卓/IOS 话题点击量+1")
	@ResponseBody
	public MobileResultBean topicClick() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "topicClick");
		String message = "";
		try {
			String topicId = request.getParameter("topicId");
			BbsTopicModel topic = zhanglmServiceManage.bbsTopicService.findById(topicId);
			Long ClickNum = topic.getClickNum();
			if(null != ClickNum){
				topic.setClickNum(++ClickNum);
			}else{
				topic.setClickNum(1L);
			}
			zhanglmServiceManage.bbsTopicService.edit(topic, getSessionUser());
			result.setObject(map);
			message = "点击量更改成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	/*@RequestMapping(method = RequestMethod.POST, value = "getSharePage")
	@MemberEvent(desc ="安卓/IOS 获取分享页面内容")
	@ResponseBody
	public MobileResultBean getSharePage() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "getSharePage");
		String message = "";
		try {
			SharePageSearch search = new SharePageSearch();
			search.setEqualIsDisable(false);
			search.setOrder(BaseSearch.Order_Type_Desc);
			SharePageView pageView = zhanglmServiceManage.sharePageService.firstView(search);
			map.put("pageView", pageView);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}*/
	
	@RequestMapping(method = RequestMethod.POST, value = "recommend")
	@MemberEvent(desc ="安卓/IOS 获取推荐话题")
	@ResponseBody
	public MobileResultBean recommend() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		List<BbsTopicView> topicView = new ArrayList<BbsTopicView>();
		map.put("method", "recommend");
		String message = "";
		try {
			BbsTopicSearch search = new BbsTopicSearch();
			search.setEqualIsDisable(true);
			search.setSort("createTime");
			search.setOrder(BaseSearch.Order_Type_Desc);
			search.setRows(2);
			topicView = zhanglmServiceManage.bbsTopicService.viewListTopic(search,getMobileUser());
			System.out.println(topicView);
			map.put("topicView", topicView);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "topicPhoto")
	@MemberEvent(desc = "安卓/IOS圈子 上传话题图片")
	@ResponseBody
	public MobileResultBean topicPhoto(String model){
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		String message = "";
		map.put("method", "topicPhoto");
		//String model = request.getParameter("model");
			if(!isLogin()){
				message = "登陆失效";
			}else{
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				Map<String, MultipartFile> fileMap = multipartRequest.getFileMap();
				MultipartFile multipartFile =null;
				String fileName = "";
				String ctxPath = projectConfigration.getFileRootUrl() +"file/" + model+ "/";
				String mapPath = projectConfigration.mappingUrl + "file/" + model+ "/";
				File file = new File(ctxPath);
				if(!file.exists()) file.mkdirs();
				for(Map.Entry<String,MultipartFile > set:fileMap.entrySet()){
					multipartFile = set.getValue();//文件名
					fileName = multipartFile.getOriginalFilename();
		            String suffix = fileName.indexOf(".") != -1 ? fileName.substring(fileName.lastIndexOf("."), fileName.length()) : null;
		            String newFileName =  "photo"+getSessionUser().getId() + (suffix!=null?suffix:"");// 构成新文件名。
		            File uploadFile = new File(file.getPath() + "/"+newFileName);
		            try {  
		            	FileCopyUtils.copy(multipartFile.getBytes(), uploadFile); 
		                map.put("filePath", mapPath + newFileName);
		                message = "上传成功";
						result.setStatus(MobileResultBean.SUCCESS);
						result.setObject(map);
		            }catch (Exception e) {
		            	e.printStackTrace();
		            	message = e.getMessage();
					}
				}
			}
		result.setObject(map);
		result.setMessage(message);
		return result;
	}

	/*添加关注*/
	@RequestMapping(method = RequestMethod.POST, value = "attention")
	@MemberEvent(desc = "安卓/IOS 添加关注")
	@ResponseBody
	public MobileResultBean attention(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "attention");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				//app会员id
				String memberId = request.getParameter("memberId");
				System.out.println(memberId);
				//登录系统用户id
				String fansId = getSessionUser().getId();
				if(StringUtils.equals(memberId, fansId)){
					result.setMessage("自己不能关注自己");
					return result;
				}
				MemberAttentionSearch search = new MemberAttentionSearch();
				search.setEqualFansId(fansId);
				search.setEqualMemberId(memberId);
				MemberAttentionModel model = zhanglmServiceManage.memberAttentionService.findBySearch(search);
				if(model != null){
					result.setMessage("您已经关注过了");
					return result;
				}else{
					model = new MemberAttentionModel();
					model.setMemberId(memberId);
					model.setFansId(fansId);
					zhanglmServiceManage.memberAttentionService.add(model, getSessionUser());
					message = "关注成功";
					result.setObject(map);
					result.setStatus(MobileResultBean.SUCCESS);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	/*
	 * 取消关注
	 * 
	 * */
	@RequestMapping(method = RequestMethod.POST, value = "cancelAttention")
	@MemberEvent(desc = "安卓/IOS 取消关注")
	@ResponseBody
	public MobileResultBean cancelAttention(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "cancelAttention");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String memberId = request.getParameter("memberId");
				String fansId = getSessionUser().getId();
				MemberAttentionSearch search = new MemberAttentionSearch();
				search.setEqualFansId(fansId);
				search.setEqualMemberId(memberId);
				MemberAttentionModel model = zhanglmServiceManage.memberAttentionService.findBySearch(search);
				zhanglmServiceManage.memberAttentionService.delete(model, getSessionUser());
				message = "取消关注成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "addCollect")
	@MemberEvent(desc = "安卓/IOS 添加收藏")
	@ResponseBody
	public MobileResultBean collect(String circleId){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "addCollect");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				//String circleId = request.getParameter("circleId");
				String userId = getSessionUser().getId();
				CollectSearch search = new CollectSearch();
				search.setEqualCircleId(circleId);
				search.setEqualUserId(userId);
				CollectModel model = zhanglmServiceManage.collectService.findBySearch(search);
				if(model != null){
					result.setMessage("您已经收藏了");
					result.setStatus(MobileResultBean.SUCCESS);
					return result;
				}
				model = new CollectModel();
				//话题id
				model.setCircleId(circleId);
				model.setUserId(userId);
				zhanglmServiceManage.collectService.add(model, getSessionUser());
				//收藏数量
				BbsTopicModel topicModel = zhanglmServiceManage.bbsTopicService.findById(circleId);
				Integer collection = topicModel.getCollection();
				if(null != collection){
					collection++;
					topicModel.setCollection(collection);
				}else{
					topicModel.setCollection(1);
				}
				zhanglmServiceManage.bbsTopicService.edit(topicModel, getSessionUser());
				message = "收藏成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---addCollect---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "cancelCollect")
	@MemberEvent(desc = "安卓/IOS 取消收藏")
	@ResponseBody
	public MobileResultBean cancelCollect(){
		String message = "";
		MobileResultBean result = new MobileResultBean();
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("method", "cancelCollect");
		try {
			if(!isLogin()){
				message = "登陆失效";
			}else{
				String circleId = request.getParameter("circleId");
				String userId = getSessionUser().getId();
				CollectSearch search = new CollectSearch();
				search.setEqualUserId(userId);
				search.setEqualCircleId(circleId);
				CollectModel model = zhanglmServiceManage.collectService.findBySearch(search);
				zhanglmServiceManage.collectService.delete(model, getSessionUser());
				message = "取消收藏成功";
				result.setObject(map);
				result.setStatus(MobileResultBean.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("---cancelCollect---"+e.getMessage());
		}
		result.setMessage(message);
		return result;
	}
	
}
