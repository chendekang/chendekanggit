package com.jrzh.mvc.convert.zhanglm;

import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.GoldHistoryModel;
import com.jrzh.mvc.view.zhanglm.GoldHistoryView;

public class GoldHistoryConvert implements BaseConvertI<GoldHistoryModel, GoldHistoryView> {

	@Override
	public GoldHistoryModel addConvert(GoldHistoryView view) throws ProjectException {
		GoldHistoryModel model = new GoldHistoryModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}
	
	public GoldHistoryModel addConvertByStr(GoldHistoryView view) throws ProjectException {
		GoldHistoryModel model = new GoldHistoryModel();
		model.setSymbol(view.getSymbol());
		model.setName(view.getName());
		model.setDateTime(view.getDateTime());
		if(StringUtils.equals(view.getOpenStr(), "-")){
			model.setOpen(0.0);
		}else{
			model.setOpen(Double.parseDouble(view.getOpenStr()));
		}
		if(StringUtils.equals(view.getHighStr(), "-")){
			model.setHigh(0.0);
		}else{
			model.setHigh(Double.parseDouble(view.getHighStr()));
		}
		if(StringUtils.equals(view.getLowStr(), "-")){
			model.setLow(0.0);
		}else{
			model.setLow(Double.parseDouble(view.getLowStr()));
		}
		if(StringUtils.equals(view.getCloseStr(), "-")){
			model.setClose(0.0);
		}else{
			model.setClose(Double.parseDouble(view.getCloseStr()));
		}
		if(StringUtils.equals(view.getTvolumeStr(), "-")){
			model.setTvolume(0.0);
		}else{
			model.setTvolume(Double.parseDouble(view.getTvolumeStr()));
		}
		if(StringUtils.equals(view.getTvalueStr(),"-")){
			model.setTvalue(0.0);
		}
		return model;
	}

	@Override
	public GoldHistoryModel editConvert(GoldHistoryView view, GoldHistoryModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public GoldHistoryView convertToView(GoldHistoryModel model) throws ProjectException {
		GoldHistoryView view = new GoldHistoryView();
		ReflectUtils.copySameFieldToTarget(model, view);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		view.setDateTimeStr(sdf.format(view.getDateTime()));
		return view;
	}

}
