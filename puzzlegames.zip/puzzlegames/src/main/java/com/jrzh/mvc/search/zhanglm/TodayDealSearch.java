package com.jrzh.mvc.search.zhanglm;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;
public class TodayDealSearch extends BaseSearch{

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private String likeName;
		

		public String getLikeName() {
			return likeName;
		}


		public void setLikeName(String likeName) {
			this.likeName = likeName;
		}


		public void setDc(DetachedCriteria dc) {
			if(StringUtils.isNotBlank(likeName)){
				dc.add(Restrictions.like("accNo", "%"+likeName+"%"));
			}
	
		}
}
