package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class CollectSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String equalUserId;
	
	private String equalCircleId;
	
	
	
	public String getEqualCircleId() {
		return equalCircleId;
	}

	public void setEqualCircleId(String equalCircleId) {
		this.equalCircleId = equalCircleId;
	}

	public String getEqualUserId() {
		return equalUserId;
	}

	public void setEqualUserId(String equalUserId) {
		this.equalUserId = equalUserId;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
	if(StringUtils.isNotBlank(equalUserId)){
		dc.add(Restrictions.eq("userId", equalUserId));
	}
	if(StringUtils.isNotBlank(equalCircleId)){
		dc.add(Restrictions.eq("circleId", equalCircleId));
	}
	}

}