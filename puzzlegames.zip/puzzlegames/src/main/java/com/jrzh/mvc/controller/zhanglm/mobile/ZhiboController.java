package com.jrzh.mvc.controller.zhanglm.mobile;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.bean.MobileResultBean;
import com.jrzh.framework.annotation.MemberEvent;
import com.jrzh.framework.base.search.BaseSearch;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.model.zhanglm.MemberAttentionModel;
import com.jrzh.mvc.model.zhanglm.ZhiboCourseModel;
import com.jrzh.mvc.model.zhanglm.ZhiboLiveModel;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.search.zhanglm.MemberAttentionSearch;
import com.jrzh.mvc.search.zhanglm.SpecialColumnSearch;
import com.jrzh.mvc.search.zhanglm.ZhiboCourseSearch;
import com.jrzh.mvc.search.zhanglm.ZhiboLiveSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.SpecialColumnView;
import com.jrzh.mvc.view.zhanglm.ZhiboLiveView;

@Controller(ZhiboController.LOCATION + "ZhiboController")
@RequestMapping(ZhiboController.LOCATION)
public class ZhiboController extends BaseMobileController {
	public static final String LOCATION = "/mobile/zhibo/";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;

	@RequestMapping(method = RequestMethod.POST, value = "single")
	@MemberEvent(desc ="安卓/IOS 获取单个直播")
	@ResponseBody
	public MobileResultBean single() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "single");
		String message = "";
		try {
			String zhiboId = request.getParameter("zhiboId"); //直播id
			String talentId=request.getParameter("talentId");//用户id
			String fanId=request.getParameter("fanId");     //粉丝id
			MemberAttentionSearch search = new MemberAttentionSearch();
			search.setEqualMemberId(talentId);
			//search.setEqualFansId(fanId);
			Boolean flag=false;
			if(StringUtils.isNotEmpty(fanId)){
				MemberAttentionModel memberAttention = zhanglmServiceManage.memberAttentionService.findBySearch(search);
				if(null != memberAttention){
					flag=true;
				}
				
			}
			
			ZhiboLiveView singleOne=zhanglmServiceManage.zhiboLiveService.findViewById(zhiboId);
			DefaultSearch defaultsearch = new DefaultSearch();
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
			if(null == singleOne.getPhoto()){
				singleOne.setPhoto(defaultModel.getImgUrl());
			}
			map.put("flag", flag);
			map.put("singleOne",singleOne);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "today")
	@MemberEvent(desc ="安卓/IOS 获取每日直播")
	@ResponseBody
	public MobileResultBean today() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ZhiboLiveView> todayList = new ArrayList<ZhiboLiveView>();
		map.put("method", "today");
		String message = "";
		try {
			Date date=new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			//今天的日期时间
			String now = sdf.format(date);
			List<ZhiboLiveView> zhiboList=zhanglmServiceManage.zhiboLiveService.findAllView();
			//给没设置用户头像的用户设置用户头像
			DefaultSearch defaultsearch = new DefaultSearch();
			for(ZhiboLiveView zhibo : zhiboList){
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
			if(null == zhibo.getPhoto()){
				zhibo.setPhoto(defaultModel.getImgUrl());
			}
			}
			if(null!=zhiboList){
				for(ZhiboLiveView zhibo:zhiboList){
					//开始直播时间
					String startTime = sdf.format(zhibo.getStartTime());
					if(now.equals(startTime) ){
						todayList.add(zhibo);
					}
				}
			}
			map.put("todayList", todayList);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "classify")
	@MemberEvent(desc ="安卓/IOS 获取分类专栏")
	@ResponseBody
	public MobileResultBean classify(ZhiboLiveSearch search) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "classify");
		String message = "";
		try {
			String columnCode=request.getParameter("columnCode");
			search.setEqualColumnCode(columnCode);
			List<ZhiboLiveView> classifyList = zhanglmServiceManage.zhiboLiveService.viewList(search);
			DefaultSearch defaultsearch = new DefaultSearch();
			for(ZhiboLiveView zhibo : classifyList){
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
			if(null == zhibo.getPhoto()){
				zhibo.setPhoto(defaultModel.getImgUrl());
			}
			}
			map.put("classifyList", classifyList);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "recommend")
	@MemberEvent(desc ="安卓/IOS 获取推荐直播")
	@ResponseBody
	public MobileResultBean recommend(ZhiboLiveSearch search) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		ZhiboCourseSearch zhibocoursesearch = new ZhiboCourseSearch();
		List<ZhiboCourseModel> zhibocourseview = new ArrayList<ZhiboCourseModel>();
		map.put("method", "recommend");
		String message = "";
		try {
			search.setEqualIsLock(true);
			search.setRows(2);
			List<ZhiboLiveView> recommendList = zhanglmServiceManage.zhiboLiveService.viewList(search);
				DefaultSearch defaultsearch = new DefaultSearch();
			for (ZhiboLiveView zhibo : recommendList) {
				/*zhibocoursesearch.setEqualzbId(zhibo.getId());
				zhibocourseview = zhanglmServiceManage.ZhiboCourseServiceI.viewListall(zhibocoursesearch);
				if(zhibocourseview !=null && zhibocourseview.size() > 0){
					zhibo.setStartTime1(zhibocourseview.get(0).getStartTime());
					zhibo.setEndTime1(zhibocourseview.get(0).getEndTime());
					zhibo.setTitle1(zhibocourseview.get(0).getTitle());
					zhibo.setLecturer1(zhibocourseview.get(0).getLecturer());
					zhibo.setStartTime2(zhibocourseview.get(1).getStartTime());
					zhibo.setEndTime2(zhibocourseview.get(1).getEndTime());
					zhibo.setTitle2(zhibocourseview.get(1).getTitle());
					zhibo.setLecturer2(zhibocourseview.get(1).getLecturer());
					zhibo.setStartTime3(zhibocourseview.get(2).getStartTime());
					zhibo.setEndTime3(zhibocourseview.get(2).getEndTime());
					zhibo.setTitle3(zhibocourseview.get(2).getTitle());
					zhibo.setLecturer3(zhibocourseview.get(2).getLecturer());			
				}*/
				zhibo.setIntro("直播讲师:" + zhibo.getUserName());
				defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
				DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
				if (null == zhibo.getPhoto()) {
					zhibo.setPhoto(defaultModel.getImgUrl());
				}
			}
				map.put("recommendList", recommendList);
				result.setObject(map);
				message = "获取推荐直播成功";
				result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "column")
	@MemberEvent(desc ="安卓/IOS 直播专栏")
	@ResponseBody
	public MobileResultBean column(SpecialColumnSearch search) {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "column");
		String message = "";
		try {
			List<SpecialColumnView> columnList = zhanglmServiceManage.specialColumnService.viewList(search);
			map.put("columnList", columnList);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "zhibo")
	@MemberEvent(desc ="安卓/IOS 已发布的直播")
	@ResponseBody
	public MobileResultBean Zhibo() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "Zhibo");
		String currPage = request.getParameter("currPage");
		String pageSize = request.getParameter("pageSize");
		Long number = 0L;
		String message = "";
		try {
			ZhiboLiveSearch search = new ZhiboLiveSearch();
			search.setPage(Integer.parseInt(currPage));
			search.setRows(Integer.parseInt(pageSize));
			search.setOrder(BaseSearch.Order_Type_Desc);
			List<ZhiboLiveView> zhiboList = zhanglmServiceManage.zhiboLiveService.viewList(search);
			DefaultSearch defaultsearch = new DefaultSearch();
			for(ZhiboLiveView zhibo : zhiboList){
			defaultsearch.setOrder(BaseSearch.Order_Type_Desc);
			DefaultModel defaultModel = zhanglmServiceManage.defaultService.first(defaultsearch);
			if(null == zhibo.getPhoto()){
				zhibo.setPhoto(defaultModel.getImgUrl());
			}
			}
		    number = zhanglmServiceManage.zhiboLiveService.count(search);
		    map.put("number", number);
		    map.put("currPage", currPage);
			map.put("ZhiboList", zhiboList);
			result.setObject(map);
			message = "获取成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "zhiboClick")
	@MemberEvent(desc ="安卓/IOS 直播点击量+1")
	@ResponseBody
	public MobileResultBean zhiboClick() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "zhiboClick");
		String message = "";
		try {
			String zhiboId = request.getParameter("zhiboId");
			ZhiboLiveModel zhibo = zhanglmServiceManage.zhiboLiveService.findById(zhiboId);
			Long cilckNum = zhibo.getClickNum();
			if(null != cilckNum){
				zhibo.setClickNum(++cilckNum);
			}else{
				zhibo.setClickNum(1L);
			}
			zhanglmServiceManage.zhiboLiveService.edit(zhibo, getSessionUser());
			result.setObject(map);
			message = "点击量更改成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "zhiboShare")
	@MemberEvent(desc ="安卓/IOS 直播分享量+1")
	@ResponseBody
	public MobileResultBean zhiboShare() {
		MobileResultBean result = new MobileResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("method", "zhiboShare");
		String message = "";
		try {
			String zhiboId = request.getParameter("zhiboId");
			ZhiboLiveModel zhibo = zhanglmServiceManage.zhiboLiveService.findById(zhiboId);
			Integer shareNum = zhibo.getShareNum();
			if(null != shareNum){
				zhibo.setShareNum(++shareNum);
			}else{
				zhibo.setShareNum(1);
			}
			zhanglmServiceManage.zhiboLiveService.edit(zhibo, getSessionUser());
			result.setObject(map);
			message = "分享量更改成功";
			result.setStatus(MobileResultBean.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		result.setMessage(message);
		return result; 
	}
	
	
}
