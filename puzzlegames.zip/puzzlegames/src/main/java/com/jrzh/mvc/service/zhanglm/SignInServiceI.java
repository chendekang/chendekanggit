package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.SignInModel;
import com.jrzh.mvc.search.zhanglm.SignInSearch;
import com.jrzh.mvc.view.zhanglm.SignInView;

public interface SignInServiceI  extends BaseServiceI<SignInModel, SignInSearch, SignInView>{

}