package com.jrzh.mvc.service.zhanglm.impl;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.tools.CollectionTools;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.annotation.UniqueValue;
import com.jrzh.framework.base.model.BaseModel;
import com.jrzh.mvc.convert.zhanglm.CorrectAnswerConvert;
import com.jrzh.mvc.dao.zhanglm.CorrectAnswerViewDaoI;
import com.jrzh.mvc.model.zhanglm.CorrectAnswerModel;
import com.jrzh.mvc.search.zhanglm.CorrectAnswerSearch;
import com.jrzh.mvc.service.zhanglm.CorrectAnswerServiceI;
import com.jrzh.mvc.view.zhanglm.CorrectAnswerView;
@Service("CorrectAnswerServiceI")
public class CorrectAnswerServiceImpl implements CorrectAnswerServiceI {
	@Resource(name = "CorrectAnswerViewDaoI")
	private CorrectAnswerViewDaoI correctanswerviewdaoi;

	@Override
	public List<CorrectAnswerModel> viewListall(CorrectAnswerSearch search) {
		return correctanswerviewdaoi.selectByField("questionid", search.getEqualPid());
	}

	@Override
	public void add(CorrectAnswerModel saveModel) throws ProjectException {
		 String message = validate(saveModel);
		 if (StringUtils.isNotBlank(message)) throw new ProjectException(message);
		 Date date = new Date();
		 saveModel.setCeratedate(date);
		 correctanswerviewdaoi.save(saveModel);
	}
	public String validate(CorrectAnswerModel saveModel) throws ProjectException {
		String message = "";
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set constraintViolations = validator.validate(saveModel, new Class[0]);
		if (constraintViolations.size() > 0) {
			message = ((ConstraintViolation) constraintViolations.iterator().next()).getMessage();
		}
		if (StringUtils.isBlank(message)) {
			Class clazz = saveModel.getClass();
			List<Field> fields = ReflectUtils.getFieldsByAnnotation(clazz, UniqueValue.class);
			if (CollectionTools.isNotBlank(fields).booleanValue()) {
				for (Field field : fields) {
					Object value = ReflectUtils.getValue(field.getName(), saveModel);
					BaseModel _m = findByField(field.getName(), value);
					if ((_m != null) && (!(_m.getId().equals(saveModel.getId())))) {
						String name = ((UniqueValue) field.getAnnotation(UniqueValue.class)).name();
						message = name + "[" + value + "]已存在";
						break;
					}
				}
			}
		}
		return message;
	}
	private BaseModel findByField(String name, Object value) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	@Override
	public void deletecourse(List<CorrectAnswerModel> viewList) throws ProjectException {
		for(CorrectAnswerModel model : viewList){
			correctanswerviewdaoi.delete(model);
		}	
		
	}

	@Override
	public void edit(CorrectAnswerModel saveModel) throws ProjectException {
		  String message = validate(saveModel);
		    if (StringUtils.isNotBlank(message)) throw new ProjectException(message);
		    Date date = new Date();
			saveModel.setCeratedate(date);
			correctanswerviewdaoi.merge(saveModel);
		
	}

	@Override
	public List<CorrectAnswerView> viewListallzb(CorrectAnswerSearch zhibocoursesearch) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<CorrectAnswerView> viewList(CorrectAnswerSearch search) throws ProjectException{
		List<CorrectAnswerModel> list = this.list(search);
		return this.convertByModelList(list);
	}
	
	public List<CorrectAnswerModel> list(CorrectAnswerSearch search){
		return  correctanswerviewdaoi.findList(search);
	}

	public List<CorrectAnswerView> convertByModelList(List<CorrectAnswerModel> modelList) throws ProjectException{
		List<CorrectAnswerView> viewList = new ArrayList<CorrectAnswerView>();
		if(null != modelList && modelList.size() > 0){
			for(CorrectAnswerModel t : modelList){
				viewList.add(CorrectAnswerConvert.convertToView(t));
			}
		}
		return viewList;
	}

	@Override
	public CorrectAnswerModel findById(String id) {
		
		CorrectAnswerModel model = correctanswerviewdaoi.getmodel(id);
		return model;
	}

}
