package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.ActivityPictureModel;
import com.jrzh.mvc.search.zhanglm.ActivityPictureSearch;
import com.jrzh.mvc.view.zhanglm.ActivityPictureView;

public interface ActivityPictureServiceI  extends BaseServiceI<ActivityPictureModel, ActivityPictureSearch, ActivityPictureView>{

	void addAndFile(ActivityPictureModel model,FileModel file,SessionUser user) throws Exception;
	
	void editAndFile(ActivityPictureModel model, FileModel file, SessionUser user)throws Exception;

	void deleteAndFile(ActivityPictureModel model, FileModel file, SessionUser user)throws Exception;
}