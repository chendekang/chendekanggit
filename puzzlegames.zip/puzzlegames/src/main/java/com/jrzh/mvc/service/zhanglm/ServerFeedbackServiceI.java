package com.jrzh.mvc.service.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.zhanglm.ServerFeedbackModel;
import com.jrzh.mvc.search.zhanglm.ServerFeedbackSearch;
import com.jrzh.mvc.view.zhanglm.ServerFeedbackView;

public interface ServerFeedbackServiceI  extends BaseServiceI<ServerFeedbackModel, ServerFeedbackSearch, ServerFeedbackView>{

	void editAndSaveSend(ServerFeedbackModel model, SessionUser user)throws ProjectException;

}