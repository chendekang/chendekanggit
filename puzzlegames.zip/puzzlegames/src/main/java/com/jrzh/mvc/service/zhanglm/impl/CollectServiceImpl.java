package com.jrzh.mvc.service.zhanglm.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.CollectConvert;
import com.jrzh.mvc.dao.zhanglm.CollectDaoI;
import com.jrzh.mvc.model.zhanglm.AategoryModel;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.model.zhanglm.CollectModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.model.zhanglm.TitleReleaseModel;
import com.jrzh.mvc.search.zhanglm.CollectSearch;
import com.jrzh.mvc.service.zhanglm.CollectServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.AategoryView;
import com.jrzh.mvc.view.zhanglm.CollectView;
import com.jrzh.tools.HtmlTools;

@Service("collectService")
public class CollectServiceImpl extends
		BaseServiceImpl<CollectModel, CollectSearch, CollectView> implements
		CollectServiceI {

	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@Resource(name = "collectDao")
	private CollectDaoI collectDao;

	@Override
	public BaseDaoI<CollectModel> getDao() {
		return collectDao;
	}

	@Override
	public BaseConvertI<CollectModel, CollectView> getConvert() {
		return new CollectConvert();
	}

	public List<CollectView> collectList(CollectSearch search) throws ProjectException{
		List<CollectView> viewList = this.viewList(search);
		for(CollectView view:viewList){
			String userId=view.getUserId();
			String circleId=view.getCircleId();
			MemberModel member=zhanglmServiceManage.memberService.findById(userId);
			//获取用户名称
			String userName=member.getNickName();
			if(StringUtils.isBlank(userName)){
				userName="用户未设置昵称";
			}
			BbsTopicModel topic=zhanglmServiceManage.bbsTopicService.findById(circleId);
			view.setUserName(userName);
			view.setCircleTitle(topic.getTitle());
			view.setCircleContent(topic.getContent());
			view.setDiscuss(topic.getDiscuss());
			view.setPraise(topic.getPraise());
		}
		return viewList;
		
	}
	
	public List<CollectView> collectListMobile(CollectSearch search) throws ProjectException{
		List<CollectView> viewList = this.viewList(search);
		for(CollectView view:viewList){
			String userId=view.getUserId();
			String circleId=view.getCircleId();
			MemberModel member=zhanglmServiceManage.memberService.findById(userId);
			//获取用户名称
			String userName=member.getNickName();
			if(StringUtils.isBlank(userName)){
				userName="用户未设置昵称";
			}
			view.setUserName(userName);
			TitleReleaseModel topic=zhanglmServiceManage.titlereleaseservicei.findById(circleId);
			
			if(topic != null){
				//分类
				AategoryModel aategorylist  = zhanglmServiceManage.aategoryservicei.findById(topic.getCategoryid());
				if(null != aategorylist){
					view.setTypeName(aategorylist.getTypeName());
				}
				view.setCircleTitle(topic.getTitle());
				String dataIntro = HtmlTools.delHTMLTag(topic.getContent());
				if(dataIntro.length() > 30){
					view.setCircleContent((String) dataIntro.subSequence(0, 30)+"......");
				}else{
					view.setCircleContent(dataIntro);
				}
				view.setDiscuss(topic.getDiscuss());
			//	view.setPraise(topic.getPraise());
			}else{
				view.setCircleContent("该题目已被删除");
				view.setCircleTitle("该题目已被删除");
				view.setDiscuss(0);
				view.setPraise(0);
			}
		}
		return viewList;
		
	}
}
