package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.ServerQuestionModel;
import com.jrzh.mvc.search.zhanglm.ServerQuestionSearch;
import com.jrzh.mvc.view.zhanglm.ServerQuestionView;

public interface ServerQuestionServiceI  extends BaseServiceI<ServerQuestionModel, ServerQuestionSearch, ServerQuestionView>{

}