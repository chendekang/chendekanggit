package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.zhanglm.SnapshotModel;
import com.jrzh.mvc.search.zhanglm.SnapshotSearch;
import com.jrzh.mvc.view.zhanglm.SnapshotView;


public interface SnapshotServiceI {

	List<SnapshotView> viewList(SnapshotSearch search) throws ProjectException;

	List<SnapshotModel> list(SnapshotSearch search);

	EasyuiDataGrid<SnapshotView> datagrid(SnapshotSearch search)throws ProjectException;

	SnapshotModel findById(Integer id);

	SnapshotView findViewById(Integer id) throws ProjectException;

	void edit(SnapshotModel model, SessionUser user) throws ProjectException;

	SnapshotView findViewByField(String fieldName, Object value)throws ProjectException;

	SnapshotModel findByField(String fieldName, Object value)throws ProjectException;

}