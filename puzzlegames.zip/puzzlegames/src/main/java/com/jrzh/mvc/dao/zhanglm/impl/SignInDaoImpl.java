package com.jrzh.mvc.dao.zhanglm.impl;

import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.SignInDaoI;
import com.jrzh.mvc.model.zhanglm.SignInModel;

@Repository("signInDao")
public class SignInDaoImpl extends BaseDaoImpl<SignInModel> implements SignInDaoI{

}