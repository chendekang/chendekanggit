package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class BbsCommentsSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	private String equalUserId;
	private String equalcommentsId;
	public String getEqualcommentsId() {
		return equalcommentsId;
	}

	public void setEqualcommentsId(String equalcommentsId) {
		this.equalcommentsId = equalcommentsId;
	}

	public String getEqualUserId() {
		return equalUserId;
	}

	public void setEqualUserId(String equalUserId) {
		this.equalUserId = equalUserId;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalUserId)){
			dc.add(Restrictions.eq("userId", equalUserId));
		}
		
		if(StringUtils.isNotBlank(equalcommentsId)){
			dc.add(Restrictions.eq("commentsId", equalcommentsId));
		}
	}

}