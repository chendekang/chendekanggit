package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.ServerCategoryModel;
import com.jrzh.mvc.view.zhanglm.ServerCategoryView;

public class ServerCategoryConvert implements BaseConvertI<ServerCategoryModel, ServerCategoryView> {

	@Override
	public ServerCategoryModel addConvert(ServerCategoryView view) throws ProjectException {
		ServerCategoryModel model = new ServerCategoryModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public ServerCategoryModel editConvert(ServerCategoryView view, ServerCategoryModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public ServerCategoryView convertToView(ServerCategoryModel model) throws ProjectException {
		ServerCategoryView view = new ServerCategoryView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
