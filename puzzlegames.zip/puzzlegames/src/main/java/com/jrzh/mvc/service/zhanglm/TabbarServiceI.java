package com.jrzh.mvc.service.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.TabbarModel;
import com.jrzh.mvc.search.zhanglm.TabbarSearch;
import com.jrzh.mvc.view.zhanglm.TabbarView;

public interface TabbarServiceI  extends BaseServiceI<TabbarModel, TabbarSearch, TabbarView>{

	void addAndFiles(TabbarModel model, FileModel[] fileModels, SessionUser user)throws ProjectException;

	void editAndFiles(TabbarModel model, FileModel[] fileModels,SessionUser user) throws ProjectException;

	void deleteAndFiles(TabbarModel model, FileModel[] fileModels,SessionUser user) throws ProjectException;


}