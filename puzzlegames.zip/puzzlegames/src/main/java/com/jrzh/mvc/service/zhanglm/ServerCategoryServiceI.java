package com.jrzh.mvc.service.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.ServerCategoryModel;
import com.jrzh.mvc.search.zhanglm.ServerCategorySearch;
import com.jrzh.mvc.view.zhanglm.ServerCategoryView;

public interface ServerCategoryServiceI  extends BaseServiceI<ServerCategoryModel, ServerCategorySearch, ServerCategoryView>{

	void editAndFile(ServerCategoryModel model, FileModel file, SessionUser user)throws ProjectException;

	void addAndFile(ServerCategoryModel model, FileModel file, SessionUser user)throws ProjectException;

	void deleteAndFile(ServerCategoryModel model, FileModel file,SessionUser user) throws ProjectException;

}