package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "zlm_today_deal")
public class TodayDealModel{
	@Id
	  @Column(name="_id")
	  @GenericGenerator(name="system-uuid", strategy="uuid")
	  @GeneratedValue(generator="system-uuid")
	  private String id;
	/**
     * 客户号
     */
    @Column(name = "_accno")
    private String accNo;
    /**
     *成交手数
     */
    @Column(name = "_dealaccount")
    private String dealAccount;
    /**
     * 成交方向
     */
    @Column(name = "_direction")
    private String direction;
    
    /**
     *合约代码
     */
    @Column(name = "_instid")
    private String instId;
    /**
     *委托价格
     */
    @Column(name = "_eachprice")
    private String eachPrice;
    /**
     * 保证金
     */
    @Column(name = "_commision")
    private String commision;
    /**
     *成交金额
     */
    @Column(name = "_deposit")
    private String deposit;
    
    /**
     * 本地报单号
     */
    @Column(name = "_localorderno")
    private String localOrderNo;
    /**
     *交易日期
     */
    @Column(name = "_tradedate")
    private String tradeDate;
    
    /**
     *创建时间
     */
    @Column(name = "_create_time")
    private Date createtime;
    
    
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getDealAccount() {
		return dealAccount;
	}
	public void setDealAccount(String dealAccount) {
		this.dealAccount = dealAccount;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getInstId() {
		return instId;
	}
	public void setInstId(String instId) {
		this.instId = instId;
	}
	public String getEachPrice() {
		return eachPrice;
	}
	public void setEachPrice(String eachPrice) {
		this.eachPrice = eachPrice;
	}
	public String getCommision() {
		return commision;
	}
	public void setCommision(String commision) {
		this.commision = commision;
	}
	public String getDeposit() {
		return deposit;
	}
	public void setDeposit(String deposit) {
		this.deposit = deposit;
	}
	public String getLocalOrderNo() {
		return localOrderNo;
	}
	public void setLocalOrderNo(String localOrderNo) {
		this.localOrderNo = localOrderNo;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
}