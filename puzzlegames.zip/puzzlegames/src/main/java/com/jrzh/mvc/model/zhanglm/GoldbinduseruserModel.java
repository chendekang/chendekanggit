package com.jrzh.mvc.model.zhanglm;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name = "zlm_gold_binduser_user")
public class GoldbinduseruserModel {
	@Id
	@Column(name = "_id")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@GeneratedValue(generator = "system-uuid")
	private String id;
	/**
	 * 绑定用户id
	 */
	@Column(name = "_binduseruserid")
	private String binduseruserid;
	/**
	 * 会员id
	 */
	@Column(name = "_membersid")
	private String membersid;
	/**
	 * 创建时间
	 */
	@Column(name = "creation_time")
	private Date creation_time;

	public Date getCreation_time() {
		return creation_time;
	}
	public void setCreation_time(Date creation_time) {
		this.creation_time = creation_time;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBinduseruserid() {
		return binduseruserid;
	}
	public void setBinduseruserid(String binduseruserid) {
		this.binduseruserid = binduseruserid;
	}
	public String getMembersid() {
		return membersid;
	}
	public void setMembersid(String membersid) {
		this.membersid = membersid;
	}
}
