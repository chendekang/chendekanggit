package com.jrzh.mvc.model.zhanglm;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;
@Entity
@Table(name = "_number_statistics")
public class NumberstatisticsModel extends BaseModel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * 用户id记录数量
     */
    @Column(name = "_userId")
    private String userId;
    /**
     * 话题id
     */
    @Column(name = "_topicId")
    private String topicId;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTopicId() {
		return topicId;
	}
	public void setTopicId(String topicId) {
		this.topicId = topicId;
	}



}


