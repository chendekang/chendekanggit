package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.BbsTopicAuditLogModel;
import com.jrzh.mvc.view.zhanglm.BbsTopicAuditLogView;

public class BbsTopicAuditLogConvert implements BaseConvertI<BbsTopicAuditLogModel, BbsTopicAuditLogView> {

	@Override
	public BbsTopicAuditLogModel addConvert(BbsTopicAuditLogView view) throws ProjectException {
		BbsTopicAuditLogModel model = new BbsTopicAuditLogModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public BbsTopicAuditLogModel editConvert(BbsTopicAuditLogView view, BbsTopicAuditLogModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public BbsTopicAuditLogView convertToView(BbsTopicAuditLogModel model) throws ProjectException {
		BbsTopicAuditLogView view = new BbsTopicAuditLogView();
		ReflectUtils.copySameFieldToTarget(model, view);
		view.setStatusStr(BusinessConstants.BBS_TOPIC_STATUS.valueMap.get(view.getStatus()));
		return view;
	}

}
