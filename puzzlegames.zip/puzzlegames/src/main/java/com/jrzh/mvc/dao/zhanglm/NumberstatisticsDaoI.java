package com.jrzh.mvc.dao.zhanglm;

import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.NumberstatisticsModel;

public interface NumberstatisticsDaoI extends BaseDaoI<NumberstatisticsModel>{

}
