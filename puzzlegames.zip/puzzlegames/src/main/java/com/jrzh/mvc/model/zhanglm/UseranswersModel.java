package com.jrzh.mvc.model.zhanglm;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;
@Entity
@Table(name = "user_answer")
public class UseranswersModel extends BaseModel {

	private static final long serialVersionUID = 1L;
	/**
     * 用户id
     */
    @Column(name = "uid")
    private String uid;
    /**
     * 题目id
     */
    @Column(name = "qid")
    private String qid;
    /**
     * 用户答案
     */
    @Column(name = "answer")
    private String answer;
    /**
     * 回答结果(正确1/错误0)
     */
    @Column(name = "result")
    private String result;
     /**
      * 减分项
      */
     @Column(name = "reduction")
     private String reduction;
     /**
      * 分类id
      */
     @Column(name = "_categoryid")
     private String categoryid;
     
     
	public String getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(String categoryid) {
		this.categoryid = categoryid;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getQid() {
		return qid;
	}
	public void setQid(String qid) {
		this.qid = qid;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getReduction() {
		return reduction;
	}
	public void setReduction(String reduction) {
		this.reduction = reduction;
	}


}


