package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.OpenAccoLogModel;
import com.jrzh.mvc.search.zhanglm.OpenAccoLogSearch;
import com.jrzh.mvc.view.zhanglm.OpenAccoLogView;

public interface OpenAccoLogServiceI  extends BaseServiceI<OpenAccoLogModel, OpenAccoLogSearch, OpenAccoLogView>{

}