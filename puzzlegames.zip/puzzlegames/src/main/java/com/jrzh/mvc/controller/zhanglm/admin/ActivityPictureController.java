package com.jrzh.mvc.controller.zhanglm.admin;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.ActivityPictureConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.ActivityPictureModel;
import com.jrzh.mvc.search.zhanglm.ActivityPictureSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.ActivityPictureView;

@Controller(ActivityPictureController.LOCATION +"/ActivityPictureController")
@RequestMapping(ActivityPictureController.LOCATION)
public class ActivityPictureController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/activityPicture";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_activityPicture";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "ActivityPicture列表查询")
	@ResponseBody
	public EasyuiDataGrid<ActivityPictureView> datagrid(ActivityPictureSearch search) {
		EasyuiDataGrid<ActivityPictureView> dg = new EasyuiDataGrid<ActivityPictureView>();
	    try{
	    	dg = zhanglmServiceManage.activityPictureService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new ActivityPictureView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "ActivityPicture增加")
	@ResponseBody
	public ResultBean add(ActivityPictureView view,BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		if(this.log.isDebugEnabled()){
			this.log.debug("doAdd() View:"+ view.toString());
		}
		try{
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			String actionurl = request.getParameter("actionurl");
			ActivityPictureModel model =new ActivityPictureConvert().addConvert(view);
			model.setImgUrl(url);
			model.setImgType(type);
			model.setActionurl(actionurl);
			model.setIsDisable(true);
			message = zhanglmServiceManage.activityPictureService.validate(model);
			if(StringUtils.isNotBlank(message)){
					result.setMsg(message);
					return result;
			}
			FileModel file=new FileModel();
			file.setModel("activityPicture");
			file.setType(type);
			file.setName(view.getImgName());
			file.setUrl(url);
			message = sysServiceManage.fileService.validate(file);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.activityPictureService.addAndFile(model, file,getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.activityPictureService.findViewById(id));
			request.setAttribute("file", sysServiceManage.fileService.findByField("formId", id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "ActivityPicture修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, ActivityPictureView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (this.log.isDebugEnabled()) {
			this.log.debug("doEdit() View:" + view.toString());
		}
		try {
			if(StringUtils.isBlank(view.getImgName())){
				result.setMsg("文件名称不能为空");
				return result;
			}
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			String actionurl = request.getParameter("actionurl");
			ActivityPictureModel model = zhanglmServiceManage.activityPictureService.findById(id);
			model = new ActivityPictureConvert().editConvert(view, model);
			model.setImgUrl(url);
			model.setImgType(type);
			model.setActionurl(actionurl);
			message = zhanglmServiceManage.activityPictureService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			FileModel file = sysServiceManage.fileService.findByField("formId", model.getId());
			file.setModel("activityPicture");
			file.setType(type);
			file.setName(view.getImgName());
			file.setUrl(url);
			message = sysServiceManage.fileService.validate(file);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.activityPictureService.editAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "ActivityPicture删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id,ActivityPictureView view) {
		ResultBean result = new ResultBean();
		if (this.log.isDebugEnabled()) {
			this.log.debug("doDelete() View:" + view.toString());
		}
		try {
			ActivityPictureModel model = zhanglmServiceManage.activityPictureService.findById(id);
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			zhanglmServiceManage.activityPictureService.deleteAndFile(model,file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "ActivityPicture禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			ActivityPictureModel model = zhanglmServiceManage.activityPictureService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.activityPictureService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
