package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.UseranswersModel;
import com.jrzh.mvc.search.zhanglm.UseranswersSearch;
import com.jrzh.mvc.view.zhanglm.UseranswersView;

public interface UseranswersServiceI  extends BaseServiceI<UseranswersModel, UseranswersSearch, UseranswersView>{



}