package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.TitleReleaseModel;
import com.jrzh.mvc.search.zhanglm.TitleReleaseSearch;
import com.jrzh.mvc.view.zhanglm.TitleReleaseView;

public interface TitleReleaseServiceI  extends BaseServiceI<TitleReleaseModel, TitleReleaseSearch, TitleReleaseView>{

	void addAndFiles(TitleReleaseModel model, FileModel[] fileModels, SessionUser sessionUser) throws ProjectException;



	List<TitleReleaseView> viewListReply(TitleReleaseSearch replySearch, String userId) throws ProjectException;



	TitleReleaseModel viewlatestValue(TitleReleaseSearch titlereleasesearch) throws ProjectException;



	EasyuiDataGrid<TitleReleaseView> topicdatagrid(TitleReleaseSearch search);



	void editAndFiles(TitleReleaseModel model, FileModel[] fileModels, SessionUser sessionUser) throws ProjectException;




}