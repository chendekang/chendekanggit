package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.ZhiboAdModel;
import com.jrzh.mvc.search.zhanglm.ZhiboAdSearch;
import com.jrzh.mvc.view.zhanglm.ZhiboAdView;

public interface ZhiboAdServiceI  extends BaseServiceI<ZhiboAdModel, ZhiboAdSearch, ZhiboAdView>{

	void addAndFile(ZhiboAdModel model,FileModel file,SessionUser user) throws Exception;
	void editAndFile(ZhiboAdModel model,FileModel file,SessionUser user) throws Exception;
	void deleteAndFile(ZhiboAdModel model, FileModel file, SessionUser user)throws Exception;
}