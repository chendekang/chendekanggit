package com.jrzh.mvc.model.zhanglm;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;
@Entity
@Table(name = "_do_title")
public class DotitleModel extends BaseModel {
	private static final long serialVersionUID = 1L;
	/**
     * 用户id
     */
    @Column(name = "_user_id")
    private String userid;
    /**
     * 题目id
     */
    @Column(name = "_title_id")
    private String titleid;

	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getTitleid() {
		return titleid;
	}
	public void setTitleid(String titleid) {
		this.titleid = titleid;
	}


}


