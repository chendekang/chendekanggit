package com.jrzh.mvc.controller.zhanglm.admin;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.SharePageConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.SharePageModel;
import com.jrzh.mvc.search.zhanglm.SharePageSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.SharePageView;

@Controller(SharePageController.LOCATION +"/SharePageController")
@RequestMapping(SharePageController.LOCATION)
public class SharePageController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/sharePage";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_sharePage";
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "SharePage列表查询")
	@ResponseBody
	public EasyuiDataGrid<SharePageView> datagrid(SharePageSearch search) {
		EasyuiDataGrid<SharePageView> dg = new EasyuiDataGrid<SharePageView>();
	    try{
	    	dg = zhanglmServiceManage.sharePageService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new SharePageView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "SharePage增加")
	@ResponseBody
	public ResultBean add(SharePageView view,BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		if(this.log.isDebugEnabled()){
			this.log.debug("doAdd() View:"+ view.toString());
		}
		try{
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			SharePageModel model =new SharePageConvert().addConvert(view);
			model.setImgUrl(url);
			message = zhanglmServiceManage.sharePageService.validate(model);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
		    }
			FileModel file=new FileModel();
			file.setModel("sharePage");
			file.setType(type);
			file.setName(view.getName());
			file.setUrl(url);
			message = sysServiceManage.fileService.validate(file);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
		    zhanglmServiceManage.sharePageService.addAndFile(model, file,getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.sharePageService.findViewById(id));
			request.setAttribute("file", sysServiceManage.fileService.findByField("formId", id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "SharePage修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, SharePageView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (this.log.isDebugEnabled()) {
			this.log.debug("doEdit() View:" + view.toString());
		}
		try {
			if(StringUtils.isBlank(view.getName())){
				result.setMsg("文件名称不能为空");
				return result;
			}
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			SharePageModel model = zhanglmServiceManage.sharePageService.findById(id);
			model = new SharePageConvert().editConvert(view, model);
			model.setImgUrl(url);
			message = zhanglmServiceManage.sharePageService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			FileModel file = sysServiceManage.fileService.findByField("formId", model.getId());
			file.setModel("sharePage");
			file.setType(type);
			file.setName(view.getName());
			file.setUrl(url);
			message = sysServiceManage.fileService.validate(file);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.sharePageService.editAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "SharePage删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			SharePageModel model = zhanglmServiceManage.sharePageService.findById(id);
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			zhanglmServiceManage.sharePageService.deleteAndFile(model,file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "SharePage禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			SharePageModel model = zhanglmServiceManage.sharePageService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.sharePageService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
