package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.annotation.UniqueValue;
import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_zhibo_lives")
public class ZhiboLiveModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 用户ID
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 关联用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_user_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel member;
    
    /**
     * 标题
     */
    @Column(name = "_title")
    private String title;
    /**
     * 简介
     */
    @Column(name = "_intro")
    private String intro;
    /**
     * 图片名称
     */
    @Column(name = "_img_name")
    private String imgName;
    /**
     * 图片路径
     */
    @Column(name = "_img_url")
    private String imgUrl;
    /**
     * 图片类型
     */
    @Column(name = "_img_type")
    private String imgType;
    /**
     * 点击量
     */
    @Column(name = "_click_num")
    private Long clickNum;
    /**
     * 分享量
     */
    @Column(name = "_share_num")
    private Integer shareNum;
    /**
     * 收藏量
     */
    @Column(name = "_collect_num")
    private Long collectNum;
    /**
     * 拉取视频地址
     */
    @Column(name = "_zhibo_url")
    private String zhiboUrl;
    /**
     * 直播开始时间
     */
    @Column(name = "_start_time")
    private Date startTime;
    /**
     * 直播结束时间
     */
    @Column(name = "_end_time")
    private Date endTime;
    /**
     *栏目编号 
     */
    @Column(name = "_column_code")
    private String columnCode;
    /**
     *栏目编号实体
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = SpecialColumnModel.class)
	@JoinColumn(name = "_column_code", referencedColumnName = "_code",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private SpecialColumnModel specialColumn;
    /**
     * 直播端口号
     */
    @UniqueValue(name = "直播端口号")
    @Column(name = "_port")
    private String port;
    
    /**
     * 日期时间
     */
    @Column(name = "_zb_date")
    private Date zbdate;
     
    /**
     *观众人数
     */
    @UniqueValue(name = "观众人数")
    @Column(name = "_audienceNum")
    private Long audienceNum;
    
    /**
     * 直播流畅
     */
    @UniqueValue(name = "直播流畅")
    @Column(name = "_zbld")
    private String zbld;
    /**
     * 直播标准
     */
    @UniqueValue(name = "直播标准")
    @Column(name = "_zbsd")
    private String zbsd;
    /**
     * 直播高清
     */
    @UniqueValue(name = "直播高清")
    @Column(name = "_zbhd")
    private String zbhd;
    /**
     * 直播超高清
     */
    @UniqueValue(name = "直播超高清")
    @Column(name = "_zbud")
    private String zbud;

	public Long getAudienceNum() {
		return audienceNum;
	}

	public void setAudienceNum(Long audienceNum) {
		this.audienceNum = audienceNum;
	}

	public Date getZbdate() {
		return zbdate;
	}

	public void setZbdate(Date zbdate) {
		this.zbdate = zbdate;
	}

	public String getZbld() {
		return zbld;
	}

	public void setZbld(String zbld) {
		this.zbld = zbld;
	}

	public String getZbsd() {
		return zbsd;
	}

	public void setZbsd(String zbsd) {
		this.zbsd = zbsd;
	}

	public String getZbhd() {
		return zbhd;
	}

	public void setZbhd(String zbhd) {
		this.zbhd = zbhd;
	}

	public String getZbud() {
		return zbud;
	}

	public void setZbud(String zbud) {
		this.zbud = zbud;
	}
	public Integer getShareNum() {
		return shareNum;
	}

	public void setShareNum(Integer shareNum) {
		this.shareNum = shareNum;
	}

	public Long getCollectNum() {
		return collectNum;
	}

	public void setCollectNum(Long collectNum) {
		this.collectNum = collectNum;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public SpecialColumnModel getSpecialColumn() {
		return specialColumn;
	}

	public void setSpecialColumn(SpecialColumnModel specialColumn) {
		this.specialColumn = specialColumn;
	}

	public String getColumnCode() {
		return columnCode;
	}

	public void setColumnCode(String columnCode) {
		this.columnCode = columnCode;
	}

	public MemberModel getMember() {
		return member;
	}

	public void setMember(MemberModel member) {
		this.member = member;
	}

	public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getTitle() {
        return this.title;
    }
    public void setIntro(String intro) {
        this.intro = intro;
    }
    
    public String getIntro() {
        return this.intro;
    }
    public void setImgName(String imgName) {
        this.imgName = imgName;
    }
    
    public String getImgName() {
        return this.imgName;
    }
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
    
    public String getImgUrl() {
        return this.imgUrl;
    }
    public void setImgType(String imgType) {
        this.imgType = imgType;
    }
    
    public String getImgType() {
        return this.imgType;
    }
    public Long getClickNum() {
		return clickNum;
	}

	public void setClickNum(Long clickNum) {
		this.clickNum = clickNum;
	}

	public void setZhiboUrl(String zhiboUrl) {
        this.zhiboUrl = zhiboUrl;
    }
    
    public String getZhiboUrl() {
        return this.zhiboUrl;
    }
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }
    
    public Date getStartTime() {
        return this.startTime;
    }
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
    
    public Date getEndTime() {
        return this.endTime;
    }

}