package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.BbsFanModel;
import com.jrzh.mvc.search.zhanglm.BbsFanSearch;
import com.jrzh.mvc.view.zhanglm.BbsFanView;

public interface BbsFanServiceI  extends BaseServiceI<BbsFanModel, BbsFanSearch, BbsFanView>{

}