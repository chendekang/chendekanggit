package com.jrzh.mvc.service.zhanglm.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.jrzh.common.tools.CollectionTools;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.convert.zhanglm.AppVersionConvert;
import com.jrzh.mvc.dao.zhanglm.AppVersionDaoI;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.AppVersionModel;
import com.jrzh.mvc.search.zhanglm.AppVersionSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.AppVersionServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.AppVersionView;

@Service("appVersionService")
public class AppVersionServiceImpl extends
		BaseServiceImpl<AppVersionModel, AppVersionSearch, AppVersionView> implements
		AppVersionServiceI {

	@Resource(name = "appVersionDao")
	private AppVersionDaoI appVersionDao;
	
	@Resource(name = "sysServiceManage")
	private SysServiceManage sysServiceManage;
	
	@Resource(name = "zhanglmServiceManage")
	private ZhanglmServiceManage zhanglmServiceManage;

	@Override
	public BaseDaoI<AppVersionModel> getDao() {
		return appVersionDao;
	}

	@Override
	public BaseConvertI<AppVersionModel, AppVersionView> getConvert() {
		return new AppVersionConvert();
	}

	public void addAndFile(AppVersionModel model,FileModel fileModel,SessionUser sessionUser)throws Exception{
		this.add(model, sessionUser);
		List<AppVersionModel> modelList=zhanglmServiceManage.appVersionService.findAll();	
		if(CollectionTools.isNotBlank(modelList)){
			for(AppVersionModel appModel:modelList){
				//将所有状态改为true也就是全禁用
				appModel.setIsDisable(true);
				zhanglmServiceManage.appVersionService.edit(appModel, sessionUser);
			}
		}
		
		fileModel.setFormId(model.getId());
		
		sysServiceManage.fileService.add(fileModel, sessionUser);
	}
	
	public void editAndFile(AppVersionModel model,FileModel fileModel,SessionUser sessionUser)throws Exception{
		//无论如何都有这条数据
		this.edit(model, sessionUser);
		//根据字段查询一条数据
		FileModel dbFile=sysServiceManage.fileService.findByField("appVersion", model.getId());
		//数据库存在
		if(null!=dbFile){
			//这条数据的地址不为空
			if(StringUtils.isNotBlank(dbFile.getUrl())){
				//需要更新的地址与旧地址不同
				if(!StringUtils.equals(fileModel.getUrl(), dbFile.getUrl())){
					//先删除掉旧地址
					sysServiceManage.fileService.delete(dbFile, sessionUser);		
				}		
			}
		}
			if(StringUtils.isNotBlank(fileModel.getUrl())){				
				fileModel.setFormId(model.getId());
				sysServiceManage.fileService.add(fileModel, sessionUser);
			}
	}
	
	public void deleteAndFile(AppVersionModel model,FileModel fileModel,SessionUser sessionUser) throws Exception{
		if(null!=fileModel){
			sysServiceManage.fileService.delete(fileModel, sessionUser);
		}
		this.delete(model, sessionUser);
	}

	

	
}
