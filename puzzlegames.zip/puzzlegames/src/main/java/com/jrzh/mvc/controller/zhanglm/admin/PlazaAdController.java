package com.jrzh.mvc.controller.zhanglm.admin;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.PlazaAdConvert;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.PlazaAdModel;
import com.jrzh.mvc.search.zhanglm.PlazaAdSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.PlazaAdView;

@Controller(PlazaAdController.LOCATION +"/PlazaAdController")
@RequestMapping(PlazaAdController.LOCATION)
public class PlazaAdController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/plaza/adMap";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_plazaAd";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "PlazaAd列表查询")
	@ResponseBody
	public EasyuiDataGrid<PlazaAdView> datagrid(PlazaAdSearch search) {
		EasyuiDataGrid<PlazaAdView> dg = new EasyuiDataGrid<PlazaAdView>();
	    try{
	    	dg = zhanglmServiceManage.plazaAdService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new PlazaAdView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "PlazaAd增加")
	@ResponseBody
	public ResultBean add(PlazaAdView view,BindingResult errors){
		ResultBean result = new ResultBean();
		String message = null;
		if(errors.hasErrors()){
			for(ObjectError objectError : errors.getAllErrors()){
				message = this.getMessage(objectError.getCode(),objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if(this.log.isDebugEnabled()){
			this.log.debug("doAdd() View:"+ view.toString());
		}
		try{
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			PlazaAdModel model =new PlazaAdConvert().addConvert(view);
			model.setImgUrl(url);
			model.setImgType(type);
			message = zhanglmServiceManage.plazaAdService.validate(model);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			FileModel file=new FileModel();
			file.setModel("plazaAd");
			file.setType(type);
			file.setName(view.getImgName());
			file.setUrl(url);
			message = sysServiceManage.fileService.validate(file);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.plazaAdService.addAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.plazaAdService.findViewById(id));
			request.setAttribute("file", sysServiceManage.fileService.findByField("formId", id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "PlazaAd修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, PlazaAdView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(), objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if (this.log.isDebugEnabled()) {
			this.log.debug("doEdit() View:" + view.toString());
		}
		try {
			if(StringUtils.isBlank(view.getImgName())){
				result.setMsg("文件名称不能为空");
				return result;
			}
			String url = request.getParameter("fileUrl");
			String type = request.getParameter("fileType");
			PlazaAdModel model = zhanglmServiceManage.plazaAdService.findById(id);
			model = new PlazaAdConvert().editConvert(view, model);
			model.setImgUrl(url);
			model.setImgType(type);
			message = zhanglmServiceManage.plazaAdService.validate(model);
			if (StringUtils.isNotBlank(message)) {
				result.setMsg(message);
				return result;
			}
			FileModel file = sysServiceManage.fileService.findByField("formId", model.getId());
			file.setModel("plazaAd");
			file.setType(type);
			file.setName(view.getImgName());
			file.setUrl(url);
			message = sysServiceManage.fileService.validate(file);
			if(StringUtils.isNotBlank(message)){
				result.setMsg(message);
				return result;
			}
			zhanglmServiceManage.plazaAdService.editAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "PlazaAd删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id,PlazaAdView view,BindingResult errors) {
		ResultBean result = new ResultBean();
		String message = null;
		if (errors.hasErrors()) {
			for (ObjectError objectError : errors.getAllErrors()) {
				message = this.getMessage(objectError.getCode(),
						objectError.getArguments());
				result.setMsg(message);
				return result;
			}
		}
		if (this.log.isDebugEnabled()) {
			this.log.debug("doDelete() View:" + view.toString());
		}
		try {
			PlazaAdModel model = zhanglmServiceManage.plazaAdService.findById(id);
			FileModel file = sysServiceManage.fileService.findByField("formId", id);
			zhanglmServiceManage.plazaAdService.deleteAndFile(model, file, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "PlazaAd禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			PlazaAdModel model = zhanglmServiceManage.plazaAdService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.plazaAdService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
