package com.jrzh.mvc.model.zhanglm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_snapshot_log")
public class SnapshotLogModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 对应黄金表id字段
     */
    @Column(name = "_snapshot_id")
    private Integer snapshotId;
    /**
     * 产品类型（0:1分钟|1：5分钟|2：15分钟|3：30分钟|4：60分钟）
     */
    @Column(name="_type")
    private Integer type;
    /**
     * 历史产品代码
     */
    @Column(name = "_old_symbol")
    private String oldSymbol;
    /**
     * 历史产品名称
     */
    @Column(name = "_old_name")
    private String oldName;
    /**
     * 历史存入时间
     */
    @Column(name = "_old_datetime")
    private Date oldDatetime;
    /**
     * 存入时间
     */
    @Column(name = "_datetime")
    private Date datetime;
    /**
     * 历史开盘价
     */
    @Column(name = "_old_open")
    private Double oldOpen;
    /**
     * 历史最高价
     */
    @Column(name = "_old_high")
    private Double oldHigh;
    /**
     * 历史最低价
     */
    @Column(name = "_old_low")
    private Double oldLow;
    /**
     * 历史最新价
     */
    @Column(name = "_old_close")
    private Double oldClose;
    /**
     * 历史买价
     */
    @Column(name = "_old_bid1price")
    private Double oldBid1price;
    /**
     * 历史买量
     */
    @Column(name = "_old_bid1volume")
    private Integer oldBid1volume;
    /**
     * 历史卖价
     */
    @Column(name = "old_ask1price")
    private Double oldAsk1price;
    /**
     * 历史卖量
     */
    @Column(name = "_old_ask1volume")
    private Integer oldAsk1volume;
    /**
     * 历史昨收价
     */
    @Column(name = "_old_pclose")
    private Double oldPclose;
    /**
     * 历史成交价
     */
    @Column(name = "_old_tvolume")
    private Double oldTvolume;
    /**
     * 历史成仓量
     */
    @Column(name = "_old_tvalue")
    private Double oldTvalue;

    public void setSnapshotId(Integer snapshotId) {
        this.snapshotId = snapshotId;
    }
    
    public Integer getSnapshotId() {
        return this.snapshotId;
    }
    public void setOldSymbol(String oldSymbol) {
        this.oldSymbol = oldSymbol;
    }
    
    public String getOldSymbol() {
        return this.oldSymbol;
    }
    public void setOldName(String oldName) {
        this.oldName = oldName;
    }
    
    public String getOldName() {
        return this.oldName;
    }
    public void setOldDatetime(Date oldDatetime) {
        this.oldDatetime = oldDatetime;
    }
    
    public Date getOldDatetime() {
        return this.oldDatetime;
    }
    public void setDatetime(Date datetime) {
        this.datetime = datetime;
    }
    
    public Date getDatetime() {
        return this.datetime;
    }
    public void setOldOpen(Double oldOpen) {
        this.oldOpen = oldOpen;
    }
    
    public Double getOldOpen() {
        return this.oldOpen;
    }
    public void setOldHigh(Double oldHigh) {
        this.oldHigh = oldHigh;
    }
    
    public Double getOldHigh() {
        return this.oldHigh;
    }
    public void setOldLow(Double oldLow) {
        this.oldLow = oldLow;
    }
    
    public Double getOldLow() {
        return this.oldLow;
    }
    public void setOldClose(Double oldClose) {
        this.oldClose = oldClose;
    }
    
    public Double getOldClose() {
        return this.oldClose;
    }
    public void setOldBid1price(Double oldBid1price) {
        this.oldBid1price = oldBid1price;
    }
    
    public Double getOldBid1price() {
        return this.oldBid1price;
    }
    public void setOldBid1volume(Integer oldBid1volume) {
        this.oldBid1volume = oldBid1volume;
    }
    
    public Integer getOldBid1volume() {
        return this.oldBid1volume;
    }
    public void setOldAsk1price(Double oldAsk1price) {
        this.oldAsk1price = oldAsk1price;
    }
    
    public Double getOldAsk1price() {
        return this.oldAsk1price;
    }
    public void setOldAsk1volume(Integer oldAsk1volume) {
        this.oldAsk1volume = oldAsk1volume;
    }
    
    public Integer getOldAsk1volume() {
        return this.oldAsk1volume;
    }
    public void setOldPclose(Double oldPclose) {
        this.oldPclose = oldPclose;
    }
    
    public Double getOldPclose() {
        return this.oldPclose;
    }
    public void setOldTvolume(Double oldTvolume) {
        this.oldTvolume = oldTvolume;
    }
    
    public Double getOldTvolume() {
        return this.oldTvolume;
    }
    public void setOldTvalue(Double oldTvalue) {
        this.oldTvalue = oldTvalue;
    }
    
    public Double getOldTvalue() {
        return this.oldTvalue;
    }

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
    

}