package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.mvc.convert.zhanglm.DownloadConvert;
import com.jrzh.mvc.dao.zhanglm.DownloadDaoI;
import com.jrzh.mvc.model.zhanglm.DownloadModel;
import com.jrzh.mvc.search.zhanglm.DownloadSearch;
import com.jrzh.mvc.service.zhanglm.DownloadServiceI;
import com.jrzh.mvc.view.zhanglm.DownloadView;

@Service("downloadService")
public class DownloadServiceImpl extends
		BaseServiceImpl<DownloadModel, DownloadSearch, DownloadView> implements
		DownloadServiceI {

	@Resource(name = "downloadDao")
	private DownloadDaoI downloadDao;

	@Override
	public BaseDaoI<DownloadModel> getDao() {
		return downloadDao;
	}

	@Override
	public BaseConvertI<DownloadModel, DownloadView> getConvert() {
		return new DownloadConvert();
	}

}
