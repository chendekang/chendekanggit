package com.jrzh.mvc.dao.zhanglm.impl;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jrzh.framework.base.dao.impl.BaseDaoImpl;
import com.jrzh.mvc.dao.zhanglm.MemberLogStatisticsDaoI;
import com.jrzh.mvc.model.zhanglm.GoldbinduseruserModel;
import com.jrzh.mvc.model.zhanglm.MemberLogStatisticsModel;
import com.jrzh.mvc.search.zhanglm.GoidCustomerSearch;
import com.jrzh.mvc.search.zhanglm.MemberLogStatisticsSearch;
@Repository("memberlogstatisticsdaoi")
public class MemberLogStatisticsDaoImpl  extends BaseDaoImpl<MemberLogStatisticsModel> implements MemberLogStatisticsDaoI{

	
	@Autowired
	private SessionFactory sessionFactory;


	@SuppressWarnings("unchecked")
	private Class<MemberLogStatisticsModel> getClazz(){
		return  (Class< MemberLogStatisticsModel >)((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}
	@Override
	public String save(MemberLogStatisticsModel model) {
		return ((String)this.sessionFactory.getCurrentSession().save(model));
	}



	@Override
	public Long countBySearch(GoidCustomerSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		search.setAutoDc(dc);
		Long count = (Long) dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
				.setProjection(Projections.rowCount()).uniqueResult();
		return Long.valueOf((count == null) ? 0L : count.longValue());
	}



	@SuppressWarnings("unchecked")
	@Override
	public List<MemberLogStatisticsModel> findListBySearch(GoidCustomerSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
		if (search != null) {
			search.setAutoDc(dc);
			return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession())
					.setFirstResult((search.getPage() - 1) * search.getRows()).setMaxResults(search.getRows()).list();
		}
		return dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).list();
	}
	@Override
	public MemberLogStatisticsModel findModelBySearch(MemberLogStatisticsSearch search) {
		DetachedCriteria dc = DetachedCriteria.forClass(getClazz());
	    search.setAutoDc(dc);
	    return (MemberLogStatisticsModel) dc.getExecutableCriteria(this.sessionFactory.getCurrentSession()).uniqueResult();
	}


	@Override
	public void update(MemberLogStatisticsModel model) {
		this.sessionFactory.getCurrentSession().update(model);
	}
	
	//添加绑定用户
	@Override
	public String savebinduser(GoldbinduseruserModel binduseruser) {
		return ((String)this.sessionFactory.getCurrentSession().save(binduseruser));
	}
}
