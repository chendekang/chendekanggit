package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.zhanglm.SnapshotLogModel;
import com.jrzh.mvc.model.zhanglm.SnapshotModel;
import com.jrzh.mvc.model.zhanglm.SnapshotSecondLogModel;
import com.jrzh.mvc.search.zhanglm.SnapshotLogSearch;
import com.jrzh.mvc.view.zhanglm.SnapshotLogView;

public interface SnapshotLogServiceI  extends BaseServiceI<SnapshotLogModel, SnapshotLogSearch, SnapshotLogView>{
	//记录黄金
	void saveSnapshowLog(SnapshotModel model,Integer type, SessionUser user ) throws Exception;
	//记录分钟数据
	void saveSnapshowLog(SnapshotSecondLogModel model, Integer type,SessionUser user) throws Exception;
}