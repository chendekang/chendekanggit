package com.jrzh.mvc.service.zhanglm.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.convert.zhanglm.GoldHistoryConvert;
import com.jrzh.mvc.dao.zhanglm.GoldHistoryDaoI;
import com.jrzh.mvc.model.zhanglm.GoldHistoryModel;
import com.jrzh.mvc.search.zhanglm.GoldHistorySearch;
import com.jrzh.mvc.service.zhanglm.GoldHistoryServiceI;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.GoldHistoryView;

@Service("goldHistoryService")
public class GoldHistoryServiceImpl extends
		BaseServiceImpl<GoldHistoryModel, GoldHistorySearch, GoldHistoryView> implements
		GoldHistoryServiceI {

	@Resource(name = "goldHistoryDao")
	private GoldHistoryDaoI goldHistoryDao;
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;

	@Override
	public BaseDaoI<GoldHistoryModel> getDao() {
		return goldHistoryDao;
	}

	@Override
	public BaseConvertI<GoldHistoryModel, GoldHistoryView> getConvert() {
		return new GoldHistoryConvert();
	}

	@Override
	public void addAndReset(List<GoldHistoryView> list, SessionUser user)
			throws Exception {
		for (GoldHistoryView view : list) {
			GoldHistoryModel model = new GoldHistoryConvert().addConvertByStr(view);
			zhanglmServiceManage.goldHistoryService.add(model, user);
		}
	}
	
}
