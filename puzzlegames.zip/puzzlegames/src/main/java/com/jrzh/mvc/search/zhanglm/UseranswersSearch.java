package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class UseranswersSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String equalUserId;
	

	private String eqtopicId;

	
	private String eqcategoryid;
	
	
	public String getEqcategoryid() {
		return eqcategoryid;
	}

	public void setEqcategoryid(String eqcategoryid) {
		this.eqcategoryid = eqcategoryid;
	}

	public String getEqualUserId() {
		return equalUserId;
	}

	public void setEqualUserId(String equalUserId) {
		this.equalUserId = equalUserId;
	}

	public String getEqtopicId() {
		return eqtopicId;
	}

	public void setEqtopicId(String eqtopicId) {
		this.eqtopicId = eqtopicId;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalUserId)){
			//用户id
			dc.add(Restrictions.eq("uid", equalUserId));
		}

		if(StringUtils.isNotBlank(eqtopicId)){
			//题目id
			dc.add(Restrictions.eq("qid", eqtopicId));
		}
		
		if(StringUtils.isNotBlank(eqcategoryid)){
			//题目id
			dc.add(Restrictions.eq("categoryid", eqcategoryid));
		}
	}

}