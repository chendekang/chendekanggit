package com.jrzh.mvc.service.zhanglm;

import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.view.zhanglm.DefaultView;

public interface DefaultServiceI  extends BaseServiceI<DefaultModel, DefaultSearch, DefaultView>{

	void addAndFile(DefaultModel model,FileModel file,SessionUser user) throws Exception;

	void editAndFile(DefaultModel model, FileModel file, SessionUser user)throws Exception;

	void deleteAndFile(DefaultModel model, FileModel file, SessionUser user)throws Exception;

}