package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class DotitleSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
		
	private String likeName;
	
	private Integer equalStatus;
	
	private String equalMenuCode;
	
	private String equalUserId;
	
	private Boolean equalIsDisable;
	
	private String  equalmenuid;
	
	public String getEqualmenuid() {
		return equalmenuid;
	}

	public void setEqualmenuid(String equalmenuid) {
		this.equalmenuid = equalmenuid;
	}

	public Boolean getEqualIsDisable() {
		return equalIsDisable;
	}

	public void setEqualIsDisable(Boolean equalIsDisable) {
		this.equalIsDisable = equalIsDisable;
	}

	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}

	public String getEqualUserId() {
		return equalUserId;
	}

	public void setEqualUserId(String equalUserId) {
		this.equalUserId = equalUserId;
	}

	public String getEqualMenuCode() {
		return equalMenuCode;
	}

	public void setEqualMenuCode(String equalMenuCode) {
		this.equalMenuCode = equalMenuCode;
	}

	public Integer getEqualStatus() {
		return equalStatus;
	}

	public void setEqualStatus(Integer equalStatus) {
		this.equalStatus = equalStatus;
	}

	@Override
	public void setDc(DetachedCriteria dc) {
		if(equalmenuid != null){
			dc.add(Restrictions.eq("menuid", equalmenuid));
		}
		if(equalStatus != null){
			dc.add(Restrictions.eq("status", equalStatus));
		}
		if(equalMenuCode != null){
			dc.add(Restrictions.eq("menuCode", equalMenuCode));
		}
		if(StringUtils.isNotBlank(equalUserId)){
			dc.add(Restrictions.eq("userid", equalUserId));
		}
		if(StringUtils.isNotBlank(likeName)){
			dc.add(Restrictions.like("title", "%"+likeName+"%"));
		}
		if(null != equalIsDisable){
			dc.add(Restrictions.eq("isDisable", equalIsDisable));
		}
	}

}