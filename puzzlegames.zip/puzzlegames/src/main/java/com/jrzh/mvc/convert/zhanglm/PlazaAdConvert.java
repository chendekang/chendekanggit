package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.PlazaAdModel;
import com.jrzh.mvc.view.zhanglm.PlazaAdView;

public class PlazaAdConvert implements BaseConvertI<PlazaAdModel, PlazaAdView> {

	@Override
	public PlazaAdModel addConvert(PlazaAdView view) throws ProjectException {
		PlazaAdModel model = new PlazaAdModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public PlazaAdModel editConvert(PlazaAdView view, PlazaAdModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public PlazaAdView convertToView(PlazaAdModel model) throws ProjectException {
		PlazaAdView view = new PlazaAdView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
