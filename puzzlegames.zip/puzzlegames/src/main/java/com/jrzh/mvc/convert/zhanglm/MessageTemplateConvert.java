package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.MessageTemplateModel;
import com.jrzh.mvc.view.zhanglm.MessageTemplateView;

public class MessageTemplateConvert implements BaseConvertI<MessageTemplateModel, MessageTemplateView> {

	@Override
	public MessageTemplateModel addConvert(MessageTemplateView view) throws ProjectException {
		MessageTemplateModel model = new MessageTemplateModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		if(null == view.getIsSendMobile()){
			model.setIsSendMobile(false);
		}
		if(null == view.getIsSendPlatform()){
			model.setIsSendPlatform(false);
		}
		return model;
	}

	@Override
	public MessageTemplateModel editConvert(MessageTemplateView view, MessageTemplateModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		if(null == view.getIsSendMobile()){
			model.setIsSendMobile(false);
		}
		if(null == view.getIsSendPlatform()){
			model.setIsSendPlatform(false);
		}
		return model;
	}

	@Override
	public MessageTemplateView convertToView(MessageTemplateModel model) throws ProjectException {
		MessageTemplateView view = new MessageTemplateView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
