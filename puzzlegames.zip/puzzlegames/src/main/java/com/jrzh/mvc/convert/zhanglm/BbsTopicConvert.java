package com.jrzh.mvc.convert.zhanglm;

import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.model.zhanglm.BbsTopicModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.view.zhanglm.BbsTopicView;

public class BbsTopicConvert implements BaseConvertI<BbsTopicModel, BbsTopicView> {

	@Override
	public BbsTopicModel addConvert(BbsTopicView view) throws ProjectException {
		BbsTopicModel model = new BbsTopicModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public BbsTopicModel editConvert(BbsTopicView view, BbsTopicModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public BbsTopicView convertToView(BbsTopicModel model) throws ProjectException {
		System.out.println(">>>>>>>>>>>convertToView>>>>>>>>>>>"+model);
		BbsTopicView view = new BbsTopicView();
		//ReflectUtils.copySameFieldToTarget(model, view);
		view.setId(model.getId());
		view.setTitle(model.getTitle());
		view.setContent(model.getContent());
		view.setUserId(model.getUserId());
		view.setDiscuss(model.getDiscuss());
		view.setPraise(model.getPraise());
		view.setAverage(model.getAverage());
		view.setMenuCode(model.getMenuCode());
		view.setStatus(model.getStatus());
		view.setAuditer(model.getAuditer());
		view.setOpinion(model.getOpinion());
		view.setSortNum(model.getSortNum());
		view.setCreateTime(model.getCreateTime());
		view.setIsDisable(model.getIsDisable());
		view.setAuditTime(model.getAuditTime());
		view.setClickNum(model.getClickNum());
		view.setMenuid(model.getMenuid());
		//阅读数
		view.setReadAccount(model.getReadAccount());
		//转发数
		view.setTransmit(model.getTransmit());
		//收藏数
		view.setCollection(model.getCollection());
		//话题id
		view.setMenuid(model.getMenuid());
		System.out.println(">>>>>>>>>>>>>>>>>>"+model.getImgUrl());
		view.setImgUrl(model.getImgUrl());
		MemberModel member = model.getMember();
		if(member != null){
			String nickName = member.getNickName();
			String photo = member.getPhoto();
			String intro = member.getIntro();
			if(StringUtils.isNotBlank(nickName)){
				view.setMenuName(nickName);
				view.setUserName(nickName);
			}else{
				view.setMenuName("平台用户");
			}
			if(StringUtils.isNotBlank(photo)){
				view.setUserPhoto(photo);
			}
			if(StringUtils.isNotBlank(intro)){
				view.setUserIntro(intro);
			}
			
		}
		if(model.getBbsMenu() != null){
			view.setMenuName(model.getBbsMenu().getName());
		}else{
			view.setMenuName("所属圈子信息不存在");
		}
		view.setStatusStr(BusinessConstants.BBS_TOPIC_STATUS.valueMap.get(view.getStatus()));
		if(StringUtils.isBlank(model.getAuditer())){
			view.setAuditer("------");
		}
		if(StringUtils.isBlank(model.getOpinion())){
			view.setOpinion("------");
		}
		view.setDataId(model.getId());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String createTime = sdf.format(model.getCreateTime());
		view.setTopicCreate(createTime);
		return view;
	}

}
