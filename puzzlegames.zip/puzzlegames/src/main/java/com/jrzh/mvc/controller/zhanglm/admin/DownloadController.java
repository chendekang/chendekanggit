package com.jrzh.mvc.controller.zhanglm.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.framework.bean.ResultBean;
import com.jrzh.mvc.convert.zhanglm.DownloadConvert;
import com.jrzh.mvc.model.zhanglm.DownloadModel;
import com.jrzh.mvc.search.zhanglm.DownloadSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.DownloadView;

@Controller(DownloadController.LOCATION +"/DownloadController")
@RequestMapping(DownloadController.LOCATION)
public class DownloadController extends BaseAdminController{
	public static final String LOCATION = "zhanglm/admin/download";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String FORM_PAGE = LOCATION + "/form";
	
	public static final String MODULE = "zhanglm_download";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "Download列表查询")
	@ResponseBody
	public EasyuiDataGrid<DownloadView> datagrid(DownloadSearch search) {
		EasyuiDataGrid<DownloadView> dg = new EasyuiDataGrid<DownloadView>();
	    try{
	    	dg = zhanglmServiceManage.downloadService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "add")
	public String preAdd() {
		request.setAttribute("view", new DownloadView());
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "add")
	@UserEvent(desc = "Download增加")
	@ResponseBody
	public ResultBean add(DownloadView view,BindingResult errors){
		ResultBean result = new ResultBean();
		try{
			String type = request.getParameter("type");
			DownloadModel model =new DownloadConvert().addConvert(view);
			model.setType(type);
			zhanglmServiceManage.downloadService.add(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("添加成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;	
	}


	
	@RequestMapping(method = RequestMethod.GET, value = "edit/{id}")
	public String preEdit(@PathVariable("id") String id) {
		try {
			request.setAttribute("view", zhanglmServiceManage.downloadService.findViewById(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FORM_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "edit/{id}")
	@UserEvent(desc = "Download修改")
	@ResponseBody
	public ResultBean edit(@PathVariable("id") String id, DownloadView view, BindingResult errors) {
		ResultBean result = new ResultBean();
		try {
			String type = request.getParameter("type");
			DownloadModel model = zhanglmServiceManage.downloadService.findById(id);
			model = new DownloadConvert().editConvert(view, model);
			model.setType(type);
			zhanglmServiceManage.downloadService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("修改成功");
		}catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	@RequestMapping(method = RequestMethod.POST, value = "delete/{id}")
	@UserEvent(desc = "Download删除")
	@ResponseBody
	public ResultBean delete(@PathVariable("id") String id) {
		ResultBean result = new ResultBean();
		try {
			DownloadModel model = zhanglmServiceManage.downloadService.findById(id);
			zhanglmServiceManage.downloadService.delete(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("删除成功");
		} catch (Exception ex) {
			ex.printStackTrace();
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "changeStatus/{id}")
	@UserEvent(desc = "Download禁用/启用状态")
	@ResponseBody
	public ResultBean changeStatus(@PathVariable("id") String id){
		ResultBean result = new ResultBean();
		try {
			DownloadModel model = zhanglmServiceManage.downloadService.findById(id);
			model.setIsDisable(!model.getIsDisable());
			zhanglmServiceManage.downloadService.edit(model, getSessionUser());
			result.setStatus(ResultBean.SUCCESS);
			result.setMsg("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.setMsg(e.getMessage());
		}
		return result;
	}
	
	@Override
	protected void setData() {
	}

}
