package com.jrzh.mvc.dao.zhanglm;

import java.util.List;

import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.mvc.model.zhanglm.AnswerModel;
import com.jrzh.mvc.search.zhanglm.AnswerSearch;
import com.jrzh.mvc.view.zhanglm.AnswerView;

public interface AnswerDaoI extends BaseDaoI<AnswerModel>{
	 public List<AnswerModel> selectByField(String paramString, Object paramObject);

	public List<AnswerModel> findList(AnswerSearch search);

	public AnswerModel getmodel(String id);

	public List<AnswerView> findBylistField(String string, String equalPid);

}
