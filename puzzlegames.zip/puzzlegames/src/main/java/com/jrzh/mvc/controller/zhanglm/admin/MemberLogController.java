package com.jrzh.mvc.controller.zhanglm.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.mvc.constants.BusinessConstants;
import com.jrzh.mvc.search.zhanglm.MemberSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.MemberView;

@Controller(MemberLogController.LOCATION +"/MemberLogController")
@RequestMapping(MemberLogController.LOCATION)
public class MemberLogController extends BaseAdminController {
	public static final String LOCATION = "statistics/admin/memberLog";
	
	public static final String INDEX_PAGE = LOCATION + "/index";
	
	public static final String REGISTER_INDEX_PAGE = LOCATION + "/registerIndex";
	
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	@RequestMapping(method = RequestMethod.GET,value = "index")
	public String index() {
		return INDEX_PAGE;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "datagrid")
	@UserEvent(desc = "Member列表查询")
	@ResponseBody
	public EasyuiDataGrid<MemberView> datagrid(MemberSearch search) {
		EasyuiDataGrid<MemberView> dg = new EasyuiDataGrid<MemberView>();
	    try{
	    	dg = zhanglmServiceManage.memberService.datagrid(search);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
		return dg;
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "registerIndex")
	public String registerIndex(MemberSearch search) {
		try {
			Long sum = zhanglmServiceManage.memberService.count(search);
			//平台注册
			search.setEqualLoginChannel(BusinessConstants.LOGIN_CHANNEL.PLATFORM);
			Long platSum = zhanglmServiceManage.memberService.count(search);
			//QQ注册
			search.setEqualLoginChannel(BusinessConstants.LOGIN_CHANNEL.QQ);
			Long qqSum = zhanglmServiceManage.memberService.count(search);
			//微博注册
			search.setEqualLoginChannel(BusinessConstants.LOGIN_CHANNEL.WEIBO);
			Long weiboSum = zhanglmServiceManage.memberService.count(search);
			//微信注册
			search.setEqualLoginChannel(BusinessConstants.LOGIN_CHANNEL.WECHAT);
			Long wechatSum = zhanglmServiceManage.memberService.count(search);
			request.setAttribute("sum", sum);
			request.setAttribute("platSum", platSum);
			request.setAttribute("qqSum", qqSum);
			request.setAttribute("weiboSum", weiboSum);
			request.setAttribute("wechatSum", wechatSum);
		} catch (ProjectException e) {
			e.printStackTrace();
		}
		return REGISTER_INDEX_PAGE;
	}
	
	@Override
	protected void setData() {

	}

}
