package com.jrzh.mvc.constants;

import java.util.HashMap;
import java.util.Map;

public interface BusinessConstants {
		public static final String RTMP_LIVE = "rtmp://zhangleme.rtmplive.ks-cdn.com/live/";//RTMP拉流域名

		//注册渠道
		public abstract class LOGIN_CHANNEL{
				public static final Integer PLATFORM = 0;
				public static final Integer WEIBO = 1;
				public static final Integer QQ = 2;
				public static final Integer WECHAT = 3;
				
				public static Map<Integer,  String> valueMap = new HashMap<Integer, String>();
				static{
					valueMap.put(PLATFORM, "平台");
					valueMap.put(WEIBO, "微博");
					valueMap.put(QQ, "QQ");
					valueMap.put(WECHAT, "微信");
				}
		}
		
		//预约开户状态
		public abstract class OPEN_ACCO_STATUS{
				public static final Integer SOLVE = 0;//已处理
				public static final Integer NOT_SOLVE = 1;//未处理
				
				public static Map<Integer,  String> valueMap = new HashMap<Integer, String>();
				static{
					valueMap.put(SOLVE, "已处理");
					valueMap.put(NOT_SOLVE, "未处理");
				}
		}
		
		//圈子话题状态
		public abstract class BBS_TOPIC_STATUS{
				public static final Integer AUDING = 0;//审核中
				public static final Integer NOT_AUDIT = 1;//未通过审核
				public static final Integer AUDIT = 2;//已通过审核
				
				public static Map<Integer,  String> valueMap = new HashMap<Integer, String>();
				static{
					valueMap.put(AUDING, "审核中");
					valueMap.put(NOT_AUDIT, "未通过审核");
					valueMap.put(AUDIT, "已通过审核");
				}
		}
		
		//反馈意见状态
		public abstract class FEED_BACK_STATUS{
				public static final Integer SOLVE = 0;//已处理
				public static final Integer NOT_SOLVE = 1;//未处理
				
				public static Map<Integer,  String> valueMap = new HashMap<Integer, String>();
				static{
					valueMap.put(SOLVE, "已处理");
					valueMap.put(NOT_SOLVE, "未处理");
				}
		}
		
		//用户消息状态
		public abstract class MEMBER_MSG_STATUS{
				public static final Integer READED = 0;//已读
				public static final Integer NOT_READ = 1;//未读
				
				public static Map<Integer,  String> valueMap = new HashMap<Integer, String>();
				static{
					valueMap.put(READED, "已读");
					valueMap.put(NOT_READ, "未读");
				}
		}
		
		//提现审核状态
		public abstract class WITHDROW_AUDIT_STATUS{
				public static final Integer AUDING = 0;//审核中
				public static final Integer NOT_AUDIT = 1;//未通过审核
				public static final Integer AUDIT = 2;//已通过审核
				
				public static Map<Integer,  String> valueMap = new HashMap<Integer, String>();
				static{
					valueMap.put(AUDING, "审核中");
					valueMap.put(NOT_AUDIT, "未通过审核");
					valueMap.put(AUDIT, "已通过审核");
				}
		}
		
		//广场数据类别
		public abstract class PLAZA_DATA_CATEGORY{
				public static final Integer TOPIC = 0;//话题
				public static final Integer ZHIBO = 1;//直播室
				
				public static Map<Integer,  String> valueMap = new HashMap<Integer, String>();
				static{
					valueMap.put(TOPIC, "话题");
					valueMap.put(ZHIBO, "直播室");
				}
		}
		
		//黄金K线数据类型
		public abstract class SNAPSHOT_TYPE{
			public static Integer ONE = 0;
			public static Integer FIVE = 1;
			public static Integer FIFTEEN = 2;
			public static Integer THIRTY = 3;
			public static Integer SIXTY = 4;
		}
		
		//关注状态
		public abstract class ATTENTION_STATUS{
				public static final Integer NOT_FAN = 0;//未关注
				public static final Integer IS_FAN = 1;//已关注
				public static final Integer TOGETHER = 2;//互相关注
		}
		
		//下载路径类型
		public abstract class DOWNLOAD_TYPE{
				public static final String ANDROID = "2";
				public static final String IOS = "1";
				public static final String OTHER = "0";
				
				public static Map<String,  String> valueMap = new HashMap<String, String>();
				static{
					valueMap.put(ANDROID, "android");
					valueMap.put(IOS, "ios");
					valueMap.put(OTHER, "其他");
				}
		}
		
}
