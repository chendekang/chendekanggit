package com.jrzh.mvc.controller.zhanglm.admin;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jrzh.framework.annotation.UserEvent;
import com.jrzh.framework.base.controller.BaseAdminController;
import com.jrzh.framework.bean.EasyuiDataGrid;
import com.jrzh.mvc.search.zhanglm.TodayDealSearch;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.TodayDealView;
@Controller(TodaydealController.LOCATION +"/TodaydealController")
@RequestMapping(TodaydealController.LOCATION)
public class TodaydealController  extends BaseAdminController{
public static final String LOCATION = "zhanglm/admin/memberLog";
	//当日成交
	public static final String TODAY_DAELIDEX = LOCATION + "/todaydealIndex";
	@Autowired
	private ZhanglmServiceManage zhanglmServiceManage;
	
	// 当日成交统计
	@RequestMapping(method = RequestMethod.GET, value = "todaydealIndex")
	public String todaydealIndex() {
		return TODAY_DAELIDEX;
	}

	@RequestMapping(method = RequestMethod.POST, value = "querytodaydeal")
	@UserEvent(desc = "当日成交统计列表查询")
	@ResponseBody
	public EasyuiDataGrid<TodayDealView> querytodaydeal(TodayDealSearch search) {
		EasyuiDataGrid<TodayDealView> dg = new EasyuiDataGrid<TodayDealView>();
		try {
			dg = zhanglmServiceManage.todaydealservicei.datagrid(search);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dg;
	}
	//导出当日成交统计
	@RequestMapping(method = RequestMethod.POST, value = "exporttodaydeal")
	@UserEvent(desc = "导出当日成交统计")
	@ResponseBody
	public void exporttodaydeal(TodayDealSearch search,HttpServletResponse response) {
	    try{
	    	
	    	zhanglmServiceManage.todaydealservicei.exporttodaydeal(search,response);
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
	}
	@Override
	protected void setData() {
		
	}
}
