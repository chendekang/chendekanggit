package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.common.exception.ProjectException;
import com.jrzh.mvc.model.zhanglm.GoldRecommendModel;
import com.jrzh.mvc.view.zhanglm.GoldRecommendView;
import com.jrzh.common.utils.ReflectUtils;

public class GoldRecommendConvert implements BaseConvertI<GoldRecommendModel, GoldRecommendView> {

	@Override
	public GoldRecommendModel addConvert(GoldRecommendView view) throws ProjectException {
		GoldRecommendModel model = new GoldRecommendModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public GoldRecommendModel editConvert(GoldRecommendView view, GoldRecommendModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public GoldRecommendView convertToView(GoldRecommendModel model) throws ProjectException {
		GoldRecommendView view = new GoldRecommendView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
