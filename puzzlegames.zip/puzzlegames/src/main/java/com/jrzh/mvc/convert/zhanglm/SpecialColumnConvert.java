package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.SpecialColumnModel;
import com.jrzh.mvc.view.zhanglm.SpecialColumnView;

public class SpecialColumnConvert implements BaseConvertI<SpecialColumnModel, SpecialColumnView> {

	@Override
	public SpecialColumnModel addConvert(SpecialColumnView view) throws ProjectException {
		SpecialColumnModel model = new SpecialColumnModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public SpecialColumnModel editConvert(SpecialColumnView view, SpecialColumnModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public SpecialColumnView convertToView(SpecialColumnModel model) throws ProjectException {
		SpecialColumnView view = new SpecialColumnView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
