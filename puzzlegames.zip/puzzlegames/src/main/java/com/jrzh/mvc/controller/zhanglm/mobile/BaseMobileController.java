package com.jrzh.mvc.controller.zhanglm.mobile;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.jrzh.common.cache.Cache;
import com.jrzh.common.cache.CacheManager;
import com.jrzh.config.ProjectConfigration;
import com.jrzh.framework.base.controller.BaseFrontController;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.constants.ConfigConstants;
import com.jrzh.mvc.constants.ZhanglmConstants;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.request.AlibabaAliqinFcSmsNumSendRequest;
import com.taobao.api.response.AlibabaAliqinFcSmsNumSendResponse;

public class BaseMobileController extends BaseFrontController{
	
	@Autowired
	private ProjectConfigration projectConfigration;
	
	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Autowired
	public SysServiceManage sysServiceManage;
	
	//private SendSmsImpl sendsms = new SendSmsImpl();
	
	protected Boolean isLogin(){
		return null != getSessionUser();
	}
	
	protected Boolean isMobileLogin(){
		return null != getMobileUser();
	}

	@Override
	protected SessionUser getSessionUser( ) {
		SessionUser user = null;
		String mac = request.getParameter("userId");
		Cache cache = CacheManager.getCacheInfo("userCache"+mac);
		if(null != cache){
			user = (SessionUser)cache.getValue();
		}
		return user;
	}
	
	protected SessionUser getMobileUser() {
		String userId = request.getParameter("userId");
		SessionUser user = null;
		Cache cache = CacheManager.getCacheInfo("userCache"+userId);
		if(null != cache){
			user = (SessionUser)cache.getValue();
		}
		return user;
	}

	protected String sendMobileCode(String mobile) throws Exception {
		String code = System.currentTimeMillis() + "";
		code = code.substring(code.length()-4);
		if(projectConfigration.env.equals(ZhanglmConstants.ENV_PARAM.PROD)){
			String appKey = sysServiceManage.configService.getValue(ConfigConstants.SMS_ACCOUNT);
			String appPass = sysServiceManage.configService.getValue(ConfigConstants.SMS_PASSWORD);
			TaobaoClient client = new DefaultTaobaoClient("http://gw.api.taobao.com/router/rest", appKey, appPass);
			AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest();
			req.setExtend(code);
			req.setSmsType("normal");
			req.setSmsFreeSignName("注册验证");
			req.setSmsParamString("{\"code\":\""+code+"\",\"product\":\"：吃掉你的脑子\"}");
			req.setRecNum(mobile);
			req.setSmsTemplateCode("SMS_12796019");
			AlibabaAliqinFcSmsNumSendResponse rsp = client.execute(req);
			System.out.println("appKey:"+appKey+"----appPass:"+appPass+">>>>>>>>>>>>>>>"+rsp.getBody()); 
		}
		System.out.println("mobile:"+mobile+">>>code【"+code+"】");
		Cache cache = new Cache();
		cache.setKey(mobile);
		cache.setValue(code);
		CacheManager.putCache(mobile, cache);
		return code;
	}

	protected String validateMobileCode(String mobile, String code) {
		String result = "";
		Cache cache = CacheManager.getCacheInfo(mobile);
		if(null !=  cache){
			String mobileCode = (String)cache.getValue();
			if(StringUtils.isNotBlank(mobileCode)){
				if(!StringUtils.equals(code, mobileCode)){
					result = "验证码不正确";
				}
			}else{
				result = "验证码已过期";
			}
		}else{
			result = "验证码或手机号码不存在";
		}
		return result;
	}
	
	@Override
	protected void setData() {
		
	}
}
