package com.jrzh.mvc.convert.zhanglm;

import org.apache.commons.lang.StringUtils;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.BbsCommentsModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.view.zhanglm.BbsCommentsView;

public class BbsCommentsConvert implements BaseConvertI<BbsCommentsModel, BbsCommentsView> {

	@Override
	public BbsCommentsModel addConvert(BbsCommentsView view) throws ProjectException {
		BbsCommentsModel model = new BbsCommentsModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public BbsCommentsModel editConvert(BbsCommentsView view, BbsCommentsModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public BbsCommentsView convertToView(BbsCommentsModel model) throws ProjectException {
		BbsCommentsView view = new BbsCommentsView();
		ReflectUtils.copySameFieldToTarget(model, view);
		MemberModel member = model.getMember();
		if(null != member){
			String userName = member.getNickName();
			String userPhoto = member.getPhoto();
			if(StringUtils.isNotBlank(userPhoto)){
				view.setUserPhoto(userPhoto);
			}
			if(StringUtils.isNotBlank(userName)){
				view.setUserName(userName);
			}else{
				view.setUserName("未设置用户名");
			}
		}
		return view;
	}

}
