package com.jrzh.mvc.search.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.jrzh.framework.base.search.BaseSearch;

public class BbsFanSearch extends BaseSearch{
	private static final long serialVersionUID = 1L;
	
	private String equalMenuIds;
	
	private String equalUserId;
	private String equalMenuId;
		
	private String likeName;
	
	public String getLikeName() {
		return likeName;
	}

	public void setLikeName(String likeName) {
		this.likeName = likeName;
	}

	public String getEqualMenuIds() {
		return equalMenuIds;
	}

	public void setEqualMenuIds(String equalMenuIds) {
		this.equalMenuIds = equalMenuIds;
	}

	public String getEqualUserId() {
		return equalUserId;
	}

	public void setEqualUserId(String equalUserId) {
		this.equalUserId = equalUserId;
	}

	public String getEqualMenuId() {
		return equalMenuId;
	}

	public void setEqualMenuId(String equalMenuId) {
		this.equalMenuId = equalMenuId;
	}
	@Override
	public void setDc(DetachedCriteria dc) {
		if(StringUtils.isNotBlank(equalMenuIds)){
		dc.createAlias("bbsMenu", "bbsMenu");
		if(StringUtils.isNotBlank(equalMenuIds)){
				dc.add(Restrictions.eq("bbsMenu.id", equalMenuIds));
		    }
		}
		if(StringUtils.isNotBlank(likeName)){
			dc.createAlias("member", "member");
			if(StringUtils.isNotBlank(likeName)){
				dc.add(Restrictions.like("member.nickName", "%"+likeName+"%"));	
			}
		}
		if(StringUtils.isNotBlank(equalMenuId)){
			dc.add(Restrictions.eq("menuId", equalMenuId));
		}
		if(StringUtils.isNotBlank(equalUserId)){
			dc.add(Restrictions.eq("userId", equalUserId));
		}
	}
}