package com.jrzh.mvc.service.zhanglm;
import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.mvc.model.zhanglm.AnswerModel;
import com.jrzh.mvc.search.zhanglm.AnswerSearch;
import com.jrzh.mvc.view.zhanglm.AnswerView;
public interface AnswerServiceI{
	List<AnswerModel> viewListall(AnswerSearch search)throws ProjectException;
	void add(AnswerModel views)throws ProjectException;
	List<AnswerView> viewListallzb(AnswerSearch zhibocoursesearch);
	void deletecourse(List<AnswerModel> viewList) throws ProjectException;
	void edit(AnswerModel model) throws ProjectException;
	List<AnswerView> viewList(AnswerSearch answwer) throws ProjectException;
	AnswerModel findById(String id);


}            