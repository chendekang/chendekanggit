package com.jrzh.mvc.service.zhanglm;

import java.util.List;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.framework.base.service.BaseServiceI;
import com.jrzh.mvc.model.zhanglm.BbsReplyModel;
import com.jrzh.mvc.search.zhanglm.BbsReplySearch;
import com.jrzh.mvc.view.zhanglm.BbsReplyView;

public interface BbsReplyServiceI  extends BaseServiceI<BbsReplyModel, BbsReplySearch, BbsReplyView>{

	List<BbsReplyView> viewListbbsReply(BbsReplySearch replySearch, String userId) throws ProjectException;

}