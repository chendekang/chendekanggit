package com.jrzh.mvc.convert.zhanglm;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.MemberAttentionModel;
import com.jrzh.mvc.model.zhanglm.MemberModel;
import com.jrzh.mvc.service.zhanglm.manage.ZhanglmServiceManage;
import com.jrzh.mvc.view.zhanglm.MemberAttentionView;

public class MemberAttentionConvert implements BaseConvertI<MemberAttentionModel, MemberAttentionView> {

	@Autowired
	public ZhanglmServiceManage zhanglmServiceManage;
	
	@Override
	public MemberAttentionModel addConvert(MemberAttentionView view) throws ProjectException {
		MemberAttentionModel model = new MemberAttentionModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public MemberAttentionModel editConvert(MemberAttentionView view, MemberAttentionModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public MemberAttentionView convertToView(MemberAttentionModel model) throws ProjectException {
		MemberAttentionView view = new MemberAttentionView();
		ReflectUtils.copySameFieldToTarget(model, view);
		//关注对象
		MemberModel member = model.getMember();
		if(member != null){
			view.setPhoto(member.getPhoto());
			view.setNickName(member.getNickName());
			if(StringUtils.isBlank(view.getNickName())){
				view.setNickName("用户未设置昵称");
			}
		}
		//粉丝对象
		MemberModel fans = model.getFans();
		if(fans != null){
			view.setFansPhoto(fans.getPhoto());
			view.setFansName(fans.getNickName());
		}
		return view;
	}

}
