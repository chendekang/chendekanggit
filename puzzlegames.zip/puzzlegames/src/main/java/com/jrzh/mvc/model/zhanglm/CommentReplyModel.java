package com.jrzh.mvc.model.zhanglm;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.jrzh.framework.base.model.BaseModel;

@Entity
@Table(name = "zlm_comment_reply")
public class CommentReplyModel extends BaseModel {
	private static final long serialVersionUID = 1L;
    
    /**
     * 用户Id
     */
    @Column(name = "_user_id")
    private String userId;
    /**
     * 关联用户
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.PERSIST, targetEntity = MemberModel.class)
	@JoinColumn(name = "_user_id", referencedColumnName = "_id",insertable=false,updatable=false)
	@NotFound(action=NotFoundAction.IGNORE)
    private MemberModel member;
    /**
     * 评论回复内容
     */
    @Column(name = "_comment")
    private String content;
    /**
     * 评论Id
     */
    @Column(name = "_comment_id")
    private String commentId;
    /**
     * 回复Id
     */
    @Column(name = "_reply_id")
    private String replyId;
    
    /**
     * 点赞数
     */
    @Column(name = "_praise")
    private Integer praise;
    
    /**
     * 状态1是回复回复
     */
    @Column(name = "_state")
    private Integer state;
   
    /**
     * 回复人
     */
    @Column(name = "_reply_Name")
    private String replyname;
   

    
    /**
     * 回复用户Id
     */
    @Column(name = "_replyuser_id")
    private String replyuserId;
    
    
	public String getReplyuserId() {
		return replyuserId;
	}

	public void setReplyuserId(String replyuserId) {
		this.replyuserId = replyuserId;
	}

	public String getReplyname() {
		return replyname;
	}

	public void setReplyname(String replyname) {
		this.replyname = replyname;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getPraise() {
		return praise;
	}

	public void setPraise(Integer praise) {
		this.praise = praise;
	}

	public String getCommentId() {
		return commentId;
	}

	public void setCommentId(String commentId) {
		this.commentId = commentId;
	}

	public MemberModel getMember() {
		return member;
	}

	public void setMember(MemberModel member) {
		this.member = member;
	}


	public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getUserId() {
        return this.userId;
    }

    
    public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setReplyId(String replyId) {
        this.replyId = replyId;
    }
    
    public String getReplyId() {
        return this.replyId;
    }

}