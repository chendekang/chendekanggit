package com.jrzh.mvc.convert.zhanglm;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.SharePageModel;
import com.jrzh.mvc.view.zhanglm.SharePageView;

public class SharePageConvert implements BaseConvertI<SharePageModel, SharePageView> {

	@Override
	public SharePageModel addConvert(SharePageView view) throws ProjectException {
		SharePageModel model = new SharePageModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public SharePageModel editConvert(SharePageView view, SharePageModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public SharePageView convertToView(SharePageModel model) throws ProjectException {
		SharePageView view = new SharePageView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

}
