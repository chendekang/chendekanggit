package com.jrzh.mvc.convert.zhanglm;

import java.util.Date;

import com.jrzh.common.exception.ProjectException;
import com.jrzh.common.utils.ReflectUtils;
import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.mvc.model.zhanglm.SnapshotModel;
import com.jrzh.mvc.model.zhanglm.SnapshotSecondLogModel;
import com.jrzh.mvc.view.zhanglm.SnapshotSecondLogView;

public class SnapshotSecondLogConvert implements BaseConvertI<SnapshotSecondLogModel, SnapshotSecondLogView> {

	@Override
	public SnapshotSecondLogModel addConvert(SnapshotSecondLogView view) throws ProjectException {
		SnapshotSecondLogModel model = new SnapshotSecondLogModel();
		ReflectUtils.copySameFieldToTarget(view, model);
		return model;
	}

	@Override
	public SnapshotSecondLogModel editConvert(SnapshotSecondLogView view, SnapshotSecondLogModel model) throws ProjectException {
		ReflectUtils.copySameFieldToTargetFilter(view, model, new String[]{"createBy", "createTime"});
		return model;
	}

	@Override
	public SnapshotSecondLogView convertToView(SnapshotSecondLogModel model) throws ProjectException {
		SnapshotSecondLogView view = new SnapshotSecondLogView();
		ReflectUtils.copySameFieldToTarget(model, view);
		return view;
	}

	public SnapshotSecondLogModel convertSnapshotToSnapshotLog(SnapshotModel model) {
		SnapshotSecondLogModel logModel = new SnapshotSecondLogModel();
		logModel.setOldClose(model.getClose());
		logModel.setOldDatetime(new Date());
		logModel.setSnapshotId(model.getId());
		logModel.setOldName(model.getName());
		logModel.setOldTvolume(model.getTvolume());
		logModel.setOldTvalue(model.getTvalue());
		logModel.setOldSymbol(model.getSymbol());
		return logModel;
	}

}
