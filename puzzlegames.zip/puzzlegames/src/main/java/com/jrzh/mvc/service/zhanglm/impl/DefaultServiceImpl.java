package com.jrzh.mvc.service.zhanglm.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jrzh.framework.base.convert.BaseConvertI;
import com.jrzh.framework.base.dao.BaseDaoI;
import com.jrzh.framework.base.service.impl.BaseServiceImpl;
import com.jrzh.framework.bean.SessionUser;
import com.jrzh.mvc.convert.zhanglm.DefaultConvert;
import com.jrzh.mvc.dao.zhanglm.DefaultDaoI;
import com.jrzh.mvc.model.sys.FileModel;
import com.jrzh.mvc.model.zhanglm.DefaultModel;
import com.jrzh.mvc.search.zhanglm.DefaultSearch;
import com.jrzh.mvc.service.sys.manage.SysServiceManage;
import com.jrzh.mvc.service.zhanglm.DefaultServiceI;
import com.jrzh.mvc.view.zhanglm.DefaultView;

@Service("defaultService")
public class DefaultServiceImpl extends
		BaseServiceImpl<DefaultModel, DefaultSearch, DefaultView> implements
		DefaultServiceI {

	@Autowired
	public SysServiceManage sysServiceManage;
	
	@Resource(name = "defaultDao")
	private DefaultDaoI defaultDao;

	@Override
	public BaseDaoI<DefaultModel> getDao() {
		return defaultDao;
	}

	@Override
	public BaseConvertI<DefaultModel, DefaultView> getConvert() {
		return new DefaultConvert();
	}

	@Override
	public void addAndFile(DefaultModel model, FileModel file, SessionUser user)throws Exception {
		this.add(model, user);
		if(file != null){
			file.setFormId(model.getId());
			sysServiceManage.fileService.add(file, user);
		}
		
	}

	@Override
	public void editAndFile(DefaultModel model, FileModel file, SessionUser user)throws Exception {
		this.edit(model, user);
		if(file != null){
			sysServiceManage.fileService.edit(file, user);
		}
		
	}

	@Override
	public void deleteAndFile(DefaultModel model, FileModel file,SessionUser user) throws Exception {
		this.delete(model, user);
		if(file != null){
			sysServiceManage.fileService.delete(file, user);
		}
		
	}
}
