package com.jrzh.config.zhanglm;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("zhanglmConfigration")
public class ZhanglmConfigration implements Serializable {
	private static final long serialVersionUID = 4854552459224578198L;
	
	@Value("${project_base_url}")
	public String projectBaseUrl;
	
	@Value("${project_cache_url}")
	public String projectCacheUrl;
	
	@Value("${project_tourist_url}")
	public String projectTouristUrl;
	
	@Value("${project_del_cache_url}")
	public String projectDelCacheUrl;
	
}
