package com.jrzh.bean;

import com.jrzh.framework.base.BaseBean;


public class MobileResultBean extends BaseBean{

	private static final long serialVersionUID = 3519738894821921582L;
	
	public static final String SUCCESS = "1";
	public static final String ERROR = "0";
	public MobileResultBean(){
		this.status = ERROR;
	}
	
	private String status;
	
	private String message;
	
	private Object object;
	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}
}
